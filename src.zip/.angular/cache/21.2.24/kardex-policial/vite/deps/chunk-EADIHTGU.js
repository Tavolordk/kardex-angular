import {
  CanvasFilterSystem,
  FilterPipe,
  FilterSystem
} from "./chunk-2TIJWRQZ.js";
import {
  extensions
} from "./chunk-YC5XMVVP.js";

// node_modules/pixi.js/lib/filters/init.mjs
extensions.add(FilterSystem, CanvasFilterSystem);
extensions.add(FilterPipe);
//# sourceMappingURL=chunk-EADIHTGU.js.map
