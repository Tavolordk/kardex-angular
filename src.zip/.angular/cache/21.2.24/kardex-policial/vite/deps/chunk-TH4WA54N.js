import {
  Cache
} from "./chunk-A5DJO54Z.js";
import {
  FillGradient,
  FillPattern,
  GraphicsContext,
  toFillStyle,
  toStrokeStyle
} from "./chunk-MGJ7YREG.js";
import {
  ImageSource,
  canvasUtils
} from "./chunk-DBITZEUE.js";
import {
  CanvasPool,
  Color,
  DOMAdapter,
  Matrix,
  Rectangle,
  Texture,
  TextureStyle,
  deprecation,
  eventemitter3_default,
  groupD8,
  uid,
  v8_0_0,
  warn
} from "./chunk-YC5XMVVP.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-I6DCS273.js";

// node_modules/pixi.js/lib/scene/text-bitmap/AbstractBitmapFont.mjs
var AbstractBitmapFont = class extends eventemitter3_default {
  constructor() {
    super(...arguments);
    this.chars = /* @__PURE__ */ Object.create(null);
    this.lineHeight = 0;
    this.fontFamily = "";
    this.fontMetrics = { fontSize: 0, ascent: 0, descent: 0 };
    this.baseLineOffset = 0;
    this.distanceField = { type: "none", range: 0 };
    this.pages = [];
    this.applyFillAsTint = true;
    this.baseMeasurementFontSize = 100;
    this.baseRenderedFontSize = 100;
  }
  /**
   * The name of the font face.
   * @deprecated since 8.0.0 Use `fontFamily` instead.
   */
  get font() {
    deprecation(v8_0_0, "BitmapFont.font is deprecated, please use BitmapFont.fontFamily instead.");
    return this.fontFamily;
  }
  /**
   * The map of base page textures (i.e., sheets of glyphs).
   * @deprecated since 8.0.0 Use `pages` instead.
   */
  get pageTextures() {
    deprecation(v8_0_0, "BitmapFont.pageTextures is deprecated, please use BitmapFont.pages instead.");
    return this.pages;
  }
  /**
   * The size of the font face in pixels.
   * @deprecated since 8.0.0 Use `fontMetrics.fontSize` instead.
   */
  get size() {
    deprecation(v8_0_0, "BitmapFont.size is deprecated, please use BitmapFont.fontMetrics.fontSize instead.");
    return this.fontMetrics.fontSize;
  }
  /**
   * The kind of distance field for this font or "none".
   * @deprecated since 8.0.0 Use `distanceField.type` instead.
   */
  get distanceFieldRange() {
    deprecation(v8_0_0, "BitmapFont.distanceFieldRange is deprecated, please use BitmapFont.distanceField.range instead.");
    return this.distanceField.range;
  }
  /**
   * The range of the distance field in pixels.
   * @deprecated since 8.0.0 Use `distanceField.range` instead.
   */
  get distanceFieldType() {
    deprecation(v8_0_0, "BitmapFont.distanceFieldType is deprecated, please use BitmapFont.distanceField.type instead.");
    return this.distanceField.type;
  }
  destroy(destroyTextures = false) {
    this.emit("destroy", this);
    this.removeAllListeners();
    for (const i in this.chars) {
      this.chars[i].texture?.destroy();
    }
    this.chars = null;
    if (destroyTextures) {
      this.pages.forEach((page) => page.texture.destroy(true));
      this.pages = null;
    }
  }
};

// node_modules/tiny-lru/dist/tiny-lru.js
var LRU = class {
  /**
   * Creates a new LRU cache instance.
   * Note: Constructor does not validate parameters. Use lru() factory function for parameter validation.
   *
   * @constructor
   * @param {number} [max=0] - Maximum number of items to store. 0 means unlimited.
   * @param {number} [ttl=0] - Time to live in milliseconds. 0 means no expiration.
   * @param {boolean} [resetTtl=false] - Whether to reset TTL when accessing existing items via get().
   * @example
   * const cache = new LRU(1000, 60000, true); // 1000 items, 1 minute TTL, reset on access
   * @see {@link lru} For parameter validation
   * @since 1.0.0
   */
  constructor(max = 0, ttl = 0, resetTtl = false) {
    this.first = null;
    this.items = /* @__PURE__ */ Object.create(null);
    this.last = null;
    this.max = max;
    this.resetTtl = resetTtl;
    this.size = 0;
    this.ttl = ttl;
  }
  /**
   * Removes all items from the cache.
   *
   * @method clear
   * @memberof LRU
   * @returns {LRU} The LRU instance for method chaining.
   * @example
   * cache.clear();
   * console.log(cache.size); // 0
   * @since 1.0.0
   */
  clear() {
    this.first = null;
    this.items = /* @__PURE__ */ Object.create(null);
    this.last = null;
    this.size = 0;
    return this;
  }
  /**
   * Removes an item from the cache by key.
   *
   * @method delete
   * @memberof LRU
   * @param {string} key - The key of the item to delete.
   * @returns {LRU} The LRU instance for method chaining.
   * @example
   * cache.set('key1', 'value1');
   * cache.delete('key1');
   * console.log(cache.has('key1')); // false
   * @see {@link LRU#has}
   * @see {@link LRU#clear}
   * @since 1.0.0
   */
  delete(key) {
    if (this.has(key)) {
      const item = this.items[key];
      delete this.items[key];
      this.size--;
      if (item.prev !== null) {
        item.prev.next = item.next;
      }
      if (item.next !== null) {
        item.next.prev = item.prev;
      }
      if (this.first === item) {
        this.first = item.next;
      }
      if (this.last === item) {
        this.last = item.prev;
      }
    }
    return this;
  }
  /**
   * Returns an array of [key, value] pairs for the specified keys.
   * Order follows LRU order (least to most recently used).
   *
   * @method entries
   * @memberof LRU
   * @param {string[]} [keys=this.keys()] - Array of keys to get entries for. Defaults to all keys.
   * @returns {Array<Array<*>>} Array of [key, value] pairs in LRU order.
   * @example
   * cache.set('a', 1).set('b', 2);
   * console.log(cache.entries()); // [['a', 1], ['b', 2]]
   * console.log(cache.entries(['a'])); // [['a', 1]]
   * @see {@link LRU#keys}
   * @see {@link LRU#values}
   * @since 11.1.0
   */
  entries(keys = this.keys()) {
    const result = new Array(keys.length);
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      result[i] = [key, this.get(key)];
    }
    return result;
  }
  /**
   * Removes the least recently used item from the cache.
   *
   * @method evict
   * @memberof LRU
   * @param {boolean} [bypass=false] - Whether to force eviction even when cache is empty.
   * @returns {LRU} The LRU instance for method chaining.
   * @example
   * cache.set('old', 'value').set('new', 'value');
   * cache.evict(); // Removes 'old' item
   * @see {@link LRU#setWithEvicted}
   * @since 1.0.0
   */
  evict(bypass = false) {
    if (bypass || this.size > 0) {
      const item = this.first;
      delete this.items[item.key];
      if (--this.size === 0) {
        this.first = null;
        this.last = null;
      } else {
        this.first = item.next;
        this.first.prev = null;
      }
    }
    return this;
  }
  /**
   * Returns the expiration timestamp for a given key.
   *
   * @method expiresAt
   * @memberof LRU
   * @param {string} key - The key to check expiration for.
   * @returns {number|undefined} The expiration timestamp in milliseconds, or undefined if key doesn't exist.
   * @example
   * const cache = new LRU(100, 5000); // 5 second TTL
   * cache.set('key1', 'value1');
   * console.log(cache.expiresAt('key1')); // timestamp 5 seconds from now
   * @see {@link LRU#get}
   * @see {@link LRU#has}
   * @since 1.0.0
   */
  expiresAt(key) {
    let result;
    if (this.has(key)) {
      result = this.items[key].expiry;
    }
    return result;
  }
  /**
   * Retrieves a value from the cache by key. Updates the item's position to most recently used.
   *
   * @method get
   * @memberof LRU
   * @param {string} key - The key to retrieve.
   * @returns {*} The value associated with the key, or undefined if not found or expired.
   * @example
   * cache.set('key1', 'value1');
   * console.log(cache.get('key1')); // 'value1'
   * console.log(cache.get('nonexistent')); // undefined
   * @see {@link LRU#set}
   * @see {@link LRU#has}
   * @since 1.0.0
   */
  get(key) {
    const item = this.items[key];
    if (item !== void 0) {
      if (this.ttl > 0) {
        if (item.expiry <= Date.now()) {
          this.delete(key);
          return void 0;
        }
      }
      this.moveToEnd(item);
      return item.value;
    }
    return void 0;
  }
  /**
   * Checks if a key exists in the cache.
   *
   * @method has
   * @memberof LRU
   * @param {string} key - The key to check for.
   * @returns {boolean} True if the key exists, false otherwise.
   * @example
   * cache.set('key1', 'value1');
   * console.log(cache.has('key1')); // true
   * console.log(cache.has('nonexistent')); // false
   * @see {@link LRU#get}
   * @see {@link LRU#delete}
   * @since 9.0.0
   */
  has(key) {
    return key in this.items;
  }
  /**
   * Efficiently moves an item to the end of the LRU list (most recently used position).
   * This is an internal optimization method that avoids the overhead of the full set() operation
   * when only LRU position needs to be updated.
   *
   * @method moveToEnd
   * @memberof LRU
   * @param {Object} item - The cache item with prev/next pointers to reposition.
   * @private
   * @since 11.3.5
   */
  moveToEnd(item) {
    if (this.last === item) {
      return;
    }
    if (item.prev !== null) {
      item.prev.next = item.next;
    }
    if (item.next !== null) {
      item.next.prev = item.prev;
    }
    if (this.first === item) {
      this.first = item.next;
    }
    item.prev = this.last;
    item.next = null;
    if (this.last !== null) {
      this.last.next = item;
    }
    this.last = item;
    if (this.first === null) {
      this.first = item;
    }
  }
  /**
   * Returns an array of all keys in the cache, ordered from least to most recently used.
   *
   * @method keys
   * @memberof LRU
   * @returns {string[]} Array of keys in LRU order.
   * @example
   * cache.set('a', 1).set('b', 2);
   * cache.get('a'); // Move 'a' to most recent
   * console.log(cache.keys()); // ['b', 'a']
   * @see {@link LRU#values}
   * @see {@link LRU#entries}
   * @since 9.0.0
   */
  keys() {
    const result = new Array(this.size);
    let x = this.first;
    let i = 0;
    while (x !== null) {
      result[i++] = x.key;
      x = x.next;
    }
    return result;
  }
  /**
   * Sets a value in the cache and returns any evicted item.
   *
   * @method setWithEvicted
   * @memberof LRU
   * @param {string} key - The key to set.
   * @param {*} value - The value to store.
   * @param {boolean} [resetTtl=this.resetTtl] - Whether to reset the TTL for this operation.
   * @returns {Object|null} The evicted item (if any) with shape {key, value, expiry, prev, next}, or null.
   * @example
   * const cache = new LRU(2);
   * cache.set('a', 1).set('b', 2);
   * const evicted = cache.setWithEvicted('c', 3); // evicted = {key: 'a', value: 1, ...}
   * @see {@link LRU#set}
   * @see {@link LRU#evict}
   * @since 11.3.0
   */
  setWithEvicted(key, value, resetTtl = this.resetTtl) {
    let evicted = null;
    if (this.has(key)) {
      this.set(key, value, true, resetTtl);
    } else {
      if (this.max > 0 && this.size === this.max) {
        evicted = __spreadValues({}, this.first);
        this.evict(true);
      }
      let item = this.items[key] = {
        expiry: this.ttl > 0 ? Date.now() + this.ttl : this.ttl,
        key,
        prev: this.last,
        next: null,
        value
      };
      if (++this.size === 1) {
        this.first = item;
      } else {
        this.last.next = item;
      }
      this.last = item;
    }
    return evicted;
  }
  /**
   * Sets a value in the cache. Updates the item's position to most recently used.
   *
   * @method set
   * @memberof LRU
   * @param {string} key - The key to set.
   * @param {*} value - The value to store.
   * @param {boolean} [bypass=false] - Internal parameter for setWithEvicted method.
   * @param {boolean} [resetTtl=this.resetTtl] - Whether to reset the TTL for this operation.
   * @returns {LRU} The LRU instance for method chaining.
   * @example
   * cache.set('key1', 'value1')
   *      .set('key2', 'value2')
   *      .set('key3', 'value3');
   * @see {@link LRU#get}
   * @see {@link LRU#setWithEvicted}
   * @since 1.0.0
   */
  set(key, value, bypass = false, resetTtl = this.resetTtl) {
    let item = this.items[key];
    if (bypass || item !== void 0) {
      item.value = value;
      if (bypass === false && resetTtl) {
        item.expiry = this.ttl > 0 ? Date.now() + this.ttl : this.ttl;
      }
      this.moveToEnd(item);
    } else {
      if (this.max > 0 && this.size === this.max) {
        this.evict(true);
      }
      item = this.items[key] = {
        expiry: this.ttl > 0 ? Date.now() + this.ttl : this.ttl,
        key,
        prev: this.last,
        next: null,
        value
      };
      if (++this.size === 1) {
        this.first = item;
      } else {
        this.last.next = item;
      }
      this.last = item;
    }
    return this;
  }
  /**
   * Returns an array of all values in the cache for the specified keys.
   * Order follows LRU order (least to most recently used).
   *
   * @method values
   * @memberof LRU
   * @param {string[]} [keys=this.keys()] - Array of keys to get values for. Defaults to all keys.
   * @returns {Array<*>} Array of values corresponding to the keys in LRU order.
   * @example
   * cache.set('a', 1).set('b', 2);
   * console.log(cache.values()); // [1, 2]
   * console.log(cache.values(['a'])); // [1]
   * @see {@link LRU#keys}
   * @see {@link LRU#entries}
   * @since 11.1.0
   */
  values(keys = this.keys()) {
    const result = new Array(keys.length);
    for (let i = 0; i < keys.length; i++) {
      result[i] = this.get(keys[i]);
    }
    return result;
  }
};
function lru(max = 1e3, ttl = 0, resetTtl = false) {
  if (isNaN(max) || max < 0) {
    throw new TypeError("Invalid max value");
  }
  if (isNaN(ttl) || ttl < 0) {
    throw new TypeError("Invalid ttl value");
  }
  if (typeof resetTtl !== "boolean") {
    throw new TypeError("Invalid resetTtl value");
  }
  return new LRU(max, ttl, resetTtl);
}

// node_modules/pixi.js/lib/scene/text/canvas/utils/parseTaggedText.mjs
function hasTagStyles(style) {
  return !!style.tagStyles && Object.keys(style.tagStyles).length > 0;
}
function hasTagMarkup(text) {
  return text.includes("<");
}
function createMergedStyle(baseStyle, overrides) {
  return baseStyle.clone().assign(overrides);
}
function parseTaggedText(text, style) {
  const runs = [];
  const tagStyles = style.tagStyles;
  if (!hasTagStyles(style) || !hasTagMarkup(text)) {
    runs.push({ text, style });
    return runs;
  }
  const styleStack = [style];
  const tagStack = [];
  let currentText = "";
  let i = 0;
  while (i < text.length) {
    const char = text[i];
    if (char === "<") {
      const closeIndex = text.indexOf(">", i);
      if (closeIndex === -1) {
        currentText += char;
        i++;
        continue;
      }
      const nextOpenIndex = text.indexOf("<", i + 1);
      if (nextOpenIndex !== -1 && nextOpenIndex < closeIndex) {
        currentText += char;
        i++;
        continue;
      }
      const tagContent = text.slice(i + 1, closeIndex);
      if (tagContent.startsWith("/")) {
        const closingTagName = tagContent.slice(1).trim();
        if (tagStack.length > 0 && tagStack[tagStack.length - 1] === closingTagName) {
          if (currentText.length > 0) {
            runs.push({
              text: currentText,
              style: styleStack[styleStack.length - 1]
            });
            currentText = "";
          }
          styleStack.pop();
          tagStack.pop();
          i = closeIndex + 1;
          continue;
        } else {
          currentText += text.slice(i, closeIndex + 1);
          i = closeIndex + 1;
          continue;
        }
      } else {
        const tagName = tagContent.trim();
        if (tagStyles[tagName]) {
          if (currentText.length > 0) {
            runs.push({
              text: currentText,
              style: styleStack[styleStack.length - 1]
            });
            currentText = "";
          }
          const currentStyle = styleStack[styleStack.length - 1];
          const mergedStyle = createMergedStyle(currentStyle, tagStyles[tagName]);
          styleStack.push(mergedStyle);
          tagStack.push(tagName);
          i = closeIndex + 1;
          continue;
        } else {
          currentText += text.slice(i, closeIndex + 1);
          i = closeIndex + 1;
          continue;
        }
      }
    } else {
      currentText += char;
      i++;
    }
  }
  if (currentText.length > 0) {
    runs.push({
      text: currentText,
      style: styleStack[styleStack.length - 1]
    });
  }
  return runs;
}
function getPlainText(text, style) {
  if (!hasTagStyles(style) || !hasTagMarkup(text)) {
    return text;
  }
  const runs = parseTaggedText(text, style);
  return runs.map((run) => run.text).join("");
}

// node_modules/pixi.js/lib/scene/text/canvas/utils/textTokenization.mjs
var NEWLINES = [
  10,
  // line feed
  13
  // carriage return
];
var NEWLINES_SET = new Set(NEWLINES);
var BREAKING_SPACES = [
  9,
  // character tabulation
  32,
  // space
  8192,
  // en quad
  8193,
  // em quad
  8194,
  // en space
  8195,
  // em space
  8196,
  // three-per-em space
  8197,
  // four-per-em space
  8198,
  // six-per-em space
  8200,
  // punctuation space
  8201,
  // thin space
  8202,
  // hair space
  8287,
  // medium mathematical space
  12288
  // ideographic space
];
var BREAKING_SPACES_SET = new Set(BREAKING_SPACES);
var COLLAPSIBLE_SPACES = [
  9,
  // character tabulation (tab)
  32
  // space
];
var COLLAPSIBLE_SPACES_SET = new Set(COLLAPSIBLE_SPACES);
var BREAK_AFTER_CHARS = [
  45,
  // hyphen-minus
  8208,
  // unicode hyphen
  8211,
  // en-dash
  8212,
  // em-dash
  173
  // soft hyphen
];
var BREAK_AFTER_CHARS_SET = new Set(BREAK_AFTER_CHARS);
var NEWLINE_SPLIT_REGEX = /(\r\n|\r|\n)/;
var NEWLINE_MATCH_REGEX = /(?:\r\n|\r|\n)/;
function isNewline(char) {
  if (typeof char !== "string") {
    return false;
  }
  return NEWLINES_SET.has(char.charCodeAt(0));
}
function isBreakingSpace(char, _nextChar) {
  if (typeof char !== "string") {
    return false;
  }
  return BREAKING_SPACES_SET.has(char.charCodeAt(0));
}
function isCollapsibleSpace(char) {
  if (typeof char !== "string") {
    return false;
  }
  return COLLAPSIBLE_SPACES_SET.has(char.charCodeAt(0));
}
function isBreakAfterChar(char) {
  if (typeof char !== "string") {
    return false;
  }
  return BREAK_AFTER_CHARS_SET.has(char.charCodeAt(0));
}
function collapseSpaces(whiteSpace) {
  return whiteSpace === "normal" || whiteSpace === "pre-line";
}
function collapseNewlines(whiteSpace) {
  return whiteSpace === "normal";
}
function trimRight(text) {
  if (typeof text !== "string") {
    return "";
  }
  let i = text.length - 1;
  while (i >= 0 && isBreakingSpace(text[i])) {
    i--;
  }
  return i < text.length - 1 ? text.slice(0, i + 1) : text;
}
function tokenize(text) {
  const tokens = [];
  const tokenChars = [];
  if (typeof text !== "string") {
    return tokens;
  }
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];
    if (isBreakingSpace(char, nextChar) || isNewline(char)) {
      if (tokenChars.length > 0) {
        tokens.push(tokenChars.join(""));
        tokenChars.length = 0;
      }
      if (char === "\r" && nextChar === "\n") {
        tokens.push("\r\n");
        i++;
      } else {
        tokens.push(char);
      }
      continue;
    }
    tokenChars.push(char);
    if (isBreakAfterChar(char) && nextChar && !isBreakingSpace(nextChar) && !isNewline(nextChar)) {
      tokens.push(tokenChars.join(""));
      tokenChars.length = 0;
    }
  }
  if (tokenChars.length > 0) {
    tokens.push(tokenChars.join(""));
  }
  return tokens;
}
function getCharacterGroups(token, breakWords, splitFn, canBreakCharsFn) {
  const characters = splitFn(token);
  const groups = [];
  for (let j = 0; j < characters.length; j++) {
    let char = characters[j];
    let lastChar = char;
    let k = 1;
    while (characters[j + k]) {
      const nextChar = characters[j + k];
      if (!canBreakCharsFn(lastChar, nextChar, token, j, breakWords)) {
        char += nextChar;
        lastChar = nextChar;
        k++;
      } else {
        break;
      }
    }
    j += k - 1;
    groups.push(char);
  }
  return groups;
}

// node_modules/pixi.js/lib/scene/text/canvas/utils/measureTaggedText.mjs
var NEWLINE_TO_SPACE_REGEX = /\r\n|\r|\n/g;
function measureTaggedText(text, style, wordWrap2, context, measureTextFn, wrapMeasureTextFn, measureFontFn, canBreakCharsFn, wordWrapSplitFn) {
  const runs = parseTaggedText(text, style);
  const shouldCollapseNewlines = collapseNewlines(style.whiteSpace);
  if (shouldCollapseNewlines) {
    for (let i = 0; i < runs.length; i++) {
      const run = runs[i];
      runs[i] = { text: run.text.replace(NEWLINE_TO_SPACE_REGEX, " "), style: run.style };
    }
  }
  const runsByLine = [];
  let currentLineRuns = [];
  for (const run of runs) {
    const parts = run.text.split(NEWLINE_SPLIT_REGEX);
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (part === "\r\n" || part === "\r" || part === "\n") {
        runsByLine.push(currentLineRuns);
        currentLineRuns = [];
      } else if (part.length > 0) {
        currentLineRuns.push({ text: part, style: run.style });
      }
    }
  }
  if (currentLineRuns.length > 0 || runsByLine.length === 0) {
    runsByLine.push(currentLineRuns);
  }
  const wrappedRunsByLine = wordWrap2 ? wordWrapTaggedLines(
    runsByLine,
    style,
    context,
    wrapMeasureTextFn,
    canBreakCharsFn,
    wordWrapSplitFn
  ) : runsByLine;
  const lineWidths = [];
  const lineAscents = [];
  const lineDescents = [];
  const lineHeightsArr = [];
  const lines = [];
  let maxLineWidth = 0;
  const baseFont = style._fontString;
  const baseFontProps = measureFontFn(baseFont);
  if (baseFontProps.fontSize === 0) {
    baseFontProps.fontSize = style.fontSize;
    baseFontProps.ascent = style.fontSize;
  }
  let lastFont = "";
  let hasDropShadow = !!style.dropShadow;
  let maxRunStrokeWidth = style._stroke?.width || 0;
  for (const lineRuns of wrappedRunsByLine) {
    let lineWidth = 0;
    let lineAscent = baseFontProps.ascent;
    let lineDescent = baseFontProps.descent;
    let lineText = "";
    for (const run of lineRuns) {
      const runFont = run.style._fontString;
      const runFontProps = measureFontFn(runFont);
      if (runFont !== lastFont) {
        context.font = runFont;
        lastFont = runFont;
      }
      const runWidth = measureTextFn(run.text, run.style.letterSpacing, context);
      lineWidth += runWidth;
      lineAscent = Math.max(lineAscent, runFontProps.ascent);
      lineDescent = Math.max(lineDescent, runFontProps.descent);
      lineText += run.text;
      const runStrokeWidth = run.style._stroke?.width || 0;
      if (runStrokeWidth > maxRunStrokeWidth) maxRunStrokeWidth = runStrokeWidth;
      if (!hasDropShadow && run.style.dropShadow) {
        hasDropShadow = true;
      }
    }
    if (lineRuns.length === 0) {
      lineAscent = baseFontProps.ascent;
      lineDescent = baseFontProps.descent;
    }
    lineWidths.push(lineWidth);
    lineAscents.push(lineAscent);
    lineDescents.push(lineDescent);
    lines.push(lineText);
    const computedLineHeight = style.lineHeight || lineAscent + lineDescent;
    lineHeightsArr.push(computedLineHeight + style.leading);
    maxLineWidth = Math.max(maxLineWidth, lineWidth);
  }
  const strokeWidth = maxRunStrokeWidth;
  const width = maxLineWidth + strokeWidth + (style.dropShadow ? style.dropShadow.distance : 0);
  let baseHeight = 0;
  for (let i = 0; i < lineHeightsArr.length; i++) {
    baseHeight += lineHeightsArr[i];
  }
  baseHeight = Math.max(baseHeight, lineHeightsArr[0] + strokeWidth);
  const height = baseHeight + (style.dropShadow ? style.dropShadow.distance : 0);
  const baseLineHeight = style.lineHeight || baseFontProps.fontSize;
  return {
    width,
    height,
    lines,
    lineWidths,
    lineHeight: baseLineHeight + style.leading,
    maxLineWidth,
    fontProperties: baseFontProps,
    runsByLine: wrappedRunsByLine,
    lineAscents,
    lineDescents,
    lineHeights: lineHeightsArr,
    hasDropShadow
  };
}
function wordWrapTaggedLines(runsByLine, style, context, measureTextFn, canBreakCharsFn, wordWrapSplitFn) {
  const { letterSpacing, whiteSpace, wordWrapWidth, breakWords } = style;
  const shouldCollapseSpaces = collapseSpaces(whiteSpace);
  const adjustedWrapWidth = wordWrapWidth + letterSpacing;
  const tokenWidthCache = {};
  let lastFont = "";
  const measureTokenWidth = (token, tokenStyle) => {
    const cacheKey = `${token}|${tokenStyle.styleKey}`;
    let width = tokenWidthCache[cacheKey];
    if (width === void 0) {
      const font = tokenStyle._fontString;
      if (font !== lastFont) {
        context.font = font;
        lastFont = font;
      }
      width = measureTextFn(token, tokenStyle.letterSpacing, context) + tokenStyle.letterSpacing;
      tokenWidthCache[cacheKey] = width;
    }
    return width;
  };
  const result = [];
  for (const lineRuns of runsByLine) {
    const styledTokens = tokenizeTaggedRuns(lineRuns);
    const resultStartLength = result.length;
    const getWordGroupWidth = (startIndex) => {
      let totalWidth = 0;
      let j = startIndex;
      do {
        const { token: groupToken, style: groupStyle } = styledTokens[j];
        totalWidth += measureTokenWidth(groupToken, groupStyle);
        j++;
      } while (j < styledTokens.length && styledTokens[j].continuesFromPrevious);
      return totalWidth;
    };
    const getWordGroupTokens = (startIndex) => {
      const tokens = [];
      let j = startIndex;
      do {
        tokens.push({ token: styledTokens[j].token, style: styledTokens[j].style });
        j++;
      } while (j < styledTokens.length && styledTokens[j].continuesFromPrevious);
      return tokens;
    };
    let currentLineRuns = [];
    let currentWidth = 0;
    let canPrependSpaces = !shouldCollapseSpaces;
    let buildingRun = null;
    const flushBuildingRun = () => {
      if (buildingRun && buildingRun.text.length > 0) {
        currentLineRuns.push(buildingRun);
      }
      buildingRun = null;
    };
    const startNewLine = () => {
      flushBuildingRun();
      if (currentLineRuns.length > 0) {
        const lastRun = currentLineRuns[currentLineRuns.length - 1];
        lastRun.text = trimRight(lastRun.text);
        if (lastRun.text.length === 0) {
          currentLineRuns.pop();
        }
      }
      result.push(currentLineRuns);
      currentLineRuns = [];
      currentWidth = 0;
      canPrependSpaces = false;
    };
    for (let i = 0; i < styledTokens.length; i++) {
      const { token, style: tokenStyle, continuesFromPrevious } = styledTokens[i];
      const tokenWidth = measureTokenWidth(token, tokenStyle);
      if (shouldCollapseSpaces) {
        const currIsSpace = isBreakingSpace(token);
        const lastChar = buildingRun?.text[buildingRun.text.length - 1] ?? currentLineRuns[currentLineRuns.length - 1]?.text.slice(-1) ?? "";
        const lastIsSpace = lastChar ? isBreakingSpace(lastChar) : false;
        if (currIsSpace && lastIsSpace) {
          continue;
        }
      }
      const startsWordGroup = !continuesFromPrevious;
      const wordGroupWidth = startsWordGroup ? getWordGroupWidth(i) : tokenWidth;
      if (wordGroupWidth > adjustedWrapWidth && startsWordGroup) {
        if (currentWidth > 0) {
          startNewLine();
        }
        if (breakWords) {
          const wordGroupTokens = getWordGroupTokens(i);
          for (let g = 0; g < wordGroupTokens.length; g++) {
            const groupToken = wordGroupTokens[g].token;
            const groupStyle = wordGroupTokens[g].style;
            const charGroups = getCharacterGroups(
              groupToken,
              breakWords,
              wordWrapSplitFn,
              canBreakCharsFn
            );
            for (const char of charGroups) {
              const charWidth = measureTokenWidth(char, groupStyle);
              if (charWidth + currentWidth > adjustedWrapWidth) {
                startNewLine();
              }
              if (!buildingRun || buildingRun.style !== groupStyle) {
                flushBuildingRun();
                buildingRun = { text: char, style: groupStyle };
              } else {
                buildingRun.text += char;
              }
              currentWidth += charWidth;
            }
          }
          i += wordGroupTokens.length - 1;
        } else {
          const wordGroupTokens = getWordGroupTokens(i);
          flushBuildingRun();
          result.push(wordGroupTokens.map((t) => ({ text: t.token, style: t.style })));
          canPrependSpaces = false;
          i += wordGroupTokens.length - 1;
        }
      } else if (wordGroupWidth + currentWidth > adjustedWrapWidth && startsWordGroup) {
        if (isBreakingSpace(token)) {
          canPrependSpaces = false;
          continue;
        }
        startNewLine();
        buildingRun = { text: token, style: tokenStyle };
        currentWidth = tokenWidth;
      } else if (continuesFromPrevious && !breakWords) {
        if (!buildingRun || buildingRun.style !== tokenStyle) {
          flushBuildingRun();
          buildingRun = { text: token, style: tokenStyle };
        } else {
          buildingRun.text += token;
        }
        currentWidth += tokenWidth;
      } else {
        const isSpace = isBreakingSpace(token);
        if (currentWidth === 0 && isSpace && !canPrependSpaces) {
          continue;
        }
        if (!buildingRun || buildingRun.style !== tokenStyle) {
          flushBuildingRun();
          buildingRun = { text: token, style: tokenStyle };
        } else {
          buildingRun.text += token;
        }
        currentWidth += tokenWidth;
      }
    }
    flushBuildingRun();
    if (currentLineRuns.length > 0) {
      const lastRun = currentLineRuns[currentLineRuns.length - 1];
      lastRun.text = trimRight(lastRun.text);
      if (lastRun.text.length === 0) {
        currentLineRuns.pop();
      }
    }
    if (currentLineRuns.length > 0 || result.length === resultStartLength) {
      result.push(currentLineRuns);
    }
  }
  return result;
}
function tokenizeTaggedRuns(runs) {
  const styledTokens = [];
  let lastTokenWasWord = false;
  for (const run of runs) {
    const tokens = tokenize(run.text);
    let isFirstTokenInRun = true;
    for (const token of tokens) {
      const isSpace = isBreakingSpace(token) || isNewline(token);
      const continuesFromPrevious = isFirstTokenInRun && lastTokenWasWord && !isSpace;
      styledTokens.push({ token, style: run.style, continuesFromPrevious });
      lastTokenWasWord = !isSpace;
      isFirstTokenInRun = false;
    }
  }
  return styledTokens;
}

// node_modules/pixi.js/lib/scene/text/canvas/utils/wordWrap.mjs
var contextSettings = {
  // TextMetrics requires getImageData readback for measuring fonts.
  willReadFrequently: true
};
function getFromCache(key, letterSpacing, cache, context, measureTextFn) {
  let width = cache[key];
  if (typeof width !== "number") {
    width = measureTextFn(key, letterSpacing, context) + letterSpacing;
    cache[key] = width;
  }
  return width;
}
function wordWrap(text, style, canvas, measureTextFn, canBreakWordsFn, canBreakCharsFn, wordWrapSplitFn) {
  const context = canvas.getContext("2d", contextSettings);
  context.font = style._fontString;
  let width = 0;
  let line = "";
  const linesArray = [];
  const cache = /* @__PURE__ */ Object.create(null);
  const { letterSpacing, whiteSpace } = style;
  const shouldCollapseSpaces = collapseSpaces(whiteSpace);
  const shouldCollapseNewlines = collapseNewlines(whiteSpace);
  let canPrependSpaces = !shouldCollapseSpaces;
  const wordWrapWidth = style.wordWrapWidth + letterSpacing;
  const tokens = tokenize(text);
  for (let i = 0; i < tokens.length; i++) {
    let token = tokens[i];
    if (isNewline(token)) {
      if (!shouldCollapseNewlines) {
        linesArray.push(trimRight(line));
        canPrependSpaces = !shouldCollapseSpaces;
        line = "";
        width = 0;
        continue;
      }
      token = " ";
    }
    if (shouldCollapseSpaces) {
      const currIsBreakingSpace = isBreakingSpace(token);
      const lastIsBreakingSpace = isBreakingSpace(line[line.length - 1]);
      if (currIsBreakingSpace && lastIsBreakingSpace) {
        continue;
      }
    }
    const tokenWidth = getFromCache(token, letterSpacing, cache, context, measureTextFn);
    if (tokenWidth > wordWrapWidth) {
      if (line !== "") {
        linesArray.push(trimRight(line));
        line = "";
        width = 0;
      }
      if (canBreakWordsFn(token, style.breakWords)) {
        const charGroups = getCharacterGroups(token, style.breakWords, wordWrapSplitFn, canBreakCharsFn);
        for (const char of charGroups) {
          const characterWidth = getFromCache(char, letterSpacing, cache, context, measureTextFn);
          if (characterWidth + width > wordWrapWidth) {
            linesArray.push(trimRight(line));
            canPrependSpaces = false;
            line = "";
            width = 0;
          }
          line += char;
          width += characterWidth;
        }
      } else {
        if (line.length > 0) {
          linesArray.push(trimRight(line));
          line = "";
          width = 0;
        }
        linesArray.push(trimRight(token));
        canPrependSpaces = false;
        line = "";
        width = 0;
      }
    } else {
      if (tokenWidth + width > wordWrapWidth) {
        canPrependSpaces = false;
        linesArray.push(trimRight(line));
        line = "";
        width = 0;
      }
      if (line.length > 0 || !isBreakingSpace(token) || canPrependSpaces) {
        line += token;
        width += tokenWidth;
      }
    }
  }
  const trimmedLine = trimRight(line);
  if (trimmedLine.length > 0) {
    linesArray.push(trimmedLine);
  }
  return linesArray.join("\n");
}

// node_modules/pixi.js/lib/scene/text/canvas/CanvasTextMetrics.mjs
var contextSettings2 = {
  // TextMetrics requires getImageData readback for measuring fonts.
  willReadFrequently: true
};
var _CanvasTextMetrics = class _CanvasTextMetrics2 {
  /**
   * Checking that we can use modern canvas 2D API.
   *
   * Note: This is an unstable API, Chrome < 94 use `textLetterSpacing`, later versions use `letterSpacing`.
   * @see CanvasTextMetrics.experimentalLetterSpacing
   * @see https://developer.mozilla.org/en-US/docs/Web/API/ICanvasRenderingContext2D/letterSpacing
   * @see https://developer.chrome.com/origintrials/#/view_trial/3585991203293757441
   */
  static get experimentalLetterSpacingSupported() {
    let result = _CanvasTextMetrics2._experimentalLetterSpacingSupported;
    if (result === void 0) {
      const proto = DOMAdapter.get().getCanvasRenderingContext2D().prototype;
      result = _CanvasTextMetrics2._experimentalLetterSpacingSupported = "letterSpacing" in proto || "textLetterSpacing" in proto;
    }
    return result;
  }
  /**
   * @param text - the text that was measured
   * @param style - the style that was measured
   * @param width - the measured width of the text
   * @param height - the measured height of the text
   * @param lines - an array of the lines of text broken by new lines and wrapping if specified in style
   * @param lineWidths - an array of the line widths for each line matched to `lines`
   * @param lineHeight - the measured line height for this style
   * @param maxLineWidth - the maximum line width for all measured lines
   * @param fontProperties - the font properties object from TextMetrics.measureFont
   * @param taggedData - optional object containing tagged text specific data
   * @param taggedData.runsByLine - per-line style runs for tagged text
   * @param taggedData.lineAscents - per-line ascent values for tagged text
   * @param taggedData.lineDescents - per-line descent values for tagged text
   * @param taggedData.lineHeights - per-line height values for tagged text
   * @param taggedData.hasDropShadow - whether any run has a drop shadow
   */
  constructor(text, style, width, height, lines, lineWidths, lineHeight, maxLineWidth, fontProperties, taggedData) {
    this.text = text;
    this.style = style;
    this.width = width;
    this.height = height;
    this.lines = lines;
    this.lineWidths = lineWidths;
    this.lineHeight = lineHeight;
    this.maxLineWidth = maxLineWidth;
    this.fontProperties = fontProperties;
    if (taggedData) {
      this.runsByLine = taggedData.runsByLine;
      this.lineAscents = taggedData.lineAscents;
      this.lineDescents = taggedData.lineDescents;
      this.lineHeights = taggedData.lineHeights;
      this.hasDropShadow = taggedData.hasDropShadow;
    }
  }
  /**
   * Measures the supplied string of text and returns a Rectangle.
   * @param text - The text to measure.
   * @param style - The text style to use for measuring
   * @param canvas - optional specification of the canvas to use for measuring.
   * @param wordWrap
   * @returns Measured width and height of the text.
   */
  static measureText(text = " ", style, canvas = _CanvasTextMetrics2._canvas, wordWrap2 = style.wordWrap) {
    const textKey = `${text}-${style.styleKey}-wordWrap-${wordWrap2}`;
    if (_CanvasTextMetrics2._measurementCache.has(textKey)) {
      return _CanvasTextMetrics2._measurementCache.get(textKey);
    }
    const isTagged = hasTagStyles(style) && hasTagMarkup(text);
    if (isTagged) {
      const result = measureTaggedText(
        text,
        style,
        wordWrap2,
        _CanvasTextMetrics2._context,
        _CanvasTextMetrics2._measureText,
        _CanvasTextMetrics2._measureTextAdvance,
        _CanvasTextMetrics2.measureFont,
        _CanvasTextMetrics2.canBreakChars,
        _CanvasTextMetrics2.wordWrapSplit
      );
      const measurements2 = new _CanvasTextMetrics2(
        text,
        style,
        result.width,
        result.height,
        result.lines,
        result.lineWidths,
        result.lineHeight,
        result.maxLineWidth,
        result.fontProperties,
        {
          runsByLine: result.runsByLine,
          lineAscents: result.lineAscents,
          lineDescents: result.lineDescents,
          lineHeights: result.lineHeights,
          hasDropShadow: result.hasDropShadow
        }
      );
      _CanvasTextMetrics2._measurementCache.set(textKey, measurements2);
      return measurements2;
    }
    const font = style._fontString;
    const fontProperties = _CanvasTextMetrics2.measureFont(font);
    if (fontProperties.fontSize === 0) {
      fontProperties.fontSize = style.fontSize;
      fontProperties.ascent = style.fontSize;
      fontProperties.descent = 0;
    }
    const context = _CanvasTextMetrics2._context;
    context.font = font;
    const outputText = wordWrap2 ? _CanvasTextMetrics2._wordWrap(text, style, canvas) : text;
    const lines = outputText.split(NEWLINE_MATCH_REGEX);
    const lineWidths = new Array(lines.length);
    let maxLineWidth = 0;
    for (let i = 0; i < lines.length; i++) {
      const lineWidth = _CanvasTextMetrics2._measureText(lines[i], style.letterSpacing, context);
      lineWidths[i] = lineWidth;
      maxLineWidth = Math.max(maxLineWidth, lineWidth);
    }
    const strokeWidth = style._stroke?.width ?? 0;
    const lineHeight = style.lineHeight || fontProperties.fontSize;
    const width = _CanvasTextMetrics2._adjustWidthForStyle(maxLineWidth, style);
    const baseHeight = Math.max(lineHeight, fontProperties.fontSize + strokeWidth) + (lines.length - 1) * (lineHeight + style.leading);
    const height = _CanvasTextMetrics2._adjustHeightForStyle(baseHeight, style);
    const measurements = new _CanvasTextMetrics2(
      text,
      style,
      width,
      height,
      lines,
      lineWidths,
      lineHeight + style.leading,
      maxLineWidth,
      fontProperties
    );
    _CanvasTextMetrics2._measurementCache.set(textKey, measurements);
    return measurements;
  }
  /**
   * Adjusts the measured width to account for stroke and drop shadow.
   * @param baseWidth - The base content width
   * @param style - The text style
   * @returns The adjusted width
   */
  static _adjustWidthForStyle(baseWidth, style) {
    const strokeWidth = style._stroke?.width || 0;
    let width = baseWidth + strokeWidth;
    if (style.dropShadow) {
      width += style.dropShadow.distance;
    }
    return width;
  }
  /**
   * Adjusts the measured height to account for drop shadow.
   * @param baseHeight - The base content height
   * @param style - The text style
   * @returns The adjusted height
   */
  static _adjustHeightForStyle(baseHeight, style) {
    let height = baseHeight;
    if (style.dropShadow) {
      height += style.dropShadow.distance;
    }
    return height;
  }
  /**
   * Measures the rendered width of a string, accounting for letter spacing and using the provided context.
   * Returns the larger of the advance width and the bounding box width.
   * @param text - The text to measure
   * @param letterSpacing - Letter spacing in pixels
   * @param context - Canvas 2D context
   * @returns The measured width of the text with spacing
   * @internal
   */
  static _measureText(text, letterSpacing, context) {
    const { metricWidth, metrics, letterSpacingVal } = _CanvasTextMetrics2._measureTextCore(text, letterSpacing, context);
    const actualBoundingBoxLeft = -(metrics.actualBoundingBoxLeft ?? 0);
    const actualBoundingBoxRight = metrics.actualBoundingBoxRight ?? 0;
    let boundsWidth = actualBoundingBoxRight - actualBoundingBoxLeft;
    if (metrics.width > 0) {
      boundsWidth += letterSpacingVal;
    }
    return Math.max(metricWidth, boundsWidth);
  }
  /**
   * Measures advance width only (no bounding box). Advance widths are additive,
   * making this suitable for word wrap line-fitting where per-token widths must sum correctly.
   * @param text - The text to measure
   * @param letterSpacing - Letter spacing in pixels
   * @param context - Canvas 2D context
   * @returns The advance width of the text
   * @internal
   */
  static _measureTextAdvance(text, letterSpacing, context) {
    return _CanvasTextMetrics2._measureTextCore(text, letterSpacing, context).metricWidth;
  }
  /**
   * Shared measurement core: sets up letter spacing on the context, calls
   * context.measureText, and adjusts the advance width for letter spacing.
   * @param text
   * @param letterSpacing
   * @param context
   * @internal
   */
  static _measureTextCore(text, letterSpacing, context) {
    let useExperimentalLetterSpacing = false;
    if (_CanvasTextMetrics2.experimentalLetterSpacingSupported) {
      if (_CanvasTextMetrics2.experimentalLetterSpacing) {
        context.letterSpacing = `${letterSpacing}px`;
        context.textLetterSpacing = `${letterSpacing}px`;
        useExperimentalLetterSpacing = true;
      } else {
        context.letterSpacing = "0px";
        context.textLetterSpacing = "0px";
      }
    }
    const metrics = context.measureText(text);
    let metricWidth = metrics.width;
    let letterSpacingVal = 0;
    if (metricWidth > 0) {
      if (useExperimentalLetterSpacing) {
        letterSpacingVal = -letterSpacing;
      } else {
        letterSpacingVal = (_CanvasTextMetrics2.graphemeSegmenter(text).length - 1) * letterSpacing;
      }
      metricWidth += letterSpacingVal;
    }
    return { metricWidth, metrics, letterSpacingVal };
  }
  /**
   * Applies newlines to a string to have it optimally fit into the horizontal
   * bounds set by the Text object's wordWrapWidth property.
   * @param text - String to apply word wrapping to
   * @param style - the style to use when wrapping
   * @param canvas - optional specification of the canvas to use for measuring.
   * @returns New string with new lines applied where required
   */
  static _wordWrap(text, style, canvas = _CanvasTextMetrics2._canvas) {
    return wordWrap(
      text,
      style,
      canvas,
      _CanvasTextMetrics2._measureTextAdvance,
      _CanvasTextMetrics2.canBreakWords,
      _CanvasTextMetrics2.canBreakChars,
      _CanvasTextMetrics2.wordWrapSplit
    );
  }
  /**
   * Determines if char is a breaking whitespace.
   *
   * It allows one to determine whether char should be a breaking whitespace
   * For example certain characters in CJK langs or numbers.
   * It must return a boolean.
   * @param char - The character
   * @param [_nextChar] - The next character
   * @returns True if whitespace, False otherwise.
   */
  static isBreakingSpace(char, _nextChar) {
    return isBreakingSpace(char, _nextChar);
  }
  /**
   * Overridable helper method used internally by TextMetrics, exposed to allow customizing the class's behavior.
   *
   * It allows one to customise which words should break
   * Examples are if the token is CJK or numbers.
   * It must return a boolean.
   * @param _token - The token
   * @param breakWords - The style attr break words
   * @returns Whether to break word or not
   */
  static canBreakWords(_token, breakWords) {
    return breakWords;
  }
  /**
   * Overridable helper method used internally by TextMetrics, exposed to allow customizing the class's behavior.
   *
   * It allows one to determine whether a pair of characters
   * should be broken by newlines
   * For example certain characters in CJK langs or numbers.
   * It must return a boolean.
   * @param _char - The character
   * @param _nextChar - The next character
   * @param _token - The token/word the characters are from
   * @param _index - The index in the token of the char
   * @param _breakWords - The style attr break words
   * @returns whether to break word or not
   */
  static canBreakChars(_char, _nextChar, _token, _index, _breakWords) {
    return true;
  }
  /**
   * Overridable helper method used internally by TextMetrics, exposed to allow customizing the class's behavior.
   *
   * It is called when a token (usually a word) has to be split into separate pieces
   * in order to determine the point to break a word.
   * It must return an array of characters.
   * @param token - The token to split
   * @returns The characters of the token
   * @see CanvasTextMetrics.graphemeSegmenter
   */
  static wordWrapSplit(token) {
    return _CanvasTextMetrics2.graphemeSegmenter(token);
  }
  /**
   * Calculates the ascent, descent and fontSize of a given font-style
   * @param font - String representing the style of the font
   * @returns Font properties object
   */
  static measureFont(font) {
    if (_CanvasTextMetrics2._fonts[font]) {
      return _CanvasTextMetrics2._fonts[font];
    }
    const context = _CanvasTextMetrics2._context;
    context.font = font;
    const metrics = context.measureText(_CanvasTextMetrics2.METRICS_STRING + _CanvasTextMetrics2.BASELINE_SYMBOL);
    const ascent = metrics.actualBoundingBoxAscent ?? 0;
    const descent = metrics.actualBoundingBoxDescent ?? 0;
    const properties = {
      ascent,
      descent,
      fontSize: ascent + descent
    };
    _CanvasTextMetrics2._fonts[font] = properties;
    return properties;
  }
  /**
   * Clear font metrics in metrics cache.
   * @param {string} [font] - font name. If font name not set then clear cache for all fonts.
   */
  static clearMetrics(font = "") {
    if (font) {
      delete _CanvasTextMetrics2._fonts[font];
    } else {
      _CanvasTextMetrics2._fonts = {};
    }
  }
  /**
   * Cached canvas element for measuring text
   * TODO: this should be private, but isn't because of backward compat, will fix later.
   * @ignore
   */
  static get _canvas() {
    if (!_CanvasTextMetrics2.__canvas) {
      let canvas;
      try {
        const c = new OffscreenCanvas(0, 0);
        const context = c.getContext("2d", contextSettings2);
        if (context?.measureText) {
          _CanvasTextMetrics2.__canvas = c;
          return c;
        }
        canvas = DOMAdapter.get().createCanvas();
      } catch (_cx) {
        canvas = DOMAdapter.get().createCanvas();
      }
      canvas.width = canvas.height = 10;
      _CanvasTextMetrics2.__canvas = canvas;
    }
    return _CanvasTextMetrics2.__canvas;
  }
  /**
   * TODO: this should be private, but isn't because of backward compat, will fix later.
   * @ignore
   */
  static get _context() {
    if (!_CanvasTextMetrics2.__context) {
      _CanvasTextMetrics2.__context = _CanvasTextMetrics2._canvas.getContext("2d", contextSettings2);
    }
    return _CanvasTextMetrics2.__context;
  }
};
_CanvasTextMetrics.METRICS_STRING = "|ÉqÅ";
_CanvasTextMetrics.BASELINE_SYMBOL = "M";
_CanvasTextMetrics.BASELINE_MULTIPLIER = 1.4;
_CanvasTextMetrics.HEIGHT_MULTIPLIER = 2;
_CanvasTextMetrics.graphemeSegmenter = (() => {
  if (typeof Intl?.Segmenter === "function") {
    const segmenter = new Intl.Segmenter();
    return (s) => {
      const segments = segmenter.segment(s);
      const result = [];
      let i = 0;
      for (const segment of segments) {
        result[i++] = segment.segment;
      }
      return result;
    };
  }
  return (s) => [...s];
})();
_CanvasTextMetrics.experimentalLetterSpacing = false;
_CanvasTextMetrics._fonts = {};
_CanvasTextMetrics._measurementCache = lru(1e3);
var CanvasTextMetrics = _CanvasTextMetrics;

// node_modules/pixi.js/lib/scene/text/canvas/utils/fontStringFromTextStyle.mjs
var genericFontFamilies = [
  "serif",
  "sans-serif",
  "monospace",
  "cursive",
  "fantasy",
  "system-ui"
];
function fontStringFromTextStyle(style) {
  const fontSizeString = typeof style.fontSize === "number" ? `${style.fontSize}px` : style.fontSize;
  let fontFamilies = style.fontFamily;
  if (!Array.isArray(style.fontFamily)) {
    fontFamilies = style.fontFamily.split(",");
  }
  for (let i = fontFamilies.length - 1; i >= 0; i--) {
    let fontFamily = fontFamilies[i].trim();
    if (!/([\"\'])[^\'\"]+\1/.test(fontFamily) && !genericFontFamilies.includes(fontFamily)) {
      fontFamily = `"${fontFamily}"`;
    }
    fontFamilies[i] = fontFamily;
  }
  return `${style.fontStyle} ${style.fontVariant} ${style.fontWeight} ${fontSizeString} ${fontFamilies.join(",")}`;
}

// node_modules/pixi.js/lib/scene/text/TextStyle.mjs
var _TextStyle = class _TextStyle2 extends eventemitter3_default {
  constructor(style = {}) {
    super();
    this.uid = uid("textStyle");
    this._tick = 0;
    this._cachedFontString = null;
    convertV7Tov8Style(style);
    const isTextStyle = style instanceof _TextStyle2;
    const existingStyle = style;
    if (isTextStyle) {
      style = existingStyle._toObject();
    }
    const fullStyle = __spreadValues(__spreadValues({}, _TextStyle2.defaultTextStyle), style);
    for (const key in fullStyle) {
      const thisKey = key;
      this[thisKey] = fullStyle[key];
    }
    this._tagStyles = style.tagStyles ?? void 0;
    this.update();
    this._tick = 0;
  }
  /**
   * Alignment for multiline text, does not affect single line text.
   * @type {'left'|'center'|'right'|'justify'}
   */
  get align() {
    return this._align;
  }
  set align(value) {
    if (this._align === value) return;
    this._align = value;
    this.update();
  }
  /** Indicates if lines can be wrapped within words, it needs wordWrap to be set to true. */
  get breakWords() {
    return this._breakWords;
  }
  set breakWords(value) {
    if (this._breakWords === value) return;
    this._breakWords = value;
    this.update();
  }
  /** Set a drop shadow for the text. */
  get dropShadow() {
    return this._dropShadow;
  }
  set dropShadow(value) {
    if (this._dropShadow === value) return;
    if (value !== null && typeof value === "object") {
      this._dropShadow = this._createProxy(__spreadValues(__spreadValues({}, _TextStyle2.defaultDropShadow), value));
    } else {
      this._dropShadow = value ? this._createProxy(__spreadValues({}, _TextStyle2.defaultDropShadow)) : null;
    }
    this.update();
  }
  /** The font family, can be a single font name, or a list of names where the first is the preferred font. */
  get fontFamily() {
    return this._fontFamily;
  }
  set fontFamily(value) {
    if (this._fontFamily === value) return;
    this._fontFamily = value;
    this.update();
  }
  /** The font size (as a number it converts to px, but as a string, equivalents are '26px','20pt','160%' or '1.6em') */
  get fontSize() {
    return this._fontSize;
  }
  set fontSize(value) {
    if (this._fontSize === value) return;
    if (typeof value === "string") {
      this._fontSize = parseInt(value, 10);
    } else {
      this._fontSize = value;
    }
    this.update();
  }
  /**
   * The font style.
   * @type {'normal'|'italic'|'oblique'}
   */
  get fontStyle() {
    return this._fontStyle;
  }
  set fontStyle(value) {
    if (this._fontStyle === value) return;
    this._fontStyle = value.toLowerCase();
    this.update();
  }
  /**
   * The font variant.
   * @type {'normal'|'small-caps'}
   */
  get fontVariant() {
    return this._fontVariant;
  }
  set fontVariant(value) {
    if (this._fontVariant === value) return;
    this._fontVariant = value;
    this.update();
  }
  /**
   * The font weight.
   * @type {'normal'|'bold'|'bolder'|'lighter'|'100'|'200'|'300'|'400'|'500'|'600'|'700'|'800'|'900'}
   */
  get fontWeight() {
    return this._fontWeight;
  }
  set fontWeight(value) {
    if (this._fontWeight === value) return;
    this._fontWeight = value;
    this.update();
  }
  /** The space between lines. */
  get leading() {
    return this._leading;
  }
  set leading(value) {
    if (this._leading === value) return;
    this._leading = value;
    this.update();
  }
  /** The amount of spacing between letters, default is 0. */
  get letterSpacing() {
    return this._letterSpacing;
  }
  set letterSpacing(value) {
    if (this._letterSpacing === value) return;
    this._letterSpacing = value;
    this.update();
  }
  /** The line height, a number that represents the vertical space that a letter uses. */
  get lineHeight() {
    return this._lineHeight;
  }
  set lineHeight(value) {
    if (this._lineHeight === value) return;
    this._lineHeight = value;
    this.update();
  }
  /**
   * Occasionally some fonts are cropped. Adding some padding will prevent this from happening
   * by adding padding to all sides of the text.
   * > [!NOTE] This will NOT affect the positioning or bounds of the text.
   */
  get padding() {
    return this._padding;
  }
  set padding(value) {
    if (this._padding === value) return;
    this._padding = value;
    this.update();
  }
  /**
   * An optional filter or array of filters to apply to the text, allowing for advanced visual effects.
   * These filters will be applied to the text as it is created, resulting in faster rendering for static text
   * compared to applying the filter directly to the text object (which would be applied at run time).
   * @default null
   */
  get filters() {
    return this._filters;
  }
  set filters(value) {
    if (this._filters === value) return;
    this._filters = Object.freeze(value);
    this.update();
  }
  /**
   * Trim transparent borders from the text texture.
   * > [!IMPORTANT] PERFORMANCE WARNING:
   * > This is a costly operation as it requires scanning pixel alpha values.
   * > Avoid using `trim: true` for dynamic text, as it could significantly impact performance.
   */
  get trim() {
    return this._trim;
  }
  set trim(value) {
    if (this._trim === value) return;
    this._trim = value;
    this.update();
  }
  /**
   * The baseline of the text that is rendered.
   * @type {'alphabetic'|'top'|'hanging'|'middle'|'ideographic'|'bottom'}
   */
  get textBaseline() {
    return this._textBaseline;
  }
  set textBaseline(value) {
    if (this._textBaseline === value) return;
    this._textBaseline = value;
    this.update();
  }
  /**
   * How newlines and spaces should be handled.
   * Default is 'pre' (preserve, preserve).
   *
   *  value       | New lines     |   Spaces
   *  ---         | ---           |   ---
   * 'normal'     | Collapse      |   Collapse
   * 'pre'        | Preserve      |   Preserve
   * 'pre-line'   | Preserve      |   Collapse
   * @type {'normal'|'pre'|'pre-line'}
   */
  get whiteSpace() {
    return this._whiteSpace;
  }
  set whiteSpace(value) {
    if (this._whiteSpace === value) return;
    this._whiteSpace = value;
    this.update();
  }
  /** Indicates if word wrap should be used. */
  get wordWrap() {
    return this._wordWrap;
  }
  set wordWrap(value) {
    if (this._wordWrap === value) return;
    this._wordWrap = value;
    this.update();
  }
  /** The width at which text will wrap, it needs wordWrap to be set to true. */
  get wordWrapWidth() {
    return this._wordWrapWidth;
  }
  set wordWrapWidth(value) {
    if (this._wordWrapWidth === value) return;
    this._wordWrapWidth = value;
    this.update();
  }
  /**
   * The fill style that will be used to color the text.
   * This can be:
   * - A color string like 'red', '#00FF00', or 'rgba(255,0,0,0.5)'
   * - A hex number like 0xff0000 for red
   * - A FillStyle object with properties like { color: 0xff0000, alpha: 0.5 }
   * - A FillGradient for gradient fills
   * - A FillPattern for pattern/texture fills
   *
   * When using a FillGradient, vertical gradients (angle of 90 degrees) are applied per line of text,
   * while gradients at any other angle are spread across the entire text body as a whole.
   * @example
   * // Vertical gradient applied per line
   * const verticalGradient = new FillGradient(0, 0, 0, 1)
   *     .addColorStop(0, 0xff0000)
   *     .addColorStop(1, 0x0000ff);
   *
   * const text = new Text({
   *     text: 'Line 1\nLine 2',
   *     style: { fill: verticalGradient }
   * });
   *
   * To manage the gradient in a global scope, set the textureSpace property of the FillGradient to 'global'.
   * @type {string|number|FillStyle|FillGradient|FillPattern}
   */
  get fill() {
    return this._originalFill;
  }
  set fill(value) {
    if (value === this._originalFill) return;
    this._originalFill = value;
    if (this._isFillStyle(value)) {
      this._originalFill = this._createProxy(__spreadValues(__spreadValues({}, GraphicsContext.defaultFillStyle), value), () => {
        this._fill = toFillStyle(
          __spreadValues({}, this._originalFill),
          GraphicsContext.defaultFillStyle
        );
      });
    }
    this._fill = toFillStyle(
      value === 0 ? "black" : value,
      GraphicsContext.defaultFillStyle
    );
    this.update();
  }
  /** A fillstyle that will be used on the text stroke, e.g., 'blue', '#FCFF00'. */
  get stroke() {
    return this._originalStroke;
  }
  set stroke(value) {
    if (value === this._originalStroke) return;
    this._originalStroke = value;
    if (this._isFillStyle(value)) {
      this._originalStroke = this._createProxy(__spreadValues(__spreadValues({}, GraphicsContext.defaultStrokeStyle), value), () => {
        this._stroke = toStrokeStyle(
          __spreadValues({}, this._originalStroke),
          GraphicsContext.defaultStrokeStyle
        );
      });
    }
    this._stroke = toStrokeStyle(value, GraphicsContext.defaultStrokeStyle);
    this.update();
  }
  /**
   * Custom styles to apply to specific tags within the text.
   * Allows for rich text formatting using simple tag markup like `<red>text</red>`.
   *
   * Tags are only parsed when this property has entries. If `tagStyles` is undefined,
   * `<` characters in text are treated as literal.
   * @example
   * ```ts
   * const text = new Text({
   *     text: '<red>Red</red>, <blue>Blue</blue>',
   *     style: {
   *         fill: 'white',
   *         tagStyles: {
   *             red: { fill: 'red' },
   *             blue: { fill: 'blue' }
   *         }
   *     }
   * });
   * ```
   */
  get tagStyles() {
    return this._tagStyles;
  }
  set tagStyles(value) {
    if (this._tagStyles === value) return;
    this._tagStyles = value ?? void 0;
    this.update();
  }
  update() {
    this._tick++;
    this._cachedFontString = null;
    this.emit("update", this);
  }
  /** Resets all properties to the default values */
  reset() {
    const defaultStyle = _TextStyle2.defaultTextStyle;
    for (const key in defaultStyle) {
      this[key] = defaultStyle[key];
    }
  }
  /**
   * Assigns partial style options to this TextStyle instance.
   * Uses public setters to ensure proper value transformation.
   * @param values - Partial style options to assign
   * @returns This TextStyle instance for chaining
   */
  assign(values) {
    for (const key in values) {
      const thisKey = key;
      this[thisKey] = values[key];
    }
    return this;
  }
  /**
   * Returns a unique key for this instance.
   * This key is used for caching.
   * @returns {string} Unique key for the instance
   */
  get styleKey() {
    return `${this.uid}-${this._tick}`;
  }
  /**
   * Returns the CSS font string for this style, cached for performance.
   * @internal
   * @returns CSS font string
   */
  get _fontString() {
    if (this._cachedFontString === null) {
      this._cachedFontString = fontStringFromTextStyle(this);
    }
    return this._cachedFontString;
  }
  /**
   * Returns an object with the same values as this TextStyle instance.
   * @returns Object with the same values as this TextStyle instance
   * @example
   * ```ts
   * const style = new TextStyle({
   *     fontSize: 24,
   *     fill: 0xff0000,
   *     stroke: { color: 0x0000ff, width: 2 }
   * });
   * const object = style.toObject();
   * console.log(object);
   * // { fontSize: 24, fill: 0xff0000, stroke: { color: 0x0000ff, width: 2 } }
   * ```
   */
  _toObject() {
    return {
      align: this.align,
      breakWords: this.breakWords,
      dropShadow: this._dropShadow ? __spreadValues({}, this._dropShadow) : null,
      fill: this._fill ? __spreadValues({}, this._fill) : void 0,
      fontFamily: this.fontFamily,
      fontSize: this.fontSize,
      fontStyle: this.fontStyle,
      fontVariant: this.fontVariant,
      fontWeight: this.fontWeight,
      leading: this.leading,
      letterSpacing: this.letterSpacing,
      lineHeight: this.lineHeight,
      padding: this.padding,
      stroke: this._stroke ? __spreadValues({}, this._stroke) : void 0,
      textBaseline: this.textBaseline,
      trim: this.trim,
      whiteSpace: this.whiteSpace,
      wordWrap: this.wordWrap,
      wordWrapWidth: this.wordWrapWidth,
      filters: this._filters ? [...this._filters] : void 0,
      tagStyles: this._tagStyles ? __spreadValues({}, this._tagStyles) : void 0
    };
  }
  /**
   * Creates a new TextStyle object with the same values as this one.
   * @returns New cloned TextStyle object
   */
  clone() {
    return new _TextStyle2(this._toObject());
  }
  /**
   * Returns the final padding for the text style, taking into account any filters applied.
   * Used internally for correct measurements
   * @internal
   * @returns {number} The final padding for the text style.
   */
  _getFinalPadding() {
    let filterPadding = 0;
    if (this._filters) {
      for (let i = 0; i < this._filters.length; i++) {
        filterPadding += this._filters[i].padding;
      }
    }
    return Math.max(this._padding, filterPadding);
  }
  /**
   * Destroys this text style.
   * @param options - Options parameter. A boolean will act as if all options
   *  have been set to that value
   * @example
   * // Destroy the text style and its textures
   * textStyle.destroy({ texture: true, textureSource: true });
   * textStyle.destroy(true);
   */
  destroy(options = false) {
    this.removeAllListeners();
    const destroyTexture = typeof options === "boolean" ? options : options?.texture;
    if (destroyTexture) {
      const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
      if (this._fill?.texture) {
        this._fill.texture.destroy(destroyTextureSource);
      }
      if (this._originalFill?.texture) {
        this._originalFill.texture.destroy(destroyTextureSource);
      }
      if (this._stroke?.texture) {
        this._stroke.texture.destroy(destroyTextureSource);
      }
      if (this._originalStroke?.texture) {
        this._originalStroke.texture.destroy(destroyTextureSource);
      }
    }
    this._fill = null;
    this._stroke = null;
    this.dropShadow = null;
    this._originalStroke = null;
    this._originalFill = null;
  }
  _createProxy(value, cb) {
    return new Proxy(value, {
      set: (target, property, newValue) => {
        if (target[property] === newValue) return true;
        target[property] = newValue;
        cb?.(property, newValue);
        this.update();
        return true;
      }
    });
  }
  _isFillStyle(value) {
    return (value ?? null) !== null && !(Color.isColorLike(value) || value instanceof FillGradient || value instanceof FillPattern);
  }
};
_TextStyle.defaultDropShadow = {
  alpha: 1,
  angle: Math.PI / 6,
  blur: 0,
  color: "black",
  distance: 5
};
_TextStyle.defaultTextStyle = {
  align: "left",
  breakWords: false,
  dropShadow: null,
  fill: "black",
  fontFamily: "Arial",
  fontSize: 26,
  fontStyle: "normal",
  fontVariant: "normal",
  fontWeight: "normal",
  leading: 0,
  letterSpacing: 0,
  lineHeight: 0,
  padding: 0,
  stroke: null,
  textBaseline: "alphabetic",
  trim: false,
  whiteSpace: "pre",
  wordWrap: false,
  wordWrapWidth: 100
};
var TextStyle = _TextStyle;
function convertV7Tov8Style(style) {
  const oldStyle = style;
  if (typeof oldStyle.dropShadow === "boolean" && oldStyle.dropShadow) {
    const defaults = TextStyle.defaultDropShadow;
    style.dropShadow = {
      alpha: oldStyle.dropShadowAlpha ?? defaults.alpha,
      angle: oldStyle.dropShadowAngle ?? defaults.angle,
      blur: oldStyle.dropShadowBlur ?? defaults.blur,
      color: oldStyle.dropShadowColor ?? defaults.color,
      distance: oldStyle.dropShadowDistance ?? defaults.distance
    };
  }
  if (oldStyle.strokeThickness !== void 0) {
    deprecation(v8_0_0, "strokeThickness is now a part of stroke");
    const color = oldStyle.stroke;
    let obj = {};
    if (Color.isColorLike(color)) {
      obj.color = color;
    } else if (color instanceof FillGradient || color instanceof FillPattern) {
      obj.fill = color;
    } else if (Object.hasOwnProperty.call(color, "color") || Object.hasOwnProperty.call(color, "fill")) {
      obj = color;
    } else {
      throw new Error("Invalid stroke value.");
    }
    style.stroke = __spreadProps(__spreadValues({}, obj), {
      width: oldStyle.strokeThickness
    });
  }
  if (Array.isArray(oldStyle.fillGradientStops)) {
    deprecation(v8_0_0, "gradient fill is now a fill pattern: `new FillGradient(...)`");
    if (!Array.isArray(oldStyle.fill) || oldStyle.fill.length === 0) {
      throw new Error("Invalid fill value. Expected an array of colors for gradient fill.");
    }
    if (oldStyle.fill.length !== oldStyle.fillGradientStops.length) {
      warn("The number of fill colors must match the number of fill gradient stops.");
    }
    const gradientFill = new FillGradient({
      start: { x: 0, y: 0 },
      end: { x: 0, y: 1 },
      textureSpace: "local"
    });
    const fillGradientStops = oldStyle.fillGradientStops.slice();
    const fills = oldStyle.fill.map((color) => Color.shared.setValue(color).toNumber());
    fillGradientStops.forEach((stop, index) => {
      gradientFill.addColorStop(stop, fills[index]);
    });
    style.fill = {
      fill: gradientFill
    };
  }
}

// node_modules/pixi.js/lib/scene/text/canvas/utils/getCanvasFillStyle.mjs
var PRECISION = 1e5;
function getCanvasFillStyle(fillStyle, context, textMetrics, padding = 0, offsetX = 0, offsetY = 0) {
  if (fillStyle.texture === Texture.WHITE && !fillStyle.fill) {
    return Color.shared.setValue(fillStyle.color).setAlpha(fillStyle.alpha ?? 1).toHexa();
  } else if (!fillStyle.fill) {
    const pattern = context.createPattern(fillStyle.texture.source.resource, "repeat");
    const tempMatrix = fillStyle.matrix.copyTo(Matrix.shared);
    tempMatrix.scale(fillStyle.texture.source.pixelWidth, fillStyle.texture.source.pixelHeight);
    pattern.setTransform(tempMatrix);
    return pattern;
  } else if (fillStyle.fill instanceof FillPattern) {
    const fillPattern = fillStyle.fill;
    const pattern = context.createPattern(fillPattern.texture.source.resource, "repeat");
    canvasUtils.applyPatternTransform(pattern, fillPattern.transform, false);
    return pattern;
  } else if (fillStyle.fill instanceof FillGradient) {
    const fillGradient = fillStyle.fill;
    const isLinear = fillGradient.type === "linear";
    const isLocal = fillGradient.textureSpace === "local";
    let width = 1;
    let height = 1;
    if (isLocal && textMetrics) {
      width = textMetrics.width + padding;
      height = textMetrics.height + padding;
    }
    let gradient;
    let isNearlyVertical = false;
    if (isLinear) {
      const { start, end } = fillGradient;
      gradient = context.createLinearGradient(
        start.x * width + offsetX,
        start.y * height + offsetY,
        end.x * width + offsetX,
        end.y * height + offsetY
      );
      isNearlyVertical = Math.abs(end.x - start.x) < Math.abs((end.y - start.y) * 0.1);
    } else {
      const { center, innerRadius, outerCenter, outerRadius } = fillGradient;
      gradient = context.createRadialGradient(
        center.x * width + offsetX,
        center.y * height + offsetY,
        innerRadius * width,
        outerCenter.x * width + offsetX,
        outerCenter.y * height + offsetY,
        outerRadius * width
      );
    }
    if (isNearlyVertical && isLocal && textMetrics) {
      const ratio = textMetrics.lineHeight / height;
      for (let i = 0; i < textMetrics.lines.length; i++) {
        const start = (i * textMetrics.lineHeight + padding / 2) / height;
        fillGradient.colorStops.forEach((stop) => {
          let globalStop = start + stop.offset * ratio;
          globalStop = Math.max(0, Math.min(1, globalStop));
          gradient.addColorStop(
            // fix to 5 decimal places to avoid floating point precision issues
            Math.floor(globalStop * PRECISION) / PRECISION,
            Color.shared.setValue(stop.color).toHex()
          );
        });
      }
    } else {
      fillGradient.colorStops.forEach((stop) => {
        gradient.addColorStop(stop.offset, Color.shared.setValue(stop.color).toHex());
      });
    }
    return gradient;
  }
  warn("FillStyle not recognised", fillStyle);
  return "red";
}

// node_modules/pixi.js/lib/scene/text-bitmap/DynamicBitmapFont.mjs
var _DynamicBitmapFont = class _DynamicBitmapFont2 extends AbstractBitmapFont {
  /**
   * @param options - The options for the dynamic bitmap font.
   */
  constructor(options) {
    super();
    this.resolution = 1;
    this.pages = [];
    this._padding = 0;
    this._measureCache = /* @__PURE__ */ Object.create(null);
    this._currentChars = [];
    this._currentX = 0;
    this._currentY = 0;
    this._currentMaxCharHeight = 0;
    this._currentPageIndex = -1;
    this._skipKerning = false;
    const dynamicOptions = __spreadValues(__spreadValues({}, _DynamicBitmapFont2.defaultOptions), options);
    this._textureSize = dynamicOptions.textureSize;
    this._mipmap = dynamicOptions.mipmap;
    const style = dynamicOptions.style.clone();
    if (dynamicOptions.overrideFill) {
      style._fill.color = 16777215;
      style._fill.alpha = 1;
      style._fill.texture = Texture.WHITE;
      style._fill.fill = null;
    }
    this.applyFillAsTint = dynamicOptions.overrideFill;
    const requestedFontSize = style.fontSize;
    style.fontSize = this.baseMeasurementFontSize;
    const font = fontStringFromTextStyle(style);
    if (dynamicOptions.overrideSize) {
      if (style._stroke) {
        style._stroke.width *= this.baseRenderedFontSize / requestedFontSize;
      }
      if (style.dropShadow) {
        style.dropShadow.blur *= this.baseRenderedFontSize / requestedFontSize;
        style.dropShadow.distance *= this.baseRenderedFontSize / requestedFontSize;
      }
    } else {
      style.fontSize = this.baseRenderedFontSize = requestedFontSize;
    }
    this._style = style;
    this._skipKerning = dynamicOptions.skipKerning ?? false;
    this.resolution = dynamicOptions.resolution ?? 1;
    this._padding = dynamicOptions.padding ?? 4;
    if (dynamicOptions.textureStyle) {
      this._textureStyle = dynamicOptions.textureStyle instanceof TextureStyle ? dynamicOptions.textureStyle : new TextureStyle(dynamicOptions.textureStyle);
    }
    this.fontMetrics = CanvasTextMetrics.measureFont(font);
    this.lineHeight = style.lineHeight || this.fontMetrics.fontSize || style.fontSize;
  }
  ensureCharacters(chars) {
    const charList = CanvasTextMetrics.graphemeSegmenter(chars).filter((char) => !this._currentChars.includes(char)).filter((char, index, self) => self.indexOf(char) === index);
    if (!charList.length) return;
    this._currentChars = [...this._currentChars, ...charList];
    let pageData;
    if (this._currentPageIndex === -1) {
      pageData = this._nextPage();
    } else {
      pageData = this.pages[this._currentPageIndex];
    }
    let { canvas, context } = pageData.canvasAndContext;
    let textureSource = pageData.texture.source;
    const style = this._style;
    let currentX = this._currentX;
    let currentY = this._currentY;
    let currentMaxCharHeight = this._currentMaxCharHeight;
    const fontScale = this.baseRenderedFontSize / this.baseMeasurementFontSize;
    const extraPadding = (style.dropShadow?.distance ?? 0) + (style._stroke?.width ?? 0);
    const padding = this._padding + extraPadding;
    let skipTexture = false;
    const maxTextureWidth = canvas.width / this.resolution;
    const maxTextureHeight = canvas.height / this.resolution;
    for (let i = 0; i < charList.length; i++) {
      const char = charList[i];
      const metrics = CanvasTextMetrics.measureText(char, style, canvas, false);
      metrics.lineHeight = metrics.height;
      const width = metrics.width * fontScale;
      const textureGlyphWidth = Math.ceil((style.fontStyle === "italic" ? 2 : 1) * width);
      const height = metrics.height * fontScale;
      const paddedWidth = textureGlyphWidth + padding * 2;
      const paddedHeight = height + padding * 2;
      skipTexture = false;
      if (char !== "\n" && char !== "\r" && char !== "	" && char !== " ") {
        skipTexture = true;
        currentMaxCharHeight = Math.ceil(Math.max(paddedHeight, currentMaxCharHeight));
      }
      if (currentX + paddedWidth > maxTextureWidth) {
        currentY += currentMaxCharHeight;
        currentMaxCharHeight = paddedHeight;
        currentX = 0;
        if (currentY + currentMaxCharHeight > maxTextureHeight) {
          textureSource.update();
          const pageData2 = this._nextPage();
          canvas = pageData2.canvasAndContext.canvas;
          context = pageData2.canvasAndContext.context;
          textureSource = pageData2.texture.source;
          currentX = 0;
          currentY = 0;
          currentMaxCharHeight = 0;
        }
      }
      const xAdvance = context.measureText(char).width / fontScale;
      this.chars[char] = {
        id: char.codePointAt(0),
        xOffset: -(padding / fontScale),
        yOffset: -(padding / fontScale),
        xAdvance,
        kerning: {}
      };
      if (skipTexture) {
        this._drawGlyph(
          context,
          metrics,
          currentX + padding,
          currentY + padding,
          fontScale,
          style
        );
        const px = textureSource.width * fontScale;
        const py = textureSource.height * fontScale;
        const frame = new Rectangle(
          currentX / px * textureSource.width,
          currentY / py * textureSource.height,
          paddedWidth / px * textureSource.width,
          paddedHeight / py * textureSource.height
        );
        this.chars[char].texture = new Texture({
          source: textureSource,
          frame
        });
        currentX += Math.ceil(paddedWidth);
      }
    }
    textureSource.update();
    this._currentX = currentX;
    this._currentY = currentY;
    this._currentMaxCharHeight = currentMaxCharHeight;
    if (!this._skipKerning) this._applyKerning(charList, context, fontScale);
  }
  /**
   * @deprecated since 8.0.0
   * The map of base page textures (i.e., sheets of glyphs).
   */
  get pageTextures() {
    deprecation(v8_0_0, "BitmapFont.pageTextures is deprecated, please use BitmapFont.pages instead.");
    return this.pages;
  }
  _applyKerning(newChars, context, fontScale) {
    const measureCache = this._measureCache;
    for (let i = 0; i < newChars.length; i++) {
      const first = newChars[i];
      for (let j = 0; j < this._currentChars.length; j++) {
        const second = this._currentChars[j];
        let c1 = measureCache[first];
        if (!c1) c1 = measureCache[first] = context.measureText(first).width;
        let c2 = measureCache[second];
        if (!c2) c2 = measureCache[second] = context.measureText(second).width;
        let total = context.measureText(first + second).width;
        let amount = total - (c1 + c2);
        if (amount && this.chars[first]) {
          this.chars[first].kerning[second] = amount / fontScale;
        }
        total = context.measureText(first + second).width;
        amount = total - (c1 + c2);
        if (amount && this.chars[second]) {
          this.chars[second].kerning[first] = amount / fontScale;
        }
      }
    }
  }
  _nextPage() {
    this._currentPageIndex++;
    const textureResolution = this.resolution;
    const canvasAndContext = CanvasPool.getOptimalCanvasAndContext(
      this._textureSize,
      this._textureSize,
      textureResolution
    );
    this._setupContext(canvasAndContext.context, this._style, textureResolution);
    const resolution = textureResolution * (this.baseRenderedFontSize / this.baseMeasurementFontSize);
    const texture = new Texture({
      source: new ImageSource({
        resource: canvasAndContext.canvas,
        resolution,
        alphaMode: "premultiply-alpha-on-upload",
        autoGenerateMipmaps: this._mipmap
      })
    });
    if (this._textureStyle) {
      texture.source.style = this._textureStyle;
    }
    const pageData = {
      canvasAndContext,
      texture
    };
    this.pages[this._currentPageIndex] = pageData;
    return pageData;
  }
  // canvas style!
  _setupContext(context, style, resolution) {
    style.fontSize = this.baseRenderedFontSize;
    context.scale(resolution, resolution);
    context.font = fontStringFromTextStyle(style);
    style.fontSize = this.baseMeasurementFontSize;
    context.textBaseline = style.textBaseline;
    const stroke = style._stroke;
    const strokeThickness = stroke?.width ?? 0;
    if (stroke) {
      context.lineWidth = strokeThickness;
      context.lineJoin = stroke.join;
      context.miterLimit = stroke.miterLimit;
      context.strokeStyle = getCanvasFillStyle(stroke, context);
    }
    if (style._fill) {
      context.fillStyle = getCanvasFillStyle(style._fill, context);
    }
    if (style.dropShadow) {
      const shadowOptions = style.dropShadow;
      const rgb = Color.shared.setValue(shadowOptions.color).toArray();
      const dropShadowBlur = shadowOptions.blur * resolution;
      const dropShadowDistance = shadowOptions.distance * resolution;
      context.shadowColor = `rgba(${rgb[0] * 255},${rgb[1] * 255},${rgb[2] * 255},${shadowOptions.alpha})`;
      context.shadowBlur = dropShadowBlur;
      context.shadowOffsetX = Math.cos(shadowOptions.angle) * dropShadowDistance;
      context.shadowOffsetY = Math.sin(shadowOptions.angle) * dropShadowDistance;
    } else {
      context.shadowColor = "black";
      context.shadowBlur = 0;
      context.shadowOffsetX = 0;
      context.shadowOffsetY = 0;
    }
  }
  _drawGlyph(context, metrics, x, y, fontScale, style) {
    const char = metrics.text;
    const fontProperties = metrics.fontProperties;
    const stroke = style._stroke;
    const strokeThickness = (stroke?.width ?? 0) * fontScale;
    const tx = x + strokeThickness / 2;
    const ty = y - strokeThickness / 2;
    const descent = fontProperties.descent * fontScale;
    const lineHeight = metrics.lineHeight * fontScale;
    let removeShadow = false;
    if (style.stroke && strokeThickness) {
      removeShadow = true;
      context.strokeText(char, tx, ty + lineHeight - descent);
    }
    const { shadowBlur, shadowOffsetX, shadowOffsetY } = context;
    if (style._fill) {
      if (removeShadow) {
        context.shadowBlur = 0;
        context.shadowOffsetX = 0;
        context.shadowOffsetY = 0;
      }
      context.fillText(char, tx, ty + lineHeight - descent);
    }
    if (removeShadow) {
      context.shadowBlur = shadowBlur;
      context.shadowOffsetX = shadowOffsetX;
      context.shadowOffsetY = shadowOffsetY;
    }
  }
  destroy() {
    super.destroy();
    for (let i = 0; i < this.pages.length; i++) {
      const { canvasAndContext, texture } = this.pages[i];
      CanvasPool.returnCanvasAndContext(canvasAndContext);
      texture.destroy(true);
    }
    this.pages = null;
  }
};
_DynamicBitmapFont.defaultOptions = {
  textureSize: 512,
  style: new TextStyle(),
  mipmap: true
};
var DynamicBitmapFont = _DynamicBitmapFont;

// node_modules/pixi.js/lib/scene/text-bitmap/utils/getBitmapTextLayout.mjs
function getBitmapTextLayout(chars, style, font, trimEnd) {
  const layoutData = {
    width: 0,
    height: 0,
    offsetY: 0,
    scale: style.fontSize / font.baseMeasurementFontSize,
    lines: [{
      width: 0,
      charPositions: [],
      spaceWidth: 0,
      spacesIndex: [],
      chars: []
    }]
  };
  layoutData.offsetY = font.baseLineOffset;
  let currentLine = layoutData.lines[0];
  let previousChar = null;
  let firstWord = true;
  const currentWord = {
    spaceWord: false,
    width: 0,
    start: 0,
    index: 0,
    // use index to not modify the array as we use it a lot!
    positions: [],
    chars: []
  };
  const scale = font.baseMeasurementFontSize / style.fontSize;
  const adjustedLetterSpacing = style.letterSpacing * scale;
  const adjustedWordWrapWidth = style.wordWrapWidth * scale;
  const adjustedLineHeight = style.lineHeight ? style.lineHeight * scale : font.lineHeight;
  const breakWords = style.wordWrap && style.breakWords;
  const shouldCollapseSpaces = collapseSpaces(style.whiteSpace);
  const shouldCollapseNewlines = collapseNewlines(style.whiteSpace);
  if (shouldCollapseSpaces || shouldCollapseNewlines) {
    const processed = [];
    let prevWasBreakingSpace = shouldCollapseSpaces;
    for (let c = 0; c < chars.length; c++) {
      let char = chars[c];
      if (char === "\r" || char === "\n") {
        if (shouldCollapseNewlines) {
          if (char === "\r" && chars[c + 1] === "\n") c++;
          char = " ";
        } else {
          if (shouldCollapseSpaces) prevWasBreakingSpace = true;
          processed.push(char);
          continue;
        }
      }
      if (isBreakingSpace(char)) {
        if (shouldCollapseSpaces && isCollapsibleSpace(char)) {
          if (prevWasBreakingSpace) continue;
          prevWasBreakingSpace = true;
          processed.push(" ");
        } else {
          prevWasBreakingSpace = false;
          processed.push(char);
        }
      } else {
        prevWasBreakingSpace = false;
        processed.push(char);
      }
    }
    chars = processed;
  }
  const nextWord = (word) => {
    const start = currentLine.width;
    for (let j = 0; j < currentWord.index; j++) {
      const position = word.positions[j];
      currentLine.chars.push(word.chars[j]);
      currentLine.charPositions.push(position + start);
    }
    currentLine.width += word.width;
    if (currentWord.index > 0 || !shouldCollapseSpaces) {
      firstWord = false;
    }
    currentWord.width = 0;
    currentWord.index = 0;
    currentWord.chars.length = 0;
  };
  const nextLine = () => {
    let index = currentLine.chars.length - 1;
    if (trimEnd) {
      let lastChar = currentLine.chars[index];
      while (isCollapsibleSpace(lastChar)) {
        currentLine.width -= font.chars[lastChar].xAdvance;
        currentLine.spacesIndex.pop();
        lastChar = currentLine.chars[--index];
      }
    }
    layoutData.width = Math.max(layoutData.width, currentLine.width);
    currentLine = {
      width: 0,
      charPositions: [],
      chars: [],
      spaceWidth: 0,
      spacesIndex: []
    };
    firstWord = true;
    layoutData.lines.push(currentLine);
    layoutData.height += adjustedLineHeight;
  };
  const checkIsOverflow = (lineWidth) => lineWidth - adjustedLetterSpacing > adjustedWordWrapWidth;
  for (let i = 0; i < chars.length + 1; i++) {
    let char;
    const isEnd = i === chars.length;
    if (!isEnd) {
      char = chars[i];
    }
    const charData = font.chars[char];
    const isSpace = /(?:\s)/.test(char);
    const isWordBreak = isSpace || char === "\r" || char === "\n" || isEnd;
    if (isWordBreak) {
      const addWordToNextLine = !firstWord && style.wordWrap && checkIsOverflow(currentLine.width + currentWord.width);
      if (addWordToNextLine) {
        nextLine();
        nextWord(currentWord);
        if (!isEnd && charData) {
          currentLine.charPositions.push(0);
        }
      } else {
        currentWord.start = currentLine.width;
        nextWord(currentWord);
        if (!isEnd && charData) {
          currentLine.charPositions.push(0);
        }
      }
      if (char === "\r" || char === "\n") {
        nextLine();
      } else if (!isEnd && charData) {
        const spaceWidth = charData.xAdvance + (charData.kerning?.[previousChar] || 0) + adjustedLetterSpacing;
        currentLine.width += spaceWidth;
        currentLine.spaceWidth = spaceWidth;
        currentLine.spacesIndex.push(currentLine.charPositions.length);
        currentLine.chars.push(char);
      }
    } else if (charData) {
      const kerning = charData.kerning?.[previousChar] || 0;
      const nextCharWidth = charData.xAdvance + kerning + adjustedLetterSpacing;
      const wordExceedsWrapWidth = breakWords && checkIsOverflow(currentWord.width + nextCharWidth);
      if (wordExceedsWrapWidth) {
        if (!firstWord) {
          nextLine();
        }
        nextWord(currentWord);
        nextLine();
      }
      currentWord.positions[currentWord.index++] = currentWord.width + kerning;
      currentWord.chars.push(char);
      currentWord.width += nextCharWidth;
      if (isBreakAfterChar(char)) {
        const addWordToNextLine = !firstWord && style.wordWrap && checkIsOverflow(currentLine.width + currentWord.width);
        if (addWordToNextLine) {
          nextLine();
        }
        nextWord(currentWord);
      }
    }
    previousChar = char;
  }
  nextLine();
  if (style.align === "center") {
    alignCenter(layoutData);
  } else if (style.align === "right") {
    alignRight(layoutData);
  } else if (style.align === "justify") {
    alignJustify(layoutData);
  }
  return layoutData;
}
function alignCenter(measurementData) {
  for (let i = 0; i < measurementData.lines.length; i++) {
    const line = measurementData.lines[i];
    const offset = measurementData.width / 2 - line.width / 2;
    for (let j = 0; j < line.charPositions.length; j++) {
      line.charPositions[j] += offset;
    }
  }
}
function alignRight(measurementData) {
  for (let i = 0; i < measurementData.lines.length; i++) {
    const line = measurementData.lines[i];
    const offset = measurementData.width - line.width;
    for (let j = 0; j < line.charPositions.length; j++) {
      line.charPositions[j] += offset;
    }
  }
}
function alignJustify(measurementData) {
  const width = measurementData.width;
  for (let i = 0; i < measurementData.lines.length - 2; i++) {
    const line = measurementData.lines[i];
    let indy = 0;
    let spaceIndex = line.spacesIndex[indy++];
    let offset = 0;
    const totalSpaces = line.spacesIndex.length;
    const newSpaceWidth = (width - line.width) / totalSpaces;
    const spaceWidth = newSpaceWidth;
    for (let j = 0; j < line.charPositions.length; j++) {
      if (j === spaceIndex) {
        spaceIndex = line.spacesIndex[indy++];
        offset += spaceWidth;
      }
      line.charPositions[j] += offset;
    }
  }
}

// node_modules/pixi.js/lib/scene/text-bitmap/utils/resolveCharacters.mjs
function resolveCharacters(chars) {
  if (chars === "") {
    return [];
  }
  if (typeof chars === "string") {
    chars = [chars];
  }
  const result = [];
  for (let i = 0, j = chars.length; i < j; i++) {
    const item = chars[i];
    if (Array.isArray(item)) {
      if (item.length !== 2) {
        throw new Error(`[BitmapFont]: Invalid character range length, expecting 2 got ${item.length}.`);
      }
      if (item[0].length === 0 || item[1].length === 0) {
        throw new Error("[BitmapFont]: Invalid character delimiter.");
      }
      const startCode = item[0].charCodeAt(0);
      const endCode = item[1].charCodeAt(0);
      if (endCode < startCode) {
        throw new Error("[BitmapFont]: Invalid character range.");
      }
      for (let i2 = startCode, j2 = endCode; i2 <= j2; i2++) {
        result.push(String.fromCharCode(i2));
      }
    } else {
      result.push(...Array.from(item));
    }
  }
  if (result.length === 0) {
    throw new Error("[BitmapFont]: Empty set when resolving characters.");
  }
  return result;
}

// node_modules/pixi.js/lib/scene/text-bitmap/BitmapFontManager.mjs
var fontCount = 0;
var BitmapFontManagerClass = class {
  constructor() {
    this.ALPHA = [["a", "z"], ["A", "Z"], " "];
    this.NUMERIC = [["0", "9"]];
    this.ALPHANUMERIC = [["a", "z"], ["A", "Z"], ["0", "9"], " "];
    this.ASCII = [[" ", "~"]];
    this.defaultOptions = {
      chars: this.ALPHANUMERIC,
      resolution: 1,
      padding: 4,
      skipKerning: false,
      textureStyle: null
    };
    this.measureCache = lru(1e3);
  }
  /**
   * Get a font for the specified text and style.
   * @param text - The text to get the font for
   * @param style - The style to use
   */
  getFont(text, style) {
    let fontFamilyKey = `${style.fontFamily}-bitmap`;
    let overrideFill = true;
    if (Cache.has(fontFamilyKey)) {
      const dynamicFont2 = Cache.get(fontFamilyKey);
      dynamicFont2.ensureCharacters?.(text);
      return dynamicFont2;
    }
    if (style._fill.fill && !style._stroke) {
      fontFamilyKey += style._fill.fill.styleKey;
      overrideFill = false;
    } else if (style._stroke || style.dropShadow) {
      fontFamilyKey = `${style.styleKey}-bitmap`;
      overrideFill = false;
    }
    fontFamilyKey += `-${style.fontStyle}`;
    fontFamilyKey += `-${style.fontVariant}`;
    fontFamilyKey += `-${style.fontWeight}`;
    if (!Cache.has(fontFamilyKey)) {
      const styleCopy = Object.create(style);
      styleCopy["_lineHeight"] = 0;
      const fnt = new DynamicBitmapFont(__spreadValues({
        style: styleCopy,
        overrideFill,
        overrideSize: true
      }, this.defaultOptions));
      fontCount++;
      if (fontCount > 50) {
        warn("BitmapText", `You have dynamically created ${fontCount} bitmap fonts, this can be inefficient. Try pre installing your font styles using \`BitmapFont.install({name:"style1", style})\``);
      }
      fnt.once("destroy", () => {
        fontCount--;
        Cache.remove(fontFamilyKey);
      });
      Cache.set(
        fontFamilyKey,
        fnt
      );
    }
    const dynamicFont = Cache.get(fontFamilyKey);
    dynamicFont.ensureCharacters?.(text);
    return dynamicFont;
  }
  /**
   * Get the layout of a text for the specified style.
   * @param text - The text to get the layout for
   * @param style - The style to use
   * @param trimEnd - Whether to ignore whitespaces at the end of each line
   */
  getLayout(text, style, trimEnd = true) {
    const bitmapFont = this.getFont(text, style);
    const id = `${text}-${style.styleKey}-${trimEnd}`;
    if (this.measureCache.has(id)) {
      return this.measureCache.get(id);
    }
    const segments = CanvasTextMetrics.graphemeSegmenter(text);
    const layoutData = getBitmapTextLayout(segments, style, bitmapFont, trimEnd);
    this.measureCache.set(id, layoutData);
    return layoutData;
  }
  /**
   * Measure the text using the specified style.
   * @param text - The text to measure
   * @param style - The style to use
   * @param trimEnd - Whether to ignore whitespaces at the end of each line
   */
  measureText(text, style, trimEnd = true) {
    return this.getLayout(text, style, trimEnd);
  }
  // eslint-disable-next-line max-len
  install(...args) {
    let options = args[0];
    if (typeof options === "string") {
      options = {
        name: options,
        style: args[1],
        chars: args[2]?.chars,
        resolution: args[2]?.resolution,
        padding: args[2]?.padding,
        skipKerning: args[2]?.skipKerning
      };
      deprecation(v8_0_0, "BitmapFontManager.install(name, style, options) is deprecated, use BitmapFontManager.install({name, style, ...options})");
    }
    const name = options?.name;
    if (!name) {
      throw new Error("[BitmapFontManager] Property `name` is required.");
    }
    options = __spreadValues(__spreadValues({}, this.defaultOptions), options);
    const textStyle = options.style;
    const style = textStyle instanceof TextStyle ? textStyle : new TextStyle(textStyle);
    const overrideFill = options.dynamicFill ?? this._canUseTintForStyle(style);
    const font = new DynamicBitmapFont({
      style,
      overrideFill,
      skipKerning: options.skipKerning,
      padding: options.padding,
      resolution: options.resolution,
      overrideSize: false,
      textureStyle: options.textureStyle
    });
    const flatChars = resolveCharacters(options.chars);
    font.ensureCharacters(flatChars.join(""));
    Cache.set(`${name}-bitmap`, font);
    font.once("destroy", () => Cache.remove(`${name}-bitmap`));
    return font;
  }
  /**
   * Uninstalls a bitmap font from the cache.
   * @param {string} name - The name of the bitmap font to uninstall.
   */
  uninstall(name) {
    const cacheKey = `${name}-bitmap`;
    const font = Cache.get(cacheKey);
    if (font) {
      font.destroy();
    }
  }
  /**
   * Determines if a style can use tinting instead of baking colors into the bitmap.
   * Tinting is more efficient as it allows reusing the same bitmap with different colors.
   * @param style - The text style to evaluate
   * @returns true if the style can use tinting, false if colors must be baked in
   * @private
   */
  _canUseTintForStyle(style) {
    return !style._stroke && (!style.dropShadow || style.dropShadow.color === 0) && !style._fill.fill && style._fill.color === 16777215;
  }
};
var BitmapFontManager = new BitmapFontManagerClass();

// node_modules/pixi.js/lib/scene/text-bitmap/BitmapFont.mjs
var BitmapFont = class extends AbstractBitmapFont {
  constructor(options, url) {
    super();
    const { textures, data } = options;
    Object.keys(data.pages).forEach((key) => {
      const pageData = data.pages[parseInt(key, 10)];
      const texture = textures[pageData.id];
      this.pages.push({ texture });
    });
    Object.keys(data.chars).forEach((key) => {
      const charData = data.chars[key];
      const {
        frame: textureFrame,
        source: textureSource,
        rotate: textureRotate
      } = textures[charData.page];
      const frame = groupD8.transformRectCoords(
        charData,
        textureFrame,
        textureRotate,
        new Rectangle()
      );
      const texture = new Texture({
        frame,
        orig: new Rectangle(0, 0, charData.width, charData.height),
        source: textureSource,
        rotate: textureRotate
      });
      this.chars[key] = {
        id: key.codePointAt(0),
        xOffset: charData.xOffset,
        yOffset: charData.yOffset,
        xAdvance: charData.xAdvance,
        kerning: charData.kerning ?? {},
        texture
      };
    });
    this.baseRenderedFontSize = data.fontSize;
    this.baseMeasurementFontSize = data.fontSize;
    this.fontMetrics = {
      ascent: 0,
      descent: 0,
      fontSize: data.fontSize
    };
    this.baseLineOffset = data.baseLineOffset;
    this.lineHeight = data.lineHeight;
    this.fontFamily = data.fontFamily;
    this.distanceField = data.distanceField ?? {
      type: "none",
      range: 0
    };
    this.url = url;
  }
  /** Destroys the BitmapFont object. */
  destroy() {
    super.destroy();
    for (let i = 0; i < this.pages.length; i++) {
      const { texture } = this.pages[i];
      texture.destroy(true);
    }
    this.pages = null;
  }
  /**
   * Generates and installs a bitmap font with the specified options.
   * The font will be cached and available for use in BitmapText objects.
   * @param options - Setup options for font generation
   * @returns Installed font instance
   * @example
   * ```ts
   * // Install a basic font
   * BitmapFont.install({
   *     name: 'Title',
   *     style: {
   *         fontFamily: 'Arial',
   *         fontSize: 32,
   *         fill: '#ffffff'
   *     }
   * });
   *
   * // Install with advanced options
   * BitmapFont.install({
   *     name: 'Custom',
   *     style: {
   *         fontFamily: 'Arial',
   *         fontSize: 24,
   *         fill: '#00ff00',
   *         stroke: { color: '#000000', width: 2 }
   *     },
   *     chars: [['a', 'z'], ['A', 'Z'], ['0', '9']],
   *     resolution: 2,
   *     padding: 4,
   *     textureStyle: {
   *         scaleMode: 'nearest'
   *     }
   * });
   * ```
   */
  static install(options) {
    BitmapFontManager.install(options);
  }
  /**
   * Uninstalls a bitmap font from the cache.
   * This frees up memory and resources associated with the font.
   * @param name - The name of the bitmap font to uninstall
   * @example
   * ```ts
   * // Remove a font when it's no longer needed
   * BitmapFont.uninstall('MyCustomFont');
   *
   * // Clear multiple fonts
   * ['Title', 'Heading', 'Body'].forEach(BitmapFont.uninstall);
   * ```
   */
  static uninstall(name) {
    BitmapFontManager.uninstall(name);
  }
};

export {
  AbstractBitmapFont,
  hasTagStyles,
  hasTagMarkup,
  parseTaggedText,
  getPlainText,
  NEWLINES,
  NEWLINES_SET,
  BREAKING_SPACES,
  BREAKING_SPACES_SET,
  COLLAPSIBLE_SPACES,
  COLLAPSIBLE_SPACES_SET,
  BREAK_AFTER_CHARS,
  BREAK_AFTER_CHARS_SET,
  NEWLINE_SPLIT_REGEX,
  NEWLINE_MATCH_REGEX,
  isNewline,
  isBreakingSpace,
  isCollapsibleSpace,
  isBreakAfterChar,
  collapseSpaces,
  collapseNewlines,
  trimRight,
  tokenize,
  getCharacterGroups,
  measureTaggedText,
  wordWrapTaggedLines,
  tokenizeTaggedRuns,
  wordWrap,
  CanvasTextMetrics,
  fontStringFromTextStyle,
  TextStyle,
  getCanvasFillStyle,
  DynamicBitmapFont,
  getBitmapTextLayout,
  resolveCharacters,
  BitmapFontManager,
  BitmapFont
};
//# sourceMappingURL=chunk-TH4WA54N.js.map
