import {
  BufferResource,
  GpuStencilModesToPixi,
  UboSystem,
  compileBufferSync,
  ensureAttributes,
  getTexelRangeRects,
  localUniformBit,
  localUniformBitGroup2,
  textureBit,
  uboSyncFunctionsWGSL
} from "./chunk-P4Q4RSHI.js";
import {
  AbstractRenderer,
  CLEAR,
  RenderTargetSystem,
  SharedRenderPipes,
  SharedSystems
} from "./chunk-C7R4GKG4.js";
import {
  CanvasSource,
  State
} from "./chunk-RSU6N5IH.js";
import {
  getTextureBatchBindGroup
} from "./chunk-RBG5Z5MZ.js";
import {
  GCManagedHash,
  STENCIL_MODES,
  colorBit,
  compileHighShaderGpuProgram,
  fastCopy,
  generateTextureBatchBit,
  roundPixelsBit
} from "./chunk-XZ3F7MYX.js";
import {
  BindGroup,
  Buffer,
  BufferUsage,
  CanvasPool,
  DOMAdapter,
  ExtensionType,
  Matrix,
  Rectangle,
  RendererType,
  Shader,
  ShaderOverrides,
  Texture,
  TextureSource,
  UniformGroup,
  createIdFromString,
  extensions,
  warn
} from "./chunk-YC5XMVVP.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-I6DCS273.js";

// node_modules/pixi.js/lib/scene/graphics/gpu/GpuGraphicsAdaptor.mjs
var GpuGraphicsAdaptor = class {
  constructor() {
    this._maxTextures = 0;
  }
  contextChange(renderer) {
    const localUniforms = new UniformGroup({
      uTransformMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      uColor: { value: new Float32Array([1, 1, 1, 1]), type: "vec4<f32>" },
      uRound: { value: 0, type: "f32" }
    });
    this._maxTextures = renderer.limits.maxBatchableTextures;
    const gpuProgram = compileHighShaderGpuProgram({
      name: "graphics",
      bits: [
        colorBit,
        generateTextureBatchBit(this._maxTextures),
        localUniformBitGroup2,
        roundPixelsBit
      ]
    });
    this.shader = new Shader({
      gpuProgram,
      resources: {
        // added on the fly!
        localUniforms
      }
    });
  }
  execute(graphicsPipe, renderable) {
    const context = renderable.context;
    const shader = context.customShader || this.shader;
    const renderer = graphicsPipe.renderer;
    const contextSystem = renderer.graphicsContext;
    const {
      batcher,
      instructions
    } = contextSystem.getContextRenderData(context);
    const encoder = renderer.encoder;
    encoder.setGeometry(batcher.geometry, shader.gpuProgram);
    const globalUniformsBindGroup = renderer.globalUniforms.bindGroup;
    encoder.setBindGroup(0, globalUniformsBindGroup, shader.gpuProgram);
    const localBindGroup = renderer.renderPipes.uniformBatch.getUniformBindGroup(shader.resources.localUniforms, true);
    encoder.setBindGroup(2, localBindGroup, shader.gpuProgram);
    const batches = instructions.instructions;
    let topology = null;
    for (let i = 0; i < instructions.instructionSize; i++) {
      const batch = batches[i];
      if (batch.topology !== topology) {
        topology = batch.topology;
        encoder.setPipelineFromGeometryProgramAndState(
          batcher.geometry,
          shader.gpuProgram,
          graphicsPipe.state,
          batch.topology,
          shader._overrides
        );
      }
      shader.groups[1] = batch.bindGroup;
      if (!batch.gpuBindGroup) {
        const textureBatch = batch.textures;
        batch.bindGroup = getTextureBatchBindGroup(
          textureBatch.textures,
          textureBatch.count,
          this._maxTextures
        );
        batch.gpuBindGroup = renderer.bindGroup.getBindGroup(
          batch.bindGroup,
          shader.gpuProgram,
          1
        );
      }
      encoder.setBindGroup(1, batch.bindGroup, shader.gpuProgram);
      encoder.renderPassEncoder.drawIndexed(batch.size, 1, batch.start);
    }
  }
  destroy() {
    this.shader.destroy();
    this.shader = null;
  }
};
GpuGraphicsAdaptor.extension = {
  type: [
    ExtensionType.WebGPUPipesAdaptor
  ],
  name: "graphics"
};

// node_modules/pixi.js/lib/scene/mesh/gpu/GpuMeshAdapter.mjs
var GpuMeshAdapter = class {
  init() {
    const gpuProgram = compileHighShaderGpuProgram({
      name: "mesh",
      bits: [
        localUniformBit,
        textureBit,
        roundPixelsBit
      ]
    });
    this._shader = new Shader({
      gpuProgram,
      resources: {
        uTexture: Texture.EMPTY._source,
        uSampler: Texture.EMPTY._source.style,
        textureUniforms: {
          uTextureMatrix: { type: "mat3x3<f32>", value: new Matrix() }
        }
      }
    });
  }
  execute(meshPipe, mesh) {
    const renderer = meshPipe.renderer;
    let shader = mesh._shader;
    if (!shader) {
      shader = this._shader;
      shader.groups[2] = renderer.texture.getTextureBindGroup(mesh.texture);
    } else if (!shader.gpuProgram) {
      warn("Mesh shader has no gpuProgram", mesh.shader);
      return;
    }
    const gpuProgram = shader.gpuProgram;
    if (gpuProgram.autoAssignGlobalUniforms) {
      shader.groups[0] = renderer.globalUniforms.bindGroup;
    }
    if (gpuProgram.autoAssignLocalUniforms) {
      const localUniforms = meshPipe.localUniforms;
      shader.groups[1] = renderer.renderPipes.uniformBatch.getUniformBindGroup(localUniforms, true);
    }
    renderer.encoder.draw({
      geometry: mesh._geometry,
      shader,
      state: mesh.state
    });
  }
  destroy() {
    this._shader.destroy();
    this._shader = null;
  }
};
GpuMeshAdapter.extension = {
  type: [
    ExtensionType.WebGPUPipesAdaptor
  ],
  name: "mesh"
};

// node_modules/pixi.js/lib/rendering/batcher/gpu/GpuBatchAdaptor.mjs
var tempState = State.for2d();
var GpuBatchAdaptor = class {
  start(batchPipe, geometry, shader) {
    const renderer = batchPipe.renderer;
    const encoder = renderer.encoder;
    const program = shader.gpuProgram;
    this._shader = shader;
    this._geometry = geometry;
    encoder.setGeometry(geometry, program);
    tempState.blendMode = "normal";
    renderer.pipeline.getPipeline(
      geometry,
      program,
      tempState,
      void 0,
      shader._overrides
    );
    const globalUniformsBindGroup = renderer.globalUniforms.bindGroup;
    encoder.resetBindGroup(1);
    encoder.setBindGroup(0, globalUniformsBindGroup, program);
  }
  execute(batchPipe, batch) {
    const program = this._shader.gpuProgram;
    const renderer = batchPipe.renderer;
    const encoder = renderer.encoder;
    if (!batch.bindGroup) {
      const textureBatch = batch.textures;
      batch.bindGroup = getTextureBatchBindGroup(
        textureBatch.textures,
        textureBatch.count,
        renderer.limits.maxBatchableTextures
      );
    }
    tempState.blendMode = batch.blendMode;
    const gpuBindGroup = renderer.bindGroup.getBindGroup(
      batch.bindGroup,
      program,
      1
    );
    const pipeline = renderer.pipeline.getPipeline(
      this._geometry,
      program,
      tempState,
      batch.topology,
      this._shader._overrides
    );
    batch.bindGroup._touch(renderer.gc.now);
    encoder.setPipeline(pipeline);
    encoder.renderPassEncoder.setBindGroup(1, gpuBindGroup);
    encoder.renderPassEncoder.drawIndexed(batch.size, 1, batch.start);
  }
};
GpuBatchAdaptor.extension = {
  type: [
    ExtensionType.WebGPUPipesAdaptor
  ],
  name: "batch"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/BindGroupSystem.mjs
var GpuBindGroupEntry = class {
  constructor(gpuBindGroup, now) {
    this.autoGarbageCollect = true;
    this._gpuData = null;
    this.gpuBindGroup = gpuBindGroup;
    this._gcLastUsed = now;
  }
  /**
   * Native bind groups have no destroy; dropping the reference is the whole release. Anything
   * still holding the group (a recorded render bundle, a graphics batch) keeps it alive, and the
   * next immediate-mode bind simply recreates the cache entry.
   */
  unload() {
    this.gpuBindGroup = null;
  }
};
var BindGroupSystem = class {
  constructor(renderer) {
    this._hash = /* @__PURE__ */ Object.create(null);
    this._renderer = renderer;
    renderer.gc.addResourceHash(this, "_hash", "resource");
    renderer.gc.addCollection(this, "_hash", "hash");
  }
  contextChange(gpu) {
    this._gpu = gpu;
    this._hash = /* @__PURE__ */ Object.create(null);
  }
  getBindGroup(bindGroup, program, groupIndex) {
    const key = `${bindGroup._key}:${program._layoutKey << 4 | groupIndex}`;
    const entry = this._hash[key];
    if (entry) {
      entry._gcLastUsed = this._renderer.gc.now;
      return entry.gpuBindGroup;
    }
    return this._createBindGroup(key, bindGroup, program, groupIndex);
  }
  _createBindGroup(key, group, program, groupIndex) {
    const device = this._gpu.device;
    const groupLayout = program.layout[groupIndex];
    const entries = [];
    const renderer = this._renderer;
    for (const j in groupLayout) {
      const resource = group.resources[j] ?? group.resources[groupLayout[j]];
      if (!resource || resource.destroyed) {
        throw new Error(`[BindGroup] the resource bound as '${j}' was destroyed while a shader still uses it. Remove it from the shader before destroying it.`);
      }
      let gpuResource;
      if (resource._resourceType === "uniformGroup") {
        const uniformGroup = resource;
        renderer.ubo.updateUniformGroup(uniformGroup);
        const buffer = uniformGroup.buffer;
        gpuResource = {
          buffer: renderer.buffer.getGPUBuffer(buffer),
          offset: 0,
          size: buffer.descriptor.size
        };
      } else if (resource._resourceType === "buffer") {
        const buffer = resource;
        gpuResource = {
          buffer: renderer.buffer.getGPUBuffer(buffer),
          offset: 0,
          size: buffer.descriptor.size
        };
      } else if (resource._resourceType === "bufferResource") {
        const bufferResource = resource;
        gpuResource = {
          buffer: renderer.buffer.getGPUBuffer(bufferResource.buffer),
          offset: bufferResource.offset,
          size: bufferResource.size ?? bufferResource.buffer.descriptor.size
        };
      } else if (resource._resourceType === "textureSampler") {
        const sampler = resource;
        gpuResource = renderer.texture.getGpuSampler(sampler);
      } else if (resource._resourceType === "textureSource") {
        const texture = resource;
        gpuResource = renderer.texture.getTextureView(texture);
      } else if (resource._resourceType === "textureView") {
        const textureView = resource;
        gpuResource = renderer.texture.getTextureView(textureView.source, textureView.viewDescriptor);
      }
      entries.push({
        binding: groupLayout[j],
        resource: gpuResource
      });
    }
    const layout = renderer.shader.getProgramData(program).bindGroups[groupIndex];
    const gpuBindGroup = device.createBindGroup({
      layout,
      entries
    });
    this._hash[key] = new GpuBindGroupEntry(gpuBindGroup, renderer.gc.now);
    return gpuBindGroup;
  }
  destroy() {
    this._hash = null;
    this._renderer = null;
  }
};
BindGroupSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "bindGroup"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/buffer/GpuBufferSystem.mjs
var GpuBufferData = class {
  constructor(gpuBuffer) {
    this.gpuBuffer = gpuBuffer;
  }
  destroy() {
    this.gpuBuffer.destroy();
    this.gpuBuffer = null;
  }
};
var GpuBufferSystem = class {
  constructor(renderer) {
    this._renderer = renderer;
    this._managedBuffers = new GCManagedHash({
      renderer,
      type: "resource",
      onUnload: this.onBufferUnload.bind(this),
      name: "gpuBuffer"
    });
  }
  contextChange(gpu) {
    this._gpu = gpu;
    this.destroyAll();
  }
  getGPUBuffer(buffer) {
    buffer._gcLastUsed = this._renderer.gc.now;
    return buffer._gpuData[this._renderer.uid]?.gpuBuffer || this.createGPUBuffer(buffer);
  }
  updateBuffer(buffer) {
    const gpuBuffer = this.getGPUBuffer(buffer);
    const data = buffer.data;
    if (buffer._updateID && data) {
      buffer._updateID = 0;
      this._gpu.device.queue.writeBuffer(
        gpuBuffer,
        buffer._updateOffset,
        data.buffer,
        data.byteOffset + buffer._updateOffset,
        // round to the nearest 4 bytes
        (buffer._updateSize || data.byteLength) + 3 & ~3
      );
    }
    return gpuBuffer;
  }
  /** dispose all WebGL resources of all managed buffers */
  destroyAll() {
    this._managedBuffers.removeAll();
  }
  onBufferUnload(buffer) {
    buffer.off("update", this.updateBuffer, this);
    buffer.off("change", this.onBufferChange, this);
  }
  createGPUBuffer(buffer) {
    const gpuBuffer = this._gpu.device.createBuffer(buffer.descriptor);
    buffer._updateID = 0;
    if (buffer.data) {
      fastCopy(
        buffer.data.buffer,
        gpuBuffer.getMappedRange(),
        buffer.data.byteOffset,
        buffer.data.byteLength
      );
      gpuBuffer.unmap();
    }
    buffer._gpuData[this._renderer.uid] = new GpuBufferData(gpuBuffer);
    if (this._managedBuffers.add(buffer)) {
      buffer.on("update", this.updateBuffer, this);
      buffer.on("change", this.onBufferChange, this);
    }
    return gpuBuffer;
  }
  onBufferChange(buffer) {
    this._managedBuffers.remove(buffer);
    buffer._updateID = 0;
    this.createGPUBuffer(buffer);
  }
  destroy() {
    this._managedBuffers.destroy();
    this._renderer = null;
    this._gpu = null;
  }
};
GpuBufferSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "buffer"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/GpuColorMaskSystem.mjs
var GpuColorMaskSystem = class {
  constructor(renderer) {
    this._colorMaskCache = 15;
    this._renderer = renderer;
  }
  setMask(colorMask) {
    if (this._colorMaskCache === colorMask) return;
    this._colorMaskCache = colorMask;
    this._renderer.pipeline.setColorMask(colorMask);
  }
  destroy() {
    this._renderer = null;
    this._colorMaskCache = null;
  }
};
GpuColorMaskSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "colorMask"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/GpuDeviceSystem.mjs
var tileBasedVendors = /* @__PURE__ */ new Set(["apple", "arm", "qualcomm", "img-tec"]);
var GpuDeviceSystem = class {
  /**
   * @param {WebGPURenderer} renderer - The renderer this System works for.
   */
  constructor(renderer) {
    this._renderer = renderer;
  }
  init(options) {
    return __async(this, null, function* () {
      if (this._initPromise) return this._initPromise;
      this._options = options;
      this._initPromise = (options.gpu ? Promise.resolve(options.gpu) : this._createDeviceAndAdaptor(options)).then((gpu) => this._setGpu(gpu));
      return this._initPromise;
    });
  }
  _setGpu(gpu) {
    this.gpu = gpu;
    this.extensions = {
      transientAttachment: typeof GPUTextureUsage.TRANSIENT_ATTACHMENT === "number",
      tileBased: tileBasedVendors.has(gpu.adapter?.info?.vendor)
    };
    if (!this._options.gpu) {
      void gpu.device.lost.then(() => this._restoreDevice()).catch((e) => warn("WebGPU device was lost and could not be restored", e));
    }
    this._renderer.runners.contextChange.emit(this.gpu);
  }
  _restoreDevice() {
    return __async(this, null, function* () {
      if (!this._renderer) return;
      const gpu = yield this._createDeviceAndAdaptor(this._options);
      if (!this._renderer) {
        gpu.device.destroy();
        return;
      }
      this._setGpu(gpu);
    });
  }
  /**
   * Handle the context change event
   * @param gpu
   */
  contextChange(gpu) {
    this._renderer.gpu = gpu;
  }
  /**
   * Helper class to create a WebGL Context
   * @param {object} options - An options object that gets passed in to the canvas element containing the
   *    context attributes
   * @see https://developer.mozilla.org/en/docs/Web/API/HTMLCanvasElement/getContext
   * @returns {WebGLRenderingContext} the WebGL context
   */
  _createDeviceAndAdaptor(options) {
    return __async(this, null, function* () {
      const adapter = yield DOMAdapter.get().getNavigator().gpu.requestAdapter({
        powerPreference: options.powerPreference,
        forceFallbackAdapter: options.forceFallbackAdapter
      });
      if (!adapter) {
        throw new Error("WebGPU not supported. No GPU adapter was returned by navigator.gpu.requestAdapter().");
      }
      const requiredFeatures = [
        "texture-compression-bc",
        "texture-compression-astc",
        "texture-compression-etc2",
        "indirect-first-instance",
        // more formats for TextureSource `storage`
        "bgra8unorm-storage",
        "texture-formats-tier1"
      ].filter((feature) => adapter.features.has(feature));
      const device = yield adapter.requestDevice({
        requiredFeatures,
        requiredLimits: {
          maxSampledTexturesPerShaderStage: adapter.limits.maxSampledTexturesPerShaderStage,
          maxSamplersPerShaderStage: adapter.limits.maxSamplersPerShaderStage
        }
      });
      return { adapter, device };
    });
  }
  destroy() {
    if (!this._options?.gpu) {
      this.gpu?.device.destroy();
    }
    this.gpu = null;
    this.extensions = null;
    this._renderer = null;
  }
};
GpuDeviceSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "device"
};
GpuDeviceSystem.defaultOptions = {
  /**
   * {@link WebGPUOptions.powerPreference}
   * @default default
   */
  powerPreference: void 0,
  /**
   * Force the use of the fallback adapter
   * @default false
   */
  forceFallbackAdapter: false
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/RenderBundle.mjs
var RenderBundle = class {
  /**
   * @param gpuBundle - The recorded native render bundle.
   * @param stateKey - The pipeline state key captured when recording began.
   * @param device - The device the bundle was recorded on.
   * @param label - Optional debug label for the bundle.
   */
  constructor(gpuBundle, stateKey, device, label) {
    this.gpuBundle = gpuBundle;
    this.stateKey = stateKey;
    this.device = device;
    this.label = label;
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/GpuEncoderSystem.mjs
var GpuEncoderSystem = class {
  constructor(renderer) {
    this._boundBindGroup = /* @__PURE__ */ Object.create(null);
    this._boundVertexBuffer = /* @__PURE__ */ Object.create(null);
    this._renderer = renderer;
    for (let i = 0; i < 16; i++) {
      this._boundBindGroup[i] = { bindGroup: null, program: null, key: null };
    }
  }
  renderStart() {
    this.commandFinished = new Promise((resolve) => {
      this._resolveCommandFinished = resolve;
    });
    this.commandEncoder = this._renderer.gpu.device.createCommandEncoder();
  }
  /**
   * Ends any open pass and begins one on the target's descriptor.
   * @param gpuRenderTarget - the target to render to
   * @returns the begun pass
   */
  beginRenderPass(gpuRenderTarget) {
    this.endRenderPass();
    this._clearCache();
    this._passEncoder = this.commandEncoder.beginRenderPass(gpuRenderTarget.descriptor);
    this.renderPassEncoder = this._passEncoder;
    return this._passEncoder;
  }
  endRenderPass() {
    if (this._passEncoder) {
      this._passEncoder.end();
    }
    this.renderPassEncoder = null;
    this._passEncoder = null;
  }
  /**
   * Begins recording a render bundle. While recording, all draw commands are captured into a
   * {@link GPURenderBundleEncoder} instead of the active render pass. The current render pass
   * encoder is saved and restored when {@link endBundle} is called.
   *
   * Render bundles allow pre-recording of draw commands that can be replayed multiple times
   * via {@link executeBundle}, reducing CPU overhead for repeated draw sequences.
   * @param label - Optional debug label. Names the bundle in GPU captures and in the WebGPU
   * validation errors it can raise when replayed, instead of `(unlabeled)`.
   * @throws If a render bundle is already being recorded.
   */
  beginBundle(label) {
    if (this._passEncoder !== this.renderPassEncoder) {
      throw new Error("Cannot begin a new render bundle while one is already being recorded.");
    }
    this._clearCache();
    const pipeline = this._renderer.pipeline;
    const descriptor = pipeline.getBundleDescriptor();
    descriptor.label = label;
    this._bundleStateKey = pipeline.bundleStateKey;
    this._bundleLabel = label;
    this.renderPassEncoder = this._gpu.device.createRenderBundleEncoder(descriptor);
  }
  /**
   * Finishes recording the current render bundle and restores the previous render pass encoder.
   * @returns The recorded {@link RenderBundle}, ready to be executed via {@link executeBundle} and
   * stamped with the pipeline state it baked so {@link isBundleValid} can vet it on later frames.
   */
  endBundle() {
    const encoder = this.renderPassEncoder;
    if (!encoder || !("finish" in encoder)) {
      throw new Error("endBundle called without an active render bundle.");
    }
    const gpuBundle = encoder.finish({ label: this._bundleLabel });
    this.renderPassEncoder = this._passEncoder;
    this._clearCache();
    return new RenderBundle(gpuBundle, this._bundleStateKey, this._gpu.device, this._bundleLabel);
  }
  /**
   * Checks whether a recorded bundle can still be replayed against the render target that is
   * bound now.
   *
   * A bundle permanently bakes the attachment state it was recorded with — color format(s),
   * color target count, depth/stencil format, sample count — and WebGPU rejects the entire
   * command buffer if any of it differs at execute time. It also bakes the front-face winding of
   * its pipelines, which WebGPU does *not* validate: once the target's {@link RenderTarget.flipY}
   * parity changes, replaying silently renders geometry inside out.
   *
   * Ask before replaying rather than after: only the caller owns the draw commands, so only the
   * caller can re-record. A missing bundle reports `false`, so `!isBundleValid(bundles[i])` reads
   * correctly on the first frame, before anything has been recorded.
   * @param bundle - The bundle to check, as returned by {@link endBundle}.
   * @returns `true` if the bundle is safe to execute right now, `false` if it must be re-recorded.
   */
  isBundleValid(bundle) {
    return bundle?.stateKey === this._renderer.pipeline.bundleStateKey && bundle.device === this._gpu.device;
  }
  /**
   * Replays previously recorded render bundles on the current render pass.
   * The bound state cache is cleared since a bundle may set its own pipeline, bind groups, and buffers.
   *
   * Pass a whole run of bundles rather than calling this once per bundle: WebGPU resets the pass
   * state after every call, so N calls cost N cache clears and N trips through the binding layer
   * for exactly the same result.
   *
   * Every bundle must have been recorded against a matching render target — check with
   * {@link isBundleValid} first and re-record if it says no, as Pixi cannot rebuild your draw
   * commands for you.
   * @param bundle - The render bundle to execute, or a run of them to execute in one call.
   */
  executeBundle(bundle) {
    const gpuBundles = [];
    if (Array.isArray(bundle)) {
      for (let i = 0; i < bundle.length; i++) {
        gpuBundles[i] = this._getGpuBundle(bundle[i]);
      }
    } else {
      gpuBundles[0] = this._getGpuBundle(bundle);
    }
    this._clearCache();
    this._passEncoder.executeBundles(gpuBundles);
  }
  /**
   * Unwraps a bundle for {@link executeBundle}, complaining first if it no longer matches the
   * bound render target — the winding half of that mismatch is invisible otherwise, since WebGPU
   * validates attachments but not front-face order.
   * @param bundle - The bundle being executed.
   * @returns The native bundle to hand to `executeBundles`.
   */
  _getGpuBundle(bundle) {
    if (!this.isBundleValid(bundle)) {
      warn(`Render bundle ${bundle?.label ?? "(unlabeled)"} was recorded against a different render target state or on a lost device. Re-record it — replaying it will either be rejected by WebGPU or draw with the wrong winding. Check encoder.isBundleValid(bundle) before executing.`);
    }
    return bundle.gpuBundle;
  }
  setViewport(viewport) {
    this._passEncoder.setViewport(viewport.x, viewport.y, viewport.width, viewport.height, 0, 1);
  }
  /**
   * Sets the stencil reference value for subsequent draws. This is a pass-level command, so it
   * always targets the real render pass — not a bundle encoder, which cannot set stencil state.
   * @param stencilReference - The stencil reference value to use.
   */
  setStencilReference(stencilReference) {
    this._passEncoder.setStencilReference(stencilReference);
  }
  setPipelineFromGeometryProgramAndState(geometry, program, state, topology, overrides) {
    const pipeline = this._renderer.pipeline.getPipeline(
      geometry,
      program,
      state,
      topology,
      overrides
    );
    this.setPipeline(pipeline);
  }
  setPipeline(pipeline) {
    if (this._boundPipeline === pipeline) return;
    this._boundPipeline = pipeline;
    this.renderPassEncoder.setPipeline(pipeline);
  }
  _setVertexBuffer(index, buffer) {
    if (this._boundVertexBuffer[index] === buffer) return;
    this._boundVertexBuffer[index] = buffer;
    this.renderPassEncoder.setVertexBuffer(index, this._renderer.buffer.updateBuffer(buffer));
  }
  _setIndexBuffer(buffer) {
    if (this._boundIndexBuffer === buffer) return;
    this._boundIndexBuffer = buffer;
    const indexFormat = buffer.data.BYTES_PER_ELEMENT === 2 ? "uint16" : "uint32";
    this.renderPassEncoder.setIndexBuffer(this._renderer.buffer.updateBuffer(buffer), indexFormat);
  }
  resetBindGroup(index) {
    const slot = this._boundBindGroup[index];
    slot.bindGroup = null;
    slot.program = null;
    slot.key = null;
  }
  setBindGroup(index, bindGroup, program) {
    const slot = this._boundBindGroup[index];
    if (slot.bindGroup === bindGroup && slot.program === program && slot.key === bindGroup._key) return;
    slot.bindGroup = bindGroup;
    slot.program = program;
    slot.key = bindGroup._key;
    bindGroup._touch(this._renderer.gc.now);
    const gpuBindGroup = this._renderer.bindGroup.getBindGroup(bindGroup, program, index);
    this.renderPassEncoder.setBindGroup(index, gpuBindGroup);
  }
  setGeometry(geometry, program) {
    const buffersToBind = this._renderer.pipeline.getBufferNamesToBind(geometry, program);
    for (let i = 0; i < buffersToBind.length; i++) {
      this._setVertexBuffer(i, geometry.attributes[buffersToBind[i]].buffer);
    }
    if (geometry.indexBuffer) {
      this._setIndexBuffer(geometry.indexBuffer);
    }
  }
  _setShaderBindGroups(shader, skipSync) {
    const program = shader.gpuProgram;
    const layout = program.layout;
    for (let i = 0; i < layout.length; i++) {
      const bindGroup = shader.groups[i];
      if (!layout[i] || !bindGroup) continue;
      if (!skipSync) {
        this._syncBindGroup(bindGroup);
      }
      this.setBindGroup(i, bindGroup, program);
    }
  }
  _syncBindGroup(bindGroup) {
    const resources = bindGroup.resources;
    const keys = bindGroup._resourceKeys;
    for (let i = 0; i < keys.length; i++) {
      const resource = resources[keys[i]];
      if (!resource) continue;
      if (resource.isUniformGroup) {
        this._renderer.ubo.updateUniformGroup(resource);
      }
    }
  }
  draw(options) {
    const { geometry, shader, state, topology, size, start, baseVertex, instanceCount, skipSync, firstInstance } = options;
    this.setPipelineFromGeometryProgramAndState(geometry, shader.gpuProgram, state, topology, shader._overrides);
    this.setGeometry(geometry, shader.gpuProgram);
    this._setShaderBindGroups(shader, skipSync);
    if (geometry.indexBuffer) {
      this.renderPassEncoder.drawIndexed(
        size || geometry.indexCount || geometry.indexBuffer.data.length,
        instanceCount ?? geometry.instanceCount,
        start || 0,
        baseVertex || 0,
        firstInstance || 0
      );
    } else {
      this.renderPassEncoder.draw(
        size || geometry.vertexCount,
        instanceCount ?? geometry.instanceCount,
        start || 0,
        firstInstance || 0
      );
    }
  }
  /**
   * Sets up the pipeline, geometry, and bind groups then issues an indirect draw call.
   * Uses `drawIndexedIndirect` when the geometry has an index buffer, otherwise `drawIndirect`.
   * Draw parameters (vertex count, instance count, etc.) are read from the indirect buffer on the GPU.
   * @param options - The draw options.
   * @param options.geometry - The geometry to draw.
   * @param options.shader - The shader to use.
   * @param options.state - Optional render state (blending, depth, etc.).
   * @param options.topology - Optional primitive topology override.
   * @param options.skipSync - If true, skips syncing uniform groups to their GPU buffers.
   * @param options.indirectBuffer - The GPU buffer containing the indirect draw parameters.
   * @param options.indirectOffset - Byte offset into the indirect buffer.
   */
  drawIndirect(options) {
    const { geometry, shader, state, topology, skipSync, indirectBuffer, indirectOffset } = options;
    this.setPipelineFromGeometryProgramAndState(geometry, shader.gpuProgram, state, topology, shader._overrides);
    this.setGeometry(geometry, shader.gpuProgram);
    this._setShaderBindGroups(shader, skipSync);
    if (geometry.indexBuffer) {
      this.renderPassEncoder.drawIndexedIndirect(indirectBuffer, indirectOffset);
    } else {
      this.renderPassEncoder.drawIndirect(indirectBuffer, indirectOffset);
    }
  }
  finishRenderPass() {
    if (this._passEncoder) {
      this._passEncoder.end();
      this.renderPassEncoder = null;
      this._passEncoder = null;
    }
  }
  postrender() {
    this.finishRenderPass();
    this._gpu.device.queue.submit([this.commandEncoder.finish()]);
    this._resolveCommandFinished();
    this.commandEncoder = null;
  }
  _clearCache() {
    for (let i = 0; i < 16; i++) {
      const slot = this._boundBindGroup[i];
      slot.bindGroup = null;
      slot.program = null;
      slot.key = null;
      this._boundVertexBuffer[i] = null;
    }
    this._boundIndexBuffer = null;
    this._boundPipeline = null;
  }
  destroy() {
    this._renderer = null;
    this._gpu = null;
    this._boundBindGroup = null;
    this._boundVertexBuffer = null;
    this._boundIndexBuffer = null;
    this._boundPipeline = null;
    this.renderPassEncoder = null;
    this._passEncoder = null;
  }
  contextChange(gpu) {
    this._gpu = gpu;
  }
};
GpuEncoderSystem.extension = {
  type: [ExtensionType.WebGPUSystem],
  name: "encoder",
  priority: 1
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/GpuLimitsSystem.mjs
var GpuLimitsSystem = class {
  constructor(renderer) {
    this.supportsOverrideConstants = false;
    this._renderer = renderer;
  }
  contextChange() {
    const device = this._renderer.device.gpu.device;
    this.maxTextures = Math.min(
      device.limits.maxSampledTexturesPerShaderStage,
      device.limits.maxSamplersPerShaderStage
    );
    this.maxBatchableTextures = this.maxTextures;
    this._detectOverrideConstantsSupport(device);
  }
  _detectOverrideConstantsSupport(device) {
    device.pushErrorScope("validation");
    const testModule = device.createShaderModule({
      code: "override TEST_VALUE: f32 = 0.0;\n@compute @workgroup_size(1) fn main() {}"
    });
    device.createComputePipeline({
      layout: "auto",
      compute: {
        module: testModule,
        entryPoint: "main",
        constants: { TEST_VALUE: 1 }
      }
    });
    void device.popErrorScope().then((error) => {
      this.supportsOverrideConstants = !error;
    });
  }
  destroy() {
  }
};
GpuLimitsSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "limits"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/GpuStencilSystem.mjs
var GpuStencilSystem = class {
  constructor(renderer) {
    this._renderer = renderer;
    renderer.renderTarget.onRenderTargetChange.add(this);
  }
  contextChange() {
    this._activeGpuRenderTarget = null;
  }
  onRenderTargetChange(renderTarget) {
    const gpuRenderTarget = this._renderer.renderTarget.getGpuRenderTarget(renderTarget);
    this._activeRenderTarget = renderTarget;
    this._activeGpuRenderTarget = gpuRenderTarget;
    this.setStencilMode(gpuRenderTarget.stencilMode, gpuRenderTarget.stencilReference);
  }
  setStencilMode(stencilMode, stencilReference) {
    const gpuRenderTarget = this._activeGpuRenderTarget ?? (this._activeGpuRenderTarget = this._renderer.renderTarget.getGpuRenderTarget(this._activeRenderTarget));
    gpuRenderTarget.stencilMode = stencilMode;
    gpuRenderTarget.stencilReference = stencilReference;
    const renderer = this._renderer;
    renderer.pipeline.setStencilMode(stencilMode);
    renderer.encoder.setStencilReference(stencilReference);
  }
  destroy() {
    this._renderer.renderTarget.onRenderTargetChange.remove(this);
    this._renderer = null;
    this._activeRenderTarget = null;
    this._activeGpuRenderTarget = null;
  }
};
GpuStencilSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "stencil"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/createUboElementsWGSL.mjs
var WGSL_ALIGN_SIZE_DATA = {
  i32: { align: 4, size: 4 },
  u32: { align: 4, size: 4 },
  f32: { align: 4, size: 4 },
  f16: { align: 2, size: 2 },
  "vec2<i32>": { align: 8, size: 8 },
  "vec2<u32>": { align: 8, size: 8 },
  "vec2<f32>": { align: 8, size: 8 },
  "vec2<f16>": { align: 4, size: 4 },
  "vec3<i32>": { align: 16, size: 12 },
  "vec3<u32>": { align: 16, size: 12 },
  "vec3<f32>": { align: 16, size: 12 },
  "vec3<f16>": { align: 8, size: 6 },
  "vec4<i32>": { align: 16, size: 16 },
  "vec4<u32>": { align: 16, size: 16 },
  "vec4<f32>": { align: 16, size: 16 },
  "vec4<f16>": { align: 8, size: 8 },
  "mat2x2<f32>": { align: 8, size: 16 },
  "mat2x2<f16>": { align: 4, size: 8 },
  "mat3x2<f32>": { align: 8, size: 24 },
  "mat3x2<f16>": { align: 4, size: 12 },
  "mat4x2<f32>": { align: 8, size: 32 },
  "mat4x2<f16>": { align: 4, size: 16 },
  "mat2x3<f32>": { align: 16, size: 32 },
  "mat2x3<f16>": { align: 8, size: 16 },
  "mat3x3<f32>": { align: 16, size: 48 },
  "mat3x3<f16>": { align: 8, size: 24 },
  "mat4x3<f32>": { align: 16, size: 64 },
  "mat4x3<f16>": { align: 8, size: 32 },
  "mat2x4<f32>": { align: 16, size: 32 },
  "mat2x4<f16>": { align: 8, size: 16 },
  "mat3x4<f32>": { align: 16, size: 48 },
  "mat3x4<f16>": { align: 8, size: 24 },
  "mat4x4<f32>": { align: 16, size: 64 },
  "mat4x4<f16>": { align: 8, size: 32 }
};
function createUboElementsWGSL(uniformData) {
  const uboElements = uniformData.map((data) => ({
    data,
    offset: 0,
    size: 0
  }));
  let offset = 0;
  for (let i = 0; i < uboElements.length; i++) {
    const uboElement = uboElements[i];
    let size = WGSL_ALIGN_SIZE_DATA[uboElement.data.type].size;
    const align = WGSL_ALIGN_SIZE_DATA[uboElement.data.type].align;
    if (!WGSL_ALIGN_SIZE_DATA[uboElement.data.type]) {
      throw new Error(`[Pixi.js] WebGPU UniformBuffer: Unknown type ${uboElement.data.type}`);
    }
    if (uboElement.data.size > 1) {
      size = Math.max(size, align) * uboElement.data.size;
    }
    offset = Math.ceil(offset / align) * align;
    uboElement.size = size;
    uboElement.offset = offset;
    offset += size;
  }
  offset = Math.ceil(offset / 16) * 16;
  return { uboElements, size: offset };
}

// node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/generateArraySyncWGSL.mjs
function generateArraySyncWGSL(uboElement, offsetToAdd) {
  const { size, align } = WGSL_ALIGN_SIZE_DATA[uboElement.data.type];
  const remainder = (Math.max(size, align) - size) / 4;
  const data = uboElement.data.type.indexOf("i32") >= 0 ? "dataInt32" : "data";
  return `
         v = uv.${uboElement.data.name};
         ${offsetToAdd !== 0 ? `offset += ${offsetToAdd};` : ""}

         arrayOffset = offset;

         t = 0;

         for(var i=0; i < ${uboElement.data.size}; i++)
         {
             for(var j = 0; j < ${size / 4}; j++)
             {
                 ${data}[arrayOffset++] = v[t++];
             }
             ${remainder !== 0 ? `arrayOffset += ${remainder};` : ""}
         }
     `;
}

// node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/createUboSyncFunctionWGSL.mjs
function createUboSyncFunctionWGSL(uboElements) {
  return compileBufferSync(
    uboElements,
    uboSyncFunctionsWGSL,
    generateArraySyncWGSL
  );
}

// node_modules/pixi.js/lib/rendering/renderers/gpu/GpuUboSystem.mjs
var GpuUboSystem = class extends UboSystem {
  constructor() {
    super({
      createUboElements: createUboElementsWGSL,
      generateUboSync: createUboSyncFunctionWGSL
    });
  }
};
GpuUboSystem.extension = {
  type: [ExtensionType.WebGPUSystem],
  name: "ubo"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/buffer/UboBatch.mjs
var UboBatch = class {
  constructor({ minUniformOffsetAlignment: minUniformOffsetAlignment2 }) {
    this._minUniformOffsetAlignment = 256;
    this.byteIndex = 0;
    this._minUniformOffsetAlignment = minUniformOffsetAlignment2;
    this.data = new Float32Array(65535);
  }
  clear() {
    this.byteIndex = 0;
  }
  addEmptyGroup(size) {
    if (size > this._minUniformOffsetAlignment / 4) {
      throw new Error(`UniformBufferBatch: array is too large: ${size * 4}`);
    }
    const start = this.byteIndex;
    let newSize = start + size * 4;
    newSize = Math.ceil(newSize / this._minUniformOffsetAlignment) * this._minUniformOffsetAlignment;
    if (newSize > this.data.length * 4) {
      throw new Error("UniformBufferBatch: ubo batch got too big");
    }
    this.byteIndex = newSize;
    return start;
  }
  addGroup(array) {
    const offset = this.addEmptyGroup(array.length);
    for (let i = 0; i < array.length; i++) {
      this.data[offset / 4 + i] = array[i];
    }
    return offset;
  }
  destroy() {
    this.data = null;
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/GpuUniformBatchPipe.mjs
var minUniformOffsetAlignment = 128;
var GpuUniformBatchPipe = class {
  constructor(renderer) {
    this._bindGroupHash = /* @__PURE__ */ Object.create(null);
    this._buffers = [];
    this._bindGroups = [];
    this._bufferResources = [];
    this._renderer = renderer;
    this._batchBuffer = new UboBatch({ minUniformOffsetAlignment });
    const totalBuffers = 256 / minUniformOffsetAlignment;
    for (let i = 0; i < totalBuffers; i++) {
      let usage = BufferUsage.UNIFORM | BufferUsage.COPY_DST;
      if (i === 0) usage |= BufferUsage.COPY_SRC;
      this._buffers.push(new Buffer({
        data: this._batchBuffer.data,
        usage
      }));
    }
  }
  renderEnd() {
    this._uploadBindGroups();
    this._resetBindGroups();
  }
  _resetBindGroups() {
    this._bindGroupHash = /* @__PURE__ */ Object.create(null);
    this._batchBuffer.clear();
  }
  // just works for single bind groups for now
  getUniformBindGroup(group, duplicate) {
    if (!duplicate && this._bindGroupHash[group.uid]) {
      return this._bindGroupHash[group.uid];
    }
    this._renderer.ubo.ensureUniformGroup(group);
    const data = group.buffer.data;
    const offset = this._batchBuffer.addEmptyGroup(data.length);
    this._renderer.ubo.syncUniformGroup(group, this._batchBuffer.data, offset / 4);
    this._bindGroupHash[group.uid] = this._getBindGroup(offset / minUniformOffsetAlignment);
    return this._bindGroupHash[group.uid];
  }
  getUboResource(group) {
    this._renderer.ubo.updateUniformGroup(group);
    const data = group.buffer.data;
    const offset = this._batchBuffer.addGroup(data);
    return this._getBufferResource(offset / minUniformOffsetAlignment);
  }
  getArrayBindGroup(data) {
    const offset = this._batchBuffer.addGroup(data);
    return this._getBindGroup(offset / minUniformOffsetAlignment);
  }
  getArrayBufferResource(data) {
    const offset = this._batchBuffer.addGroup(data);
    const index = offset / minUniformOffsetAlignment;
    return this._getBufferResource(index);
  }
  _getBufferResource(index) {
    if (!this._bufferResources[index]) {
      const buffer = this._buffers[index % 2];
      this._bufferResources[index] = new BufferResource({
        buffer,
        offset: (index / 2 | 0) * 256,
        size: minUniformOffsetAlignment
      });
    }
    return this._bufferResources[index];
  }
  _getBindGroup(index) {
    if (!this._bindGroups[index]) {
      const bindGroup = new BindGroup({
        0: this._getBufferResource(index)
      });
      this._bindGroups[index] = bindGroup;
    }
    return this._bindGroups[index];
  }
  _uploadBindGroups() {
    const bufferSystem = this._renderer.buffer;
    const firstBuffer = this._buffers[0];
    firstBuffer.update(this._batchBuffer.byteIndex);
    bufferSystem.updateBuffer(firstBuffer);
    const commandEncoder = this._renderer.gpu.device.createCommandEncoder();
    for (let i = 1; i < this._buffers.length; i++) {
      const buffer = this._buffers[i];
      commandEncoder.copyBufferToBuffer(
        bufferSystem.getGPUBuffer(firstBuffer),
        minUniformOffsetAlignment,
        bufferSystem.getGPUBuffer(buffer),
        0,
        this._batchBuffer.byteIndex
      );
    }
    this._renderer.gpu.device.queue.submit([commandEncoder.finish()]);
  }
  destroy() {
    for (let i = 0; i < this._bindGroups.length; i++) {
      this._bindGroups[i]?.destroy();
    }
    this._bindGroups = null;
    this._bindGroupHash = null;
    for (let i = 0; i < this._buffers.length; i++) {
      this._buffers[i].destroy();
    }
    this._buffers = null;
    for (let i = 0; i < this._bufferResources.length; i++) {
      this._bufferResources[i].destroy();
    }
    this._bufferResources = null;
    this._batchBuffer.destroy();
    this._renderer = null;
  }
};
GpuUniformBatchPipe.extension = {
  type: [
    ExtensionType.WebGPUPipes
  ],
  name: "uniformBatch"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/pipeline/PipelineSystem.mjs
var topologyStringToId = {
  "point-list": 0,
  "line-list": 1,
  "line-strip": 2,
  "triangle-list": 3,
  "triangle-strip": 4
};
var emptyOverrides = new ShaderOverrides({});
var depthStencilFormatMap = {
  "depth24plus-stencil8": { depth: true, stencil: true, index: 1 },
  depth24plus: { depth: true, stencil: false, index: 2 },
  depth32float: { depth: true, stencil: false, index: 3 },
  "depth32float-stencil8": { depth: true, stencil: true, index: 4 },
  depth16unorm: { depth: true, stencil: false, index: 5 },
  stencil8: { depth: false, stencil: true, index: 6 }
};
var emptyDepthStencilFormatData = { depth: false, stencil: false, index: 0 };
function bakeOverridesIntoSource(source, overrides) {
  for (const [name, value] of Object.entries(overrides)) {
    const re = new RegExp(
      `override\\s+${name}\\s*:\\s*(\\w+)\\s*(?:=[^;]*)?;`
    );
    source = source.replace(re, (_, type) => {
      let lit;
      if (type === "u32") lit = `${Math.trunc(value)}u`;
      else if (type === "i32") lit = `${Math.trunc(value)}`;
      else lit = Number.isInteger(value) ? `${value}.0` : `${value}`;
      return `const ${name}: ${type} = ${lit};`;
    });
  }
  return source;
}
function getGraphicsStateKey(geometryLayout, shaderKey, state, blendMode, topology, overrideId) {
  return geometryLayout * 35184372088832 + shaderKey * 536870912 + overrideId * 16384 + (state << 8) + (blendMode << 3) + topology;
}
var colorFormatIds = /* @__PURE__ */ Object.create(null);
var nextColorFormatId = 0;
function getColorFormatId(format) {
  let id = colorFormatIds[format];
  if (id === void 0) id = colorFormatIds[format] = nextColorFormatId++;
  return id;
}
function getGlobalStateKey(stencilStateId, multiSampleCount, colorMask, colorTargetCount, depthStencilFormat, colorFormatId, depthReadOnly, invertFrontFace) {
  return invertFrontFace << 20 | colorFormatId << 16 | depthStencilFormat << 13 | colorMask << 9 | stencilStateId << 6 | depthReadOnly << 5 | colorTargetCount << 1 | multiSampleCount;
}
function getBundleStateKey(multiSampleCount, colorTargetCount, depthStencilFormat, depthReadOnly, stencilReadOnly, invertFrontFace, colorFormatId) {
  return colorFormatId << 11 | invertFrontFace << 10 | stencilReadOnly << 9 | depthReadOnly << 8 | depthStencilFormat << 5 | colorTargetCount << 1 | multiSampleCount;
}
var PipelineSystem = class {
  constructor(renderer) {
    this._moduleCache = /* @__PURE__ */ Object.create(null);
    this._bufferLayoutsCache = /* @__PURE__ */ Object.create(null);
    this._bindingNamesCache = /* @__PURE__ */ Object.create(null);
    this._pipeCache = /* @__PURE__ */ new Map();
    this._pipeStateCaches = /* @__PURE__ */ Object.create(null);
    this._colorMask = 15;
    this._multisampleCount = 1;
    this._colorTargetCount = 1;
    this._colorFormat = "bgra8unorm";
    this._colorFormatId = getColorFormatId("bgra8unorm");
    this._depthStencilFormat = "depth24plus-stencil8";
    this._depthStencilFormatData = emptyDepthStencilFormatData;
    this._depthReadOnly = false;
    this._stencilReadOnly = false;
    this._invertFrontFace = false;
    this._renderer = renderer;
  }
  contextChange(gpu) {
    this._gpu = gpu;
    this._moduleCache = /* @__PURE__ */ Object.create(null);
    this._pipeStateCaches = /* @__PURE__ */ Object.create(null);
    this.setStencilMode(STENCIL_MODES.DISABLED);
    this._updatePipeHash();
  }
  setMultisampleCount(multisampleCount) {
    if (this._multisampleCount === multisampleCount) return;
    this._multisampleCount = multisampleCount;
    this._updatePipeHash();
  }
  setRenderTarget(renderTarget) {
    const colorTexture = renderTarget.colorAttachments[0]?.texture;
    this._multisampleCount = colorTexture?.source.antialias ? 4 : 1;
    this._colorTargetCount = renderTarget.colorAttachments.length;
    this._colorFormat = colorTexture?.format ?? "bgra8unorm";
    this._colorFormatId = getColorFormatId(this._colorFormat);
    this._depthStencilFormat = renderTarget.depthStencilAttachment?.texture.format;
    this._depthStencilFormatData = depthStencilFormatMap[this._depthStencilFormat] || emptyDepthStencilFormatData;
    this._depthReadOnly = renderTarget.depthStencilAttachment?.depthReadOnly ?? false;
    this._stencilReadOnly = renderTarget.depthStencilAttachment?.stencilReadOnly ?? this._depthReadOnly;
    this._invertFrontFace = this._renderer.renderTarget.isFrontFaceInverted(renderTarget, renderTarget.flipY);
    this._updatePipeHash();
  }
  setColorMask(colorMask) {
    if (this._colorMask === colorMask) return;
    this._colorMask = colorMask;
    this._updatePipeHash();
  }
  setStencilMode(stencilMode) {
    if (this._stencilMode === stencilMode) return;
    this._stencilMode = stencilMode;
    this._stencilState = GpuStencilModesToPixi[stencilMode];
    this._updatePipeHash();
  }
  /**
   * A packed key for everything a render bundle recorded right now would bake into itself: the
   * attachment state WebGPU validates when the bundle is executed (color format(s), color target
   * count, depth/stencil format, sample count, read-only aspects), plus the front-face winding
   * its pipelines capture — which WebGPU does *not* validate.
   *
   * Equal keys mean a bundle recorded then is compatible with, and correct for, the pass now;
   * different keys mean it has to be re-recorded before it is replayed. Comparing the two is
   * what {@link GpuEncoderSystem.isBundleValid} does.
   *
   * `colorMask` and `stencilMode` are deliberately left out, unlike the pipeline cache key: they
   * are ambient draw state a bundle bakes per-pipeline as it records, so their value at execute
   * time says nothing about whether the bundle is still good.
   */
  get bundleStateKey() {
    const formatData = this._depthStencilFormatData;
    return getBundleStateKey(
      // normalize the raw sample count (1 or 4 — WebGPU's only renderable counts) to a
      // true single bit, so it cannot spill into the colorTargetCount field above it
      this._multisampleCount === 1 ? 0 : 1,
      this._colorTargetCount,
      formatData.index,
      // the same two flags getBundleDescriptor sets — keep them in step
      formatData.depth && this._depthReadOnly ? 1 : 0,
      formatData.stencil && this._stencilReadOnly ? 1 : 0,
      this._invertFrontFace ? 1 : 0,
      this._colorFormatId
    );
  }
  /**
   * Builds a `GPURenderBundleEncoderDescriptor` that matches the current render target
   * configuration (color formats, sample count, depth/stencil format, and which of its aspects
   * are read-only).
   * Used by {@link GpuEncoderSystem.beginBundle} to create a compatible render bundle encoder.
   * @returns A descriptor for creating a GPURenderBundleEncoder.
   */
  getBundleDescriptor() {
    const colorFormats = [];
    for (let i = 0; i < this._colorTargetCount; i++) {
      colorFormats.push(this._colorFormat);
    }
    const descriptor = {
      colorFormats,
      sampleCount: this._multisampleCount
    };
    const formatData = this._depthStencilFormatData;
    if (formatData.depth || formatData.stencil) {
      descriptor.depthStencilFormat = this._depthStencilFormat;
      if (formatData.depth && this._depthReadOnly) descriptor.depthReadOnly = true;
      if (formatData.stencil && this._stencilReadOnly) descriptor.stencilReadOnly = true;
    }
    return descriptor;
  }
  setPipeline(geometry, program, state, passEncoder) {
    const pipeline = this.getPipeline(geometry, program, state);
    passEncoder.setPipeline(pipeline);
  }
  /**
   * Generates a key for the pipeline.advanced usage only.
   * @param geometry - The geometry to get the key for
   * @param program - The program to get the key for
   * @param state - The state to get the key for
   * @param topology - The topology to get the key for
   * @param overrides - The overrides to get the key for
   * @returns The key for the pipeline
   */
  getPipelineKey(geometry, program, state, topology, overrides) {
    if (!geometry._layoutKey) {
      ensureAttributes(geometry, program.attributeData);
      this._generateBufferKey(geometry);
    }
    return getGraphicsStateKey(
      geometry._layoutKey,
      program._layoutKey,
      state.data,
      state._blendModeId,
      topologyStringToId[topology],
      overrides.id
    );
  }
  getPipeline(geometry, program, state, topology, overrides) {
    if (!geometry._layoutKey) {
      ensureAttributes(geometry, program.attributeData);
      this._generateBufferKey(geometry);
    }
    topology || (topology = geometry.topology);
    overrides || (overrides = emptyOverrides);
    const key = getGraphicsStateKey(
      geometry._layoutKey,
      program._layoutKey,
      state.data,
      state._blendModeId,
      topologyStringToId[topology],
      overrides.id
    );
    let pipeline = this._pipeCache.get(key);
    if (!pipeline) {
      pipeline = this._createPipeline(geometry, program, state, topology, overrides);
      this._pipeCache.set(key, pipeline);
    }
    return pipeline;
  }
  _createPipeline(geometry, program, state, topology, overrides) {
    const device = this._gpu.device;
    const buffers = this._createVertexBufferLayouts(geometry, program);
    const blendModes = this._renderer.state.getColorTargets(state, this._colorTargetCount, this._colorFormat);
    const writeMask = this._stencilMode === STENCIL_MODES.RENDERING_MASK_ADD ? 0 : this._colorMask;
    for (let i = 0; i < blendModes.length; i++) {
      blendModes[i].writeMask = writeMask;
    }
    const layout = this._renderer.shader.getProgramData(program).pipeline;
    const hasOverrides = Object.keys(overrides.data).length > 0;
    let vertexSource = program.vertex.source;
    let fragmentSource = program.fragment.source;
    let constants;
    if (hasOverrides) {
      if (this._renderer.limits.supportsOverrideConstants) {
        constants = overrides.data;
      } else {
        vertexSource = bakeOverridesIntoSource(vertexSource, overrides.data);
        fragmentSource = bakeOverridesIntoSource(fragmentSource, overrides.data);
      }
    }
    const descriptor = {
      // TODO later check if its helpful to create..
      // layout,
      vertex: {
        module: this._getModule(vertexSource),
        entryPoint: program.vertex.entryPoint,
        constants,
        buffers
      },
      fragment: {
        module: this._getModule(fragmentSource),
        entryPoint: program.fragment.entryPoint,
        targets: blendModes,
        constants
      },
      primitive: {
        topology,
        // Mirror WebGL's split: `gl.cullFace` is left at its `BACK` default, so the back is always
        // the culled side. Taking this from `state.cullMode` instead folds the winding into *which
        // side* is culled — the same triangles survive, but `@builtin(front_facing)` then reports
        // the opposite of `gl_FrontFacing` for clockwise-wound geometry.
        cullMode: state.culling ? "back" : "none",
        // The winding is stated once, here, exactly as `gl.frontFace` does it. `flipY` inverts the
        // projection (see setRenderTarget), so inverting the winding alongside it makes the two
        // cancel and a front face stays a front face. Both flags are part of the pipeline cache key.
        frontFace: state.clockwiseFrontFace !== this._invertFrontFace ? "cw" : "ccw"
      },
      layout,
      multisample: {
        count: this._multisampleCount
      },
      // depthStencil,
      label: program.name ? `PIXI Pipeline (${program.name})` : `PIXI Pipeline`
    };
    if (this._depthStencilFormatData.depth || this._depthStencilFormatData.stencil) {
      const formatData = this._depthStencilFormatData;
      descriptor.depthStencil = __spreadProps(__spreadValues({}, this._stencilState), {
        format: this._depthStencilFormat,
        depthWriteEnabled: formatData.depth ? state.depthMask && !this._depthReadOnly : false,
        depthCompare: formatData.depth && state.depthTest ? "less" : "always"
      });
    }
    const pipeline = device.createRenderPipeline(descriptor);
    return pipeline;
  }
  _getModule(code) {
    return this._moduleCache[code] || this._createModule(code);
  }
  _createModule(code) {
    const device = this._gpu.device;
    this._moduleCache[code] = device.createShaderModule({
      code
    });
    return this._moduleCache[code];
  }
  /**
   * Generates and caches a numeric layout key on the geometry based on its sorted attribute
   * descriptors (offset, format, stride, instancing). Geometries with identical attribute
   * layouts share the same key, enabling pipeline reuse.
   * @param geometry - The geometry to generate a layout key for.
   */
  _generateBufferKey(geometry) {
    const keyGen = [];
    let index = 0;
    const attributeKeys = Object.keys(geometry.attributes).sort();
    for (let i = 0; i < attributeKeys.length; i++) {
      const attribute = geometry.attributes[attributeKeys[i]];
      keyGen[index++] = attribute.offset;
      keyGen[index++] = attribute.format;
      keyGen[index++] = attribute.stride;
      keyGen[index++] = attribute.instance;
    }
    const stringKey = keyGen.join("|");
    geometry._layoutKey = createIdFromString(stringKey, "geometry");
    return geometry._layoutKey;
  }
  _generateAttributeLocationsKey(program) {
    const keyGen = [];
    let index = 0;
    const attributeKeys = Object.keys(program.attributeData).sort();
    for (let i = 0; i < attributeKeys.length; i++) {
      const attribute = program.attributeData[attributeKeys[i]];
      keyGen[index++] = attribute.location;
    }
    const stringKey = keyGen.join("|");
    program._attributeLocationsKey = createIdFromString(stringKey, "programAttributes");
    return program._attributeLocationsKey;
  }
  /**
   * Returns the buffer names to bind, one per vertex buffer slot.
   * This is used to bind the correct buffer to the correct location in the shader.
   * @param geometry - The geometry where to get the buffer names
   * @param program - The program where to get the buffer names
   * @returns The buffer names, indexed by vertex buffer slot.
   */
  getBufferNamesToBind(geometry, program) {
    const key = geometry._layoutKey << 16 | program._attributeLocationsKey;
    if (this._bindingNamesCache[key]) return this._bindingNamesCache[key];
    const data = this._createVertexBufferLayouts(geometry, program);
    const bufferNamesToBind = [];
    const attributeData = program.attributeData;
    for (let i = 0; i < data.length; i++) {
      const attributes = Object.values(data[i].attributes);
      const shaderLocation = attributes[0].shaderLocation;
      for (const j in attributeData) {
        if (attributeData[j].location === shaderLocation) {
          bufferNamesToBind[i] = j;
          break;
        }
      }
    }
    this._bindingNamesCache[key] = bufferNamesToBind;
    return bufferNamesToBind;
  }
  _createVertexBufferLayouts(geometry, program) {
    if (!program._attributeLocationsKey) this._generateAttributeLocationsKey(program);
    const key = geometry._layoutKey << 16 | program._attributeLocationsKey;
    if (this._bufferLayoutsCache[key]) {
      return this._bufferLayoutsCache[key];
    }
    const vertexBuffersLayout = [];
    geometry.buffers.forEach((buffer) => {
      const bufferEntry = {
        arrayStride: 0,
        stepMode: "vertex",
        attributes: []
      };
      const bufferEntryAttributes = bufferEntry.attributes;
      for (const i in program.attributeData) {
        const attribute = geometry.attributes[i];
        if ((attribute.divisor ?? 1) !== 1) {
          warn(`Attribute ${i} has an invalid divisor value of '${attribute.divisor}'. WebGPU only supports a divisor value of 1`);
        }
        if (attribute.buffer === buffer) {
          bufferEntry.arrayStride = attribute.stride;
          bufferEntry.stepMode = attribute.instance ? "instance" : "vertex";
          bufferEntryAttributes.push({
            shaderLocation: program.attributeData[i].location,
            offset: attribute.offset,
            format: attribute.format
          });
        }
      }
      if (bufferEntryAttributes.length) {
        vertexBuffersLayout.push(bufferEntry);
      }
    });
    this._bufferLayoutsCache[key] = vertexBuffersLayout;
    return vertexBuffersLayout;
  }
  _updatePipeHash() {
    var _a;
    const key = getGlobalStateKey(
      this._stencilMode,
      // normalize the raw sample count (1 or 4 — WebGPU's only renderable counts) to a
      // true single bit, so it cannot spill into the colorTargetCount field above it
      this._multisampleCount === 1 ? 0 : 1,
      this._colorMask,
      this._colorTargetCount,
      this._depthStencilFormatData.index,
      this._colorFormatId,
      this._depthReadOnly ? 1 : 0,
      this._invertFrontFace ? 1 : 0
    );
    this._pipeCache = (_a = this._pipeStateCaches)[key] ?? (_a[key] = /* @__PURE__ */ new Map());
  }
  destroy() {
    this._bufferLayoutsCache = null;
    this._pipeCache = null;
    this._gpu = null;
    this._renderer = null;
    this._bindingNamesCache = null;
    this._pipeStateCaches = null;
    this._moduleCache = null;
  }
};
PipelineSystem.extension = {
  type: [ExtensionType.WebGPUSystem],
  name: "pipeline"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/GpuMsaaRestore.mjs
var GpuMsaaRestore = class {
  constructor(renderer) {
    this._pipelines = /* @__PURE__ */ Object.create(null);
    this._modules = /* @__PURE__ */ Object.create(null);
    this._bindGroups = /* @__PURE__ */ new WeakMap();
    this._renderer = renderer;
    this._device = renderer.gpu.device;
    this._layout = this._device.createBindGroupLayout({
      entries: [{
        binding: 0,
        visibility: GPUShaderStage.FRAGMENT,
        texture: { sampleType: "unfilterable-float" }
      }]
    });
    this._pipelineLayout = this._device.createPipelineLayout({ bindGroupLayouts: [this._layout] });
  }
  /**
   * Copies one colour attachment's resolved image into the target's back texture, creating it on first use
   * at the attachment's size and format. Must be recorded outside a render pass.
   * @param commandEncoder - the encoder to record the copy on
   * @param renderTarget - the target being reopened
   * @param index - the colour attachment to copy
   * @param resolved - the attachment's resolved texture
   */
  copy(commandEncoder, renderTarget, index, resolved) {
    var _a;
    const gpuRenderTarget = this._renderer.renderTarget.getGpuRenderTarget(renderTarget);
    const colorTexture = renderTarget.colorAttachments[index].texture;
    (_a = gpuRenderTarget.msaaBackTextures)[index] ?? (_a[index] = new TextureSource({
      label: "msaa-back-texture",
      width: colorTexture.width,
      height: colorTexture.height,
      resolution: colorTexture._resolution,
      format: gpuRenderTarget.msaaTextures[index].format,
      autoGenerateMipmaps: false,
      // every restore copies into it afresh, so an idle one can be freed and re-created on the next restore
      autoGarbageCollect: true
    }));
    const backTexture = this._renderer.texture.getGpuSource(gpuRenderTarget.msaaBackTextures[index]);
    commandEncoder.copyTextureToTexture(
      { texture: resolved },
      { texture: backTexture },
      { width: Math.min(resolved.width, backTexture.width), height: Math.min(resolved.height, backTexture.height) }
    );
  }
  /**
   * Draws one colour attachment's back texture into the multisampled buffer. Must be the first draw of the
   * pass, before any viewport or scissor is set.
   * @param pass - the pass that was just begun
   * @param renderTarget - the target the pass renders to
   * @param index - the colour attachment to restore, copied by {@link GpuMsaaRestore.copy}
   */
  draw(pass, renderTarget, index) {
    var _a;
    const gpuRenderTarget = this._renderer.renderTarget.getGpuRenderTarget(renderTarget);
    const backTexture = this._renderer.texture.getGpuSource(gpuRenderTarget.msaaBackTextures[index]);
    let key = renderTarget.depthStencilAttachment?.texture.format ?? "";
    for (const attachment of renderTarget.colorAttachments) {
      key += `|${attachment.texture.format}`;
    }
    const pipelines = (_a = this._pipelines)[key] ?? (_a[key] = []);
    let bindGroup = this._bindGroups.get(backTexture);
    if (!bindGroup) {
      bindGroup = this._device.createBindGroup({
        layout: this._layout,
        entries: [{ binding: 0, resource: backTexture.createView() }]
      });
      this._bindGroups.set(backTexture, bindGroup);
    }
    pass.setPipeline(pipelines[index] ?? (pipelines[index] = this._createPipeline(renderTarget, index)));
    pass.setBindGroup(0, bindGroup);
    pass.draw(3);
  }
  _getModule(index) {
    var _a;
    (_a = this._modules)[index] ?? (_a[index] = this._device.createShaderModule({
      label: "msaa-restore",
      code: (
        /* wgsl */
        `
                @group(0) @binding(0) var resolved: texture_2d<f32>;

                @vertex
                fn vertexMain(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
                    let pos = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));

                    return vec4<f32>(pos[i], 0.0, 1.0);
                }

                @fragment
                fn fragmentMain(@builtin(position) position: vec4<f32>) -> @location(${index}) vec4<f32> {
                    return textureLoad(resolved, vec2<i32>(position.xy), 0);
                }
            `
      )
    }));
    return this._modules[index];
  }
  _createPipeline(renderTarget, index) {
    const depthStencilFormat = renderTarget.depthStencilAttachment?.texture.format;
    let depthStencil;
    if (depthStencilFormat) {
      depthStencil = { format: depthStencilFormat };
      if (depthStencilFormat.includes("depth")) {
        depthStencil.depthWriteEnabled = false;
        depthStencil.depthCompare = "always";
      }
    }
    const module = this._getModule(index);
    return this._device.createRenderPipeline({
      label: "msaa-restore",
      layout: this._pipelineLayout,
      vertex: { module, entryPoint: "vertexMain" },
      fragment: {
        module,
        entryPoint: "fragmentMain",
        // every attachment must be declared to match the pass; only the restored one is written
        targets: renderTarget.colorAttachments.map((attachment, i) => ({
          format: attachment.texture.format,
          writeMask: i === index ? GPUColorWrite.ALL : 0
        }))
      },
      depthStencil,
      multisample: { count: 4 }
    });
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/GpuRenderTarget.mjs
var GpuRenderTarget = class {
  constructor() {
    this.contexts = [];
    this.canvasTextures = [];
    this.msaaTextures = [];
    this.transient = false;
    this.msaaSamples = 1;
    this.msaaBackTextures = [];
    this.stencilMode = STENCIL_MODES.DISABLED;
    this.stencilReference = 0;
    this.maskStackIndex = 0;
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/GpuRenderTargetAdaptor.mjs
var canvasAllowedFormats = {
  bgra8unorm: true,
  rgba8unorm: true,
  rgba16float: true
};
function getCanvasContextFormat(format) {
  if (canvasAllowedFormats[format]) return format;
  const preferred = navigator.gpu.getPreferredCanvasFormat();
  warn(`[WebGPU] CanvasSource format '${format}' is not a valid GPUCanvasContext format. Falling back to '${preferred}'. Allowed formats are: bgra8unorm, rgba8unorm, rgba16float.`);
  return preferred;
}
var GpuRenderTargetAdaptor = class {
  constructor() {
    this._activePass = null;
  }
  init(renderer, renderTargetSystem) {
    this._renderer = renderer;
    this._renderTargetSystem = renderTargetSystem;
    renderer.runners.contextChange.add(this);
    renderer.runners.destroy.add(this);
  }
  /** Drops the restore helper, whose pipelines belong to the old device. The next restore makes a new one. */
  contextChange() {
    this._msaaRestore = null;
  }
  destroy() {
    this._msaaRestore = null;
  }
  copyToTexture(sourceRenderSurfaceTexture, destinationTexture, originSrc, size, originDest) {
    const renderer = this._renderer;
    this.finishRenderPass();
    const baseGpuTexture = this._getGpuColorTexture(
      sourceRenderSurfaceTexture
    );
    const backGpuTexture = renderer.texture.getGpuSource(
      destinationTexture.source
    );
    renderer.encoder.commandEncoder.copyTextureToTexture(
      {
        texture: baseGpuTexture,
        origin: originSrc
      },
      {
        texture: backGpuTexture,
        origin: originDest
      },
      size
    );
    return destinationTexture;
  }
  copyDepthTexture(source, destination, originSrc, size, originDest) {
    const renderer = this._renderer;
    this.finishRenderPass();
    const srcDepth = source.depthStencilAttachment.texture;
    const srcGpu = renderer.texture.getGpuSource(srcDepth);
    const dstGpu = renderer.texture.getGpuSource(destination.source);
    const standAlone = renderer.encoder.commandEncoder === null;
    const commandEncoder = standAlone ? renderer.gpu.device.createCommandEncoder() : renderer.encoder.commandEncoder;
    commandEncoder.copyTextureToTexture(
      { texture: srcGpu, origin: originSrc },
      { texture: dstGpu, origin: originDest },
      { width: size.width, height: size.height }
    );
    if (standAlone) {
      renderer.gpu.device.queue.submit([commandEncoder.finish()]);
    }
  }
  startRenderPass(renderTarget, clear = true, clearColor, viewport, mipLevel = 0, layer = 0) {
    const renderTargetSystem = this._renderTargetSystem;
    const gpuRenderTarget = renderTargetSystem.getGpuRenderTarget(renderTarget);
    if (layer !== 0 && gpuRenderTarget.msaaTextures?.length) {
      throw new Error("[RenderTargetSystem] Rendering to array layers is not supported with MSAA render targets.");
    }
    if (mipLevel > 0 && gpuRenderTarget.msaaTextures?.length) {
      throw new Error("[RenderTargetSystem] Rendering to mip levels is not supported with MSAA render targets.");
    }
    let clearBits = clear;
    if (typeof clearBits === "boolean") {
      clearBits = clearBits ? CLEAR.ALL : CLEAR.NONE;
    }
    if ((renderTarget.stencil || renderTarget.depth) && !renderTarget.depthStencilAttachment) {
      renderTarget.ensureDepthStencilTexture();
    }
    const hasDepthStencil = !!renderTarget.depthStencilAttachment;
    const activePass = this._activePass;
    const reuse = activePass !== null && activePass.renderTarget === renderTarget && activePass.mipLevel === mipLevel && activePass.layer === layer && activePass.depthStencil === hasDepthStencil && this._renderer.encoder.renderPassEncoder !== null && clearBits === CLEAR.NONE;
    this._renderer.pipeline.setRenderTarget(renderTarget);
    if (reuse) {
      this._renderer.encoder.setViewport(viewport);
      return;
    }
    const { descriptor, restore } = this._buildDescriptor(renderTarget, clear, clearColor, mipLevel, layer);
    gpuRenderTarget.descriptor = descriptor;
    const encoder = this._renderer.encoder;
    if (restore) {
      encoder.endRenderPass();
      this._beginRestoredPass(
        renderTarget,
        restore,
        encoder.commandEncoder,
        () => encoder.beginRenderPass(gpuRenderTarget)
      );
    } else {
      encoder.beginRenderPass(gpuRenderTarget);
    }
    encoder.setViewport(viewport);
    this._activePass = { renderTarget, mipLevel, layer, depthStencil: hasDepthStencil };
  }
  finishRenderPass() {
    this._renderer.encoder.endRenderPass();
    this._activePass = null;
  }
  /**
   * Begins a pass whose MSAA colour must be restored: copies each resolved texture in `restore` into the
   * target's back textures, begins the pass, and draws them back in before anything else (see GpuMsaaRestore).
   * @param renderTarget - the target being reopened
   * @param restore - the colour attachments to restore
   * @param commandEncoder - the encoder to record the copies on, with no pass open
   * @param beginPass - begins the pass on the same encoder
   * @returns the begun pass
   */
  _beginRestoredPass(renderTarget, restore, commandEncoder, beginPass) {
    const msaaRestore = this._msaaRestore ?? (this._msaaRestore = new GpuMsaaRestore(this._renderer));
    for (const index of restore) {
      msaaRestore.copy(commandEncoder, renderTarget, index, this._getGpuColorTexture(renderTarget, index));
    }
    const pass = beginPass();
    for (const index of restore) {
      msaaRestore.draw(pass, renderTarget, index);
    }
    return pass;
  }
  /**
   * returns the gpu texture for a color texture in the render target, the first by default
   * mainly used by the filter manager to copy the texture for blending
   * @param renderTarget
   * @param index - the color attachment to get
   * @returns a gpu texture
   */
  _getGpuColorTexture(renderTarget, index = 0) {
    if (renderTarget.colorAttachments.length === 0) {
      throw new Error("[GpuRenderTargetAdaptor] cannot get gpu color texture from a depth-only render target");
    }
    const colorTexture = renderTarget.colorAttachments[index].texture;
    if (colorTexture instanceof CanvasSource && colorTexture._gpuContext) {
      return colorTexture._gpuContext.getCurrentTexture();
    }
    return this._renderer.texture.getGpuSource(colorTexture);
  }
  getDescriptor(renderTarget, clear, clearValue, mipLevel = 0, layer = 0) {
    return this._buildDescriptor(renderTarget, clear, clearValue, mipLevel, layer).descriptor;
  }
  /**
   * Builds the pass descriptor, along with the MSAA colour attachments it opens with `clear` in place of
   * `load`. Those buffers were discarded, so the pass must restore them before drawing.
   * @param renderTarget - the target to render to
   * @param clear - what to clear
   * @param clearValue - the colour to clear to
   * @param mipLevel - the mip level to render to
   * @param layer - the array layer to render to
   */
  _buildDescriptor(renderTarget, clear, clearValue, mipLevel = 0, layer = 0) {
    let restoreList = null;
    if (typeof clear === "boolean") {
      clear = clear ? CLEAR.ALL : CLEAR.NONE;
    }
    const renderTargetSystem = this._renderTargetSystem;
    const gpuRenderTarget = renderTargetSystem.getGpuRenderTarget(renderTarget);
    const colorAttachments = renderTarget.colorAttachments.map(
      (colorAttachment, i) => {
        const colorTexture = colorAttachment.texture;
        const context = colorTexture instanceof CanvasSource ? colorTexture._gpuContext : null;
        let view;
        let resolveTarget;
        let newCanvasFrame = false;
        if (context) {
          if (layer !== 0) {
            throw new Error("[RenderTargetSystem] Rendering to array layers is not supported for canvas targets.");
          }
          const currentTexture = context.getCurrentTexture();
          newCanvasFrame = gpuRenderTarget.canvasTextures[i] !== currentTexture;
          gpuRenderTarget.canvasTextures[i] = currentTexture;
          const canvasTextureView = currentTexture.createView(colorAttachment.viewDescriptor);
          view = canvasTextureView;
        } else {
          view = this._renderer.texture.getTextureRenderTargetView(
            colorAttachment.texture,
            mipLevel,
            layer,
            colorAttachment.viewDescriptor
          );
        }
        const msaaTexture = gpuRenderTarget.msaaTextures[i];
        if (msaaTexture) {
          resolveTarget = view;
          view = this._renderer.texture.getTextureView(msaaTexture);
        }
        let loadOp = colorAttachment.loadOp;
        if (clear !== void 0) {
          loadOp = clear & CLEAR.COLOR ? "clear" : "load";
        }
        clearValue ?? (clearValue = renderTargetSystem.defaultClearColor);
        const transient = !!msaaTexture?.transient;
        const load = transient && loadOp !== "clear";
        const restore = load && !newCanvasFrame;
        if (load) {
          loadOp = "clear";
          if (restore) (restoreList ?? (restoreList = [])).push(i);
        }
        const baseAttachment = {
          view,
          resolveTarget,
          storeOp: transient ? "discard" : colorAttachment.storeOp ?? "store",
          loadOp
        };
        if (colorTexture.dimension === "3d") {
          baseAttachment.depthSlice = layer;
        }
        if (load) {
          baseAttachment.clearValue = [0, 0, 0, 0];
        } else if (loadOp === "clear") {
          clearValue ?? (clearValue = colorAttachment.clearValue ?? renderTargetSystem.defaultClearColor);
          baseAttachment.clearValue = clearValue;
        }
        for (const key in colorAttachment) {
          if (key !== "texture" && key !== "viewDescriptor" && key !== "clearValue" && key !== "loadOp" && key !== "storeOp") {
            baseAttachment[key] = colorAttachment[key];
          }
        }
        return baseAttachment;
      }
    );
    let depthStencilAttachment;
    if (renderTarget.depthStencilAttachment) {
      this._prepareDepthStencil(renderTarget, gpuRenderTarget);
      const attachment = renderTarget.depthStencilAttachment;
      const stencil = attachment.texture.format.includes("stencil");
      const depth = attachment.texture.format.includes("depth");
      const dsStoreOp = gpuRenderTarget.transient ? "discard" : "store";
      const dsLoadOp = gpuRenderTarget.transient ? "clear" : "load";
      depthStencilAttachment = {
        view: this._renderer.texture.getTextureRenderTargetView(
          attachment.texture,
          mipLevel,
          layer,
          attachment.viewDescriptor
        )
      };
      const depthReadOnly = attachment.depthReadOnly ?? false;
      const stencilReadOnly = attachment.stencilReadOnly ?? depthReadOnly;
      if (stencil && !stencilReadOnly) {
        depthStencilAttachment.stencilLoadOp = clear & CLEAR.STENCIL ? "clear" : attachment.stencilLoadOp ?? dsLoadOp;
        depthStencilAttachment.stencilStoreOp = attachment.stencilStoreOp ?? dsStoreOp;
        if (depthStencilAttachment.stencilLoadOp === "clear") {
          depthStencilAttachment.stencilClearValue = attachment.stencilClearValue ?? 0;
        }
      } else if (stencil && stencilReadOnly) {
        depthStencilAttachment.stencilReadOnly = true;
      }
      if (depth && !depthReadOnly) {
        depthStencilAttachment.depthLoadOp = clear & CLEAR.DEPTH ? "clear" : attachment.depthLoadOp ?? dsLoadOp;
        depthStencilAttachment.depthStoreOp = attachment.depthStoreOp ?? dsStoreOp;
        if (depthStencilAttachment.depthLoadOp === "clear") {
          depthStencilAttachment.depthClearValue = attachment.depthClearValue ?? 1;
        }
      } else if (depth && depthReadOnly) {
        depthStencilAttachment.depthReadOnly = true;
      }
      for (const key in attachment) {
        if (key !== "texture" && key !== "viewDescriptor" && key !== "stencilLoadOp" && key !== "stencilStoreOp" && key !== "stencilClearValue" && key !== "stencilReadOnly" && key !== "depthLoadOp" && key !== "depthStoreOp" && key !== "depthClearValue" && key !== "depthReadOnly") {
          depthStencilAttachment[key] = attachment[key];
        }
      }
    }
    const descriptor = {
      colorAttachments,
      depthStencilAttachment,
      label: renderTarget.label
    };
    return { descriptor, restore: restoreList };
  }
  clear(renderTarget, clear = true, clearColor, viewport, mipLevel = 0, layer = 0) {
    if (!clear) return;
    const { gpu, encoder } = this._renderer;
    const device = gpu.device;
    const standAlone = encoder.commandEncoder === null;
    if (standAlone) {
      const commandEncoder = device.createCommandEncoder();
      const { descriptor, restore } = this._buildDescriptor(renderTarget, clear, clearColor, mipLevel, layer);
      const beginPass = () => commandEncoder.beginRenderPass(descriptor);
      const passEncoder = restore ? this._beginRestoredPass(renderTarget, restore, commandEncoder, beginPass) : beginPass();
      passEncoder.setViewport(viewport.x, viewport.y, viewport.width, viewport.height, 0, 1);
      passEncoder.end();
      const gpuCommands = commandEncoder.finish();
      device.queue.submit([gpuCommands]);
    } else {
      this.startRenderPass(renderTarget, clear, clearColor, viewport, mipLevel, layer);
    }
  }
  initGpuRenderTarget(renderTarget) {
    renderTarget.isRoot = true;
    const gpuRenderTarget = new GpuRenderTarget();
    gpuRenderTarget.transient = !!renderTarget.colorTexture?.antialias && !!renderTarget.colorTexture.transient;
    renderTarget.colorAttachments.forEach((colorAttachment, i) => {
      const colorTexture = colorAttachment.texture;
      if (colorTexture instanceof CanvasSource) {
        const context = colorTexture._gpuContext ?? (colorTexture._gpuContext = colorTexture.resource.getContext(
          "webgpu"
        ));
        const alphaMode = colorTexture.transparent ? "premultiplied" : "opaque";
        const canvasFormat = getCanvasContextFormat(colorTexture.format);
        try {
          context.configure(__spreadValues({
            device: this._renderer.gpu.device,
            usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC,
            format: canvasFormat,
            alphaMode
          }, canvasFormat === "rgba16float" ? { toneMapping: { mode: "extended" } } : {}));
        } catch (e) {
          console.error(e);
        }
        gpuRenderTarget.contexts[i] = context;
      }
      gpuRenderTarget.msaa = colorTexture.source.antialias;
      if (colorTexture.antialias) {
        const msaaTexture = new TextureSource({
          width: 0,
          height: 0,
          sampleCount: 4,
          // WebGPU requires multisampled textures to have exactly 1 mip level, so this must never
          // inherit TextureSource.defaultOptions.autoGenerateMipmaps
          autoGenerateMipmaps: false,
          transient: this._renderer.device.extensions.tileBased || gpuRenderTarget.transient,
          arrayLayerCount: colorTexture.arrayLayerCount,
          format: colorTexture.format
        });
        gpuRenderTarget.msaaTextures[i] = msaaTexture;
      }
    });
    if (gpuRenderTarget.msaa) {
      gpuRenderTarget.msaaSamples = 4;
    }
    return gpuRenderTarget;
  }
  /**
   * Sets up a depth/stencil texture for an MSAA target before its GPU texture is created: 4 samples, and
   * the transient usage bit when the user marked the target single-pass. Both are fixed at creation, so this
   * runs when a pass descriptor is built, just before the depth/stencil view is first made.
   * @param renderTarget - the target whose depth/stencil texture to set up
   * @param gpuRenderTarget - its backend target
   */
  _prepareDepthStencil(renderTarget, gpuRenderTarget) {
    const texture = renderTarget.depthStencilAttachment?.texture;
    if (!texture || !gpuRenderTarget.msaa) return;
    texture.sampleCount = 4;
    texture.transient = gpuRenderTarget.transient;
  }
  destroyGpuRenderTarget(gpuRenderTarget) {
    gpuRenderTarget.contexts.forEach((context) => {
      context.unconfigure();
    });
    gpuRenderTarget.msaaTextures.forEach((texture) => {
      texture.destroy();
    });
    gpuRenderTarget.msaaBackTextures.forEach((texture) => {
      texture?.destroy();
    });
    gpuRenderTarget.msaaTextures.length = 0;
    gpuRenderTarget.msaaBackTextures.length = 0;
    gpuRenderTarget.contexts.length = 0;
  }
  ensureDepthStencilTexture(renderTarget) {
    this._prepareDepthStencil(renderTarget, this._renderTargetSystem.getGpuRenderTarget(renderTarget));
  }
  resizeGpuRenderTarget(renderTarget) {
    const gpuRenderTarget = this._renderTargetSystem.getGpuRenderTarget(renderTarget);
    gpuRenderTarget.width = renderTarget.width;
    gpuRenderTarget.height = renderTarget.height;
    if (gpuRenderTarget.msaa) {
      renderTarget.colorAttachments.forEach((colorAttachment, i) => {
        const colorTexture = colorAttachment.texture;
        gpuRenderTarget.msaaTextures[i]?.resize(colorTexture.width, colorTexture.height, colorTexture._resolution);
        gpuRenderTarget.msaaBackTextures[i]?.resize(
          colorTexture.width,
          colorTexture.height,
          colorTexture._resolution
        );
      });
    }
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/GpuRenderTargetSystem.mjs
var GpuRenderTargetSystem = class extends RenderTargetSystem {
  constructor(renderer) {
    super(renderer);
    this.adaptor = new GpuRenderTargetAdaptor();
    this.adaptor.init(renderer, this);
  }
};
GpuRenderTargetSystem.extension = {
  type: [ExtensionType.WebGPUSystem],
  name: "renderTarget"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/shader/GpuShaderSystem.mjs
var GpuShaderSystem = class {
  constructor() {
    this._gpuProgramData = /* @__PURE__ */ Object.create(null);
  }
  contextChange(gpu) {
    this._gpu = gpu;
    this._gpuProgramData = /* @__PURE__ */ Object.create(null);
  }
  getProgramData(program) {
    return this._gpuProgramData[program._layoutKey] || this._createGPUProgramData(program);
  }
  _createGPUProgramData(program) {
    const device = this._gpu.device;
    const bindGroups = program.gpuLayout.map((group) => device.createBindGroupLayout({ entries: group }));
    const pipelineLayoutDesc = { bindGroupLayouts: bindGroups };
    this._gpuProgramData[program._layoutKey] = {
      bindGroups,
      pipeline: device.createPipelineLayout(pipelineLayoutDesc)
    };
    return this._gpuProgramData[program._layoutKey];
  }
  destroy() {
    this._gpu = null;
    this._gpuProgramData = null;
  }
};
GpuShaderSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "shader"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/state/GpuBlendModesToPixi.mjs
var GpuBlendModesToPixi = {};
GpuBlendModesToPixi.normal = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  }
};
GpuBlendModesToPixi.add = {
  alpha: {
    srcFactor: "src-alpha",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "one",
    dstFactor: "one",
    operation: "add"
  }
};
GpuBlendModesToPixi.multiply = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "dst",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  }
};
GpuBlendModesToPixi.screen = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "one",
    dstFactor: "one-minus-src",
    operation: "add"
  }
};
GpuBlendModesToPixi.overlay = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "one",
    dstFactor: "one-minus-src",
    operation: "add"
  }
};
GpuBlendModesToPixi.none = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "zero",
    dstFactor: "zero",
    operation: "add"
  }
};
GpuBlendModesToPixi["normal-npm"] = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "src-alpha",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  }
};
GpuBlendModesToPixi["add-npm"] = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one",
    operation: "add"
  },
  color: {
    srcFactor: "src-alpha",
    dstFactor: "one",
    operation: "add"
  }
};
GpuBlendModesToPixi["screen-npm"] = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "src-alpha",
    dstFactor: "one-minus-src",
    operation: "add"
  }
};
GpuBlendModesToPixi.erase = {
  alpha: {
    srcFactor: "zero",
    dstFactor: "one-minus-src-alpha",
    operation: "add"
  },
  color: {
    srcFactor: "zero",
    dstFactor: "one-minus-src",
    operation: "add"
  }
};
GpuBlendModesToPixi.min = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one",
    operation: "min"
  },
  color: {
    srcFactor: "one",
    dstFactor: "one",
    operation: "min"
  }
};
GpuBlendModesToPixi.max = {
  alpha: {
    srcFactor: "one",
    dstFactor: "one",
    operation: "max"
  },
  color: {
    srcFactor: "one",
    dstFactor: "one",
    operation: "max"
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/state/GpuStateSystem.mjs
var GpuStateSystem = class {
  constructor() {
    this.defaultState = new State();
    this.defaultState.blend = true;
  }
  contextChange(gpu) {
    this.gpu = gpu;
  }
  /**
   * Gets the blend mode data for the current state
   * @param state - The state to get the blend mode from
   * @param count - The number of color targets to create
   * @param format - The texture format of the color attachments (assumed uniform across attachments)
   */
  getColorTargets(state, count, format) {
    const blend = state.blend ? GpuBlendModesToPixi[state.blendMode] || GpuBlendModesToPixi.normal : void 0;
    const targets = [];
    for (let i = 0; i < count; i++) {
      targets[i] = {
        format,
        writeMask: 0,
        blend
      };
    }
    return targets;
  }
  destroy() {
    this.gpu = null;
  }
};
GpuStateSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "state"
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/uploaders/gpuUploadBufferImageResource.mjs
var tempRects = [new Rectangle(), new Rectangle(), new Rectangle()];
var gpuUploadBufferImageResource = {
  type: "image",
  upload(source, gpuTexture, gpu, originZOverride = 0) {
    const resource = source.resource;
    const width = source.pixelWidth | 0;
    const height = source.pixelHeight | 0;
    const depth = source.depthOrArrayLayers;
    const bytesPerPixel = resource.byteLength / (width * height * depth);
    if (depth > 1) {
      gpu.device.queue.writeTexture(
        { texture: gpuTexture, origin: { x: 0, y: 0, z: originZOverride } },
        resource,
        { offset: 0, rowsPerImage: height, bytesPerRow: width * bytesPerPixel },
        { width, height, depthOrArrayLayers: depth }
      );
      return;
    }
    const count = getTexelRangeRects(source._updateStart, source._updateEnd, width, height, tempRects);
    for (let i = 0; i < count; i++) {
      const rect = tempRects[i];
      gpu.device.queue.writeTexture(
        { texture: gpuTexture, origin: { x: rect.x, y: rect.y, z: originZOverride } },
        resource,
        {
          offset: (rect.y * width + rect.x) * bytesPerPixel,
          rowsPerImage: rect.height,
          bytesPerRow: width * bytesPerPixel
        },
        {
          width: rect.width,
          height: rect.height,
          depthOrArrayLayers: 1
        }
      );
    }
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/uploaders/gpuUploadCompressedTextureResource.mjs
var blockDataMap = {
  "bc1-rgba-unorm": { blockBytes: 8, blockWidth: 4, blockHeight: 4 },
  "bc2-rgba-unorm": { blockBytes: 16, blockWidth: 4, blockHeight: 4 },
  "bc3-rgba-unorm": { blockBytes: 16, blockWidth: 4, blockHeight: 4 },
  "bc7-rgba-unorm": { blockBytes: 16, blockWidth: 4, blockHeight: 4 },
  "etc1-rgb-unorm": { blockBytes: 8, blockWidth: 4, blockHeight: 4 },
  "etc2-rgba8unorm": { blockBytes: 16, blockWidth: 4, blockHeight: 4 },
  "astc-4x4-unorm": { blockBytes: 16, blockWidth: 4, blockHeight: 4 }
};
var defaultBlockData = { blockBytes: 4, blockWidth: 1, blockHeight: 1 };
var gpuUploadCompressedTextureResource = {
  type: "compressed",
  upload(source, gpuTexture, gpu, originZOverride = 0) {
    let mipWidth = source.pixelWidth;
    let mipHeight = source.pixelHeight;
    const blockData = blockDataMap[source.format] || defaultBlockData;
    for (let i = 0; i < source.resource.length; i++) {
      const levelBuffer = source.resource[i];
      const bytesPerRow = Math.ceil(mipWidth / blockData.blockWidth) * blockData.blockBytes;
      gpu.device.queue.writeTexture(
        {
          texture: gpuTexture,
          mipLevel: i,
          origin: { x: 0, y: 0, z: originZOverride }
        },
        levelBuffer,
        {
          offset: 0,
          bytesPerRow
        },
        {
          width: Math.ceil(mipWidth / blockData.blockWidth) * blockData.blockWidth,
          height: Math.ceil(mipHeight / blockData.blockHeight) * blockData.blockHeight,
          depthOrArrayLayers: 1
        }
      );
      mipWidth = Math.max(mipWidth >> 1, 1);
      mipHeight = Math.max(mipHeight >> 1, 1);
    }
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/uploaders/gpuUploadCubeTextureResource.mjs
var FACE_ORDER = ["right", "left", "top", "bottom", "front", "back"];
function createGpuUploadCubeTextureResource(uploaders) {
  return {
    type: "cube",
    upload(source, gpuTexture, gpu) {
      const faces = source.faces;
      for (let i = 0; i < FACE_ORDER.length; i++) {
        const key = FACE_ORDER[i];
        const face = faces[key];
        const uploader = uploaders[face.uploadMethodId] || uploaders.image;
        uploader.upload(face, gpuTexture, gpu, i);
      }
    }
  };
}

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/uploaders/gpuUploadImageSource.mjs
var gpuUploadImageResource = {
  type: "image",
  upload(source, gpuTexture, gpu, originZOverride = 0) {
    const resource = source.resource;
    if (!resource) return;
    if (globalThis.HTMLImageElement && resource instanceof HTMLImageElement) {
      const canvas = DOMAdapter.get().createCanvas(resource.width, resource.height);
      const context = canvas.getContext("2d");
      context.drawImage(resource, 0, 0, resource.width, resource.height);
      source.resource = canvas;
      warn("ImageSource: Image element passed, converting to canvas and replacing resource.");
    }
    const width = Math.min(gpuTexture.width, source.resourceWidth || source.pixelWidth);
    const height = Math.min(gpuTexture.height, source.resourceHeight || source.pixelHeight);
    const premultipliedAlpha = source.alphaMode === "premultiply-alpha-on-upload";
    gpu.device.queue.copyExternalImageToTexture(
      { source: resource },
      { texture: gpuTexture, origin: { x: 0, y: 0, z: originZOverride }, premultipliedAlpha },
      {
        width,
        height
      }
    );
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/uploaders/gpuUploadVideoSource.mjs
var gpuUploadVideoResource = {
  type: "video",
  upload(source, gpuTexture, gpu, originZOverride) {
    gpuUploadImageResource.upload(source, gpuTexture, gpu, originZOverride);
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/utils/Gpu3dMipmapGenerator.mjs
var MIPMAP_3D_FORMATS = ["rgba8unorm", "rgba16float"];
var WORKGROUP_SIZE = 4;
function assertMipmap3dTexture(format, storage) {
  if (!storage) {
    throw new Error("[Gpu3dMipmapGenerator] generating mipmaps for a 3D texture needs storage: true.");
  }
  if (!MIPMAP_3D_FORMATS.includes(format)) {
    throw new Error(`[Gpu3dMipmapGenerator] format '${format}' can't be downsampled. Use ${MIPMAP_3D_FORMATS.join(", ")}.`);
  }
}
var Gpu3dMipmapGenerator = class {
  constructor(device) {
    this._pipelines = {};
    this._device = device;
    this._sampler = device.createSampler({
      magFilter: "linear",
      minFilter: "linear"
    });
  }
  _getMipmapPipeline(format) {
    var _a;
    (_a = this._pipelines)[format] ?? (_a[format] = this._device.createComputePipeline({
      layout: "auto",
      compute: {
        module: this._device.createShaderModule({
          code: (
            /* wgsl */
            `
                        @group(0) @binding(0) var srcSampler : sampler;
                        @group(0) @binding(1) var src : texture_3d<f32>;
                        @group(0) @binding(2) var dst : texture_storage_3d<${format}, write>;

                        @compute @workgroup_size(${WORKGROUP_SIZE}, ${WORKGROUP_SIZE}, ${WORKGROUP_SIZE})
                        fn main(@builtin(global_invocation_id) gid : vec3<u32>) {
                            let dstSize = textureDimensions(dst);

                            if (gid.x >= dstSize.x || gid.y >= dstSize.y || gid.z >= dstSize.z) {
                                return;
                            }

                            // centre of the 2x2x2 footprint in the previous mip. When a dimension is
                            // odd its last texel, row or slice is never sampled, as in the 2D generator
                            let uv = (vec3<f32>(gid) * 2.0 + 1.0) / vec3<f32>(textureDimensions(src));

                            textureStore(dst, gid, textureSampleLevel(src, srcSampler, uv, 0.0));
                        }
                    `
          )
        }),
        entryPoint: "main"
      }
    }));
    return this._pipelines[format];
  }
  /**
   * Fills mip levels 1..n of a 3D texture from level 0.
   * @param texture - a 3D texture with `STORAGE_BINDING` and more than one mip level
   */
  generateMipmap(texture) {
    if (texture.dimension !== "3d") {
      throw new Error("[Gpu3dMipmapGenerator] generateMipmap expects a 3D texture.");
    }
    if (texture.mipLevelCount < 2) return;
    assertMipmap3dTexture(texture.format, (texture.usage & GPUTextureUsage.STORAGE_BINDING) !== 0);
    const pipeline = this._getMipmapPipeline(texture.format);
    const layout = pipeline.getBindGroupLayout(0);
    const encoder = this._device.createCommandEncoder({ label: "Gpu3dMipmapGenerator" });
    const pass = encoder.beginComputePass();
    pass.setPipeline(pipeline);
    let width = texture.width;
    let height = texture.height;
    let depth = texture.depthOrArrayLayers;
    let srcView = texture.createView({ dimension: "3d", baseMipLevel: 0, mipLevelCount: 1 });
    for (let level = 1; level < texture.mipLevelCount; level++) {
      width = Math.max(1, width >> 1);
      height = Math.max(1, height >> 1);
      depth = Math.max(1, depth >> 1);
      const dstView = texture.createView({ dimension: "3d", baseMipLevel: level, mipLevelCount: 1 });
      pass.setBindGroup(0, this._device.createBindGroup({
        layout,
        entries: [
          { binding: 0, resource: this._sampler },
          { binding: 1, resource: srcView },
          { binding: 2, resource: dstView }
        ]
      }));
      pass.dispatchWorkgroups(
        Math.ceil(width / WORKGROUP_SIZE),
        Math.ceil(height / WORKGROUP_SIZE),
        Math.ceil(depth / WORKGROUP_SIZE)
      );
      srcView = dstView;
    }
    pass.end();
    this._device.queue.submit([encoder.finish()]);
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/utils/GpuMipmapGenerator.mjs
var GpuMipmapGenerator = class {
  constructor(device) {
    this._pipelines = {};
    this._device = device;
    this._sampler = device.createSampler({ minFilter: "linear" });
  }
  _getMipmapPipeline(format) {
    let pipeline = this._pipelines[format];
    if (!pipeline) {
      if (!this._mipmapShaderModule) {
        this._mipmapShaderModule = this._device.createShaderModule({
          code: (
            /* wgsl */
            `
                        var<private> pos : array<vec2<f32>, 3> = array<vec2<f32>, 3>(
                        vec2<f32>(-1.0, -1.0), vec2<f32>(-1.0, 3.0), vec2<f32>(3.0, -1.0));

                        struct VertexOutput {
                        @builtin(position) position : vec4<f32>,
                        @location(0) texCoord : vec2<f32>,
                        };

                        @vertex
                        fn vertexMain(@builtin(vertex_index) vertexIndex : u32) -> VertexOutput {
                        var output : VertexOutput;
                        output.texCoord = pos[vertexIndex] * vec2<f32>(0.5, -0.5) + vec2<f32>(0.5);
                        output.position = vec4<f32>(pos[vertexIndex], 0.0, 1.0);
                        return output;
                        }

                        @group(0) @binding(0) var imgSampler : sampler;
                        @group(0) @binding(1) var img : texture_2d<f32>;

                        @fragment
                        fn fragmentMain(@location(0) texCoord : vec2<f32>) -> @location(0) vec4<f32> {
                        return textureSample(img, imgSampler, texCoord);
                        }
                    `
          )
        });
      }
      pipeline = this._device.createRenderPipeline({
        layout: "auto",
        vertex: {
          module: this._mipmapShaderModule,
          entryPoint: "vertexMain"
        },
        fragment: {
          module: this._mipmapShaderModule,
          entryPoint: "fragmentMain",
          targets: [{ format }]
        }
      });
      this._pipelines[format] = pipeline;
    }
    return pipeline;
  }
  /**
   * Generates mipmaps for the given GPUTexture from the data in level 0.
   * @param {module:External.GPUTexture} texture - Texture to generate mipmaps for.
   * @returns {module:External.GPUTexture} - The originally passed texture
   */
  generateMipmap(texture) {
    if (texture.dimension === "3d") {
      throw new Error("[GpuMipmapGenerator] a 3D texture uses Gpu3dMipmapGenerator.");
    }
    if (texture.dimension === "1d") {
      throw new Error("Generating mipmaps for 1d textures is currently unsupported!");
    }
    const pipeline = this._getMipmapPipeline(texture.format);
    let mipTexture = texture;
    const arrayLayerCount = texture.depthOrArrayLayers || 1;
    const renderToSource = texture.usage & GPUTextureUsage.RENDER_ATTACHMENT;
    if (!renderToSource) {
      const mipTextureDescriptor = {
        size: {
          width: Math.ceil(texture.width / 2),
          height: Math.ceil(texture.height / 2),
          depthOrArrayLayers: arrayLayerCount
        },
        format: texture.format,
        usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_SRC | GPUTextureUsage.RENDER_ATTACHMENT,
        mipLevelCount: texture.mipLevelCount - 1
      };
      mipTexture = this._device.createTexture(mipTextureDescriptor);
    }
    const commandEncoder = this._device.createCommandEncoder({});
    const bindGroupLayout = pipeline.getBindGroupLayout(0);
    for (let arrayLayer = 0; arrayLayer < arrayLayerCount; ++arrayLayer) {
      let srcView = texture.createView({
        baseMipLevel: 0,
        mipLevelCount: 1,
        dimension: "2d",
        baseArrayLayer: arrayLayer,
        arrayLayerCount: 1
      });
      let dstMipLevel = renderToSource ? 1 : 0;
      for (let i = 1; i < texture.mipLevelCount; ++i) {
        const dstView = mipTexture.createView({
          baseMipLevel: dstMipLevel++,
          mipLevelCount: 1,
          dimension: "2d",
          baseArrayLayer: arrayLayer,
          arrayLayerCount: 1
        });
        const passEncoder = commandEncoder.beginRenderPass({
          colorAttachments: [{
            view: dstView,
            storeOp: "store",
            loadOp: "clear",
            clearValue: { r: 0, g: 0, b: 0, a: 0 }
          }]
        });
        const bindGroup = this._device.createBindGroup({
          layout: bindGroupLayout,
          entries: [{
            binding: 0,
            resource: this._sampler
          }, {
            binding: 1,
            resource: srcView
          }]
        });
        passEncoder.setPipeline(pipeline);
        passEncoder.setBindGroup(0, bindGroup);
        passEncoder.draw(3, 1, 0, 0);
        passEncoder.end();
        srcView = dstView;
      }
    }
    if (!renderToSource) {
      const mipLevelSize = {
        width: Math.ceil(texture.width / 2),
        height: Math.ceil(texture.height / 2),
        depthOrArrayLayers: arrayLayerCount
      };
      for (let i = 1; i < texture.mipLevelCount; ++i) {
        commandEncoder.copyTextureToTexture({
          texture: mipTexture,
          mipLevel: i - 1
        }, {
          texture,
          mipLevel: i
        }, mipLevelSize);
        mipLevelSize.width = Math.ceil(mipLevelSize.width / 2);
        mipLevelSize.height = Math.ceil(mipLevelSize.height / 2);
      }
    }
    this._device.queue.submit([commandEncoder.finish()]);
    if (!renderToSource) {
      mipTexture.destroy();
    }
    return texture;
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/GpuTextureSystem.mjs
var GPUTextureGpuData = class {
  constructor(gpuTexture) {
    this.textureView = null;
    this.textureViews = /* @__PURE__ */ Object.create(null);
    this.gpuTexture = gpuTexture;
  }
  /** Destroys this GPU data instance. */
  destroy() {
    this.gpuTexture.destroy();
    this.textureView = null;
    this.textureViews = null;
    this.gpuTexture = null;
  }
};
var SRGB_CAPABLE = /^(rgba8|bgra8|bc[1237]-rgba-|etc2-rgb8|etc2-rgb8a1|etc2-rgba8|astc-\d+x\d+-)unorm$/;
function srgbViewFormat(format) {
  return SRGB_CAPABLE.test(format) ? [`${format}-srgb`] : void 0;
}
function getViewDescriptorKey(viewDescriptor) {
  return `${viewDescriptor.format || ""}.${viewDescriptor.dimension || ""}.${viewDescriptor.aspect || ""}.${viewDescriptor.baseMipLevel || 0}.${viewDescriptor.mipLevelCount || ""}.${viewDescriptor.baseArrayLayer || 0}.${viewDescriptor.arrayLayerCount || ""}`;
}
var _GpuTextureSystem = class _GpuTextureSystem2 {
  constructor(renderer) {
    this._gpuSamplers = /* @__PURE__ */ Object.create(null);
    this._bindGroupHash = /* @__PURE__ */ Object.create(null);
    this._renderer = renderer;
    renderer.gc.addCollection(this, "_bindGroupHash", "hash");
    this._managedTextures = new GCManagedHash({
      renderer,
      type: "resource",
      onUnload: this.onSourceUnload.bind(this),
      name: "gpuTextureSource"
    });
    const baseUploaders = __spreadValues({
      image: gpuUploadImageResource,
      buffer: gpuUploadBufferImageResource,
      video: gpuUploadVideoResource,
      compressed: gpuUploadCompressedTextureResource
    }, _GpuTextureSystem2.uploadExtensions);
    this._uploads = __spreadProps(__spreadValues({}, baseUploaders), {
      cube: createGpuUploadCubeTextureResource(baseUploaders)
    });
  }
  /**
   * @deprecated since 8.15.0
   */
  get managedTextures() {
    return Object.values(this._managedTextures.items);
  }
  contextChange(gpu) {
    this._gpu = gpu;
    this._managedTextures.removeAll();
    this._gpuSamplers = /* @__PURE__ */ Object.create(null);
    this._mipmapGenerator = null;
    this._mipmap3dGenerator = null;
  }
  /**
   * Initializes a texture source, if it has already been initialized nothing will happen.
   * @param source - The texture source to initialize.
   * @returns The initialized texture source.
   */
  initSource(source) {
    return source._gpuData[this._renderer.uid]?.gpuTexture || this._initSource(source);
  }
  _initSource(source) {
    if (source.autoGenerateMipmaps) {
      if (source.dimension === "3d") assertMipmap3dTexture(source.format, source.storage);
      const biggestDimension = Math.max(source.pixelWidth, source.pixelHeight, source.depth);
      source.mipLevelCount = Math.floor(Math.log2(biggestDimension)) + 1;
    }
    let usage;
    let viewFormats;
    if (source.sampleCount > 1) {
      usage = GPUTextureUsage.RENDER_ATTACHMENT;
      if (source.transient && this._renderer.device.extensions.transientAttachment) {
        usage |= GPUTextureUsage.TRANSIENT_ATTACHMENT;
      }
    } else {
      usage = GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST;
      if (source.uploadMethodId !== "compressed") {
        usage |= GPUTextureUsage.RENDER_ATTACHMENT;
        usage |= GPUTextureUsage.COPY_SRC;
      }
      if (source.storage) usage |= GPUTextureUsage.STORAGE_BINDING;
      viewFormats = srgbViewFormat(source.format);
    }
    const blockData = blockDataMap[source.format] || { blockBytes: 4, blockWidth: 1, blockHeight: 1 };
    const width = Math.ceil(source.pixelWidth / blockData.blockWidth) * blockData.blockWidth;
    const height = Math.ceil(source.pixelHeight / blockData.blockHeight) * blockData.blockHeight;
    const textureDescriptor = {
      label: source.label,
      // WebGPU cube textures are 2D textures with 6 array layers and a cube view.
      size: { width, height, depthOrArrayLayers: source.depthOrArrayLayers },
      format: source.format,
      viewFormats,
      sampleCount: source.sampleCount,
      mipLevelCount: source.mipLevelCount,
      dimension: source.dimension,
      usage
    };
    const gpuTexture = this._gpu.device.createTexture(textureDescriptor);
    source._gpuData[this._renderer.uid] = new GPUTextureGpuData(gpuTexture);
    const added = this._managedTextures.add(source);
    if (added) {
      source.on("update", this.onSourceUpdate, this);
      source.on("resize", this.onSourceResize, this);
      source.on("updateMipmaps", this.onUpdateMipmaps, this);
    }
    this.onSourceUpdate(source);
    return gpuTexture;
  }
  onSourceUpdate(source) {
    const gpuTexture = this.getGpuSource(source);
    if (!gpuTexture) return;
    if (this._uploads[source.uploadMethodId]) {
      this._uploads[source.uploadMethodId].upload(source, gpuTexture, this._gpu);
    }
    if (source.autoGenerateMipmaps && source.mipLevelCount > 1) {
      this.onUpdateMipmaps(source);
    }
  }
  onUpdateMipmaps(source) {
    const gpuTexture = this.getGpuSource(source);
    if (source.dimension === "3d") {
      this._mipmap3dGenerator ?? (this._mipmap3dGenerator = new Gpu3dMipmapGenerator(this._gpu.device));
      this._mipmap3dGenerator.generateMipmap(gpuTexture);
      return;
    }
    this._mipmapGenerator ?? (this._mipmapGenerator = new GpuMipmapGenerator(this._gpu.device));
    this._mipmapGenerator.generateMipmap(gpuTexture);
  }
  onSourceUnload(source) {
    source.off("update", this.onSourceUpdate, this);
    source.off("resize", this.onSourceResize, this);
    source.off("updateMipmaps", this.onUpdateMipmaps, this);
  }
  onSourceResize(source) {
    source._gcLastUsed = this._renderer.gc.now;
    const gpuData = source._gpuData[this._renderer.uid];
    const gpuTexture = gpuData?.gpuTexture;
    if (!gpuTexture) {
      this.initSource(source);
    } else if (gpuTexture.width !== source.pixelWidth || gpuTexture.height !== source.pixelHeight) {
      gpuData.destroy();
      this._bindGroupHash[source.uid] = null;
      source._gpuData[this._renderer.uid] = null;
      this.initSource(source);
    }
  }
  _initSampler(sampler) {
    this._gpuSamplers[sampler._resourceId] = this._gpu.device.createSampler(sampler);
    return this._gpuSamplers[sampler._resourceId];
  }
  getGpuSampler(sampler) {
    return this._gpuSamplers[sampler._resourceId] || this._initSampler(sampler);
  }
  getGpuSource(source) {
    source._gcLastUsed = this._renderer.gc.now;
    return source._gpuData[this._renderer.uid]?.gpuTexture || this.initSource(source);
  }
  /**
   * this returns s bind group for a specific texture, the bind group contains
   * - the texture source
   * - the texture style
   * - the texture matrix
   * This is cached so the bind group should only be created once per texture
   * @param texture - the texture you want the bindgroup for
   * @returns the bind group for the texture
   */
  getTextureBindGroup(texture) {
    return this._bindGroupHash[texture.uid] || this._createTextureBindGroup(texture);
  }
  _createTextureBindGroup(texture) {
    const source = texture.source;
    this._bindGroupHash[texture.uid] = new BindGroup({
      0: source,
      1: source.style,
      2: new UniformGroup({
        uTextureMatrix: { type: "mat3x3<f32>", value: texture.textureMatrix.mapCoord }
      })
    });
    return this._bindGroupHash[texture.uid];
  }
  getTextureView(texture, viewDescriptor) {
    var _a;
    const source = texture.source;
    source._gcLastUsed = this._renderer.gc.now;
    let gpuData = source._gpuData[this._renderer.uid];
    if (!gpuData) {
      this.initSource(source);
      gpuData = source._gpuData[this._renderer.uid];
    }
    const descriptorKey = viewDescriptor ? getViewDescriptorKey(viewDescriptor) : 0;
    (_a = gpuData.textureViews)[descriptorKey] || (_a[descriptorKey] = gpuData.gpuTexture.createView(__spreadValues({
      dimension: source.viewDimension
    }, viewDescriptor)));
    return gpuData.textureViews[descriptorKey];
  }
  getTextureRenderTargetView(texture, mipLevel = 0, layer = 0, viewDescriptor) {
    var _a;
    const source = texture.source;
    source._gcLastUsed = this._renderer.gc.now;
    let gpuData = source._gpuData[this._renderer.uid];
    if (!gpuData) {
      this.initSource(source);
      gpuData = source._gpuData[this._renderer.uid];
    }
    const is3D = source.dimension === "3d";
    if (is3D) layer = 0;
    let descriptorKey = layer * (source.mipLevelCount || 1) + mipLevel + 1;
    if (viewDescriptor) {
      descriptorKey = `${descriptorKey}.${getViewDescriptorKey(viewDescriptor)}`;
    }
    (_a = gpuData.textureViews)[descriptorKey] || (_a[descriptorKey] = gpuData.gpuTexture.createView(__spreadValues({
      dimension: is3D ? "3d" : "2d",
      baseMipLevel: mipLevel,
      mipLevelCount: 1,
      baseArrayLayer: layer,
      arrayLayerCount: 1
    }, viewDescriptor)));
    return gpuData.textureViews[descriptorKey];
  }
  generateCanvas(texture) {
    const renderer = this._renderer;
    const commandEncoder = renderer.gpu.device.createCommandEncoder();
    const canvas = DOMAdapter.get().createCanvas();
    canvas.width = texture.source.pixelWidth;
    canvas.height = texture.source.pixelHeight;
    const context = canvas.getContext("webgpu");
    context.configure({
      device: renderer.gpu.device,
      usage: GPUTextureUsage.COPY_DST | GPUTextureUsage.COPY_SRC,
      format: DOMAdapter.get().getNavigator().gpu.getPreferredCanvasFormat(),
      alphaMode: "premultiplied"
    });
    commandEncoder.copyTextureToTexture({
      texture: renderer.texture.getGpuSource(texture.source),
      origin: {
        x: 0,
        y: 0
      }
    }, {
      texture: context.getCurrentTexture()
    }, {
      width: canvas.width,
      height: canvas.height
    });
    renderer.gpu.device.queue.submit([commandEncoder.finish()]);
    return canvas;
  }
  getPixels(texture) {
    const webGPUCanvas = this.generateCanvas(texture);
    const canvasAndContext = CanvasPool.getOptimalCanvasAndContext(webGPUCanvas.width, webGPUCanvas.height);
    const context = canvasAndContext.context;
    context.drawImage(webGPUCanvas, 0, 0);
    const { width, height } = webGPUCanvas;
    const imageData = context.getImageData(0, 0, width, height);
    const pixels = new Uint8ClampedArray(imageData.data.buffer);
    CanvasPool.returnCanvasAndContext(canvasAndContext);
    return { pixels, width, height };
  }
  destroy() {
    this._managedTextures.destroy();
    for (const k of Object.keys(this._bindGroupHash)) {
      const key = Number(k);
      const bindGroup = this._bindGroupHash[key];
      bindGroup?.destroy();
    }
    this._renderer = null;
    this._gpu = null;
    this._mipmapGenerator = null;
    this._mipmap3dGenerator = null;
    this._gpuSamplers = null;
    this._bindGroupHash = null;
  }
};
_GpuTextureSystem.extension = {
  type: [
    ExtensionType.WebGPUSystem
  ],
  name: "texture"
};
_GpuTextureSystem.uploadExtensions = /* @__PURE__ */ Object.create(null);
var GpuTextureSystem = _GpuTextureSystem;
extensions.handleByMap(ExtensionType.TextureUploaderWebGPU, GpuTextureSystem.uploadExtensions);

// node_modules/pixi.js/lib/rendering/renderers/gpu/WebGPURenderer.mjs
var DefaultWebGPUSystems = [
  ...SharedSystems,
  GpuUboSystem,
  GpuEncoderSystem,
  GpuDeviceSystem,
  GpuLimitsSystem,
  GpuBufferSystem,
  GpuTextureSystem,
  GpuRenderTargetSystem,
  GpuShaderSystem,
  GpuStateSystem,
  PipelineSystem,
  GpuColorMaskSystem,
  GpuStencilSystem,
  BindGroupSystem
];
var DefaultWebGPUPipes = [...SharedRenderPipes, GpuUniformBatchPipe];
var DefaultWebGPUAdapters = [GpuBatchAdaptor, GpuMeshAdapter, GpuGraphicsAdaptor];
var systems = [];
var renderPipes = [];
var renderPipeAdaptors = [];
var loaders = [];
extensions.handleByNamedList(ExtensionType.WebGPUSystem, systems);
extensions.handleByNamedList(ExtensionType.WebGPUPipes, renderPipes);
extensions.handleByNamedList(ExtensionType.WebGPUPipesAdaptor, renderPipeAdaptors);
extensions.handleByNamedList(ExtensionType.WebGPULoader, loaders);
extensions.add(...DefaultWebGPUSystems, ...DefaultWebGPUPipes, ...DefaultWebGPUAdapters);
var WebGPURenderer = class extends AbstractRenderer {
  constructor() {
    const systemConfig = {
      name: "webgpu",
      type: RendererType.WEBGPU,
      systems,
      renderPipes,
      renderPipeAdaptors,
      loaders
    };
    super(systemConfig);
  }
};

export {
  GpuGraphicsAdaptor,
  GpuMeshAdapter,
  GpuBatchAdaptor,
  BindGroupSystem,
  GpuBufferData,
  GpuBufferSystem,
  GpuColorMaskSystem,
  GpuDeviceSystem,
  RenderBundle,
  GpuEncoderSystem,
  GpuLimitsSystem,
  GpuStencilSystem,
  WGSL_ALIGN_SIZE_DATA,
  createUboElementsWGSL,
  generateArraySyncWGSL,
  createUboSyncFunctionWGSL,
  GpuUboSystem,
  UboBatch,
  GpuUniformBatchPipe,
  bakeOverridesIntoSource,
  PipelineSystem,
  GpuMsaaRestore,
  GpuRenderTarget,
  GpuRenderTargetAdaptor,
  GpuRenderTargetSystem,
  GpuShaderSystem,
  GpuBlendModesToPixi,
  GpuStateSystem,
  gpuUploadBufferImageResource,
  blockDataMap,
  gpuUploadCompressedTextureResource,
  createGpuUploadCubeTextureResource,
  gpuUploadImageResource,
  gpuUploadVideoResource,
  assertMipmap3dTexture,
  Gpu3dMipmapGenerator,
  GpuMipmapGenerator,
  GPUTextureGpuData,
  GpuTextureSystem,
  WebGPURenderer
};
//# sourceMappingURL=chunk-JTBH3JLP.js.map
