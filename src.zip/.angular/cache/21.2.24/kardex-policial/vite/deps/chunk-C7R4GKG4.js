import {
  CanvasSource,
  Container,
  Filter,
  FilterEffect,
  RenderGroup,
  Sprite,
  State,
  TexturePool,
  Ticker,
  UPDATE_BLEND,
  UPDATE_COLOR,
  UPDATE_VISIBLE,
  getGlobalBounds,
  getLocalBounds,
  multiplyColors
} from "./chunk-RSU6N5IH.js";
import {
  DefaultBatcher,
  STENCIL_MODES
} from "./chunk-XZ3F7MYX.js";
import {
  BigPool,
  BindGroup,
  Bounds,
  CanvasPool,
  Color,
  DOMAdapter,
  ExtensionType,
  GlProgram,
  GlobalResourceRegistry,
  GpuProgram,
  Matrix,
  Point,
  Rectangle,
  RendererType,
  Texture,
  TextureMatrix,
  TextureSource,
  UniformGroup,
  deprecation,
  eventemitter3_default,
  extensions,
  uid,
  v8_0_0,
  v8_21_0,
  warn
} from "./chunk-YC5XMVVP.js";
import {
  __async,
  __objRest,
  __spreadProps,
  __spreadValues
} from "./chunk-I6DCS273.js";

// node_modules/pixi.js/lib/environment/autoDetectEnvironment.mjs
var environments = [];
extensions.handleByNamedList(ExtensionType.Environment, environments);
function loadEnvironmentExtensions(skip) {
  return __async(this, null, function* () {
    if (skip) return;
    for (let i = 0; i < environments.length; i++) {
      const env = environments[i];
      if (env.value.test()) {
        yield env.value.load();
        return;
      }
    }
  });
}
function autoDetectEnvironment(add) {
  return __async(this, null, function* () {
    return loadEnvironmentExtensions(!add);
  });
}

// node_modules/pixi.js/lib/utils/browser/unsafeEvalSupported.mjs
var unsafeEval;
function unsafeEvalSupported() {
  if (typeof unsafeEval === "boolean") {
    return unsafeEval;
  }
  try {
    const func = new Function("param1", "param2", "param3", "return param1[param2] === param3;");
    unsafeEval = func({ a: "b" }, "a", "b") === true;
  } catch (_e) {
    unsafeEval = false;
  }
  return unsafeEval;
}

// node_modules/pixi.js/lib/rendering/renderers/gl/const.mjs
var CLEAR = ((CLEAR2) => {
  CLEAR2[CLEAR2["NONE"] = 0] = "NONE";
  CLEAR2[CLEAR2["COLOR"] = 16384] = "COLOR";
  CLEAR2[CLEAR2["STENCIL"] = 1024] = "STENCIL";
  CLEAR2[CLEAR2["DEPTH"] = 256] = "DEPTH";
  CLEAR2[CLEAR2["COLOR_DEPTH"] = 16640] = "COLOR_DEPTH";
  CLEAR2[CLEAR2["COLOR_STENCIL"] = 17408] = "COLOR_STENCIL";
  CLEAR2[CLEAR2["DEPTH_STENCIL"] = 1280] = "DEPTH_STENCIL";
  CLEAR2[CLEAR2["ALL"] = 17664] = "ALL";
  return CLEAR2;
})(CLEAR || {});

// node_modules/pixi.js/lib/rendering/renderers/shared/system/SystemRunner.mjs
var SystemRunner = class {
  /**
   * @param name - The function name that will be executed on the listeners added to this Runner.
   */
  constructor(name) {
    this.items = [];
    this._name = name;
  }
  /* jsdoc/check-param-names */
  /**
   * Dispatch/Broadcast Runner to all listeners added to the queue.
   * @param {...any} params - (optional) parameters to pass to each listener
   */
  /* jsdoc/check-param-names */
  emit(a0, a1, a2, a3, a4, a5, a6, a7) {
    const { name, items } = this;
    for (let i = 0, len = items.length; i < len; i++) {
      items[i][name](a0, a1, a2, a3, a4, a5, a6, a7);
    }
    return this;
  }
  /**
   * Add a listener to the Runner
   *
   * Runners do not need to have scope or functions passed to them.
   * All that is required is to pass the listening object and ensure that it has contains a function that has the same name
   * as the name provided to the Runner when it was created.
   *
   * Eg A listener passed to this Runner will require a 'complete' function.
   *
   * ```ts
   * import { Runner } from 'pixi.js';
   *
   * const complete = new Runner('complete');
   * ```
   *
   * The scope used will be the object itself.
   * @param {any} item - The object that will be listening.
   */
  add(item) {
    if (item[this._name]) {
      this.remove(item);
      this.items.push(item);
    }
    return this;
  }
  /**
   * Remove a single listener from the dispatch queue.
   * @param {any} item - The listener that you would like to remove.
   */
  remove(item) {
    const index = this.items.indexOf(item);
    if (index !== -1) {
      this.items.splice(index, 1);
    }
    return this;
  }
  /**
   * Check to see if the listener is already in the Runner
   * @param {any} item - The listener that you would like to check.
   */
  contains(item) {
    return this.items.indexOf(item) !== -1;
  }
  /** Remove all listeners from the Runner */
  removeAll() {
    this.items.length = 0;
    return this;
  }
  /** Remove all references, don't use after this. */
  destroy() {
    this.removeAll();
    this.items = null;
    this._name = null;
  }
  /**
   * `true` if there are no this Runner contains no listeners
   * @readonly
   */
  get empty() {
    return this.items.length === 0;
  }
  /**
   * The name of the runner.
   * @readonly
   */
  get name() {
    return this._name;
  }
};

// node_modules/pixi.js/lib/rendering/renderers/shared/system/AbstractRenderer.mjs
var defaultRunners = [
  "init",
  "destroy",
  "contextChange",
  "resolutionChange",
  "resetState",
  "renderEnd",
  "renderStart",
  "render",
  "update",
  "postrender",
  "prerender"
];
var _AbstractRenderer = class _AbstractRenderer2 extends eventemitter3_default {
  /**
   * Set up a system with a collection of SystemClasses and runners.
   * Systems are attached dynamically to this class when added.
   * @param config - the config for the system manager
   */
  constructor(config) {
    super();
    this.tick = 0;
    this.uid = uid("renderer");
    this.runners = /* @__PURE__ */ Object.create(null);
    this.renderPipes = /* @__PURE__ */ Object.create(null);
    this._initOptions = {};
    this._systemsHash = /* @__PURE__ */ Object.create(null);
    this.type = config.type;
    this.name = config.name;
    this.config = config;
    const combinedRunners = [...defaultRunners, ...this.config.runners ?? []];
    this._addRunners(...combinedRunners);
    this._unsafeEvalCheck();
  }
  /**
   * Initialize the renderer.
   * @param options - The options to use to create the renderer.
   */
  init() {
    return __async(this, arguments, function* (options = {}) {
      const skip = options.skipExtensionImports === true ? true : options.manageImports === false;
      yield loadEnvironmentExtensions(skip);
      if (!skip && this.config.loaders) {
        yield Promise.all(this.config.loaders.map((loader) => loader.value.load()));
      }
      this._addSystems(this.config.systems);
      this._addPipes(this.config.renderPipes, this.config.renderPipeAdaptors);
      for (const systemName in this._systemsHash) {
        const system = this._systemsHash[systemName];
        const defaultSystemOptions = system.constructor.defaultOptions;
        options = __spreadValues(__spreadValues({}, defaultSystemOptions), options);
      }
      options = __spreadValues(__spreadValues({}, _AbstractRenderer2.defaultOptions), options);
      this._roundPixels = options.roundPixels ? 1 : 0;
      for (let i = 0; i < this.runners.init.items.length; i++) {
        yield this.runners.init.items[i].init(options);
      }
      this._initOptions = options;
    });
  }
  render(args, deprecated) {
    this.tick++;
    let options = args;
    if (options instanceof Container) {
      options = { container: options };
      if (deprecated) {
        deprecation(v8_0_0, "passing a second argument is deprecated, please use render options instead");
        options.target = deprecated.renderTexture;
      }
    }
    options.target || (options.target = this.view.renderTarget);
    if (options.target === this.view.renderTarget) {
      this._lastObjectRendered = options.container;
      options.clearColor ?? (options.clearColor = this.background.colorRgba);
      options.clear ?? (options.clear = this.background.clearBeforeRender);
    }
    if (options.clearColor) {
      const isRGBAArray = Array.isArray(options.clearColor) && options.clearColor.length === 4;
      options.clearColor = isRGBAArray ? options.clearColor : Color.shared.setValue(options.clearColor).toArray();
    }
    if (!options.transform) {
      options.container.updateLocalTransform();
      options.transform = options.container.localTransform;
    }
    if (!options.container.visible) {
      return;
    }
    options.container.enableRenderGroup();
    this.runners.prerender.emit(options);
    this.runners.renderStart.emit(options);
    this.runners.render.emit(options);
    this.runners.renderEnd.emit(options);
    this.runners.postrender.emit(options);
  }
  /**
   * Resizes the WebGL view to the specified width and height.
   * @param desiredScreenWidth - The desired width of the screen.
   * @param desiredScreenHeight - The desired height of the screen.
   * @param resolution - The resolution / device pixel ratio of the renderer.
   */
  resize(desiredScreenWidth, desiredScreenHeight, resolution) {
    const previousResolution = this.view.resolution;
    this.view.resize(desiredScreenWidth, desiredScreenHeight, resolution);
    this.emit("resize", this.view.screen.width, this.view.screen.height, this.view.resolution);
    if (resolution !== void 0 && resolution !== previousResolution) {
      this.runners.resolutionChange.emit(resolution);
    }
  }
  /**
   * Clears the render target.
   * @param options - The options to use when clearing the render target.
   * @param options.target - The render target to clear.
   * @param options.clearColor - The color to clear with.
   * @param options.clear - The clear mode to use.
   * @advanced
   */
  clear(options = {}) {
    const renderer = this;
    options.target || (options.target = renderer.renderTarget.renderTarget);
    options.clearColor || (options.clearColor = this.background.colorRgba);
    options.clear ?? (options.clear = CLEAR.ALL);
    const { clear, clearColor, target, mipLevel, layer } = options;
    Color.shared.setValue(clearColor ?? this.background.colorRgba);
    renderer.renderTarget.clear(target, clear, Color.shared.toArray(), mipLevel ?? 0, layer ?? 0);
  }
  /** The resolution / device pixel ratio of the renderer. */
  get resolution() {
    return this.view.resolution;
  }
  set resolution(value) {
    this.view.resolution = value;
    this.runners.resolutionChange.emit(value);
  }
  /**
   * Same as view.width, actual number of pixels in the canvas by horizontal.
   * @type {number}
   * @readonly
   * @default 800
   */
  get width() {
    return this.view.texture.frame.width;
  }
  /**
   * Same as view.height, actual number of pixels in the canvas by vertical.
   * @default 600
   */
  get height() {
    return this.view.texture.frame.height;
  }
  // NOTE: this was `view` in v7
  /**
   * The canvas element that everything is drawn to.
   * @type {environment.ICanvas}
   */
  get canvas() {
    return this.view.canvas;
  }
  /**
   * the last object rendered by the renderer. Useful for other plugins like interaction managers
   * @readonly
   */
  get lastObjectRendered() {
    return this._lastObjectRendered;
  }
  /**
   * Flag if we are rendering to the screen vs renderTexture
   * @readonly
   * @default true
   */
  get renderingToScreen() {
    const renderer = this;
    return renderer.renderTarget.renderingToScreen;
  }
  /**
   * Measurements of the screen. (0, 0, screenWidth, screenHeight).
   *
   * Its safe to use as filterArea or hitArea for the whole stage.
   */
  get screen() {
    return this.view.screen;
  }
  /**
   * Create a bunch of runners based of a collection of ids
   * @param runnerIds - the runner ids to add
   */
  _addRunners(...runnerIds) {
    runnerIds.forEach((runnerId) => {
      this.runners[runnerId] = new SystemRunner(runnerId);
    });
  }
  _addSystems(systems) {
    let i;
    for (i in systems) {
      const val = systems[i];
      this._addSystem(val.value, val.name);
    }
  }
  /**
   * Add a new system to the renderer.
   * @param ClassRef - Class reference
   * @param name - Property name for system, if not specified
   *        will use a static `name` property on the class itself. This
   *        name will be assigned as s property on the Renderer so make
   *        sure it doesn't collide with properties on Renderer.
   * @returns Return instance of renderer
   */
  _addSystem(ClassRef, name) {
    const system = new ClassRef(this);
    if (this[name]) {
      throw new Error(`Whoops! The name "${name}" is already in use`);
    }
    this[name] = system;
    this._systemsHash[name] = system;
    for (const i in this.runners) {
      this.runners[i].add(system);
    }
    return this;
  }
  _addPipes(pipes, pipeAdaptors) {
    const adaptors = pipeAdaptors.reduce((acc, adaptor) => {
      acc[adaptor.name] = adaptor.value;
      return acc;
    }, {});
    pipes.forEach((pipe) => {
      const PipeClass = pipe.value;
      const name = pipe.name;
      const Adaptor = adaptors[name];
      this.renderPipes[name] = new PipeClass(
        this,
        Adaptor ? new Adaptor() : null
      );
      this.runners.destroy.add(this.renderPipes[name]);
    });
  }
  destroy(options = false) {
    this.runners.destroy.items.reverse();
    this.runners.destroy.emit(options);
    if (options === true || typeof options === "object" && options.releaseGlobalResources) {
      GlobalResourceRegistry.release();
    }
    Object.values(this.runners).forEach((runner) => {
      runner.destroy();
    });
    this._systemsHash = null;
    this.renderPipes = null;
    this.removeAllListeners();
  }
  /**
   * Generate a texture from a container.
   * @param options - options or container target to use when generating the texture
   * @returns a texture
   */
  generateTexture(options) {
    return this.textureGenerator.generateTexture(options);
  }
  /**
   * Whether the renderer will round coordinates to whole pixels when rendering.
   * Can be overridden on a per scene item basis.
   */
  get roundPixels() {
    return !!this._roundPixels;
  }
  /**
   * Overridable function by `pixi.js/unsafe-eval` to silence
   * throwing an error if platform doesn't support unsafe-evals.
   * @private
   * @ignore
   */
  _unsafeEvalCheck() {
    if (!unsafeEvalSupported()) {
      throw new Error("Current environment does not allow unsafe-eval, please use pixi.js/unsafe-eval module to enable support.");
    }
  }
  /**
   * Resets the rendering state of the renderer.
   * This is useful when you want to use the WebGL context directly and need to ensure PixiJS's internal state
   * stays synchronized. When modifying the WebGL context state externally, calling this method before the next Pixi
   * render will reset all internal caches and ensure it executes correctly.
   *
   * This is particularly useful when combining PixiJS with other rendering engines like Three.js:
   * ```js
   * // Reset Three.js state
   * threeRenderer.resetState();
   *
   * // Render a Three.js scene
   * threeRenderer.render(threeScene, threeCamera);
   *
   * // Reset PixiJS state since Three.js modified the WebGL context
   * pixiRenderer.resetState();
   *
   * // Now render Pixi content
   * pixiRenderer.render(pixiScene);
   * ```
   * @advanced
   */
  resetState() {
    this.runners.resetState.emit();
  }
};
_AbstractRenderer.defaultOptions = {
  /**
   * Default resolution / device pixel ratio of the renderer.
   * @default 1
   */
  resolution: 1,
  /**
   * Should the `failIfMajorPerformanceCaveat` flag be enabled as a context option used in the `isWebGLSupported`
   * function. If set to true, a WebGL renderer can fail to be created if the browser thinks there could be
   * performance issues when using WebGL.
   *
   * In PixiJS v6 this has changed from true to false by default, to allow WebGL to work in as many
   * scenarios as possible. However, some users may have a poor experience, for example, if a user has a gpu or
   * driver version blacklisted by the
   * browser.
   *
   * If your application requires high performance rendering, you may wish to set this to false.
   * We recommend one of two options if you decide to set this flag to false:
   *
   * 1: Use the Canvas renderer as a fallback in case high performance WebGL is
   *    not supported.
   *
   * 2: Call `isWebGLSupported` (which if found in the utils package) in your code before attempting to create a
   *    PixiJS renderer, and show an error message to the user if the function returns false, explaining that their
   *    device & browser combination does not support high performance WebGL.
   *    This is a much better strategy than trying to create a PixiJS renderer and finding it then fails.
   * @default false
   */
  failIfMajorPerformanceCaveat: false,
  /**
   * Should round pixels be forced when rendering?
   * @default false
   */
  roundPixels: false
};
var AbstractRenderer = _AbstractRenderer;

// node_modules/pixi.js/lib/scene/container/CustomRenderPipe.mjs
var CustomRenderPipe = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  updateRenderable() {
  }
  destroyRenderable() {
  }
  validateRenderable() {
    return false;
  }
  addRenderable(container, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add(container);
  }
  execute(container) {
    if (!container.isRenderable) return;
    container.render(this._renderer);
  }
  destroy() {
    this._renderer = null;
  }
};
CustomRenderPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "customRender"
};

// node_modules/pixi.js/lib/scene/sprite/BatchableSprite.mjs
var BatchableSprite = class {
  constructor() {
    this.batcherName = "default";
    this.topology = "triangle-list";
    this.attributeSize = 4;
    this.indexSize = 6;
    this.packAsQuad = true;
    this.roundPixels = 0;
    this._attributeStart = 0;
    this._batcher = null;
    this._batch = null;
  }
  get blendMode() {
    return this.renderable.groupBlendMode;
  }
  get color() {
    return this.renderable.groupColorAlpha;
  }
  reset() {
    this.renderable = null;
    this.texture = null;
    this._batcher = null;
    this._batch = null;
    this.bounds = null;
  }
  destroy() {
    this.reset();
  }
};

// node_modules/pixi.js/lib/scene/container/utils/executeInstructions.mjs
function executeInstructions(renderGroup, renderer) {
  const instructionSet = renderGroup.instructionSet;
  const instructions = instructionSet.instructions;
  for (let i = 0; i < instructionSet.instructionSize; i++) {
    const instruction = instructions[i];
    renderer[instruction.renderPipeId].execute(instruction);
  }
}

// node_modules/pixi.js/lib/scene/container/RenderGroupPipe.mjs
var RenderGroupPipe = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  addRenderGroup(renderGroup, instructionSet) {
    if (renderGroup.isCachedAsTexture) {
      this._addRenderableCacheAsTexture(renderGroup, instructionSet);
    } else {
      this._addRenderableDirect(renderGroup, instructionSet);
    }
  }
  execute(renderGroup) {
    if (!renderGroup.isRenderable) return;
    if (renderGroup.isCachedAsTexture) {
      this._executeCacheAsTexture(renderGroup);
    } else {
      this._executeDirect(renderGroup);
    }
  }
  destroy() {
    this._renderer = null;
  }
  _addRenderableDirect(renderGroup, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    if (renderGroup._batchableRenderGroup) {
      BigPool.return(renderGroup._batchableRenderGroup);
      renderGroup._batchableRenderGroup = null;
    }
    instructionSet.add(renderGroup);
  }
  _addRenderableCacheAsTexture(renderGroup, instructionSet) {
    const batchableRenderGroup = renderGroup._batchableRenderGroup ?? (renderGroup._batchableRenderGroup = BigPool.get(BatchableSprite));
    batchableRenderGroup.renderable = renderGroup.root;
    batchableRenderGroup.transform = renderGroup.root.relativeGroupTransform;
    batchableRenderGroup.texture = renderGroup.texture;
    batchableRenderGroup.bounds = renderGroup._textureBounds;
    instructionSet.add(renderGroup);
    this._renderer.renderPipes.blendMode.pushBlendMode(renderGroup, renderGroup.root.groupBlendMode, instructionSet);
    this._renderer.renderPipes.batch.addToBatch(batchableRenderGroup, instructionSet);
    this._renderer.renderPipes.blendMode.popBlendMode(instructionSet);
  }
  _executeCacheAsTexture(renderGroup) {
    if (renderGroup.textureNeedsUpdate) {
      renderGroup.textureNeedsUpdate = false;
      const worldTransformMatrix = new Matrix().translate(
        -renderGroup._textureBounds.x,
        -renderGroup._textureBounds.y
      );
      this._renderer.renderTarget.push({
        target: renderGroup.texture,
        clear: true,
        frame: renderGroup.texture.frame
      });
      this._renderer.globalUniforms.push({
        worldTransformMatrix,
        worldColor: 4294967295,
        offset: { x: 0, y: 0 }
      });
      executeInstructions(renderGroup, this._renderer.renderPipes);
      this._renderer.renderTarget.finishRenderPass();
      this._renderer.renderTarget.pop();
      this._renderer.globalUniforms.pop();
    }
    renderGroup._batchableRenderGroup._batcher.updateElement(renderGroup._batchableRenderGroup);
    renderGroup._batchableRenderGroup._batcher.geometry.buffers[0].update();
  }
  _executeDirect(renderGroup) {
    this._renderer.globalUniforms.push({
      worldTransformMatrix: renderGroup.inverseParentTextureTransform,
      worldColor: renderGroup.worldColorAlpha
    });
    executeInstructions(renderGroup, this._renderer.renderPipes);
    this._renderer.globalUniforms.pop();
  }
};
RenderGroupPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "renderGroup"
};

// node_modules/pixi.js/lib/scene/container/utils/clearList.mjs
function clearList(list, index) {
  index || (index = 0);
  for (let j = index; j < list.length; j++) {
    if (list[j]) {
      list[j] = null;
    } else {
      break;
    }
  }
}

// node_modules/pixi.js/lib/scene/container/utils/updateRenderGroupTransforms.mjs
var tempContainer = new Container();
var UPDATE_BLEND_COLOR_VISIBLE = UPDATE_VISIBLE | UPDATE_COLOR | UPDATE_BLEND;
function updateRenderGroupTransforms(renderGroup, updateChildRenderGroups = false) {
  updateRenderGroupTransform(renderGroup);
  const childrenToUpdate = renderGroup.childrenToUpdate;
  const updateTick = renderGroup.updateTick++;
  for (const j in childrenToUpdate) {
    const renderGroupDepth = Number(j);
    const childrenAtDepth = childrenToUpdate[j];
    const list = childrenAtDepth.list;
    const index = childrenAtDepth.index;
    for (let i = 0; i < index; i++) {
      const child = list[i];
      if (child.parentRenderGroup === renderGroup && child.relativeRenderGroupDepth === renderGroupDepth) {
        updateTransformAndChildren(child, updateTick, 0);
      }
    }
    clearList(list, index);
    childrenAtDepth.index = 0;
  }
  if (updateChildRenderGroups) {
    for (let i = 0; i < renderGroup.renderGroupChildren.length; i++) {
      updateRenderGroupTransforms(renderGroup.renderGroupChildren[i], updateChildRenderGroups);
    }
  }
}
function updateRenderGroupTransform(renderGroup) {
  const root = renderGroup.root;
  let worldAlpha;
  if (renderGroup.renderGroupParent) {
    const renderGroupParent = renderGroup.renderGroupParent;
    renderGroup.worldTransform.appendFrom(
      root.relativeGroupTransform,
      renderGroupParent.worldTransform
    );
    renderGroup.worldColor = multiplyColors(
      root.groupColor,
      renderGroupParent.worldColor
    );
    worldAlpha = root.groupAlpha * renderGroupParent.worldAlpha;
  } else {
    renderGroup.worldTransform.copyFrom(root.localTransform);
    renderGroup.worldColor = root.localColor;
    worldAlpha = root.localAlpha;
  }
  worldAlpha = worldAlpha < 0 ? 0 : worldAlpha > 1 ? 1 : worldAlpha;
  renderGroup.worldAlpha = worldAlpha;
  renderGroup.worldColorAlpha = renderGroup.worldColor + ((worldAlpha * 255 | 0) << 24);
}
function updateTransformAndChildren(container, updateTick, updateFlags) {
  if (updateTick === container.updateTick) return;
  container.updateTick = updateTick;
  container.didChange = false;
  const localTransform = container.localTransform;
  container.updateLocalTransform();
  const parent = container.parent;
  if (parent && !parent.renderGroup) {
    updateFlags |= container._updateFlags;
    container.relativeGroupTransform.appendFrom(
      localTransform,
      parent.relativeGroupTransform
    );
    if (updateFlags & UPDATE_BLEND_COLOR_VISIBLE) {
      updateColorBlendVisibility(container, parent, updateFlags);
    }
  } else {
    updateFlags = container._updateFlags;
    container.relativeGroupTransform.copyFrom(localTransform);
    if (updateFlags & UPDATE_BLEND_COLOR_VISIBLE) {
      updateColorBlendVisibility(container, tempContainer, updateFlags);
    }
  }
  if (!container.renderGroup) {
    const children = container.children;
    const length = children.length;
    for (let i = 0; i < length; i++) {
      updateTransformAndChildren(children[i], updateTick, updateFlags);
    }
    const renderGroup = container.parentRenderGroup;
    const renderable = container;
    if (renderable.renderPipeId && !renderGroup.structureDidChange) {
      renderGroup.updateRenderable(renderable);
    }
  }
}
function updateColorBlendVisibility(container, parent, updateFlags) {
  if (updateFlags & UPDATE_COLOR) {
    container.groupColor = multiplyColors(
      container.localColor,
      parent.groupColor
    );
    let groupAlpha = container.localAlpha * parent.groupAlpha;
    groupAlpha = groupAlpha < 0 ? 0 : groupAlpha > 1 ? 1 : groupAlpha;
    container.groupAlpha = groupAlpha;
    container.groupColorAlpha = container.groupColor + ((groupAlpha * 255 | 0) << 24);
  }
  if (updateFlags & UPDATE_BLEND) {
    container.groupBlendMode = container.localBlendMode === "inherit" ? parent.groupBlendMode : container.localBlendMode;
  }
  if (updateFlags & UPDATE_VISIBLE) {
    container.globalDisplayStatus = container.localDisplayStatus & parent.globalDisplayStatus;
  }
  container._updateFlags = 0;
}

// node_modules/pixi.js/lib/scene/container/utils/validateRenderables.mjs
function validateRenderables(renderGroup, renderPipes) {
  const { list } = renderGroup.childrenRenderablesToUpdate;
  let rebuildRequired = false;
  for (let i = 0; i < renderGroup.childrenRenderablesToUpdate.index; i++) {
    const container = list[i];
    const renderable = container;
    const pipe = renderPipes[renderable.renderPipeId];
    rebuildRequired = pipe.validateRenderable(container);
    if (rebuildRequired) {
      break;
    }
  }
  renderGroup.structureDidChange = rebuildRequired;
  return rebuildRequired;
}

// node_modules/pixi.js/lib/scene/container/RenderGroupSystem.mjs
var tempMatrix = new Matrix();
var RenderGroupSystem = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  render({ container, transform }) {
    const parent = container.parent;
    const renderGroupParent = container.renderGroup.renderGroupParent;
    container.parent = null;
    container.renderGroup.renderGroupParent = null;
    const renderer = this._renderer;
    const originalLocalTransform = tempMatrix;
    if (transform) {
      originalLocalTransform.copyFrom(container.renderGroup.localTransform);
      container.renderGroup.localTransform.copyFrom(transform);
    }
    const renderPipes = renderer.renderPipes;
    this._updateCachedRenderGroups(container.renderGroup, null);
    this._updateRenderGroups(container.renderGroup);
    renderer.globalUniforms.start({
      worldTransformMatrix: transform ? container.renderGroup.localTransform : container.renderGroup.worldTransform,
      worldColor: container.renderGroup.worldColorAlpha
    });
    executeInstructions(container.renderGroup, renderPipes);
    if (renderPipes.uniformBatch) {
      renderPipes.uniformBatch.renderEnd();
    }
    if (transform) {
      container.renderGroup.localTransform.copyFrom(originalLocalTransform);
    }
    container.parent = parent;
    container.renderGroup.renderGroupParent = renderGroupParent;
  }
  destroy() {
    this._renderer = null;
  }
  _updateCachedRenderGroups(renderGroup, closestCacheAsTexture) {
    renderGroup._parentCacheAsTextureRenderGroup = closestCacheAsTexture;
    if (renderGroup.isCachedAsTexture) {
      if (!renderGroup.textureNeedsUpdate) return;
      closestCacheAsTexture = renderGroup;
    }
    for (let i = renderGroup.renderGroupChildren.length - 1; i >= 0; i--) {
      this._updateCachedRenderGroups(renderGroup.renderGroupChildren[i], closestCacheAsTexture);
    }
    renderGroup.invalidateMatrices();
    if (renderGroup.isCachedAsTexture) {
      if (renderGroup.textureNeedsUpdate) {
        const bounds = renderGroup.root.getLocalBounds();
        const renderer = this._renderer;
        const resolution = renderGroup.textureOptions.resolution || renderer.view.resolution;
        const antialias = renderGroup.textureOptions.antialias ?? renderer.view.antialias;
        const scaleMode = renderGroup.textureOptions.scaleMode ?? "linear";
        const lastTexture = renderGroup.texture;
        bounds.ceil();
        if (renderGroup.texture) {
          TexturePool.returnTexture(renderGroup.texture);
        }
        const texture = TexturePool.getOptimalTexture({
          width: bounds.width,
          height: bounds.height,
          resolution,
          antialias,
          scaleMode
        });
        renderGroup.texture = texture;
        renderGroup._textureBounds || (renderGroup._textureBounds = new Bounds());
        renderGroup._textureBounds.copyFrom(bounds);
        if (lastTexture !== renderGroup.texture) {
          if (renderGroup.renderGroupParent) {
            renderGroup.renderGroupParent.structureDidChange = true;
          }
        }
      }
    } else if (renderGroup.texture) {
      TexturePool.returnTexture(renderGroup.texture);
      renderGroup.texture = null;
    }
  }
  _updateRenderGroups(renderGroup) {
    const renderer = this._renderer;
    const renderPipes = renderer.renderPipes;
    renderGroup.runOnRender(renderer);
    renderGroup.instructionSet.renderPipes = renderPipes;
    if (!renderGroup.structureDidChange) {
      validateRenderables(renderGroup, renderPipes);
    } else {
      clearList(renderGroup.childrenRenderablesToUpdate.list, 0);
    }
    updateRenderGroupTransforms(renderGroup);
    if (renderGroup.structureDidChange) {
      renderGroup.structureDidChange = false;
      this._buildInstructions(renderGroup, renderer);
    } else {
      this._updateRenderables(renderGroup);
    }
    renderGroup.childrenRenderablesToUpdate.index = 0;
    renderer.renderPipes.batch.upload(renderGroup.instructionSet);
    if (renderGroup.isCachedAsTexture && !renderGroup.textureNeedsUpdate) return;
    for (let i = 0; i < renderGroup.renderGroupChildren.length; i++) {
      this._updateRenderGroups(renderGroup.renderGroupChildren[i]);
    }
  }
  _updateRenderables(renderGroup) {
    const { list, index } = renderGroup.childrenRenderablesToUpdate;
    for (let i = 0; i < index; i++) {
      const container = list[i];
      if (container.didViewUpdate) {
        renderGroup.updateRenderable(container);
      }
    }
    clearList(list, index);
  }
  _buildInstructions(renderGroup, rendererOrPipes) {
    const root = renderGroup.root;
    const instructionSet = renderGroup.instructionSet;
    instructionSet.reset();
    const renderer = rendererOrPipes.renderPipes ? rendererOrPipes : rendererOrPipes.batch.renderer;
    const renderPipes = renderer.renderPipes;
    renderPipes.batch.buildStart(instructionSet);
    renderPipes.blendMode.buildStart();
    renderPipes.colorMask.buildStart();
    if (root.sortableChildren) {
      root.sortChildren();
    }
    root.collectRenderablesWithEffects(instructionSet, renderer, null);
    renderPipes.batch.buildEnd(instructionSet);
    renderPipes.blendMode.buildEnd(instructionSet);
  }
};
RenderGroupSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "renderGroup"
};

// node_modules/pixi.js/lib/scene/sprite/SpritePipe.mjs
var SpritePipe = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  addRenderable(sprite, instructionSet) {
    const gpuSprite = this._getGpuSprite(sprite);
    if (sprite.didViewUpdate) this._updateBatchableSprite(sprite, gpuSprite);
    this._renderer.renderPipes.batch.addToBatch(gpuSprite, instructionSet);
  }
  updateRenderable(sprite) {
    const gpuSprite = this._getGpuSprite(sprite);
    if (sprite.didViewUpdate) this._updateBatchableSprite(sprite, gpuSprite);
    gpuSprite._batcher.updateElement(gpuSprite);
  }
  validateRenderable(sprite) {
    const gpuSprite = this._getGpuSprite(sprite);
    return !gpuSprite._batcher.checkAndUpdateTexture(
      gpuSprite,
      sprite._texture
    );
  }
  _updateBatchableSprite(sprite, batchableSprite) {
    batchableSprite.bounds = sprite.visualBounds;
    batchableSprite.texture = sprite._texture;
  }
  _getGpuSprite(sprite) {
    return sprite._gpuData[this._renderer.uid] || this._initGPUSprite(sprite);
  }
  _initGPUSprite(sprite) {
    const batchableSprite = new BatchableSprite();
    batchableSprite.renderable = sprite;
    batchableSprite.transform = sprite.groupTransform;
    batchableSprite.texture = sprite._texture;
    batchableSprite.bounds = sprite.visualBounds;
    batchableSprite.roundPixels = this._renderer._roundPixels | sprite._roundPixels;
    sprite._gpuData[this._renderer.uid] = batchableSprite;
    return batchableSprite;
  }
  destroy() {
    this._renderer = null;
  }
};
SpritePipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "sprite"
};

// node_modules/pixi.js/lib/utils/const.mjs
var DATA_URI = /^\s*data:(?:([\w-]+)\/([\w+.-]+))?(?:;charset=([\w-]+))?(?:;(base64))?,(.*)/i;
var VERSION = "8.22.0";

// node_modules/pixi.js/lib/utils/global/globalHooks.mjs
var ApplicationInitHook = class {
  static init() {
    globalThis.__PIXI_APP_INIT__?.(this, VERSION);
  }
  static destroy() {
  }
};
ApplicationInitHook.extension = ExtensionType.Application;
var RendererInitHook = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  init() {
    globalThis.__PIXI_RENDERER_INIT__?.(this._renderer, VERSION);
  }
  destroy() {
    this._renderer = null;
  }
};
RendererInitHook.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem
  ],
  name: "initHook",
  priority: -10
};

// node_modules/pixi.js/lib/rendering/batcher/shared/BatcherPipe.mjs
var _BatcherPipe = class _BatcherPipe2 {
  constructor(renderer, adaptor) {
    this.state = State.for2d();
    this._batchersByInstructionSet = /* @__PURE__ */ Object.create(null);
    this._activeBatches = /* @__PURE__ */ Object.create(null);
    this.renderer = renderer;
    this._adaptor = adaptor;
    this._adaptor.init?.(this);
  }
  static getBatcher(name, maxTextures) {
    return new this._availableBatchers[name]({ maxTextures });
  }
  buildStart(instructionSet) {
    let batchers = this._batchersByInstructionSet[instructionSet.uid];
    if (!batchers) {
      batchers = this._batchersByInstructionSet[instructionSet.uid] = /* @__PURE__ */ Object.create(null);
      batchers.default || (batchers.default = new DefaultBatcher({
        maxTextures: this.renderer.limits.maxBatchableTextures
      }));
    }
    this._activeBatches = batchers;
    this._activeBatch = this._activeBatches.default;
    for (const i in this._activeBatches) {
      this._activeBatches[i].begin();
    }
  }
  addToBatch(batchableObject, instructionSet) {
    if (this._activeBatch.name !== batchableObject.batcherName) {
      this._activeBatch.break(instructionSet);
      let batch = this._activeBatches[batchableObject.batcherName];
      if (!batch) {
        batch = this._activeBatches[batchableObject.batcherName] = _BatcherPipe2.getBatcher(batchableObject.batcherName, this.renderer.limits.maxBatchableTextures);
        batch.begin();
      }
      this._activeBatch = batch;
    }
    this._activeBatch.add(batchableObject);
  }
  break(instructionSet) {
    this._activeBatch.break(instructionSet);
  }
  buildEnd(instructionSet) {
    this._activeBatch.break(instructionSet);
    const batches = this._activeBatches;
    for (const i in batches) {
      const batch = batches[i];
      const geometry = batch.geometry;
      geometry.indexBuffer.setDataWithSize(batch.indexBuffer, batch.indexSize, true);
      geometry.buffers[0].setDataWithSize(batch.attributeBuffer.float32View, batch.attributeSize, false);
    }
  }
  upload(instructionSet) {
    const batchers = this._batchersByInstructionSet[instructionSet.uid];
    for (const i in batchers) {
      const batcher = batchers[i];
      const geometry = batcher.geometry;
      if (batcher.dirty) {
        batcher.dirty = false;
        geometry.buffers[0].update(batcher.attributeSize * 4);
      }
    }
  }
  execute(batch) {
    if (batch.action === "startBatch") {
      const batcher = batch.batcher;
      const geometry = batcher.geometry;
      const shader = batcher.shader;
      this._adaptor.start(this, geometry, shader);
    }
    this._adaptor.execute(this, batch);
  }
  /**
   * Releases all batchers cached for the given InstructionSet. Called from
   * `InstructionSet.destroy()` so that batchers (and their GPU geometry / attribute
   * buffers / referenced textures) do not leak when the owning RenderGroup is destroyed.
   * @param instructionSet - the instruction set being destroyed
   */
  destroyInstructionSet(instructionSet) {
    const batchers = this._batchersByInstructionSet[instructionSet.uid];
    if (!batchers) return;
    for (const i in batchers) {
      batchers[i].destroy();
    }
    delete this._batchersByInstructionSet[instructionSet.uid];
    if (this._activeBatches === batchers) {
      this._activeBatches = /* @__PURE__ */ Object.create(null);
      this._activeBatch = null;
    }
  }
  destroy() {
    this.state = null;
    this.renderer = null;
    this._adaptor = null;
    for (const i in this._activeBatches) {
      this._activeBatches[i].destroy();
    }
    this._activeBatches = null;
  }
};
_BatcherPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "batch"
};
_BatcherPipe._availableBatchers = /* @__PURE__ */ Object.create(null);
var BatcherPipe = _BatcherPipe;
extensions.handleByMap(ExtensionType.Batcher, BatcherPipe._availableBatchers);
extensions.add(DefaultBatcher);

// node_modules/pixi.js/lib/filters/mask/mask.frag.mjs
var fragment = "in vec2 vMaskCoord;\nin vec2 vTextureCoord;\n\nuniform sampler2D uTexture;\nuniform sampler2D uMaskTexture;\n\nuniform float uAlpha;\nuniform vec4 uMaskClamp;\nuniform float uInverse;\nuniform float uChannel;\n\nout vec4 finalColor;\n\nvoid main(void)\n{\n    float clip = step(3.5,\n        step(uMaskClamp.x, vMaskCoord.x) +\n        step(uMaskClamp.y, vMaskCoord.y) +\n        step(vMaskCoord.x, uMaskClamp.z) +\n        step(vMaskCoord.y, uMaskClamp.w));\n\n    // TODO look into why this is needed\n    float npmAlpha = uAlpha;\n    vec4 original = texture(uTexture, vTextureCoord);\n    vec4 masky = texture(uMaskTexture, vMaskCoord);\n\n    float a;\n    if (uChannel == 1.0) {\n        a = masky.a * npmAlpha * clip;\n    } else {\n        float alphaMul = 1.0 - npmAlpha * (1.0 - masky.a);\n        a = alphaMul * masky.r * npmAlpha * clip;\n    }\n\n    if (uInverse == 1.0) {\n        a = 1.0 - a;\n    }\n\n    finalColor = original * a;\n}\n";

// node_modules/pixi.js/lib/filters/mask/mask.vert.mjs
var vertex = "in vec2 aPosition;\n\nout vec2 vTextureCoord;\nout vec2 vMaskCoord;\n\n\nuniform vec4 uInputSize;\nuniform vec4 uOutputFrame;\nuniform vec4 uOutputTexture;\nuniform mat3 uFilterMatrix;\n\nvec4 filterVertexPosition(  vec2 aPosition )\n{\n    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;\n       \n    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord(  vec2 aPosition )\n{\n    return aPosition * (uOutputFrame.zw * uInputSize.zw);\n}\n\nvec2 getFilterCoord( vec2 aPosition )\n{\n    return  ( uFilterMatrix * vec3( filterTextureCoord(aPosition), 1.0)  ).xy;\n}   \n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition(aPosition);\n    vTextureCoord = filterTextureCoord(aPosition);\n    vMaskCoord = getFilterCoord(aPosition);\n}\n";

// node_modules/pixi.js/lib/filters/mask/mask.wgsl.mjs
var source = "struct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct MaskUniforms {\n  uFilterMatrix:mat3x3<f32>,\n  uMaskClamp:vec4<f32>,\n  uAlpha:f32,\n  uInverse:f32,\n  uChannel:f32,\n};\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n\n@group(1) @binding(0) var<uniform> filterUniforms : MaskUniforms;\n@group(1) @binding(1) var uMaskTexture: texture_2d<f32>;\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>,\n    @location(1) filterUv : vec2<f32>,\n};\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);\n}\n\nfn getFilterCoord(aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return ( filterUniforms.uFilterMatrix * vec3( filterTextureCoord(aPosition), 1.0)  ).xy;\n}\n\nfn getSize() -> vec2<f32>\n{\n  return gfu.uGlobalFrame.zw;\n}\n\n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>,\n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition),\n   getFilterCoord(aPosition)\n  );\n}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n  @location(1) filterUv: vec2<f32>,\n  @builtin(position) position: vec4<f32>\n) -> @location(0) vec4<f32> {\n\n    var maskClamp = filterUniforms.uMaskClamp;\n    var uAlpha = filterUniforms.uAlpha;\n\n    var clip = step(3.5,\n      step(maskClamp.x, filterUv.x) +\n      step(maskClamp.y, filterUv.y) +\n      step(filterUv.x, maskClamp.z) +\n      step(filterUv.y, maskClamp.w));\n\n    var mask = textureSample(uMaskTexture, uSampler, filterUv);\n    var source = textureSample(uTexture, uSampler, uv);\n\n    var a: f32;\n    if (filterUniforms.uChannel == 1.0) {\n        a = mask.a * uAlpha * clip;\n    } else {\n        var alphaMul = 1.0 - uAlpha * (1.0 - mask.a);\n        a = alphaMul * mask.r * uAlpha * clip;\n    }\n\n    if (filterUniforms.uInverse == 1.0) {\n        a = 1.0 - a;\n    }\n\n    return source * a;\n}\n";

// node_modules/pixi.js/lib/filters/mask/MaskFilter.mjs
var MaskFilter = class extends Filter {
  constructor(options) {
    const _a = options, { sprite } = _a, rest = __objRest(_a, ["sprite"]);
    const textureMatrix = new TextureMatrix(sprite.texture);
    const filterUniforms = new UniformGroup({
      uFilterMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      uMaskClamp: { value: textureMatrix.uClampFrame, type: "vec4<f32>" },
      uAlpha: { value: 1, type: "f32" },
      uInverse: { value: options.inverse ? 1 : 0, type: "f32" },
      uChannel: { value: options.channel === "alpha" ? 1 : 0, type: "f32" }
    });
    const gpuProgram = GpuProgram.from({
      vertex: {
        source,
        entryPoint: "mainVertex"
      },
      fragment: {
        source,
        entryPoint: "mainFragment"
      }
    });
    const glProgram = GlProgram.from({
      vertex,
      fragment,
      name: "mask-filter"
    });
    super(__spreadProps(__spreadValues({}, rest), {
      gpuProgram,
      glProgram,
      clipToViewport: false,
      resources: {
        filterUniforms,
        uMaskTexture: sprite.texture.source
      }
    }));
    this.sprite = sprite;
    this._textureMatrix = textureMatrix;
  }
  /**
   * Rebinds the filter to a new mask sprite, moving the texture-matrix `update`
   * listener and the bind group's `change` subscription over to the new sprite's
   * texture. `apply` refreshes the same bindings on every use — this method exists
   * to release the previous sprite's texture immediately, without waiting for
   * (or requiring) another `apply`.
   * @param sprite - the sprite to mask with from now on.
   */
  setSprite(sprite) {
    this.sprite = sprite;
    const texture = this._getSafeTexture();
    this._textureMatrix.texture = texture;
    this.resources.uMaskTexture = texture.source;
  }
  set inverse(value) {
    this.resources.filterUniforms.uniforms.uInverse = value ? 1 : 0;
  }
  get inverse() {
    return this.resources.filterUniforms.uniforms.uInverse === 1;
  }
  set channel(value) {
    this.resources.filterUniforms.uniforms.uChannel = value === "alpha" ? 1 : 0;
  }
  get channel() {
    return this.resources.filterUniforms.uniforms.uChannel === 1 ? "alpha" : "red";
  }
  apply(filterManager, input, output, clearMode) {
    const texture = this._getSafeTexture();
    this._textureMatrix.texture = texture;
    filterManager.calculateSpriteMatrix(
      this.resources.filterUniforms.uniforms.uFilterMatrix,
      this.sprite
    ).prepend(this._textureMatrix.mapCoord);
    this.resources.uMaskTexture = texture.source;
    filterManager.applyFilter(this, input, output, clearMode);
  }
  /**
   * The sprite's texture, or `Texture.EMPTY` when that texture has been destroyed —
   * a destroyed texture has no source left to sample, so the mask degrades to empty
   * rather than crashing the render.
   */
  _getSafeTexture() {
    const texture = this.sprite.texture;
    if (texture.destroyed || !texture.source || texture.source.destroyed) {
      warn("[MaskFilter] The mask texture was destroyed while the mask is still in use. Remove the mask before destroying its texture.");
      return Texture.EMPTY;
    }
    return texture;
  }
  destroy(destroyPrograms = false) {
    this._textureMatrix.destroy();
    super.destroy(destroyPrograms);
  }
};

// node_modules/pixi.js/lib/rendering/mask/alpha/AlphaMaskPipe.mjs
var tempBounds = new Bounds();
var AlphaMaskEffect = class extends FilterEffect {
  constructor() {
    super();
    this._placeholderSprite = new Sprite(Texture.EMPTY);
    this.filters = [new MaskFilter({
      sprite: this._placeholderSprite,
      inverse: false,
      resolution: "inherit",
      antialias: "inherit"
    })];
  }
  get sprite() {
    return this.filters[0].sprite;
  }
  set sprite(value) {
    this.filters[0].setSprite(value);
  }
  get inverse() {
    return this.filters[0].inverse;
  }
  set inverse(value) {
    this.filters[0].inverse = value;
  }
  get channel() {
    return this.filters[0].channel;
  }
  set channel(value) {
    this.filters[0].channel = value;
  }
  /**
   * Called by {@link BigPool} when the pipe returns the effect: parks the filter
   * on the empty placeholder so a pooled effect keeps no bindings to the last
   * mask it applied. Without this, the pooled filter pins the mask sprite and
   * its texture for as long as the effect sits in the pool, and destroying that
   * texture's source hits a bind group subscription the user cannot release.
   */
  reset() {
    this._placeholderSprite.texture = Texture.EMPTY;
    this.sprite = this._placeholderSprite;
  }
};
var AlphaMaskPipe = class {
  constructor(renderer) {
    this._activeMaskStage = [];
    this._usedEffects = [];
    this._renderer = renderer;
    renderer.runners.postrender.add(this);
  }
  push(mask, maskedContainer, instructionSet) {
    const renderer = this._renderer;
    renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add({
      renderPipeId: "alphaMask",
      action: "pushMaskBegin",
      mask,
      inverse: maskedContainer._maskOptions.inverse,
      canBundle: false,
      maskedContainer
    });
    mask.inverse = maskedContainer._maskOptions.inverse;
    mask.channel = maskedContainer._maskOptions.channel ?? "red";
    if (mask.renderMaskToTexture) {
      const maskContainer = mask.mask;
      maskContainer.includeInBuild = true;
      maskContainer.collectRenderables(
        instructionSet,
        renderer,
        null
      );
      maskContainer.includeInBuild = false;
    }
    renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add({
      renderPipeId: "alphaMask",
      action: "pushMaskEnd",
      mask,
      maskedContainer,
      inverse: maskedContainer._maskOptions.inverse,
      canBundle: false
    });
  }
  pop(mask, _maskedContainer, instructionSet) {
    const renderer = this._renderer;
    renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add({
      renderPipeId: "alphaMask",
      action: "popMaskEnd",
      mask,
      inverse: _maskedContainer._maskOptions.inverse,
      canBundle: false
    });
  }
  execute(instruction) {
    const renderer = this._renderer;
    const renderMask = instruction.mask.renderMaskToTexture;
    if (instruction.action === "pushMaskBegin") {
      const filterEffect = BigPool.get(AlphaMaskEffect);
      filterEffect.inverse = instruction.inverse;
      filterEffect.channel = instruction.mask.channel;
      if (renderMask) {
        instruction.mask.mask.measurable = true;
        const bounds = getGlobalBounds(instruction.mask.mask, true, tempBounds);
        instruction.mask.mask.measurable = false;
        bounds.ceil();
        const colorTextureSource = renderer.renderTarget.renderTarget.colorTexture.source;
        const filterTexture = TexturePool.getOptimalTexture({
          width: bounds.width,
          height: bounds.height,
          resolution: colorTextureSource._resolution,
          antialias: colorTextureSource.antialias
        });
        renderer.renderTarget.push({ target: filterTexture, clear: true });
        renderer.globalUniforms.push({
          offset: bounds,
          worldColor: 4294967295
        });
        const sprite = filterEffect.sprite;
        sprite.texture = filterTexture;
        sprite.worldTransform.tx = bounds.minX;
        sprite.worldTransform.ty = bounds.minY;
        this._activeMaskStage.push({
          filterEffect,
          maskedContainer: instruction.maskedContainer,
          filterTexture
        });
      } else {
        filterEffect.sprite = instruction.mask.mask;
        this._activeMaskStage.push({
          filterEffect,
          maskedContainer: instruction.maskedContainer
        });
      }
    } else if (instruction.action === "pushMaskEnd") {
      const maskData = this._activeMaskStage[this._activeMaskStage.length - 1];
      if (renderMask) {
        if (renderer.type === RendererType.WEBGL) {
          renderer.renderTarget.finishRenderPass();
        }
        renderer.renderTarget.pop();
        renderer.globalUniforms.pop();
      }
      renderer.filter.push({
        renderPipeId: "filter",
        action: "pushFilter",
        container: maskData.maskedContainer,
        filterEffect: maskData.filterEffect,
        canBundle: false
      });
    } else if (instruction.action === "popMaskEnd") {
      renderer.filter.pop();
      const maskData = this._activeMaskStage.pop();
      if (renderMask) {
        TexturePool.returnTexture(maskData.filterTexture);
      }
      this._usedEffects.push(maskData.filterEffect);
    }
  }
  postrender() {
    const effects = this._usedEffects;
    for (let i = 0; i < effects.length; i++) {
      BigPool.return(effects[i]);
    }
    effects.length = 0;
  }
  destroy() {
    this.postrender();
    this._renderer.runners.postrender.remove(this);
    this._renderer = null;
    this._activeMaskStage = null;
    this._usedEffects = null;
  }
};
AlphaMaskPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "alphaMask"
};

// node_modules/pixi.js/lib/rendering/mask/color/ColorMaskPipe.mjs
var ColorMaskPipe = class {
  constructor(renderer) {
    this._colorStack = [];
    this._colorStackIndex = 0;
    this._currentColor = 0;
    this._renderer = renderer;
  }
  buildStart() {
    this._colorStack[0] = 15;
    this._colorStackIndex = 1;
    this._currentColor = 15;
  }
  push(mask, _container, instructionSet) {
    const renderer = this._renderer;
    renderer.renderPipes.batch.break(instructionSet);
    const colorStack = this._colorStack;
    colorStack[this._colorStackIndex] = colorStack[this._colorStackIndex - 1] & mask.mask;
    const currentColor = this._colorStack[this._colorStackIndex];
    if (currentColor !== this._currentColor) {
      this._currentColor = currentColor;
      instructionSet.add({
        renderPipeId: "colorMask",
        colorMask: currentColor,
        canBundle: false
      });
    }
    this._colorStackIndex++;
  }
  pop(_mask, _container, instructionSet) {
    const renderer = this._renderer;
    renderer.renderPipes.batch.break(instructionSet);
    const colorStack = this._colorStack;
    this._colorStackIndex--;
    const currentColor = colorStack[this._colorStackIndex - 1];
    if (currentColor !== this._currentColor) {
      this._currentColor = currentColor;
      instructionSet.add({
        renderPipeId: "colorMask",
        colorMask: currentColor,
        canBundle: false
      });
    }
  }
  execute(instruction) {
    const renderer = this._renderer;
    renderer.colorMask.setMask(instruction.colorMask);
  }
  destroy() {
    this._renderer = null;
    this._colorStack = null;
  }
};
ColorMaskPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes
  ],
  name: "colorMask"
};

// node_modules/pixi.js/lib/rendering/mask/stencil/StencilMaskPipe.mjs
var StencilMaskPipe = class {
  constructor(renderer) {
    this._maskHash = /* @__PURE__ */ new WeakMap();
    this._renderer = renderer;
  }
  push(mask, _container, instructionSet) {
    const effect = mask;
    const renderer = this._renderer;
    renderer.renderPipes.batch.break(instructionSet);
    renderer.renderPipes.blendMode.setBlendMode(effect.mask, "none", instructionSet);
    instructionSet.add({
      renderPipeId: "stencilMask",
      action: "pushMaskBegin",
      mask,
      inverse: _container._maskOptions.inverse,
      canBundle: false
    });
    const maskContainer = effect.mask;
    maskContainer.includeInBuild = true;
    if (!this._maskHash.has(effect)) {
      this._maskHash.set(effect, {
        instructionsStart: 0,
        instructionsLength: 0
      });
    }
    const maskData = this._maskHash.get(effect);
    maskData.instructionsStart = instructionSet.instructionSize;
    maskContainer.collectRenderables(
      instructionSet,
      renderer,
      null
    );
    maskContainer.includeInBuild = false;
    renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add({
      renderPipeId: "stencilMask",
      action: "pushMaskEnd",
      mask,
      inverse: _container._maskOptions.inverse,
      canBundle: false
    });
    const instructionsLength = instructionSet.instructionSize - maskData.instructionsStart - 1;
    maskData.instructionsLength = instructionsLength;
  }
  pop(mask, _container, instructionSet) {
    const effect = mask;
    const renderer = this._renderer;
    renderer.renderPipes.batch.break(instructionSet);
    renderer.renderPipes.blendMode.setBlendMode(effect.mask, "none", instructionSet);
    instructionSet.add({
      renderPipeId: "stencilMask",
      action: "popMaskBegin",
      inverse: _container._maskOptions.inverse,
      canBundle: false
    });
    const maskData = this._maskHash.get(mask);
    for (let i = 0; i < maskData.instructionsLength; i++) {
      instructionSet.instructions[instructionSet.instructionSize++] = instructionSet.instructions[maskData.instructionsStart++];
    }
    instructionSet.add({
      renderPipeId: "stencilMask",
      action: "popMaskEnd",
      canBundle: false
    });
  }
  execute(instruction) {
    const renderer = this._renderer;
    const gpuRenderer = renderer;
    const gpuRenderTarget = gpuRenderer.renderTarget.getGpuRenderTarget(gpuRenderer.renderTarget.renderTarget);
    let maskStackIndex = gpuRenderTarget.maskStackIndex;
    if (instruction.action === "pushMaskBegin") {
      gpuRenderer.renderTarget.ensureDepthStencil();
      gpuRenderer.stencil.setStencilMode(STENCIL_MODES.RENDERING_MASK_ADD, maskStackIndex);
      maskStackIndex++;
      gpuRenderer.colorMask.setMask(0);
    } else if (instruction.action === "pushMaskEnd") {
      if (instruction.inverse) {
        gpuRenderer.stencil.setStencilMode(STENCIL_MODES.INVERSE_MASK_ACTIVE, maskStackIndex);
      } else {
        gpuRenderer.stencil.setStencilMode(STENCIL_MODES.MASK_ACTIVE, maskStackIndex);
      }
      gpuRenderer.colorMask.setMask(15);
    } else if (instruction.action === "popMaskBegin") {
      gpuRenderer.colorMask.setMask(0);
      if (maskStackIndex !== 0) {
        gpuRenderer.stencil.setStencilMode(STENCIL_MODES.RENDERING_MASK_REMOVE, maskStackIndex);
      } else {
        gpuRenderer.renderTarget.clear(null, CLEAR.STENCIL);
        gpuRenderer.stencil.setStencilMode(STENCIL_MODES.DISABLED, maskStackIndex);
      }
      maskStackIndex--;
    } else if (instruction.action === "popMaskEnd") {
      if (instruction.inverse) {
        gpuRenderer.stencil.setStencilMode(STENCIL_MODES.INVERSE_MASK_ACTIVE, maskStackIndex);
      } else {
        gpuRenderer.stencil.setStencilMode(STENCIL_MODES.MASK_ACTIVE, maskStackIndex);
      }
      gpuRenderer.colorMask.setMask(15);
    }
    gpuRenderTarget.maskStackIndex = maskStackIndex;
  }
  destroy() {
    this._renderer = null;
    this._maskHash = null;
  }
};
StencilMaskPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes
  ],
  name: "stencilMask"
};

// node_modules/pixi.js/lib/rendering/renderers/shared/background/BackgroundSystem.mjs
var _BackgroundSystem = class _BackgroundSystem2 {
  constructor() {
    this.clearBeforeRender = true;
    this._backgroundColor = new Color(0);
    this.color = this._backgroundColor;
    this.alpha = 1;
  }
  /**
   * initiates the background system
   * @param options - the options for the background colors
   */
  init(options) {
    options = __spreadValues(__spreadValues({}, _BackgroundSystem2.defaultOptions), options);
    this.clearBeforeRender = options.clearBeforeRender;
    this.color = options.background || options.backgroundColor || this._backgroundColor;
    this.alpha = options.backgroundAlpha;
    this._backgroundColor.setAlpha(options.backgroundAlpha);
  }
  /** The background color to fill if not transparent */
  get color() {
    return this._backgroundColor;
  }
  set color(value) {
    const incoming = Color.shared.setValue(value);
    if (incoming.alpha < 1 && this._backgroundColor.alpha === 1) {
      warn(
        "Cannot set a transparent background on an opaque canvas. To enable transparency, set backgroundAlpha < 1 when initializing your Application."
      );
    }
    this._backgroundColor.setValue(value);
  }
  /** The background color alpha. Setting this to 0 will make the canvas transparent. */
  get alpha() {
    return this._backgroundColor.alpha;
  }
  set alpha(value) {
    this._backgroundColor.setAlpha(value);
  }
  /** The background color as an [R, G, B, A] array. */
  get colorRgba() {
    return this._backgroundColor.toArray();
  }
  /**
   * destroys the background system
   * @internal
   */
  destroy() {
  }
};
_BackgroundSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "background",
  priority: 0
};
_BackgroundSystem.defaultOptions = {
  /**
   * {@link WebGLOptions.backgroundAlpha}
   * @default 1
   */
  backgroundAlpha: 1,
  /**
   * {@link WebGLOptions.backgroundColor}
   * @default 0x000000
   */
  backgroundColor: 0,
  /**
   * {@link WebGLOptions.clearBeforeRender}
   * @default true
   */
  clearBeforeRender: true
};
var BackgroundSystem = _BackgroundSystem;

// node_modules/pixi.js/lib/rendering/renderers/shared/blendModes/BlendModePipe.mjs
var BLEND_MODE_FILTERS = {};
extensions.handle(ExtensionType.BlendMode, (value) => {
  if (!value.name) {
    throw new Error("BlendMode extension must have a name property");
  }
  BLEND_MODE_FILTERS[value.name] = value.ref;
}, (value) => {
  delete BLEND_MODE_FILTERS[value.name];
});
var BlendModePipe = class {
  constructor(renderer) {
    this._blendModeStack = [];
    this._isAdvanced = false;
    this._filterHash = /* @__PURE__ */ Object.create(null);
    this._renderer = renderer;
    this._renderer.runners.prerender.add(this);
  }
  prerender() {
    this._activeBlendMode = "normal";
    this._isAdvanced = false;
  }
  /**
   * Push a blend mode onto the internal stack and apply it to the instruction set if needed.
   * @param renderable - The renderable or {@link RenderGroup} associated with the change.
   * @param blendMode - The blend mode to activate.
   * @param instructionSet - The instruction set being built.
   */
  pushBlendMode(renderable, blendMode, instructionSet) {
    this._blendModeStack.push(blendMode);
    this.setBlendMode(renderable, blendMode, instructionSet);
  }
  /**
   * Pop the last blend mode from the stack and apply the new top-of-stack mode.
   * @param instructionSet - The instruction set being built.
   */
  popBlendMode(instructionSet) {
    this._blendModeStack.pop();
    const blendMode = this._blendModeStack[this._activeBlendMode.length - 1] ?? "normal";
    this.setBlendMode(null, blendMode, instructionSet);
  }
  /**
   * Ensure a blend mode switch is added to the instruction set when the mode changes.
   * If an advanced blend mode is active, subsequent renderables will be collected so they can be
   * rendered within a single filter pass.
   * @param renderable - The renderable or {@link RenderGroup} to associate with the change, or null when unwinding.
   * @param blendMode - The target blend mode.
   * @param instructionSet - The instruction set being built.
   */
  setBlendMode(renderable, blendMode, instructionSet) {
    const isRenderGroup = renderable instanceof RenderGroup;
    if (this._activeBlendMode === blendMode) {
      if (this._isAdvanced && renderable && !isRenderGroup) {
        this._renderableList?.push(renderable);
      }
      return;
    }
    if (this._isAdvanced) this._endAdvancedBlendMode(instructionSet);
    this._activeBlendMode = blendMode;
    if (!renderable) return;
    this._isAdvanced = !!BLEND_MODE_FILTERS[blendMode];
    if (this._isAdvanced) this._beginAdvancedBlendMode(renderable, instructionSet);
  }
  _beginAdvancedBlendMode(renderable, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    const blendMode = this._activeBlendMode;
    if (!BLEND_MODE_FILTERS[blendMode]) {
      warn(`Unable to assign BlendMode: '${blendMode}'. You may want to include: import 'pixi.js/advanced-blend-modes'`);
      return;
    }
    const filterEffect = this._ensureFilterEffect(blendMode);
    const isRenderGroup = renderable instanceof RenderGroup;
    const instruction = {
      renderPipeId: "filter",
      action: "pushFilter",
      filterEffect,
      renderables: isRenderGroup ? null : [renderable],
      container: isRenderGroup ? renderable.root : null,
      canBundle: false
    };
    this._renderableList = instruction.renderables;
    instructionSet.add(instruction);
  }
  _ensureFilterEffect(blendMode) {
    let filterEffect = this._filterHash[blendMode];
    if (!filterEffect) {
      filterEffect = this._filterHash[blendMode] = new FilterEffect();
      filterEffect.filters = [new BLEND_MODE_FILTERS[blendMode]()];
    }
    return filterEffect;
  }
  _endAdvancedBlendMode(instructionSet) {
    this._isAdvanced = false;
    this._renderableList = null;
    this._renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add({
      renderPipeId: "filter",
      action: "popFilter",
      canBundle: false
    });
  }
  /**
   * called when the instruction build process is starting this will reset internally to the default blend mode
   * @internal
   */
  buildStart() {
    this._isAdvanced = false;
  }
  /**
   * called when the instruction build process is finished, ensuring that if there is an advanced blend mode
   * active, we add the final render instructions added to the instruction set
   * @param instructionSet - The instruction set we are adding to
   * @internal
   */
  buildEnd(instructionSet) {
    if (!this._isAdvanced) return;
    this._endAdvancedBlendMode(instructionSet);
  }
  /** @internal */
  destroy() {
    this._renderer = null;
    this._renderableList = null;
    for (const i in this._filterHash) {
      this._filterHash[i].destroy();
    }
    this._filterHash = null;
  }
};
BlendModePipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "blendMode"
};

// node_modules/pixi.js/lib/rendering/renderers/shared/extract/ExtractSystem.mjs
var imageTypes = {
  png: "image/png",
  jpg: "image/jpeg",
  webp: "image/webp"
};
var _ExtractSystem = class _ExtractSystem2 {
  /** @param renderer - The renderer this System works for. */
  constructor(renderer) {
    this._renderer = renderer;
  }
  _normalizeOptions(options, defaults = {}) {
    if (options instanceof Container || options instanceof Texture) {
      return __spreadValues({
        target: options
      }, defaults);
    }
    return __spreadValues(__spreadValues({}, defaults), options);
  }
  /**
   * Creates an IImage from a display object or texture.
   * @param options - Options for creating the image, or the target to extract
   * @returns Promise that resolves with the generated IImage
   * @example
   * ```ts
   * // Basic usage with a sprite
   * const sprite = new Sprite(texture);
   * const image = await renderer.extract.image(sprite);
   * document.body.appendChild(image);
   *
   * // Advanced usage with options
   * const image = await renderer.extract.image({
   *     target: container,
   *     format: 'webp',
   *     quality: 0.8,
   *     frame: new Rectangle(0, 0, 100, 100),
   *     resolution: 2,
   *     clearColor: '#ff0000',
   *     antialias: true
   * });
   *
   * // Extract directly from a texture
   * const texture = Texture.from('myTexture.png');
   * const image = await renderer.extract.image(texture);
   * ```
   * @see {@link ExtractImageOptions} For detailed options
   * @see {@link ExtractSystem.base64} For base64 string output
   * @see {@link ExtractSystem.canvas} For canvas output
   * @see {@link ImageLike} For the image interface
   * @category rendering
   */
  image(options) {
    return __async(this, null, function* () {
      const image = DOMAdapter.get().createImage();
      image.src = yield this.base64(options);
      return image;
    });
  }
  /**
   * Converts the target into a base64 encoded string.
   *
   * This method works by first creating
   * a canvas using `Extract.canvas` and then converting it to a base64 string.
   * @param options - The options for creating the base64 string, or the target to extract
   * @returns Promise that resolves with the base64 encoded string
   * @example
   * ```ts
   * // Basic usage with a sprite
   * const sprite = new Sprite(texture);
   * const base64 = await renderer.extract.base64(sprite);
   * console.log(base64); // data:image/png;base64,...
   *
   * // Advanced usage with options
   * const base64 = await renderer.extract.base64({
   *     target: container,
   *     format: 'webp',
   *     quality: 0.8,
   *     frame: new Rectangle(0, 0, 100, 100),
   *     resolution: 2
   * });
   * ```
   * @throws Will throw an error if the platform doesn't support any of:
   * - ICanvas.toDataURL
   * - ICanvas.toBlob
   * - ICanvas.convertToBlob
   * @see {@link ExtractImageOptions} For detailed options
   * @see {@link ExtractSystem.canvas} For canvas output
   * @see {@link ExtractSystem.image} For HTMLImage output
   * @category rendering
   */
  base64(options) {
    return __async(this, null, function* () {
      options = this._normalizeOptions(
        options,
        _ExtractSystem2.defaultImageOptions
      );
      const { format, quality } = options;
      const canvas = this.canvas(options);
      if (canvas.toBlob !== void 0) {
        return new Promise((resolve, reject) => {
          canvas.toBlob((blob) => {
            if (!blob) {
              reject(new Error("ICanvas.toBlob failed!"));
              return;
            }
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          }, imageTypes[format], quality);
        });
      }
      if (canvas.toDataURL !== void 0) {
        return canvas.toDataURL(imageTypes[format], quality);
      }
      if (canvas.convertToBlob !== void 0) {
        const blob = yield canvas.convertToBlob({ type: imageTypes[format], quality });
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });
      }
      throw new Error("Extract.base64() requires ICanvas.toDataURL, ICanvas.toBlob, or ICanvas.convertToBlob to be implemented");
    });
  }
  /**
   * Creates a Canvas element, renders the target to it and returns it.
   * This method is useful for creating static images or when you need direct canvas access.
   * @param options - The options for creating the canvas, or the target to extract
   * @returns A Canvas element with the texture rendered on
   * @example
   * ```ts
   * // Basic canvas extraction from a sprite
   * const sprite = new Sprite(texture);
   * const canvas = renderer.extract.canvas(sprite);
   * document.body.appendChild(canvas);
   *
   * // Extract with custom region
   * const canvas = renderer.extract.canvas({
   *     target: container,
   *     frame: new Rectangle(0, 0, 100, 100)
   * });
   *
   * // Extract with high resolution
   * const canvas = renderer.extract.canvas({
   *     target: sprite,
   *     resolution: 2,
   *     clearColor: '#ff0000'
   * });
   *
   * // Extract directly from a texture
   * const texture = Texture.from('myTexture.png');
   * const canvas = renderer.extract.canvas(texture);
   *
   * // Extract with anti-aliasing
   * const canvas = renderer.extract.canvas({
   *     target: graphics,
   *     antialias: true
   * });
   * ```
   * @see {@link ExtractOptions} For detailed options
   * @see {@link ExtractSystem.image} For HTMLImage output
   * @see {@link ExtractSystem.pixels} For raw pixel data
   * @category rendering
   */
  canvas(options) {
    options = this._normalizeOptions(options);
    const target = options.target;
    const renderer = this._renderer;
    if (target instanceof Texture) {
      return renderer.texture.generateCanvas(target);
    }
    const texture = renderer.textureGenerator.generateTexture(options);
    const canvas = renderer.texture.generateCanvas(texture);
    texture.destroy(true);
    return canvas;
  }
  /**
   * Returns a one-dimensional array containing the pixel data of the entire texture in RGBA order,
   * with integer values between 0 and 255 (inclusive).
   * > [!NOE] The returned array is a flat Uint8Array where every 4 values represent RGBA
   * @param options - The options for extracting the image, or the target to extract
   * @returns One-dimensional Uint8Array containing the pixel data in RGBA format
   * @example
   * ```ts
   * // Basic pixel extraction
   * const sprite = new Sprite(texture);
   * const pixels = renderer.extract.pixels(sprite);
   * console.log(pixels[0], pixels[1], pixels[2], pixels[3]); // R,G,B,A values
   *
   * // Extract with custom region
   * const pixels = renderer.extract.pixels({
   *     target: sprite,
   *     frame: new Rectangle(0, 0, 100, 100)
   * });
   *
   * // Extract with high resolution
   * const pixels = renderer.extract.pixels({
   *     target: sprite,
   *     resolution: 2
   * });
   * ```
   * @see {@link ExtractOptions} For detailed options
   * @see {@link ExtractSystem.canvas} For canvas output
   * @see {@link ExtractSystem.image} For image output
   * @category rendering
   */
  pixels(options) {
    options = this._normalizeOptions(options);
    const target = options.target;
    const renderer = this._renderer;
    const texture = target instanceof Texture ? target : renderer.textureGenerator.generateTexture(options);
    const pixelInfo = renderer.texture.getPixels(texture);
    if (target instanceof Container) {
      texture.destroy(true);
    }
    return pixelInfo;
  }
  /**
   * Creates a texture from a display object or existing texture.
   *
   * This is useful for creating
   * reusable textures from rendered content or making copies of existing textures.
   * > [!NOTE] The returned texture should be destroyed when no longer needed
   * @param options - The options for creating the texture, or the target to extract
   * @returns A new texture containing the extracted content
   * @example
   * ```ts
   * // Basic texture extraction from a sprite
   * const sprite = new Sprite(texture);
   * const extractedTexture = renderer.extract.texture(sprite);
   *
   * // Extract with custom region
   * const regionTexture = renderer.extract.texture({
   *     target: container,
   *     frame: new Rectangle(0, 0, 100, 100)
   * });
   *
   * // Extract with high resolution
   * const hiResTexture = renderer.extract.texture({
   *     target: sprite,
   *     resolution: 2,
   *     clearColor: '#ff0000'
   * });
   *
   * // Create a new sprite from extracted texture
   * const newSprite = new Sprite(
   *     renderer.extract.texture({
   *         target: graphics,
   *         antialias: true
   *     })
   * );
   *
   * // Clean up when done
   * extractedTexture.destroy(true);
   * ```
   * @see {@link ExtractOptions} For detailed options
   * @see {@link Texture} For texture management
   * @see {@link GenerateTextureSystem} For texture generation
   * @category rendering
   */
  texture(options) {
    options = this._normalizeOptions(options);
    if (options.target instanceof Texture) return options.target;
    return this._renderer.textureGenerator.generateTexture(options);
  }
  /**
   * Extracts and downloads content from the renderer as an image file.
   * This is a convenient way to save screenshots or export rendered content.
   * > [!NOTE] The download will use PNG format regardless of the filename extension
   * @param options - The options for downloading and extracting the image, or the target to extract
   * @example
   * ```ts
   * // Basic download with default filename
   * const sprite = new Sprite(texture);
   * renderer.extract.download(sprite); // Downloads as 'image.png'
   *
   * // Download with custom filename
   * renderer.extract.download({
   *     target: sprite,
   *     filename: 'screenshot.png'
   * });
   *
   * // Download with custom region
   * renderer.extract.download({
   *     target: container,
   *     filename: 'region.png',
   *     frame: new Rectangle(0, 0, 100, 100)
   * });
   *
   * // Download with high resolution and background
   * renderer.extract.download({
   *     target: stage,
   *     filename: 'hd-screenshot.png',
   *     resolution: 2,
   *     clearColor: '#ff0000'
   * });
   *
   * // Download with anti-aliasing
   * renderer.extract.download({
   *     target: graphics,
   *     filename: 'smooth.png',
   *     antialias: true
   * });
   * ```
   * @see {@link ExtractDownloadOptions} For detailed options
   * @see {@link ExtractSystem.image} For creating images without download
   * @see {@link ExtractSystem.canvas} For canvas output
   * @category rendering
   */
  download(options) {
    options = this._normalizeOptions(options);
    const canvas = this.canvas(options);
    const link = document.createElement("a");
    link.download = options.filename ?? "image.png";
    link.href = canvas.toDataURL("image/png");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  /**
   * Logs the target to the console as an image. This is a useful way to debug what's happening in the renderer.
   * The image will be displayed in the browser's console using CSS background images.
   * @param options - The options for logging the image, or the target to log
   * @param options.width - The width of the logged image preview in the console (in pixels)
   * @example
   * ```ts
   * // Basic usage
   * const sprite = new Sprite(texture);
   * renderer.extract.log(sprite);
   * ```
   * @see {@link ExtractSystem.canvas} For getting raw canvas output
   * @see {@link ExtractSystem.pixels} For raw pixel data
   * @category rendering
   * @advanced
   */
  log(options) {
    const width = options.width ?? 200;
    options = this._normalizeOptions(options);
    const canvas = this.canvas(options);
    const base64 = canvas.toDataURL();
    console.log(`[Pixi Texture] ${canvas.width}px ${canvas.height}px`);
    const style = [
      "font-size: 1px;",
      `padding: ${width}px ${300}px;`,
      `background: url(${base64}) no-repeat;`,
      "background-size: contain;"
    ].join(" ");
    console.log("%c ", style);
  }
  destroy() {
    this._renderer = null;
  }
};
_ExtractSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "extract"
};
_ExtractSystem.defaultImageOptions = {
  format: "png",
  quality: 1
};
var ExtractSystem = _ExtractSystem;

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/RenderTexture.mjs
var RenderTexture = class _RenderTexture extends Texture {
  /**
   * Creates a RenderTexture. Pass `dynamic: true` in options to allow resizing after creation.
   * @param options - Options for the RenderTexture, including width, height, textureOptions, and dynamic.
   * @returns A new RenderTexture instance.
   * @example
   * const textureOptions = { defaultAnchor: { x: 0.5, y: 0.5 } };
   * const rt = RenderTexture.create({ width: 100, height: 100, dynamic: true, textureOptions });
   * rt.resize(500, 500);
   */
  static create(options) {
    const _a = options, { dynamic, textureOptions } = _a, rest = __objRest(_a, ["dynamic", "textureOptions"]);
    return new _RenderTexture(__spreadProps(__spreadValues({}, textureOptions), {
      source: new TextureSource(rest),
      dynamic: dynamic ?? false
    }));
  }
  /**
   * Resizes the render texture.
   * @param width - The new width of the render texture.
   * @param height - The new height of the render texture.
   * @param resolution - The new resolution of the render texture.
   * @returns This texture.
   */
  resize(width, height, resolution) {
    this.source.resize(width, height, resolution);
    return this;
  }
};

// node_modules/pixi.js/lib/rendering/renderers/shared/extract/GenerateTextureSystem.mjs
var tempRect = new Rectangle();
var tempBounds2 = new Bounds();
var noColor = [0, 0, 0, 0];
var GenerateTextureSystem = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  /**
   * Creates a texture from a display object that can be used for creating sprites and other textures.
   * This is particularly useful for optimizing performance when a complex container needs to be reused.
   * @param options - Generate texture options or a container to convert to texture
   * @returns A new RenderTexture containing the rendered display object
   * @example
   * ```ts
   * // Basic usage with a container
   * const container = new Container();
   * container.addChild(
   *     new Graphics()
   *         .circle(0, 0, 50)
   *         .fill('red')
   * );
   *
   * const texture = renderer.textureGenerator.generateTexture(container);
   *
   * // Advanced usage with options
   * const texture = renderer.textureGenerator.generateTexture({
   *     target: container,
   *     frame: new Rectangle(0, 0, 100, 100), // Specific region
   *     resolution: 2,                        // High DPI
   *     clearColor: '#ff0000',               // Red background
   *     antialias: true                      // Smooth edges
   * });
   *
   * // Create a sprite from the generated texture
   * const sprite = new Sprite(texture);
   *
   * // Clean up when done
   * texture.destroy(true);
   * ```
   * @see {@link GenerateTextureOptions} For detailed texture generation options
   * @see {@link RenderTexture} For the type of texture created
   * @category rendering
   */
  generateTexture(options) {
    if (options instanceof Container) {
      options = {
        target: options,
        frame: void 0,
        textureSourceOptions: {},
        resolution: void 0
      };
    }
    const resolution = options.resolution || this._renderer.resolution;
    const antialias = options.antialias || this._renderer.view.antialias;
    const container = options.target;
    let clearColor = options.clearColor;
    if (clearColor) {
      const isRGBAArray = Array.isArray(clearColor) && clearColor.length === 4;
      clearColor = isRGBAArray ? clearColor : Color.shared.setValue(clearColor).toArray();
    } else {
      clearColor = noColor;
    }
    const region = options.frame?.copyTo(tempRect) || getLocalBounds(container, tempBounds2).rectangle;
    const textureOptions = options.defaultAnchor && {
      defaultAnchor: options.defaultAnchor
    };
    region.width = Math.max(region.width, 1 / resolution) | 0;
    region.height = Math.max(region.height, 1 / resolution) | 0;
    const target = RenderTexture.create(__spreadProps(__spreadValues({}, options.textureSourceOptions), {
      width: region.width,
      height: region.height,
      resolution,
      antialias,
      textureOptions
    }));
    const transform = Matrix.shared.translate(-region.x, -region.y);
    this._renderer.render({
      container,
      transform,
      target,
      clearColor
    });
    target.source.updateMipmaps();
    return target;
  }
  destroy() {
    this._renderer = null;
  }
};
GenerateTextureSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "textureGenerator"
};

// node_modules/pixi.js/lib/utils/data/clean.mjs
function cleanHash(hash) {
  let clean = false;
  for (const i in hash) {
    if (hash[i] == void 0) {
      clean = true;
      break;
    }
  }
  if (!clean) return hash;
  const cleanHash2 = /* @__PURE__ */ Object.create(null);
  for (const i in hash) {
    const value = hash[i];
    if (value) {
      cleanHash2[i] = value;
    }
  }
  return cleanHash2;
}
function cleanArray(arr) {
  let offset = 0;
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] == void 0) {
      offset++;
    } else {
      arr[i - offset] = arr[i];
    }
  }
  arr.length -= offset;
  return arr;
}

// node_modules/pixi.js/lib/rendering/renderers/shared/GCSystem.mjs
var _GCSystem = class _GCSystem2 {
  /**
   * Creates a new GCSystem instance.
   * @param renderer - The renderer this garbage collection system works for
   */
  constructor(renderer) {
    this._managedResources = [];
    this._managedResourceHashes = [];
    this._managedCollections = [];
    this._ready = false;
    this._running = false;
    this._renderer = renderer;
  }
  /**
   * Initializes the garbage collection system with the provided options.
   * @param options - Configuration options
   */
  init(options) {
    options = __spreadValues(__spreadValues({}, _GCSystem2.defaultOptions), options);
    this.maxUnusedTime = options.gcMaxUnusedTime;
    this._frequency = options.gcFrequency;
    this.enabled = options.gcActive;
    this.now = performance.now();
  }
  /**
   * Gets whether the garbage collection system is currently enabled.
   * @returns True if GC is enabled, false otherwise
   */
  get enabled() {
    return !!this._handler;
  }
  /**
   * Enables or disables the garbage collection system.
   * When enabled, schedules periodic cleanup of resources.
   * When disabled, cancels all scheduled cleanups.
   */
  set enabled(value) {
    if (this.enabled === value) return;
    if (value) {
      this._handler = this._renderer.scheduler.repeat(
        () => {
          this._ready = true;
        },
        this._frequency,
        false
      );
      this._collectionsHandler = this._renderer.scheduler.repeat(
        () => {
          for (const hash of this._managedCollections) {
            const { context, collection, type } = hash;
            if (type === "hash") {
              context[collection] = cleanHash(context[collection]);
            } else {
              context[collection] = cleanArray(context[collection]);
            }
          }
        },
        this._frequency
      );
    } else {
      this._renderer.scheduler.cancel(this._handler);
      this._renderer.scheduler.cancel(this._collectionsHandler);
      this._handler = 0;
      this._collectionsHandler = 0;
    }
  }
  /**
   * Called before rendering. Updates the current timestamp.
   * @param options - The render options
   * @param options.container - The container to render
   */
  prerender({ container }) {
    this.now = performance.now();
    container.renderGroup.gcTick = this._renderer.tick++;
    this._updateInstructionGCTick(container.renderGroup, container.renderGroup.gcTick);
  }
  /** Performs garbage collection after rendering. */
  postrender() {
    if (!this._ready || !this.enabled) return;
    this.run();
    this._ready = false;
  }
  /**
   * Updates the GC tick counter for a render group and its children.
   * @param renderGroup - The render group to update
   * @param gcTick - The new tick value
   */
  _updateInstructionGCTick(renderGroup, gcTick) {
    renderGroup.instructionSet.gcTick = gcTick;
    renderGroup.gcTick = gcTick;
    for (const child of renderGroup.renderGroupChildren) {
      this._updateInstructionGCTick(child, gcTick);
    }
  }
  /**
   * Registers a collection for garbage collection tracking.
   * @param context - The object containing the collection
   * @param collection - The property name on context that holds the collection
   * @param type - The type of collection to track ('hash' or 'array')
   */
  addCollection(context, collection, type) {
    this._managedCollections.push({
      context,
      collection,
      type
    });
  }
  /**
   * Registers a resource for garbage collection tracking.
   * @param resource - The resource to track
   * @param type - The type of resource to track
   */
  addResource(resource, type) {
    if (resource._gcLastUsed !== -1) {
      resource._gcLastUsed = this.now;
      resource._onTouch?.(this.now);
      return;
    }
    const index = this._managedResources.length;
    resource._gcData = {
      index,
      type
    };
    resource._gcLastUsed = this.now;
    resource._onTouch?.(this.now);
    resource.once("unload", this.removeResource, this);
    this._managedResources.push(resource);
  }
  /**
   * Removes a resource from garbage collection tracking.
   * Call this when manually destroying a resource.
   * @param resource - The resource to stop tracking
   */
  removeResource(resource) {
    const gcData = resource._gcData;
    if (!gcData) return;
    const index = gcData.index;
    const last = this._managedResources.length - 1;
    if (this._running) {
      this._managedResources[index] = null;
    } else {
      if (index !== last) {
        const lastResource = this._managedResources[last];
        this._managedResources[index] = lastResource;
        lastResource._gcData.index = index;
      }
      this._managedResources.length--;
    }
    resource._gcData = null;
    resource._gcLastUsed = -1;
  }
  /**
   * Registers a hash-based resource collection for garbage collection tracking.
   * Resources in the hash will be automatically tracked and cleaned up when unused.
   * @param context - The object containing the hash property
   * @param hash - The property name on context that holds the resource hash
   * @param type - The type of resources in the hash ('resource' or 'renderable')
   * @param priority - Processing priority (lower values are processed first)
   */
  addResourceHash(context, hash, type, priority = 0) {
    this._managedResourceHashes.push({
      context,
      hash,
      type,
      priority
    });
    this._managedResourceHashes.sort((a, b) => a.priority - b.priority);
  }
  /**
   * Performs garbage collection by cleaning up unused resources.
   * Removes resources that haven't been used for longer than maxUnusedTime.
   */
  run() {
    if (this._running) return;
    const now = performance.now();
    const managedResourceHashes = this._managedResourceHashes;
    const managedResources = this._managedResources;
    this._running = true;
    try {
      for (const hashEntry of managedResourceHashes) {
        this.runOnHash(hashEntry, now);
      }
      const length = managedResources.length;
      for (let i = 0; i < length; i++) {
        const resource = managedResources[i];
        if (resource) this.runOnResource(resource, now);
      }
    } finally {
      let writeIndex = 0;
      for (let i = 0; i < managedResources.length; i++) {
        const resource = managedResources[i];
        if (!resource) continue;
        if (writeIndex !== i) {
          managedResources[writeIndex] = resource;
          resource._gcData.index = writeIndex;
        }
        writeIndex++;
      }
      managedResources.length = writeIndex;
      this._running = false;
    }
  }
  updateRenderableGCTick(renderable, now) {
    const renderGroup = renderable.renderGroup ?? renderable.parentRenderGroup;
    const currentTick = renderGroup?.instructionSet?.gcTick ?? -1;
    if ((renderGroup?.gcTick ?? 0) === currentTick) {
      renderable._gcLastUsed = now;
      renderable._onTouch?.(now);
    }
  }
  runOnResource(resource, now) {
    if (resource._gcData.type === "renderable") {
      this.updateRenderableGCTick(resource, now);
    }
    const isRecentlyUsed = now - resource._gcLastUsed < this.maxUnusedTime;
    if (isRecentlyUsed || !resource.autoGarbageCollect) return;
    resource.off("unload", this.removeResource, this);
    resource.unload();
    this.removeResource(resource);
  }
  /**
   * Creates a clone of the hash, copying all non-null entries up to (but not including) the stop key.
   * @param hashValue - The original hash to clone from
   * @param stopKey - The key to stop at (exclusive)
   * @returns A new hash object with copied entries
   */
  _createHashClone(hashValue, stopKey) {
    const hashClone = /* @__PURE__ */ Object.create(null);
    for (const k in hashValue) {
      if (k === stopKey) break;
      if (hashValue[k] !== null) hashClone[k] = hashValue[k];
    }
    return hashClone;
  }
  runOnHash(hashEntry, now) {
    const { context, hash, type } = hashEntry;
    const hashValue = context[hash];
    let hashClone = null;
    let nullCount = 0;
    for (const key in hashValue) {
      const resource = hashValue[key];
      if (resource === null) {
        nullCount++;
        if (nullCount === 1e4 && !hashClone) {
          hashClone = this._createHashClone(hashValue, key);
        }
        continue;
      }
      if (resource._gcLastUsed === -1) {
        resource._gcLastUsed = now;
        resource._onTouch?.(now);
        if (hashClone) hashClone[key] = resource;
        continue;
      }
      if (type === "renderable") {
        this.updateRenderableGCTick(resource, now);
      }
      const isRecentlyUsed = now - resource._gcLastUsed < this.maxUnusedTime;
      if (!isRecentlyUsed && resource.autoGarbageCollect) {
        if (type === "renderable") {
          const res = resource;
          const renderGroup = res.renderGroup ?? res.parentRenderGroup;
          if (renderGroup) renderGroup.structureDidChange = true;
        }
        resource.unload();
        resource._gcData = null;
        resource._gcLastUsed = -1;
        if (!hashClone) {
          if (nullCount + 1 !== 1e4) {
            hashValue[key] = null;
            nullCount++;
          } else {
            hashClone = this._createHashClone(hashValue, key);
          }
        }
      } else if (hashClone) {
        hashClone[key] = resource;
      }
    }
    if (hashClone) {
      context[hash] = hashClone;
    }
  }
  /** Cleans up the garbage collection system. Disables GC and removes all tracked resources. */
  destroy() {
    this.enabled = false;
    this._managedResources.forEach((resource) => {
      resource?.off("unload", this.removeResource, this);
    });
    this._managedResources.length = 0;
    this._managedResourceHashes.length = 0;
    this._managedCollections.length = 0;
    this._renderer = null;
  }
};
_GCSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "gc",
  priority: 0
};
_GCSystem.defaultOptions = {
  /** Enable/disable the garbage collector */
  gcActive: true,
  /** Time in ms before an unused resource is collected (default 1 minute) */
  gcMaxUnusedTime: 6e4,
  /** How often to run garbage collection in ms (default 30 seconds) */
  gcFrequency: 3e4
};
var GCSystem = _GCSystem;

// node_modules/pixi.js/lib/scene/graphics/gpu/colorToUniform.mjs
function colorToUniform(rgb, alpha, out, offset) {
  out[offset++] = (rgb >> 16 & 255) / 255;
  out[offset++] = (rgb >> 8 & 255) / 255;
  out[offset++] = (rgb & 255) / 255;
  out[offset++] = alpha;
}
function color32BitToUniform(abgr, out, offset) {
  const alpha = (abgr >> 24 & 255) / 255;
  out[offset++] = (abgr & 255) / 255 * alpha;
  out[offset++] = (abgr >> 8 & 255) / 255 * alpha;
  out[offset++] = (abgr >> 16 & 255) / 255 * alpha;
  out[offset++] = alpha;
}

// node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/GlobalUniformSystem.mjs
var GlobalUniformSystem = class {
  constructor(renderer) {
    this._stackIndex = 0;
    this._globalUniformDataStack = [];
    this._uniformsPool = [];
    this._activeUniforms = [];
    this._bindGroupPool = [];
    this._activeBindGroups = [];
    this._renderer = renderer;
  }
  reset() {
    this._stackIndex = 0;
    for (let i = 0; i < this._activeUniforms.length; i++) {
      this._uniformsPool.push(this._activeUniforms[i]);
    }
    for (let i = 0; i < this._activeBindGroups.length; i++) {
      this._bindGroupPool.push(this._activeBindGroups[i]);
    }
    this._activeUniforms.length = 0;
    this._activeBindGroups.length = 0;
  }
  start(options) {
    this.reset();
    this.push(options);
  }
  bind({
    size,
    projectionMatrix,
    worldTransformMatrix,
    worldColor,
    offset
  }) {
    const renderTarget = this._renderer.renderTarget.renderTarget;
    const currentGlobalUniformData = this._stackIndex ? this._globalUniformDataStack[this._stackIndex - 1] : {
      projectionData: renderTarget,
      worldTransformMatrix: new Matrix(),
      worldColor: 4294967295,
      offset: new Point()
    };
    const globalUniformData = {
      projectionMatrix: projectionMatrix || this._renderer.renderTarget.projectionMatrix,
      resolution: size || renderTarget.size,
      worldTransformMatrix: worldTransformMatrix || currentGlobalUniformData.worldTransformMatrix,
      worldColor: worldColor || currentGlobalUniformData.worldColor,
      offset: offset || currentGlobalUniformData.offset,
      bindGroup: null
    };
    const uniformGroup = this._uniformsPool.pop() || this._createUniforms();
    this._activeUniforms.push(uniformGroup);
    const uniforms = uniformGroup.uniforms;
    uniforms.uProjectionMatrix = globalUniformData.projectionMatrix;
    uniforms.uResolution = globalUniformData.resolution;
    uniforms.uWorldTransformMatrix.copyFrom(globalUniformData.worldTransformMatrix);
    uniforms.uWorldTransformMatrix.tx -= globalUniformData.offset.x;
    uniforms.uWorldTransformMatrix.ty -= globalUniformData.offset.y;
    color32BitToUniform(
      globalUniformData.worldColor,
      uniforms.uWorldColorAlpha,
      0
    );
    uniformGroup.update();
    let bindGroup;
    if (this._renderer.renderPipes.uniformBatch) {
      bindGroup = this._renderer.renderPipes.uniformBatch.getUniformBindGroup(uniformGroup, false);
    } else {
      bindGroup = this._bindGroupPool.pop() || new BindGroup();
      this._activeBindGroups.push(bindGroup);
      bindGroup.setResource(uniformGroup, 0);
    }
    globalUniformData.bindGroup = bindGroup;
    this._currentGlobalUniformData = globalUniformData;
  }
  push(options) {
    this.bind(options);
    this._globalUniformDataStack[this._stackIndex++] = this._currentGlobalUniformData;
  }
  pop() {
    this._currentGlobalUniformData = this._globalUniformDataStack[--this._stackIndex - 1];
    if (this._renderer.type === RendererType.WEBGL) {
      this._currentGlobalUniformData.bindGroup.resources[0].update();
    }
  }
  get bindGroup() {
    return this._currentGlobalUniformData.bindGroup;
  }
  get globalUniformData() {
    return this._currentGlobalUniformData;
  }
  get uniformGroup() {
    return this._currentGlobalUniformData.bindGroup.resources[0];
  }
  _createUniforms() {
    const globalUniforms = new UniformGroup({
      uProjectionMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      uWorldTransformMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      // TODO - someone smart - set this to be a unorm8x4 rather than a vec4<f32>
      uWorldColorAlpha: { value: new Float32Array(4), type: "vec4<f32>" },
      uResolution: { value: [0, 0], type: "vec2<f32>" }
    }, {
      isStatic: true
    });
    return globalUniforms;
  }
  destroy() {
    this._renderer = null;
    this._globalUniformDataStack.length = 0;
    this._uniformsPool.length = 0;
    this._activeUniforms.length = 0;
    this._bindGroupPool.length = 0;
    this._activeBindGroups.length = 0;
    this._currentGlobalUniformData = null;
  }
};
GlobalUniformSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "globalUniforms"
};

// node_modules/pixi.js/lib/rendering/renderers/shared/SchedulerSystem.mjs
var uid2 = 1;
var SchedulerSystem = class {
  constructor() {
    this._tasks = [];
    this._offset = 0;
  }
  /** Initializes the scheduler system and starts the ticker. */
  init() {
    Ticker.system.add(this._update, this);
  }
  /**
   * Schedules a repeating task.
   * @param func - The function to execute.
   * @param duration - The interval duration in milliseconds.
   * @param useOffset - this will spread out tasks so that they do not all run at the same time
   * @returns The unique identifier for the scheduled task.
   */
  repeat(func, duration, useOffset = true) {
    const id = uid2++;
    let offset = 0;
    if (useOffset) {
      this._offset += 1e3;
      offset = this._offset;
    }
    this._tasks.push({
      func,
      duration,
      start: performance.now(),
      offset,
      last: performance.now(),
      repeat: true,
      id
    });
    return id;
  }
  /**
   * Cancels a scheduled task.
   * @param id - The unique identifier of the task to cancel.
   */
  cancel(id) {
    for (let i = 0; i < this._tasks.length; i++) {
      if (this._tasks[i].id === id) {
        this._tasks.splice(i, 1);
        return;
      }
    }
  }
  /**
   * Updates and executes the scheduled tasks.
   * @private
   */
  _update() {
    const now = performance.now();
    for (let i = 0; i < this._tasks.length; i++) {
      const task = this._tasks[i];
      if (now - task.offset - task.last >= task.duration) {
        const elapsed = now - task.start;
        task.func(elapsed);
        task.last = now;
      }
    }
  }
  /**
   * Destroys the scheduler system and removes all tasks.
   * @internal
   */
  destroy() {
    Ticker.system.remove(this._update, this);
    this._tasks.length = 0;
  }
};
SchedulerSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "scheduler",
  priority: 0
};

// node_modules/pixi.js/lib/utils/sayHello.mjs
var saidHello = false;
function sayHello(type) {
  if (saidHello) {
    return;
  }
  if (DOMAdapter.get().getNavigator().userAgent.toLowerCase().indexOf("chrome") > -1) {
    const args = [
      `%c  %c  %c  %c  %c PixiJS %c v${VERSION} (${type}) http://www.pixijs.com/

`,
      "background: #E72264; padding:5px 0;",
      "background: #6CA2EA; padding:5px 0;",
      "background: #B5D33D; padding:5px 0;",
      "background: #FED23F; padding:5px 0;",
      "color: #FFFFFF; background: #E72264; padding:5px 0;",
      "color: #E72264; background: #FFFFFF; padding:5px 0;"
    ];
    globalThis.console.log(...args);
  } else if (globalThis.console) {
    globalThis.console.log(`PixiJS ${VERSION} - ${type} - http://www.pixijs.com/`);
  }
  saidHello = true;
}

// node_modules/pixi.js/lib/rendering/renderers/shared/startup/HelloSystem.mjs
var HelloSystem = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  /**
   * It all starts here! This initiates every system, passing in the options for any system by name.
   * @param options - the config for the renderer and all its systems
   */
  init(options) {
    if (options.hello) {
      let name = this._renderer.name;
      if (this._renderer.type === RendererType.WEBGL) {
        name += ` ${this._renderer.context.webGLVersion}`;
      }
      sayHello(name);
    }
  }
};
HelloSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "hello",
  priority: -2
};
HelloSystem.defaultOptions = {
  /** {@link WebGLOptions.hello} */
  hello: false
};

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/RenderableGCSystem.mjs
var _RenderableGCSystem = class _RenderableGCSystem2 {
  /**
   * Creates a new RenderableGCSystem instance.
   * @param renderer - The renderer this garbage collection system works for
   */
  constructor(renderer) {
    this._renderer = renderer;
  }
  /**
   * Initializes the garbage collection system with the provided options.
   * @param options - Configuration options for the renderer
   */
  init(options) {
    options = __spreadValues(__spreadValues({}, _RenderableGCSystem2.defaultOptions), options);
    this.maxUnusedTime = options.renderableGCMaxUnusedTime;
  }
  /**
   * Gets whether the garbage collection system is currently enabled.
   * @returns True if GC is enabled, false otherwise
   */
  get enabled() {
    deprecation("8.15.0", "RenderableGCSystem.enabled is deprecated, please use the GCSystem.enabled instead.");
    return this._renderer.gc.enabled;
  }
  /**
   * Enables or disables the garbage collection system.
   * When enabled, schedules periodic cleanup of resources.
   * When disabled, cancels all scheduled cleanups.
   */
  set enabled(value) {
    deprecation("8.15.0", "RenderableGCSystem.enabled is deprecated, please use the GCSystem.enabled instead.");
    this._renderer.gc.enabled = value;
  }
  /**
   * Adds a hash table to be managed by the garbage collector.
   * @param context - The object containing the hash table
   * @param hash - The property name of the hash table
   */
  addManagedHash(context, hash) {
    deprecation("8.15.0", "RenderableGCSystem.addManagedHash is deprecated, please use the GCSystem.addCollection instead.");
    this._renderer.gc.addCollection(context, hash, "hash");
  }
  /**
   * Adds an array to be managed by the garbage collector.
   * @param context - The object containing the array
   * @param hash - The property name of the array
   */
  addManagedArray(context, hash) {
    deprecation("8.15.0", "RenderableGCSystem.addManagedArray is deprecated, please use the GCSystem.addCollection instead.");
    this._renderer.gc.addCollection(context, hash, "array");
  }
  /**
   * Starts tracking a renderable for garbage collection.
   * @param _renderable - The renderable to track
   * @deprecated since 8.15.0
   */
  addRenderable(_renderable) {
    deprecation("8.15.0", "RenderableGCSystem.addRenderable is deprecated, please use the GCSystem instead.");
    this._renderer.gc.addResource(_renderable, "renderable");
  }
  /**
   * Performs garbage collection by cleaning up unused renderables.
   * Removes renderables that haven't been used for longer than maxUnusedTime.
   */
  run() {
    deprecation("8.15.0", "RenderableGCSystem.run is deprecated, please use the GCSystem instead.");
    this._renderer.gc.run();
  }
  /** Cleans up the garbage collection system. Disables GC and removes all tracked resources. */
  destroy() {
    this._renderer = null;
  }
};
_RenderableGCSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "renderableGC",
  priority: 0
};
_RenderableGCSystem.defaultOptions = {
  /** Enable/disable the garbage collector */
  renderableGCActive: true,
  /** Time in ms before an unused resource is collected (default 1 minute) */
  renderableGCMaxUnusedTime: 6e4,
  /** How often to run garbage collection in ms (default 30 seconds) */
  renderableGCFrequency: 3e4
};
var RenderableGCSystem = _RenderableGCSystem;

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureGCSystem.mjs
var _TextureGCSystem = class _TextureGCSystem2 {
  /**
   * Frame count since started.
   * @readonly
   * @deprecated since 8.15.0
   */
  get count() {
    return this._renderer.tick;
  }
  /**
   * Frame count since last garbage collection.
   * @readonly
   * @deprecated since 8.15.0
   */
  get checkCount() {
    return this._checkCount;
  }
  set checkCount(value) {
    deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
    this._checkCount = value;
  }
  /**
   * Maximum idle frames before a texture is destroyed by garbage collection.
   * @see TextureGCSystem.defaultMaxIdle
   * @deprecated since 8.15.0
   */
  get maxIdle() {
    return this._renderer.gc.maxUnusedTime / 1e3 * 60;
  }
  set maxIdle(value) {
    deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
    this._renderer.gc.maxUnusedTime = value / 60 * 1e3;
  }
  /**
   * Frames between two garbage collections.
   * @see TextureGCSystem.defaultCheckCountMax
   * @deprecated since 8.15.0
   */
  // eslint-disable-next-line dot-notation
  get checkCountMax() {
    return Math.floor(this._renderer.gc["_frequency"] / 1e3);
  }
  set checkCountMax(_value) {
    deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
  }
  /**
   * Current garbage collection mode.
   * @see TextureGCSystem.defaultMode
   * @deprecated since 8.15.0
   */
  get active() {
    return this._renderer.gc.enabled;
  }
  set active(value) {
    deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
    this._renderer.gc.enabled = value;
  }
  /** @param renderer - The renderer this System works for. */
  constructor(renderer) {
    this._renderer = renderer;
    this._checkCount = 0;
  }
  init(options) {
    if (options.textureGCActive !== _TextureGCSystem2.defaultOptions.textureGCActive) {
      this.active = options.textureGCActive;
    }
    if (options.textureGCMaxIdle !== _TextureGCSystem2.defaultOptions.textureGCMaxIdle) {
      this.maxIdle = options.textureGCMaxIdle;
    }
    if (options.textureGCCheckCountMax !== _TextureGCSystem2.defaultOptions.textureGCCheckCountMax) {
      this.checkCountMax = options.textureGCCheckCountMax;
    }
  }
  /**
   * Checks to see when the last time a texture was used.
   * If the texture has not been used for a specified amount of time, it will be removed from the GPU.
   * @deprecated since 8.15.0
   */
  run() {
    deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
    this._renderer.gc.run();
  }
  destroy() {
    this._renderer = null;
  }
};
_TextureGCSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem
  ],
  name: "textureGC"
};
_TextureGCSystem.defaultOptions = {
  /**
   * If set to true, this will enable the garbage collector on the GPU.
   * @default true
   */
  textureGCActive: true,
  /**
   * @deprecated since 8.3.0
   * @see {@link TextureGCSystemOptions.textureGCMaxIdle}
   */
  textureGCAMaxIdle: null,
  /**
   * The maximum idle frames before a texture is destroyed by garbage collection.
   * @default 60 * 60
   */
  textureGCMaxIdle: 60 * 60,
  /**
   * Frames between two garbage collections.
   * @default 600
   */
  textureGCCheckCountMax: 600
};
var TextureGCSystem = _TextureGCSystem;

// node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/RenderTarget.mjs
var _RenderTarget = class _RenderTarget2 extends eventemitter3_default {
  /**
   * @param options - Options for creating a render target, or a WebGPU-flavored descriptor.
   */
  constructor(options = {}) {
    super();
    this.uid = uid("renderTarget");
    this.colorAttachments = [];
    this.dirtyId = 0;
    this.isRoot = false;
    this._size = new Float32Array(2);
    this._managedColorTextures = false;
    this._depth = false;
    this._stencil = false;
    this._colorTextures = null;
    const descriptor = "colorAttachments" in options ? options : this._normalizeOptions(options);
    this.isRoot = descriptor.isRoot ?? false;
    this.label = descriptor.label;
    this.colorAttachments = descriptor.colorAttachments;
    this.depthStencilAttachment = descriptor.depthStencilAttachment;
    if (this.depthStencilAttachment) {
      const format = this.depthStencilAttachment.texture.format;
      this._depth || (this._depth = format.includes("depth"));
      this._stencil || (this._stencil = format.includes("stencil"));
    }
    if (this.colorAttachments.length === 0 && !this.depthStencilAttachment) {
      throw new Error("[RenderTarget] no color textures or depth textures were provided. Provide a depthStencilTexture or set depth/stencil to true when using colorTextures: 0.");
    }
    if (this.colorAttachments.length > 0) {
      const colorSource = this.colorTexture;
      this.resize(colorSource.width, colorSource.height, colorSource._resolution);
    }
    if (this.sizeSource) {
      this.sizeSource.on("resize", this.onSourceResize, this);
    }
  }
  _normalizeOptions(options) {
    const opts = __spreadValues(__spreadValues({}, _RenderTarget2.defaultOptions), options);
    const colorAttachments = [];
    let depthStencilAttachment;
    if (typeof opts.colorTextures === "number") {
      if (opts.colorTextures > 0) {
        this._managedColorTextures = true;
        for (let i = 0; i < opts.colorTextures; i++) {
          colorAttachments.push({
            texture: new TextureSource({
              width: opts.width,
              height: opts.height,
              resolution: opts.resolution,
              antialias: opts.antialias
            }),
            loadOp: "clear",
            storeOp: "store"
          });
        }
      }
    } else {
      opts.colorTextures.forEach((texture) => {
        colorAttachments.push({
          texture: texture.source,
          loadOp: "clear",
          storeOp: "store"
        });
      });
    }
    const wantsDepthStencilTexture = opts.depthStencilTexture === true;
    this._depth = !!(opts.depth || wantsDepthStencilTexture);
    this._stencil = !!(opts.stencil || wantsDepthStencilTexture);
    if (opts.depthStencilTexture instanceof Texture || opts.depthStencilTexture instanceof TextureSource) {
      if (opts.isRoot) {
        throw new Error("[RenderTarget] cannot attach a depth-stencil texture to the screen — the canvas owns its own depth/stencil buffers. Render to a texture target instead.");
      }
      depthStencilAttachment = {
        texture: opts.depthStencilTexture.source
      };
    } else if (wantsDepthStencilTexture && !opts.isRoot || (opts.stencil || opts.depth) && colorAttachments.length === 0) {
      depthStencilAttachment = this._createDepthStencilTexture(opts.width, opts.height, opts.resolution);
    }
    return {
      colorAttachments,
      depthStencilAttachment,
      isRoot: opts.isRoot,
      label: opts.label
    };
  }
  get size() {
    const _size = this._size;
    _size[0] = this.pixelWidth;
    _size[1] = this.pixelHeight;
    return _size;
  }
  get width() {
    return this.sizeSource.width;
  }
  get height() {
    return this.sizeSource.height;
  }
  get pixelWidth() {
    return this.sizeSource.pixelWidth;
  }
  get pixelHeight() {
    return this.sizeSource.pixelHeight;
  }
  get resolution() {
    return this.sizeSource._resolution;
  }
  /**
   * An array of textures that can be written to by the GPU - mostly this has one texture in Pixi, but you could
   * write to multiple if required! (eg deferred lighting).
   * This is a backwards-compatible getter that extracts the textures from `colorAttachments`.
   */
  get colorTextures() {
    this._colorTextures || (this._colorTextures = this.colorAttachments.map((a) => a.texture));
    return this._colorTextures;
  }
  /** The stencil and depth buffer will write to this texture in WebGPU. */
  get depthStencilTexture() {
    return this.depthStencilAttachment?.texture ?? null;
  }
  /** Whether this target provides a depth buffer — requested via options or implied by its attachment's format. */
  get depth() {
    return this._depth;
  }
  /** Whether this target provides a stencil buffer — requested via options or implied by its attachment's format. */
  get stencil() {
    return this._stencil;
  }
  get colorTexture() {
    return this.colorAttachments[0]?.texture;
  }
  /**
   * The texture that drives size, resolution, and resize events.
   * For standard targets this is `colorAttachments[0].texture`;
   * for depth-only targets it is `depthStencilAttachment.texture`.
   */
  get sizeSource() {
    return this.colorAttachments[0]?.texture ?? this.depthStencilAttachment?.texture;
  }
  onSourceResize(source2) {
    this.resize(source2.width, source2.height, source2._resolution, true);
  }
  /**
   * This will ensure a depthStencil texture is created for this render target.
   * Most likely called by the mask system to make sure we have stencil buffer added.
   * @internal
   */
  ensureDepthStencilTexture() {
    this._createDepthStencilTexture(this.sizeSource.width, this.sizeSource.height, this.sizeSource._resolution);
    this._depth = true;
    this._stencil = true;
  }
  resize(width, height, resolution = this.resolution, skipColorTexture = false) {
    this.dirtyId++;
    this.colorAttachments.forEach((colorAttachment, i) => {
      if (skipColorTexture && i === 0) return;
      colorAttachment.texture.resize(width, height, resolution);
    });
    if (this.depthStencilAttachment) {
      if (skipColorTexture && this.colorAttachments.length === 0) return;
      this.depthStencilAttachment.texture.resize(width, height, resolution);
    }
  }
  destroy() {
    if (!this.colorAttachments && !this.depthStencilAttachment) return;
    this.emit("destroy", this);
    this.sizeSource.off("resize", this.onSourceResize, this);
    if (this._managedColorTextures) {
      this.colorAttachments.forEach((attachment) => {
        attachment.texture.destroy();
      });
    }
    if (this.depthStencilAttachment) {
      this.depthStencilAttachment.texture.destroy();
      delete this.depthStencilAttachment;
    }
    this.colorAttachments = null;
    this._colorTextures = null;
    this.removeAllListeners();
  }
  /**
   * The single recipe for internally-created depth-stencil textures.
   * @param width
   * @param height
   * @param resolution
   */
  _createDepthStencilTexture(width, height, resolution) {
    this.depthStencilAttachment ?? (this.depthStencilAttachment = {
      texture: new TextureSource({
        width,
        height,
        resolution,
        format: "depth24plus-stencil8",
        autoGenerateMipmaps: false,
        antialias: false,
        mipLevelCount: 1
        // sampleCount: handled by the render target system..
      })
    });
    return this.depthStencilAttachment;
  }
};
_RenderTarget.defaultOptions = {
  /** the width of the RenderTarget */
  width: 0,
  /** the height of the RenderTarget */
  height: 0,
  /** the resolution of the RenderTarget */
  resolution: 1,
  /** an array of textures, or a number indicating how many color textures there should be */
  colorTextures: 1,
  /** should this render target have a stencil buffer? */
  stencil: false,
  /** should this render target have a depth buffer? */
  depth: false,
  /** should this render target be antialiased? */
  antialias: false,
  // save on perf by default!
  /** is this a root element, true if this is gl context owners render target */
  isRoot: false
};
var RenderTarget = _RenderTarget;

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/getCanvasTexture.mjs
var canvasCache = /* @__PURE__ */ new Map();
GlobalResourceRegistry.register(canvasCache);
function getCanvasTexture(canvas, options) {
  if (!canvasCache.has(canvas)) {
    const texture = new Texture({
      source: new CanvasSource(__spreadValues({
        resource: canvas
      }, options))
    });
    const onDestroy = () => {
      if (canvasCache.get(canvas) === texture) {
        canvasCache.delete(canvas);
      }
    };
    texture.once("destroy", onDestroy);
    texture.source.once("destroy", onDestroy);
    canvasCache.set(canvas, texture);
  }
  return canvasCache.get(canvas);
}
function hasCachedCanvasTexture(canvas) {
  return canvasCache.has(canvas);
}

// node_modules/pixi.js/lib/rendering/renderers/shared/view/ViewSystem.mjs
var _ViewSystem = class _ViewSystem2 {
  /**
   * Whether CSS dimensions of canvas view should be resized to screen dimensions automatically.
   * This is only supported for HTMLCanvasElement and will be ignored if the canvas is an OffscreenCanvas.
   * @type {boolean}
   */
  get autoDensity() {
    return this.texture.source.autoDensity;
  }
  set autoDensity(value) {
    this.texture.source.autoDensity = value;
  }
  /** The resolution / device pixel ratio of the renderer. */
  get resolution() {
    return this.texture.source._resolution;
  }
  set resolution(value) {
    this.texture.source.resize(
      this.texture.source.width,
      this.texture.source.height,
      value
    );
  }
  constructor(renderer) {
    this._renderer = renderer;
  }
  /**
   * initiates the view system
   * @param options - the options for the view
   */
  init(options) {
    options = __spreadValues(__spreadValues({}, _ViewSystem2.defaultOptions), options);
    if (options.view) {
      deprecation(v8_0_0, "ViewSystem.view has been renamed to ViewSystem.canvas");
      options.canvas = options.view;
    }
    this.screen = new Rectangle(0, 0, options.width, options.height);
    this.canvas = options.canvas || DOMAdapter.get().createCanvas();
    this.antialias = !!options.antialias;
    const _a = options, { depth } = _a, canvasOptions = __objRest(_a, ["depth"]);
    this.texture = getCanvasTexture(this.canvas, canvasOptions);
    this.renderTarget = new RenderTarget({
      colorTextures: [this.texture],
      depth: !!depth,
      isRoot: true
    });
    this.texture.source.transparent = options.backgroundAlpha < 1;
    this.texture.source.on("resize", this._updateScreenSize, this);
    this.resolution = options.resolution;
    this._updateScreenSize();
  }
  /**
   * Resizes the screen and canvas to the specified dimensions.
   * @param desiredScreenWidth - The new width of the screen.
   * @param desiredScreenHeight - The new height of the screen.
   * @param resolution
   */
  resize(desiredScreenWidth, desiredScreenHeight, resolution) {
    this.texture.source.resize(desiredScreenWidth, desiredScreenHeight, resolution);
    this.screen.width = this.texture.frame.width;
    this.screen.height = this.texture.frame.height;
  }
  /**
   * Destroys this System and optionally removes the canvas from the dom.
   * @param {options | false} options - The options for destroying the view, or "false".
   * @example
   * viewSystem.destroy();
   * viewSystem.destroy(true);
   * viewSystem.destroy({ removeView: true });
   */
  destroy(options = false) {
    const removeView = typeof options === "boolean" ? options : !!options?.removeView;
    if (removeView && this.canvas.parentNode) {
      this.canvas.parentNode.removeChild(this.canvas);
    }
    this.texture.source.off("resize", this._updateScreenSize, this);
    TexturePool.removeScreen(this._renderer.uid);
    CanvasPool.removeScreen(this._renderer.uid);
    this.texture.destroy();
  }
  /**
   * Tells the texture and canvas pools how big this renderer's screen is, in physical pixels, so they
   * can hand out screen sized resources instead of rounding every request up to a power of two.
   */
  _updateScreenSize() {
    const { pixelWidth, pixelHeight } = this.texture.source;
    const uid3 = this._renderer.uid;
    TexturePool.setScreenSize(uid3, pixelWidth, pixelHeight);
    CanvasPool.setScreenSize(uid3, pixelWidth, pixelHeight);
  }
};
_ViewSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "view",
  priority: 0
};
_ViewSystem.defaultOptions = {
  /**
   * {@link WebGLOptions.width}
   * @default 800
   */
  width: 800,
  /**
   * {@link WebGLOptions.height}
   * @default 600
   */
  height: 600,
  /**
   * {@link WebGLOptions.autoDensity}
   * @default false
   */
  autoDensity: false,
  /**
   * {@link WebGLOptions.antialias}
   * @default false
   */
  antialias: false
};
var ViewSystem = _ViewSystem;

// node_modules/pixi.js/lib/rendering/renderers/shared/system/SharedSystems.mjs
var SharedSystems = [
  BackgroundSystem,
  GlobalUniformSystem,
  HelloSystem,
  ViewSystem,
  RenderGroupSystem,
  GCSystem,
  TextureGCSystem,
  GenerateTextureSystem,
  ExtractSystem,
  RendererInitHook,
  RenderableGCSystem,
  SchedulerSystem
];
var SharedRenderPipes = [
  BlendModePipe,
  BatcherPipe,
  SpritePipe,
  RenderGroupPipe,
  AlphaMaskPipe,
  StencilMaskPipe,
  ColorMaskPipe,
  CustomRenderPipe
];

// node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/calculateProjection.mjs
function calculateProjection(pm, x, y, width, height, flipY) {
  const sign = flipY ? 1 : -1;
  pm.identity();
  pm.a = 1 / width * 2;
  pm.d = sign * (1 / height * 2);
  pm.tx = -1 - x * pm.a;
  pm.ty = -sign - y * pm.d;
  return pm;
}

// node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/isRenderingToScreen.mjs
function isRenderingToScreen(renderTarget) {
  if (renderTarget.colorAttachments.length === 0) return false;
  const resource = renderTarget.colorTexture.resource;
  return globalThis.HTMLCanvasElement && resource instanceof HTMLCanvasElement && document.body.contains(resource);
}

// node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/RenderTargetSystem.mjs
var RenderTargetSystem = class {
  constructor(renderer) {
    this.rootViewPort = new Rectangle();
    this.viewport = new Rectangle();
    this.onRenderTargetChange = new SystemRunner("onRenderTargetChange");
    this.projectionMatrix = new Matrix();
    this.defaultClearColor = [0, 0, 0, 0];
    this._renderSurfaceToRenderTargetHash = /* @__PURE__ */ new Map();
    this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
    this._renderTargetStack = [];
    this._bindState = {
      target: null,
      frame: void 0,
      mipLevel: 0,
      layer: 0,
      flipY: false
    };
    this._bindFrame = new Rectangle();
    this._renderer = renderer;
    renderer.gc.addCollection(this, "_gpuRenderTargetHash", "hash");
  }
  /** the current active render surface that the render target is created from */
  get renderSurface() {
    return this._bindState.target;
  }
  /** the current mip level being rendered to (for texture subresources) */
  get mipLevel() {
    return this._bindState.mipLevel;
  }
  /** the current array layer being rendered to (for array-backed targets) */
  get layer() {
    return this._bindState.layer;
  }
  /** called when dev wants to finish a render pass */
  finishRenderPass() {
    this.adaptor.finishRenderPass(this.renderTarget);
  }
  /**
   * called when the renderer starts to render a scene: resets the bind stack and binds the
   * root render surface
   * @param options - the {@link BindOptions} for the root binding
   */
  renderStart(options) {
    this._renderTargetStack.length = 0;
    this.push(options);
    this.rootViewPort.copyFrom(this.viewport);
    this.rootRenderTarget = this.renderTarget;
    this.renderingToScreen = isRenderingToScreen(this.rootRenderTarget);
    this.adaptor.prerender?.(this.rootRenderTarget);
  }
  postrender() {
    this.adaptor.postrender?.(this.rootRenderTarget);
  }
  bind(surfaceOrOptions, clear = true, clearColor, frame, mipLevel = 0, layer = 0, flipY) {
    let options;
    if ("target" in surfaceOrOptions) {
      options = surfaceOrOptions;
    } else {
      deprecation("8.20.0", "RenderTargetSystem.bind: positional arguments are deprecated, please use an options object instead: bind({ target, clear, clearColor, frame, mipLevel, layer, flipY })");
      options = { target: surfaceOrOptions, clear, clearColor, frame, mipLevel, layer, flipY };
    }
    const renderSurface = options.target;
    clear = options.clear ?? true;
    clearColor = options.clearColor;
    mipLevel = (options.mipLevel ?? 0) | 0;
    layer = (options.layer ?? 0) | 0;
    flipY = options.flipY;
    frame = options.frame;
    const renderTarget = this.getRenderTarget(renderSurface);
    const didChange = this.renderTarget !== renderTarget || !!renderTarget.flipY !== !!flipY;
    this.renderTarget = renderTarget;
    const gpuRenderTarget = this.getGpuRenderTarget(renderTarget);
    if (renderTarget.pixelWidth !== gpuRenderTarget.width || renderTarget.pixelHeight !== gpuRenderTarget.height) {
      this.adaptor.resizeGpuRenderTarget(renderTarget);
      gpuRenderTarget.width = renderTarget.pixelWidth;
      gpuRenderTarget.height = renderTarget.pixelHeight;
    }
    const source2 = renderTarget.colorAttachments[0]?.texture || renderTarget.depthStencilAttachment?.texture;
    const viewport = this.viewport;
    const layerCount = source2.dimension === "3d" ? Math.max(source2.depth >> mipLevel, 1) : source2.depthOrArrayLayers;
    if (layer < 0 || layer >= layerCount) {
      throw new Error(`[RenderTargetSystem] layer ${layer} is out of bounds (layer count=${layerCount}).`);
    }
    const bindState = this._bindState;
    bindState.target = renderSurface;
    bindState.frame = frame ? this._bindFrame.copyFrom(frame) : void 0;
    bindState.mipLevel = mipLevel;
    bindState.layer = layer;
    bindState.flipY = flipY;
    const pixelWidth = Math.max(source2.pixelWidth >> mipLevel, 1);
    const pixelHeight = Math.max(source2.pixelHeight >> mipLevel, 1);
    if (!frame && renderSurface instanceof Texture) {
      frame = renderSurface.frame;
    }
    if (frame) {
      const resolution = source2._resolution;
      const scale = 1 << Math.max(mipLevel, 0);
      const baseX = frame.x * resolution + 0.5 | 0;
      const baseY = frame.y * resolution + 0.5 | 0;
      const baseW = frame.width * resolution + 0.5 | 0;
      const baseH = frame.height * resolution + 0.5 | 0;
      let x = Math.floor(baseX / scale);
      let y = Math.floor(baseY / scale);
      let w = Math.ceil(baseW / scale);
      let h = Math.ceil(baseH / scale);
      if (x < 0) {
        w += x;
        x = 0;
      }
      if (y < 0) {
        h += y;
        y = 0;
      }
      x = Math.min(x, pixelWidth - 1);
      y = Math.min(y, pixelHeight - 1);
      w = Math.min(w, pixelWidth - x);
      h = Math.min(h, pixelHeight - y);
      w = Math.max(w, 1);
      h = Math.max(h, 1);
      viewport.x = x;
      viewport.y = y;
      viewport.width = w;
      viewport.height = h;
    } else {
      viewport.x = 0;
      viewport.y = 0;
      viewport.width = pixelWidth;
      viewport.height = pixelHeight;
    }
    renderTarget.flipY = flipY;
    calculateProjection(
      this.projectionMatrix,
      0,
      0,
      viewport.width / source2.resolution,
      viewport.height / source2.resolution,
      !renderTarget.isRoot !== !!renderTarget.flipY
    );
    this.adaptor.startRenderPass(renderTarget, clear, clearColor, viewport, mipLevel, layer);
    if (didChange) {
      this.onRenderTargetChange.emit(renderTarget);
    }
    return renderTarget;
  }
  /**
   * Captures the current binding as a {@link BindOptions} that can be passed back to
   * {@link RenderTargetSystem.bind} to restore it. The capture replays non-destructively:
   * its `clear` is `CLEAR.NONE`, so restoring never wipes the target.
   *
   * ```js
   * const saved = renderer.renderTarget.getBindState();
   *
   * renderer.renderTarget.bind({ target: scratchTexture, clear: true });
   * // ... draw ...
   * renderer.renderTarget.bind(saved);
   *
   * // or compose: the saved binding, but into mip 1
   * renderer.renderTarget.bind({ ...saved, mipLevel: 1 });
   * ```
   *
   * The capture is a snapshot owned by the caller — later binds cannot change it — and holds
   * `target` and `frame` as they were passed, so a Texture bound without an explicit frame
   * replays through its frame fallback. It stays valid for as long as its target does.
   * Pass `out` to reuse one object across captures; every field of it is overwritten.
   * @param out - an optional object to write the bind state into; allocated when omitted
   * @returns the captured bind state (`out` when provided)
   */
  getBindState(out) {
    if (!this.renderTarget) {
      throw new Error("[RenderTargetSystem] getBindState is only valid while a render surface is bound");
    }
    const bindState = this._bindState;
    out ?? (out = {});
    out.target = bindState.target;
    out.clear = CLEAR.NONE;
    out.clearColor = void 0;
    if (!bindState.frame) {
      out.frame = void 0;
    } else if (out.frame) {
      out.frame.copyFrom(bindState.frame);
    } else {
      out.frame = bindState.frame.clone();
    }
    out.mipLevel = bindState.mipLevel;
    out.layer = bindState.layer;
    out.flipY = !!bindState.flipY;
    return out;
  }
  /**
   * Whether pixi inverts the front face for a bind — `true` when a front-facing triangle ends up
   * wound the opposite way on the surface, so the winding/cull has been inverted to compensate.
   *
   * With no arguments, answers for the current bind. With a target, answers for that target as if
   * it were bound with the given `flipY` (defaulting to `false`, exactly as {@link bind} would), so
   * a consumer can choose a projection or a `flipY` before binding.
   *
   * This is the requested `flipY` combined with the backend's inherent orientation, not the raw request:
   *
   * ```text
   * inverted = flipY XOR (isWebGL && !isRoot)
   * ```
   *
   * WebGL's non-root FBOs carry an inherent Y-flip vs the root (the classic render-texture flip), so the
   * same requested `flipY` lands with the opposite winding depending on `isRoot`. WebGPU has no such
   * inherent flip, so there it is simply `flipY`. This is the one spelling of the rule: the winding each
   * backend bakes at bind ({@link GlStateSystem} / {@link PipelineSystem}) comes from here too, so
   * consumers (e.g. 3D pipelines) read the resolved orientation instead of re-deriving it.
   * @param renderTarget - the target to ask about; omit for the current bind
   * @param flipY - the `flipY` the target would be bound with; ignored when `renderTarget` is omitted
   * @returns whether the front face is inverted
   */
  isFrontFaceInverted(renderTarget, flipY) {
    if (!renderTarget) {
      renderTarget = this.renderTarget;
      if (!renderTarget) return false;
      flipY = renderTarget.flipY;
    }
    return !!flipY !== (this._renderer.type === RendererType.WEBGL && !renderTarget.isRoot);
  }
  /**
   * The effective front-face orientation of the current bind.
   * @deprecated since 8.21.0, use {@link isFrontFaceInverted} instead
   * @returns whether the current bind's front face is inverted
   */
  get frontFaceInverted() {
    deprecation(v8_21_0, "RenderTargetSystem.frontFaceInverted is deprecated, use isFrontFaceInverted() instead");
    return this.isFrontFaceInverted();
  }
  clear(target, clear = CLEAR.ALL, clearColor, mipLevel = this.mipLevel, layer = this.layer) {
    if (!clear) return;
    if (target) {
      target = this.getRenderTarget(target);
    }
    this.adaptor.clear(
      target || this.renderTarget,
      clear,
      clearColor,
      this.viewport,
      mipLevel,
      layer
    );
  }
  contextChange() {
    this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
  }
  push(surfaceOrOptions, clear = CLEAR.ALL, clearColor, frame, mipLevel = 0, layer = 0, flipY) {
    let options;
    if ("target" in surfaceOrOptions) {
      options = surfaceOrOptions;
    } else {
      deprecation("8.20.0", "RenderTargetSystem.push: positional arguments are deprecated, please use an options object instead: push({ target, clear, clearColor, frame, mipLevel, layer, flipY })");
      options = { target: surfaceOrOptions, clear, clearColor, frame, mipLevel, layer, flipY };
    }
    const renderTarget = this.bind(options);
    this._renderTargetStack.push({
      target: options.target,
      clear: false,
      clearColor: void 0,
      frame: options.frame ? options.frame.clone() : void 0,
      mipLevel: options.mipLevel,
      layer: options.layer,
      flipY: options.flipY
    });
    return renderTarget;
  }
  /**
   * Pops the current render target and restores the previous binding.
   * @returns the render target that was restored
   */
  pop() {
    this._renderTargetStack.pop();
    const previous = this._renderTargetStack[this._renderTargetStack.length - 1];
    if (!previous) {
      throw new Error("[RenderTargetSystem] pop: no previous binding to restore (unbalanced pop)");
    }
    return this.bind(previous);
  }
  /**
   * Gets the render target from the provide render surface. Eg if its a texture,
   * it will return the render target for the texture.
   * If its a render target, it will return the same render target.
   * @param renderSurface - the render surface to get the render target for
   * @returns the render target for the render surface
   */
  getRenderTarget(renderSurface) {
    if (renderSurface.isTexture) {
      renderSurface = renderSurface.source;
    }
    return this._renderSurfaceToRenderTargetHash.get(renderSurface) ?? this._initRenderTarget(renderSurface);
  }
  /**
   * Copies a render surface to another texture.
   *
   * NOTE:
   * for sourceRenderSurfaceTexture, The render target must be something that is written too by the renderer
   *
   * The following is not valid:
   * @example
   * const canvas = document.createElement('canvas')
   * canvas.width = 200;
   * canvas.height = 200;
   *
   * const ctx = canvas2.getContext('2d')!
   * ctx.fillStyle = 'red'
   * ctx.fillRect(0, 0, 200, 200);
   *
   * const texture = RenderTexture.create({
   *   width: 200,
   *   height: 200,
   * })
   * const renderTarget = renderer.renderTarget.getRenderTarget(canvas2);
   *
   * renderer.renderTarget.copyToTexture(renderTarget,texture, {x:0,y:0},{width:200,height:200},{x:0,y:0});
   *
   * The best way to copy a canvas is to create a texture from it. Then render with that.
   *
   * Parsing in a RenderTarget canvas context (with a 2d context)
   * @param sourceRenderSurface - the render surface (render target, texture, or canvas) to copy from
   * @param {Texture} destinationTexture - the texture to copy to
   * @param {object} originSrc - the origin of the copy
   * @param {number} originSrc.x - the x origin of the copy
   * @param {number} originSrc.y - the y origin of the copy
   * @param {object} size - the size of the copy
   * @param {number} size.width - the width of the copy
   * @param {number} size.height - the height of the copy
   * @param {object} originDest - the destination origin (top left to paste from!)
   * @param {number} originDest.x - the x origin of the paste
   * @param {number} originDest.y - the y origin of the paste
   */
  copyToTexture(sourceRenderSurface, destinationTexture, originSrc, size, originDest) {
    const sourceRenderTarget = this.getRenderTarget(sourceRenderSurface);
    if (originSrc.x < 0) {
      size.width += originSrc.x;
      originDest.x -= originSrc.x;
      originSrc.x = 0;
    }
    if (originSrc.y < 0) {
      size.height += originSrc.y;
      originDest.y -= originSrc.y;
      originSrc.y = 0;
    }
    const { pixelWidth, pixelHeight } = sourceRenderTarget;
    size.width = Math.min(size.width, pixelWidth - originSrc.x);
    size.height = Math.min(size.height, pixelHeight - originSrc.y);
    return this.adaptor.copyToTexture(
      sourceRenderTarget,
      destinationTexture,
      originSrc,
      size,
      originDest
    );
  }
  /**
   * Copies the depth attachment from one render target to another.
   * Both source and destination must have a depthStencilAttachment.
   *
   * **Important Note:** When using the copied depth buffer in a subsequent render pass,
   * you must ensure you do not clear the depth buffer again. If you need to clear the color
   * buffer of the destination render target, use `clear: CLEAR.COLOR` to preserve the copied depth data.
   * @example
   * ```js
   * renderer.renderTarget.copyDepthTexture(
   *   sourceRT, destRT, { x: 0, y: 0 }, { width: 200, height: 200 }, { x: 0, y: 0 }
   * );
   *
   * // In the subsequent render pass, clear ONLY the color buffer!
   * renderer.render({
   *   target: destRT,
   *   container: myMesh,
   *   clear: CLEAR.COLOR, // Preserves the copied depth
   *   clearColor: [0, 0, 0, 1]
   * });
   * ```
   * @param source - the render surface (render target, depth texture, or canvas) to copy depth from
   * @param destination - the depth/stencil texture to copy depth to
   * @param {object} originSrc - the origin of the copy
   * @param {number} originSrc.x - the x origin of the copy
   * @param {number} originSrc.y - the y origin of the copy
   * @param {object} size - the size of the copy
   * @param {number} size.width - the width of the copy
   * @param {number} size.height - the height of the copy
   * @param {object} originDest - the destination origin (top left to paste from!)
   * @param {number} originDest.x - the x origin of the paste
   * @param {number} originDest.y - the y origin of the paste
   */
  copyDepthTexture(source2, destination, originSrc, size, originDest = { x: 0, y: 0 }) {
    const sourceRenderTarget = this.getRenderTarget(source2);
    if (!sourceRenderTarget.depthStencilAttachment) {
      warn("[RenderTargetSystem] copyDepthTexture: the source render target has no depth attachment to copy from");
      return;
    }
    const destSource = destination.source;
    if (!destSource.format.includes("depth") && !destSource.format.includes("stencil")) {
      warn(`[RenderTargetSystem] copyDepthTexture: the destination texture must have a depth/stencil format (got '${destSource.format}')`);
      return;
    }
    let srcX = originSrc.x;
    let srcY = originSrc.y;
    let destX = originDest.x;
    let destY = originDest.y;
    let width = size.width;
    let height = size.height;
    if (srcX < 0) {
      width += srcX;
      destX -= srcX;
      srcX = 0;
    }
    if (srcY < 0) {
      height += srcY;
      destY -= srcY;
      srcY = 0;
    }
    width = Math.min(width, sourceRenderTarget.pixelWidth - srcX);
    height = Math.min(height, sourceRenderTarget.pixelHeight - srcY);
    width = Math.min(width, destSource.pixelWidth - destX);
    height = Math.min(height, destSource.pixelHeight - destY);
    if (width <= 0 || height <= 0) return;
    this.adaptor.copyDepthTexture(
      sourceRenderTarget,
      destination,
      { x: srcX, y: srcY },
      { width, height },
      { x: destX, y: destY }
    );
  }
  /**
   * ensures that we have a depth stencil buffer available to render to
   * This is used by the mask system to make sure we have a stencil buffer.
   */
  ensureDepthStencil() {
    if (!this.renderTarget.stencil) {
      if (this.renderTarget.depthStencilTexture) {
        warn(`[RenderTargetSystem] a stencil mask is being used, but the render target's depthStencilTexture format '${this.renderTarget.depthStencilTexture.format}' has no stencil aspect, so masking cannot work here. Use a 'depth24plus-stencil8' texture instead.`);
        return;
      }
      this.renderTarget._depth = true;
      this.renderTarget._stencil = true;
      this.adaptor.startRenderPass(this.renderTarget, false, null, this.viewport, 0, this.layer);
    }
  }
  /** nukes the render target system */
  destroy() {
    this._renderer = null;
    this._renderSurfaceToRenderTargetHash.forEach((renderTarget, key) => {
      if (renderTarget !== key) {
        this._releaseRenderTarget(key, renderTarget);
      } else {
        renderTarget.off("destroy", this._onRenderTargetDestroy, this);
      }
    });
    this._renderSurfaceToRenderTargetHash.clear();
    for (const gpuRenderTarget of Object.values(this._gpuRenderTargetHash)) {
      if (gpuRenderTarget) this.adaptor.destroyGpuRenderTarget(gpuRenderTarget);
    }
    this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
  }
  _initRenderTarget(renderSurface) {
    let renderTarget = null;
    if (CanvasSource.test(renderSurface)) {
      renderSurface = getCanvasTexture(renderSurface).source;
    }
    if (renderSurface instanceof RenderTarget) {
      renderTarget = renderSurface;
      renderSurface.once("destroy", this._onRenderTargetDestroy, this);
    } else if (renderSurface instanceof TextureSource) {
      const format = renderSurface.format;
      const isDepthStencil = format.includes("depth") || format.includes("stencil");
      renderTarget = isDepthStencil ? new RenderTarget({ colorTextures: 0, depthStencilTexture: renderSurface }) : new RenderTarget({ colorTextures: [renderSurface] });
      if (renderSurface.source instanceof CanvasSource) {
        renderTarget.isRoot = true;
      }
      renderSurface.once("destroy", this._onRenderSurfaceDestroy, this);
    }
    this._renderSurfaceToRenderTargetHash.set(renderSurface, renderTarget);
    return renderTarget;
  }
  _onRenderSurfaceDestroy(renderSurface) {
    const renderTarget = this._renderSurfaceToRenderTargetHash.get(renderSurface);
    if (renderTarget) this._releaseRenderTarget(renderSurface, renderTarget);
  }
  /**
   * A caller-owned render target is tearing itself down. It releases its own attachments,
   * so only the system's references to it and the backend objects built for it go here.
   * @param renderTarget - the render target being destroyed
   */
  _onRenderTargetDestroy(renderTarget) {
    this._renderSurfaceToRenderTargetHash.delete(renderTarget);
    this._releaseGpuRenderTarget(renderTarget);
  }
  /**
   * Tears down a render target that wraps a texture source, removing every reference the
   * system holds to it so neither the system's own teardown nor the source's `destroy`
   * event can destroy it a second time.
   * @param renderSurface - the texture source the render target wraps
   * @param renderTarget - the render target to release
   */
  _releaseRenderTarget(renderSurface, renderTarget) {
    renderTarget.destroy();
    this._renderSurfaceToRenderTargetHash.delete(renderSurface);
    renderSurface.off("destroy", this._onRenderSurfaceDestroy, this);
    this._releaseGpuRenderTarget(renderTarget);
  }
  /**
   * Frees the backend objects (framebuffers, renderbuffers, MSAA textures) cached for a render target.
   * @param renderTarget - the render target whose backend counterpart is no longer needed
   */
  _releaseGpuRenderTarget(renderTarget) {
    const gpuRenderTarget = this._gpuRenderTargetHash[renderTarget.uid];
    if (gpuRenderTarget) {
      this._gpuRenderTargetHash[renderTarget.uid] = null;
      this.adaptor.destroyGpuRenderTarget(gpuRenderTarget);
    }
  }
  getGpuRenderTarget(renderTarget) {
    return this._gpuRenderTargetHash[renderTarget.uid] || (this._gpuRenderTargetHash[renderTarget.uid] = this.adaptor.initGpuRenderTarget(renderTarget));
  }
  resetState() {
    this.renderTarget = null;
    this._bindState.target = null;
  }
};

export {
  loadEnvironmentExtensions,
  autoDetectEnvironment,
  unsafeEvalSupported,
  CLEAR,
  SystemRunner,
  AbstractRenderer,
  CustomRenderPipe,
  BatchableSprite,
  executeInstructions,
  RenderGroupPipe,
  clearList,
  updateRenderGroupTransforms,
  updateRenderGroupTransform,
  updateTransformAndChildren,
  validateRenderables,
  RenderGroupSystem,
  SpritePipe,
  DATA_URI,
  VERSION,
  ApplicationInitHook,
  RendererInitHook,
  BatcherPipe,
  fragment,
  vertex,
  source,
  MaskFilter,
  AlphaMaskPipe,
  ColorMaskPipe,
  StencilMaskPipe,
  BackgroundSystem,
  BlendModePipe,
  ExtractSystem,
  RenderTexture,
  GenerateTextureSystem,
  cleanHash,
  cleanArray,
  GCSystem,
  colorToUniform,
  color32BitToUniform,
  GlobalUniformSystem,
  SchedulerSystem,
  sayHello,
  HelloSystem,
  RenderableGCSystem,
  TextureGCSystem,
  RenderTarget,
  getCanvasTexture,
  hasCachedCanvasTexture,
  ViewSystem,
  SharedSystems,
  SharedRenderPipes,
  calculateProjection,
  isRenderingToScreen,
  RenderTargetSystem
};
//# sourceMappingURL=chunk-C7R4GKG4.js.map
