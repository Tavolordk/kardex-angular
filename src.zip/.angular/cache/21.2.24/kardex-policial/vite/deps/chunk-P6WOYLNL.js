import {
  AbstractRenderer,
  AlphaMaskPipe,
  BatcherPipe,
  BlendModePipe,
  CustomRenderPipe,
  RenderGroupPipe,
  RenderTargetSystem,
  SharedSystems,
  SpritePipe,
  color32BitToUniform
} from "./chunk-C7R4GKG4.js";
import {
  CanvasSource,
  State,
  ViewContainer,
  bgr2rgb
} from "./chunk-RSU6N5IH.js";
import {
  BatchableGraphics,
  FillGradient,
  FillPattern,
  GraphicsContext,
  GraphicsContextSystem,
  buildLine,
  generateTextureMatrix,
  shapeBuilders
} from "./chunk-MGJ7YREG.js";
import {
  canUseNewCanvasBlendModes,
  canvasUtils
} from "./chunk-DBITZEUE.js";
import {
  GCManagedHash
} from "./chunk-XZ3F7MYX.js";
import {
  BigPool,
  Color,
  DOMAdapter,
  ExtensionType,
  InstructionSet,
  Matrix,
  RendererType,
  Texture,
  deprecation,
  extensions,
  groupD8,
  multiplyHexColors,
  v8_0_0,
  warn
} from "./chunk-YC5XMVVP.js";
import {
  __objRest,
  __spreadValues
} from "./chunk-I6DCS273.js";

// node_modules/pixi.js/lib/scene/graphics/canvas/CanvasGraphicsAdaptor.mjs
var emptyCanvasStyle = "#808080";
var tempMatrix = new Matrix();
var tempTextureMatrix = new Matrix();
var tempGradientMatrix = new Matrix();
var tempPatternMatrix = new Matrix();
var tempUvMatrix = new Matrix();
function fillTriangles(context, vertices, indices) {
  context.beginPath();
  for (let i = 0; i < indices.length; i += 3) {
    const i0 = indices[i] * 2;
    const i1 = indices[i + 1] * 2;
    const i2 = indices[i + 2] * 2;
    context.moveTo(vertices[i0], vertices[i0 + 1]);
    context.lineTo(vertices[i1], vertices[i1 + 1]);
    context.lineTo(vertices[i2], vertices[i2 + 1]);
    context.closePath();
  }
  context.fill();
}
function colorToHex(color) {
  const clamped = color & 16777215;
  return `#${clamped.toString(16).padStart(6, "0")}`;
}
function buildRoundedRectPath(context, x, y, width, height, radius) {
  radius = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
  context.moveTo(x + radius, y);
  context.lineTo(x + width - radius, y);
  context.quadraticCurveTo(x + width, y, x + width, y + radius);
  context.lineTo(x + width, y + height - radius);
  context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  context.lineTo(x + radius, y + height);
  context.quadraticCurveTo(x, y + height, x, y + height - radius);
  context.lineTo(x, y + radius);
  context.quadraticCurveTo(x, y, x + radius, y);
}
function buildShapePath(context, shape) {
  switch (shape.type) {
    case "rectangle": {
      const rect = shape;
      context.rect(rect.x, rect.y, rect.width, rect.height);
      break;
    }
    case "roundedRectangle": {
      const rect = shape;
      buildRoundedRectPath(context, rect.x, rect.y, rect.width, rect.height, rect.radius);
      break;
    }
    case "circle": {
      const circle = shape;
      context.arc(circle.x, circle.y, circle.radius, 0, Math.PI * 2);
      break;
    }
    case "ellipse": {
      const ellipse = shape;
      if (context.ellipse) {
        context.ellipse(ellipse.x, ellipse.y, ellipse.halfWidth, ellipse.halfHeight, 0, 0, Math.PI * 2);
      } else {
        context.save();
        context.translate(ellipse.x, ellipse.y);
        context.scale(ellipse.halfWidth, ellipse.halfHeight);
        context.arc(0, 0, 1, 0, Math.PI * 2);
        context.restore();
      }
      break;
    }
    case "triangle": {
      const tri = shape;
      context.moveTo(tri.x, tri.y);
      context.lineTo(tri.x2, tri.y2);
      context.lineTo(tri.x3, tri.y3);
      context.closePath();
      break;
    }
    case "polygon":
    default: {
      const poly = shape;
      const points = poly.points;
      if (!points?.length) break;
      context.moveTo(points[0], points[1]);
      for (let i = 2; i < points.length; i += 2) {
        context.lineTo(points[i], points[i + 1]);
      }
      if (poly.closePath) {
        context.closePath();
      }
      break;
    }
  }
}
function addHolePaths(context, holes) {
  if (!holes?.length) return false;
  for (let i = 0; i < holes.length; i++) {
    const hole = holes[i];
    if (!hole?.shape) continue;
    const transform = hole.transform;
    const hasTransform = transform && !transform.isIdentity();
    if (hasTransform) {
      context.save();
      context.transform(transform.a, transform.b, transform.c, transform.d, transform.tx, transform.ty);
    }
    buildShapePath(context, hole.shape);
    if (hasTransform) {
      context.restore();
    }
  }
  return true;
}
function getCanvasStyle(style, tint, textureMatrix, currentTransform) {
  const fill = style.fill;
  if (fill instanceof FillGradient) {
    fill.buildGradient();
    const gradientTexture = fill.texture;
    if (gradientTexture) {
      const pattern = canvasUtils.getTintedPattern(gradientTexture, tint);
      const patternMatrix = textureMatrix ? tempPatternMatrix.copyFrom(textureMatrix).scale(gradientTexture.source.pixelWidth, gradientTexture.source.pixelHeight) : tempPatternMatrix.copyFrom(fill.transform);
      if (currentTransform && !style.textureSpace) {
        patternMatrix.append(currentTransform);
      }
      canvasUtils.applyPatternTransform(pattern, patternMatrix);
      return pattern;
    }
  }
  if (fill instanceof FillPattern) {
    const pattern = canvasUtils.getTintedPattern(fill.texture, tint);
    canvasUtils.applyPatternTransform(pattern, fill.transform, false);
    return pattern;
  }
  const texture = style.texture;
  if (texture && texture !== Texture.WHITE) {
    if (!texture.source.resource) {
      return emptyCanvasStyle;
    }
    const pattern = canvasUtils.getTintedPattern(texture, tint);
    let patternMatrix = style.matrix;
    if (textureMatrix) {
      const { resolution } = texture.source;
      patternMatrix = tempPatternMatrix.copyFrom(textureMatrix);
      if (texture.rotate) {
        const { uvs, orig } = texture;
        patternMatrix.prepend(tempUvMatrix.set(
          uvs.x1 - uvs.x0,
          uvs.y1 - uvs.y0,
          uvs.x3 - uvs.x0,
          uvs.y3 - uvs.y0,
          uvs.x0,
          uvs.y0
        ).invert()).scale(orig.width * resolution, orig.height * resolution);
      } else {
        patternMatrix.scale(texture.source.pixelWidth, texture.source.pixelHeight).translate(-texture.frame.x * resolution, -texture.frame.y * resolution);
      }
    }
    canvasUtils.applyPatternTransform(pattern, patternMatrix);
    return pattern;
  }
  return colorToHex(tint);
}
var CanvasGraphicsAdaptor = class {
  constructor() {
    this.shader = null;
  }
  contextChange(renderer) {
    void renderer;
  }
  execute(graphicsPipe, renderable) {
    const renderer = graphicsPipe.renderer;
    const contextSystem = renderer.canvasContext;
    const context = contextSystem.activeContext;
    const baseTransform = renderable.groupTransform;
    const globalColor = renderer.globalUniforms.globalUniformData?.worldColor ?? 4294967295;
    const groupColorAlpha = renderable.groupColorAlpha;
    const globalAlpha = (globalColor >>> 24 & 255) / 255;
    const groupAlphaValue = (groupColorAlpha >>> 24 & 255) / 255;
    const filterAlpha = renderer.filter?.alphaMultiplier ?? 1;
    const groupAlpha = globalAlpha * groupAlphaValue * filterAlpha;
    if (groupAlpha <= 0) return;
    const globalTint = globalColor & 16777215;
    const groupTintBGR = groupColorAlpha & 16777215;
    const groupTint = bgr2rgb(multiplyHexColors(groupTintBGR, globalTint));
    const roundPixels = renderer._roundPixels | renderable._roundPixels;
    context.save();
    contextSystem.setContextTransform(baseTransform, roundPixels === 1);
    contextSystem.setBlendMode(renderable.groupBlendMode);
    const instructions = renderable.context.instructions;
    for (let i = 0; i < instructions.length; i++) {
      const instruction = instructions[i];
      if (instruction.action === "texture") {
        const data2 = instruction.data;
        const texture = data2.image;
        const source = texture ? canvasUtils.getCanvasSource(texture) : null;
        if (!source) continue;
        const alpha2 = data2.alpha * groupAlpha;
        if (alpha2 <= 0) continue;
        const tint2 = multiplyHexColors(data2.style, groupTint);
        context.globalAlpha = alpha2;
        let drawSource = source;
        if (tint2 !== 16777215) {
          drawSource = canvasUtils.getTintedCanvas({ texture }, tint2);
        }
        const frame = texture.frame;
        const resolution = texture.source._resolution ?? texture.source.resolution ?? 1;
        let sx = frame.x * resolution;
        let sy = frame.y * resolution;
        const sw = frame.width * resolution;
        const sh = frame.height * resolution;
        if (drawSource !== source) {
          sx = 0;
          sy = 0;
        }
        const transform = data2.transform;
        const hasTransform = transform && !transform.isIdentity();
        const rotate = texture.rotate;
        if (hasTransform || rotate) {
          tempMatrix.copyFrom(baseTransform);
          if (hasTransform) {
            tempMatrix.append(transform);
          }
          if (rotate) {
            groupD8.matrixAppendRotationInv(tempMatrix, rotate, data2.dx, data2.dy, data2.dw, data2.dh);
          }
          contextSystem.setContextTransform(tempMatrix, roundPixels === 1);
        } else {
          contextSystem.setContextTransform(baseTransform, roundPixels === 1);
        }
        context.drawImage(
          drawSource,
          sx,
          sy,
          drawSource === source ? sw : drawSource.width,
          drawSource === source ? sh : drawSource.height,
          rotate ? 0 : data2.dx,
          rotate ? 0 : data2.dy,
          data2.dw,
          data2.dh
        );
        if (hasTransform || rotate) {
          contextSystem.setContextTransform(baseTransform, roundPixels === 1);
        }
        continue;
      }
      const data = instruction.data;
      const shapePath = data?.path?.shapePath;
      if (!shapePath?.shapePrimitives?.length) continue;
      const style = data.style;
      const tint = multiplyHexColors(style.color, groupTint);
      const alpha = style.alpha * groupAlpha;
      if (alpha <= 0) continue;
      const isStroke = instruction.action === "stroke";
      context.globalAlpha = alpha;
      if (isStroke) {
        const strokeStyle = style;
        context.lineWidth = strokeStyle.width;
        context.lineCap = strokeStyle.cap;
        context.lineJoin = strokeStyle.join;
        context.miterLimit = strokeStyle.miterLimit;
      }
      const shapePrimitives = shapePath.shapePrimitives;
      if (!isStroke && data.hole?.shapePath?.shapePrimitives?.length) {
        const lastShape = shapePrimitives[shapePrimitives.length - 1];
        lastShape.holes = data.hole.shapePath.shapePrimitives;
      }
      for (let j = 0; j < shapePrimitives.length; j++) {
        const primitive = shapePrimitives[j];
        if (!primitive?.shape) continue;
        const transform = primitive.transform;
        const hasTransform = transform && !transform.isIdentity();
        const hasTexture = style.texture && style.texture !== Texture.WHITE;
        const textureTransform = style.textureSpace === "global" ? transform : null;
        const textureMatrix = hasTexture ? generateTextureMatrix(tempTextureMatrix, style, primitive.shape, textureTransform) : null;
        const currentTransform = hasTransform ? tempGradientMatrix.copyFrom(baseTransform).append(transform) : baseTransform;
        const canvasStyle = getCanvasStyle(
          style,
          tint,
          textureMatrix,
          currentTransform
        );
        if (hasTransform) {
          context.save();
          context.transform(transform.a, transform.b, transform.c, transform.d, transform.tx, transform.ty);
        }
        if (isStroke) {
          const strokeStyle = style;
          const useStrokeGeometry = strokeStyle.alignment !== 0.5 && !strokeStyle.pixelLine;
          if (useStrokeGeometry) {
            const points = [];
            const vertices = [];
            const indices = [];
            const shapeBuilder = shapeBuilders[primitive.shape.type];
            if (shapeBuilder?.build(primitive.shape, points)) {
              const close = primitive.shape.closePath ?? true;
              buildLine(points, strokeStyle, false, close, vertices, indices);
              context.fillStyle = canvasStyle;
              fillTriangles(context, vertices, indices);
            } else {
              context.strokeStyle = canvasStyle;
              context.beginPath();
              buildShapePath(context, primitive.shape);
              context.stroke();
            }
          } else {
            context.strokeStyle = canvasStyle;
            context.beginPath();
            buildShapePath(context, primitive.shape);
            context.stroke();
          }
        } else {
          context.fillStyle = canvasStyle;
          context.beginPath();
          buildShapePath(context, primitive.shape);
          const hasHoles = addHolePaths(context, primitive.holes);
          if (hasHoles) {
            context.fill("evenodd");
          } else {
            context.fill();
          }
        }
        if (hasTransform) {
          context.restore();
        }
      }
    }
    context.restore();
  }
  destroy() {
    this.shader = null;
  }
};
CanvasGraphicsAdaptor.extension = {
  type: [
    ExtensionType.CanvasPipesAdaptor
  ],
  name: "graphics"
};

// node_modules/pixi.js/lib/rendering/batcher/canvas/CanvasBatchAdaptor.mjs
var _CanvasBatchAdaptor = class _CanvasBatchAdaptor2 {
  static _getPatternRepeat(addressModeU, addressModeV) {
    const repeatU = addressModeU && addressModeU !== "clamp-to-edge";
    const repeatV = addressModeV && addressModeV !== "clamp-to-edge";
    if (repeatU && repeatV) return "repeat";
    if (repeatU) return "repeat-x";
    if (repeatV) return "repeat-y";
    return "no-repeat";
  }
  start(batchPipe, geometry, shader) {
    void batchPipe;
    void geometry;
    void shader;
  }
  execute(batchPipe, batch) {
    const elements = batch.elements;
    if (!elements || !elements.length) return;
    const renderer = batchPipe.renderer;
    const contextSystem = renderer.canvasContext;
    const context = contextSystem.activeContext;
    for (let i = 0; i < elements.length; i++) {
      const element = elements[i];
      if (!element.packAsQuad) continue;
      const quad = element;
      const texture = quad.texture;
      const source = texture ? canvasUtils.getCanvasSource(texture) : null;
      if (!source) continue;
      const textureStyle = texture.source.style;
      const smoothProperty = contextSystem.smoothProperty;
      const shouldSmooth = textureStyle.scaleMode !== "nearest";
      if (context[smoothProperty] !== shouldSmooth) {
        context[smoothProperty] = shouldSmooth;
      }
      contextSystem.setBlendMode(batch.blendMode);
      const globalColor = renderer.globalUniforms.globalUniformData?.worldColor ?? 4294967295;
      const argb = quad.color;
      const globalAlpha = (globalColor >>> 24 & 255) / 255;
      const quadAlpha = (argb >>> 24 & 255) / 255;
      const filterAlpha = renderer.filter?.alphaMultiplier ?? 1;
      const alpha = globalAlpha * quadAlpha * filterAlpha;
      if (alpha <= 0) continue;
      context.globalAlpha = alpha;
      const globalTint = globalColor & 16777215;
      const quadTint = argb & 16777215;
      const tint = bgr2rgb(multiplyHexColors(quadTint, globalTint));
      const frame = texture.frame;
      const repeatU = textureStyle.addressModeU ?? textureStyle.addressMode;
      const repeatV = textureStyle.addressModeV ?? textureStyle.addressMode;
      const repeat = _CanvasBatchAdaptor2._getPatternRepeat(repeatU, repeatV);
      const resolution = texture.source._resolution ?? texture.source.resolution ?? 1;
      const isFromCachedRenderGroup = quad.renderable?.renderGroup?.isCachedAsTexture;
      const sx = frame.x * resolution;
      const sy = frame.y * resolution;
      const sw = frame.width * resolution;
      const sh = frame.height * resolution;
      const bounds = quad.bounds;
      const isRootTarget = renderer.renderTarget.renderTarget.isRoot;
      const dx = bounds.minX;
      const dy = bounds.minY;
      const dw = bounds.maxX - bounds.minX;
      const dh = bounds.maxY - bounds.minY;
      const rotate = texture.rotate;
      const uvs = texture.uvs;
      const uvMin = Math.min(uvs.x0, uvs.x1, uvs.x2, uvs.x3, uvs.y0, uvs.y1, uvs.y2, uvs.y3);
      const uvMax = Math.max(uvs.x0, uvs.x1, uvs.x2, uvs.x3, uvs.y0, uvs.y1, uvs.y2, uvs.y3);
      const needsRepeat = repeat !== "no-repeat" && (uvMin < 0 || uvMax > 1);
      const willUseProcessedCanvas = !needsRepeat && (tint !== 16777215 || rotate);
      const applyRotateTransform = rotate && !willUseProcessedCanvas;
      if (applyRotateTransform) {
        _CanvasBatchAdaptor2._tempPatternMatrix.copyFrom(quad.transform);
        groupD8.matrixAppendRotationInv(
          _CanvasBatchAdaptor2._tempPatternMatrix,
          rotate,
          dx,
          dy,
          dw,
          dh
        );
        contextSystem.setContextTransform(
          _CanvasBatchAdaptor2._tempPatternMatrix,
          quad.roundPixels === 1,
          void 0,
          isFromCachedRenderGroup && isRootTarget
        );
      } else {
        contextSystem.setContextTransform(
          quad.transform,
          quad.roundPixels === 1,
          void 0,
          isFromCachedRenderGroup && isRootTarget
        );
      }
      const drawW = dw;
      const drawH = dh;
      let drawX = applyRotateTransform ? 0 : dx;
      let drawY = applyRotateTransform ? 0 : dy;
      if (!applyRotateTransform && quad.roundPixels === 1) {
        drawX |= 0;
        drawY |= 0;
      }
      if (needsRepeat) {
        let patternSource = source;
        const canTint = tint !== 16777215 && !rotate;
        const fitsFrame = frame.width <= texture.source.width && frame.height <= texture.source.height;
        if (canTint && fitsFrame) {
          patternSource = canvasUtils.getTintedCanvas({ texture }, tint);
        }
        const pattern = context.createPattern(patternSource, repeat);
        if (!pattern) continue;
        const denomX = drawW;
        const denomY = drawH;
        if (denomX === 0 || denomY === 0) continue;
        const invDx = 1 / denomX;
        const invDy = 1 / denomY;
        const a = (uvs.x1 - uvs.x0) * invDx;
        const b = (uvs.y1 - uvs.y0) * invDx;
        const c = (uvs.x3 - uvs.x0) * invDy;
        const d = (uvs.y3 - uvs.y0) * invDy;
        const tx = uvs.x0 - a * drawX - c * drawY;
        const ty = uvs.y0 - b * drawX - d * drawY;
        const pixelWidth = texture.source.pixelWidth;
        const pixelHeight = texture.source.pixelHeight;
        _CanvasBatchAdaptor2._tempPatternMatrix.set(
          a * pixelWidth,
          b * pixelHeight,
          c * pixelWidth,
          d * pixelHeight,
          tx * pixelWidth,
          ty * pixelHeight
        );
        canvasUtils.applyPatternTransform(pattern, _CanvasBatchAdaptor2._tempPatternMatrix);
        context.fillStyle = pattern;
        context.fillRect(drawX, drawY, drawW, drawH);
      } else {
        const needsProcessing = tint !== 16777215 || rotate;
        const processedSource = needsProcessing ? canvasUtils.getTintedCanvas({ texture }, tint) : source;
        const isProcessed = processedSource !== source;
        context.drawImage(
          processedSource,
          isProcessed ? 0 : sx,
          isProcessed ? 0 : sy,
          isProcessed ? processedSource.width : sw,
          isProcessed ? processedSource.height : sh,
          drawX,
          drawY,
          drawW,
          drawH
        );
      }
    }
  }
};
_CanvasBatchAdaptor._tempPatternMatrix = new Matrix();
_CanvasBatchAdaptor.extension = {
  type: [
    ExtensionType.CanvasPipesAdaptor
  ],
  name: "batch"
};
var CanvasBatchAdaptor = _CanvasBatchAdaptor;

// node_modules/pixi.js/lib/rendering/mask/color/CanvasColorMaskPipe.mjs
var CanvasColorMaskPipe = class {
  constructor(renderer) {
    this._colorStack = [];
    this._colorStackIndex = 0;
    this._currentColor = 0;
    this._renderer = renderer;
  }
  buildStart() {
    this._colorStack[0] = 15;
    this._colorStackIndex = 1;
    this._currentColor = 15;
  }
  push(mask, _container, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    const colorStack = this._colorStack;
    colorStack[this._colorStackIndex] = colorStack[this._colorStackIndex - 1] & mask.mask;
    const currentColor = this._colorStack[this._colorStackIndex];
    if (currentColor !== this._currentColor) {
      this._currentColor = currentColor;
      instructionSet.add({
        renderPipeId: "colorMask",
        colorMask: currentColor,
        canBundle: false
      });
    }
    this._colorStackIndex++;
  }
  pop(_mask, _container, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    const colorStack = this._colorStack;
    this._colorStackIndex--;
    const currentColor = colorStack[this._colorStackIndex - 1];
    if (currentColor !== this._currentColor) {
      this._currentColor = currentColor;
      instructionSet.add({
        renderPipeId: "colorMask",
        colorMask: currentColor,
        canBundle: false
      });
    }
  }
  execute(_instruction) {
  }
  destroy() {
    this._renderer = null;
    this._colorStack = null;
  }
};
CanvasColorMaskPipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "colorMask"
};

// node_modules/pixi.js/lib/scene/graphics/canvas/CanvasGraphicsContextSystem.mjs
var CanvasGraphicsContext = class {
  constructor() {
    this.isBatchable = false;
  }
  /**
   * Reset cached canvas data.
   * @advanced
   */
  reset() {
    this.isBatchable = false;
    this.context = null;
    if (this.graphicsData) {
      this.graphicsData.destroy();
      this.graphicsData = null;
    }
  }
  /**
   * Destroy the cached data.
   * @advanced
   */
  destroy() {
    this.reset();
  }
};
var CanvasGraphicsContextRenderData = class {
  constructor() {
    this.instructions = new InstructionSet();
  }
  /**
   * Initialize render data.
   * @advanced
   */
  init() {
    this.instructions.reset();
  }
  /**
   * Destroy render data.
   * @advanced
   */
  destroy() {
    this.instructions.destroy();
    this.instructions = null;
  }
};
var _CanvasGraphicsContextSystem = class _CanvasGraphicsContextSystem2 {
  constructor(renderer) {
    this._renderer = renderer;
    this._managedContexts = new GCManagedHash({ renderer, type: "resource", name: "graphicsContext" });
  }
  /**
   * Runner init called, update the default options
   * @ignore
   */
  init(options) {
    _CanvasGraphicsContextSystem2.defaultOptions.bezierSmoothness = options?.bezierSmoothness ?? _CanvasGraphicsContextSystem2.defaultOptions.bezierSmoothness;
  }
  /**
   * Returns the render data for a given GraphicsContext.
   * @param context - The GraphicsContext to get the render data for.
   * @internal
   */
  getContextRenderData(context) {
    const gpuContext = this.getGpuContext(context);
    return gpuContext.graphicsData || this._initContextRenderData(context);
  }
  /**
   * Updates the GPU context for a given GraphicsContext.
   * @param context - The GraphicsContext to update.
   * @returns The updated CanvasGraphicsContext.
   * @internal
   */
  updateGpuContext(context) {
    const gpuData = context._gpuData;
    const hasContext = !!gpuData[this._renderer.uid];
    const gpuContext = gpuData[this._renderer.uid] || this._initContext(context);
    if (context.dirty || !hasContext) {
      if (hasContext) {
        gpuContext.reset();
      }
      gpuContext.isBatchable = false;
      context.dirty = false;
    }
    return gpuContext;
  }
  /**
   * Returns the CanvasGraphicsContext for a given GraphicsContext.
   * If it does not exist, it will initialize a new one.
   * @param context - The GraphicsContext to get the CanvasGraphicsContext for.
   * @returns The CanvasGraphicsContext for the given GraphicsContext.
   * @internal
   */
  getGpuContext(context) {
    const gpuData = context._gpuData;
    return gpuData[this._renderer.uid] || this._initContext(context);
  }
  _initContextRenderData(context) {
    const renderData = new CanvasGraphicsContextRenderData();
    const gpuContext = this.getGpuContext(context);
    gpuContext.graphicsData = renderData;
    renderData.init();
    return renderData;
  }
  _initContext(context) {
    const gpuContext = new CanvasGraphicsContext();
    gpuContext.context = context;
    context._gpuData[this._renderer.uid] = gpuContext;
    this._managedContexts.add(context);
    return gpuContext;
  }
  destroy() {
    this._managedContexts.destroy();
    this._renderer = null;
  }
};
_CanvasGraphicsContextSystem.extension = {
  type: [
    ExtensionType.CanvasSystem
  ],
  name: "graphicsContext"
};
_CanvasGraphicsContextSystem.defaultOptions = {
  /**
   * A value from 0 to 1 that controls the smoothness of bezier curves (the higher the smoother)
   * @default 0.5
   */
  bezierSmoothness: 0.5
};
var CanvasGraphicsContextSystem = _CanvasGraphicsContextSystem;

// node_modules/pixi.js/lib/scene/graphics/canvas/CanvasGraphicsPipe.mjs
var CanvasGraphicsPipe = class {
  constructor(renderer, adaptor) {
    this.state = State.for2d();
    this.renderer = renderer;
    this._adaptor = adaptor;
    this.renderer.runners.contextChange.add(this);
    this._managedGraphics = new GCManagedHash({ renderer, type: "renderable", priority: -1, name: "graphics" });
  }
  contextChange() {
    this._adaptor.contextChange(this.renderer);
  }
  validateRenderable(_graphics) {
    return false;
  }
  addRenderable(graphics, instructionSet) {
    this._managedGraphics.add(graphics);
    this.renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add(graphics);
  }
  updateRenderable(_graphics) {
  }
  execute(graphics) {
    if (!graphics.isRenderable) return;
    this._adaptor.execute(this, graphics);
  }
  destroy() {
    this._managedGraphics.destroy();
    this.renderer = null;
    this._adaptor.destroy();
    this._adaptor = null;
  }
};
CanvasGraphicsPipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "graphics"
};

// node_modules/pixi.js/lib/scene/graphics/shared/GraphicsPipe.mjs
var GraphicsGpuData = class {
  constructor() {
    this.batches = [];
    this.batched = false;
  }
  destroy() {
    this.batches.forEach((batch) => {
      BigPool.return(batch);
    });
    this.batches.length = 0;
  }
};
var GraphicsPipe = class {
  constructor(renderer, adaptor) {
    this.state = State.for2d();
    this.renderer = renderer;
    this._adaptor = adaptor;
    this.renderer.runners.contextChange.add(this);
    this._managedGraphics = new GCManagedHash({ renderer, type: "renderable", priority: -1, name: "graphics" });
  }
  contextChange() {
    this._adaptor.contextChange(this.renderer);
  }
  validateRenderable(graphics) {
    const context = graphics.context;
    const wasBatched = !!graphics._gpuData;
    const contextSystem = this.renderer.graphicsContext;
    const gpuContext = contextSystem.updateGpuContext(context);
    if (gpuContext.isBatchable || wasBatched !== gpuContext.isBatchable) {
      return true;
    }
    return false;
  }
  addRenderable(graphics, instructionSet) {
    const contextSystem = this.renderer.graphicsContext;
    const gpuContext = contextSystem.updateGpuContext(graphics.context);
    if (graphics.didViewUpdate || !graphics._gpuData[this.renderer.uid]) {
      this._rebuild(graphics);
    }
    if (gpuContext.isBatchable) {
      this._addToBatcher(graphics, instructionSet);
    } else {
      this.renderer.renderPipes.batch.break(instructionSet);
      instructionSet.add(graphics);
    }
  }
  updateRenderable(graphics) {
    const gpuData = this._getGpuDataForRenderable(graphics);
    const batches = gpuData.batches;
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      batch._batcher.updateElement(batch);
    }
  }
  execute(graphics) {
    if (!graphics.isRenderable) return;
    const renderer = this.renderer;
    const context = graphics.context;
    const contextSystem = renderer.graphicsContext;
    if (!contextSystem.getGpuContext(context).batches.length) {
      return;
    }
    const shader = context.customShader || this._adaptor.shader;
    this.state.blendMode = graphics.groupBlendMode;
    const localUniforms = shader.resources.localUniforms.uniforms;
    localUniforms.uTransformMatrix = graphics.groupTransform;
    localUniforms.uRound = renderer._roundPixels | graphics._roundPixels;
    color32BitToUniform(
      graphics.groupColorAlpha,
      localUniforms.uColor,
      0
    );
    this._adaptor.execute(this, graphics);
  }
  _rebuild(graphics) {
    const gpuData = this._getGpuDataForRenderable(graphics);
    const contextSystem = this.renderer.graphicsContext;
    const gpuContext = contextSystem.updateGpuContext(graphics.context);
    gpuData.destroy();
    if (gpuContext.isBatchable) {
      this._updateBatchesForRenderable(graphics, gpuData);
    }
  }
  _addToBatcher(graphics, instructionSet) {
    const batchPipe = this.renderer.renderPipes.batch;
    const batches = this._getGpuDataForRenderable(graphics).batches;
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      batchPipe.addToBatch(batch, instructionSet);
    }
  }
  _getGpuDataForRenderable(graphics) {
    return graphics._gpuData[this.renderer.uid] || this._initGpuDataForRenderable(graphics);
  }
  _initGpuDataForRenderable(graphics) {
    const gpuData = new GraphicsGpuData();
    graphics._gpuData[this.renderer.uid] = gpuData;
    this._managedGraphics.add(graphics);
    return gpuData;
  }
  _updateBatchesForRenderable(graphics, gpuData) {
    const context = graphics.context;
    const contextSystem = this.renderer.graphicsContext;
    const gpuContext = contextSystem.getGpuContext(context);
    const roundPixels = this.renderer._roundPixels | graphics._roundPixels;
    gpuData.batches = gpuContext.batches.map((batch) => {
      const batchClone = BigPool.get(BatchableGraphics);
      batch.copyTo(batchClone);
      batchClone.renderable = graphics;
      batchClone.roundPixels = roundPixels;
      return batchClone;
    });
  }
  destroy() {
    this._managedGraphics.destroy();
    this.renderer = null;
    this._adaptor.destroy();
    this._adaptor = null;
    this.state = null;
  }
};
GraphicsPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes
  ],
  name: "graphics"
};

// node_modules/pixi.js/lib/scene/graphics/init.mjs
extensions.add(CanvasGraphicsPipe);
extensions.add(GraphicsPipe);
extensions.add(CanvasGraphicsContextSystem);
extensions.add(GraphicsContextSystem);

// node_modules/pixi.js/lib/scene/graphics/shared/Graphics.mjs
var Graphics = class _Graphics extends ViewContainer {
  /**
   * Creates a new Graphics object.
   * @param options - Options for the Graphics.
   */
  constructor(options) {
    if (options instanceof GraphicsContext) {
      options = { context: options };
    }
    const _a = options || {}, { context, roundPixels } = _a, rest = __objRest(_a, ["context", "roundPixels"]);
    super(__spreadValues({
      label: "Graphics"
    }, rest));
    this.renderPipeId = "graphics";
    if (!context) {
      this.context = this._ownedContext = new GraphicsContext();
      this.context.autoGarbageCollect = this.autoGarbageCollect;
    } else {
      this.context = context;
    }
    this.didViewUpdate = true;
    this.allowChildren = false;
    this.roundPixels = roundPixels ?? false;
  }
  set context(context) {
    if (context === this._context) return;
    if (this._context) {
      this._context.off("update", this.onViewUpdate, this);
      this._context.off("unload", this.unload, this);
    }
    this._context = context;
    this._context.on("update", this.onViewUpdate, this);
    this._context.on("unload", this.unload, this);
    this.onViewUpdate();
  }
  /**
   * The underlying graphics context used for drawing operations.
   * Controls how shapes and paths are rendered.
   * @example
   * ```ts
   * // Create a shared context
   * const sharedContext = new GraphicsContext();
   *
   * // Create graphics objects sharing the same context
   * const graphics1 = new Graphics();
   * const graphics2 = new Graphics();
   *
   * // Assign shared context
   * graphics1.context = sharedContext;
   * graphics2.context = sharedContext;
   *
   * // Both graphics will show the same shapes
   * sharedContext
   *     .rect(0, 0, 100, 100)
   *     .fill({ color: 0xff0000 });
   * ```
   * @see {@link GraphicsContext} For drawing operations
   * @see {@link GraphicsOptions} For context configuration
   */
  get context() {
    return this._context;
  }
  /**
   * The local bounds of the graphics object.
   * Returns the boundaries after all graphical operations but before any transforms.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Draw a shape
   * graphics
   *     .rect(0, 0, 100, 100)
   *     .fill({ color: 0xff0000 });
   *
   * // Get bounds information
   * const bounds = graphics.bounds;
   * console.log(bounds.width);  // 100
   * console.log(bounds.height); // 100
   * ```
   * @readonly
   * @see {@link Bounds} For bounds operations
   * @see {@link Container#getBounds} For transformed bounds
   */
  get bounds() {
    return this._context.bounds;
  }
  /**
   * Graphics objects do not need to update their bounds as the context handles this.
   * @private
   */
  updateBounds() {
  }
  /**
   * Checks if the object contains the given point.
   * Returns true if the point lies within the Graphics object's rendered area.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Draw a shape
   * graphics
   *     .rect(0, 0, 100, 100)
   *     .fill({ color: 0xff0000 });
   *
   * // Check point intersection
   * if (graphics.containsPoint({ x: 50, y: 50 })) {
   *     console.log('Point is inside rectangle!');
   * }
   * ```
   * @param point - The point to check in local coordinates
   * @returns True if the point is inside the Graphics object
   * @see {@link Graphics#bounds} For bounding box checks
   * @see {@link PointData} For point data structure
   */
  containsPoint(point) {
    return this._context.containsPoint(point);
  }
  /**
   * Destroys this graphics renderable and optionally its context.
   * @param options - Options parameter. A boolean will act as if all options
   *
   * If the context was created by this graphics and `destroy(false)` or `destroy()` is called
   * then the context will still be destroyed.
   *
   * If you want to explicitly not destroy this context that this graphics created,
   * then you should pass destroy({ context: false })
   *
   * If the context was passed in as an argument to the constructor then it will not be destroyed
   * @example
   * ```ts
   * // Destroy the graphics and its context
   * graphics.destroy();
   * graphics.destroy(true);
   * graphics.destroy({ context: true, texture: true, textureSource: true });
   * ```
   */
  destroy(options) {
    if (this._ownedContext && !options) {
      this._ownedContext.destroy(options);
    } else if (options === true || options?.context === true) {
      this._context.destroy(options);
    }
    this._context?.off("update", this.onViewUpdate, this);
    this._context?.off("unload", this.unload, this);
    this._ownedContext = null;
    this._context = null;
    super.destroy(options);
  }
  /**
   * @param now - The current time in milliseconds.
   * @internal
   */
  _onTouch(now) {
    this._gcLastUsed = now;
    this._context._gcLastUsed = now;
  }
  _callContextMethod(method, args) {
    this.context[method](...args);
    return this;
  }
  // --------------------------------------- GraphicsContext methods ---------------------------------------
  /**
   * Sets the current fill style of the graphics context.
   * The fill style can be a color, gradient, pattern, or a complex style object.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Basic color fill
   * graphics
   *     .setFillStyle({ color: 0xff0000 }) // Red fill
   *     .rect(0, 0, 100, 100)
   *     .fill();
   *
   * // Gradient fill
   * const gradient = new FillGradient({
   *    end: { x: 1, y: 0 },
   *    colorStops: [
   *         { offset: 0, color: 0xff0000 }, // Red at start
   *         { offset: 0.5, color: 0x00ff00 }, // Green at middle
   *         { offset: 1, color: 0x0000ff }, // Blue at end
   *    ],
   * });
   *
   * graphics
   *     .setFillStyle(gradient)
   *     .circle(100, 100, 50)
   *     .fill();
   *
   * // Pattern fill
   * const pattern = new FillPattern(texture);
   * graphics
   *     .setFillStyle({
   *         fill: pattern,
   *         alpha: 0.5
   *     })
   *     .rect(0, 0, 200, 200)
   *     .fill();
   * ```
   * @param {FillInput} args - The fill style to apply
   * @returns The Graphics instance for chaining
   * @see {@link FillStyle} For fill style options
   * @see {@link FillGradient} For gradient fills
   * @see {@link FillPattern} For pattern fills
   */
  setFillStyle(...args) {
    return this._callContextMethod("setFillStyle", args);
  }
  /**
   * Sets the current stroke style of the graphics context.
   * Similar to fill styles, stroke styles can encompass colors, gradients, patterns, or more detailed configurations.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Basic color stroke
   * graphics
   *     .setStrokeStyle({
   *         width: 2,
   *         color: 0x000000
   *     })
   *     .rect(0, 0, 100, 100)
   *     .stroke();
   *
   * // Complex stroke style
   * graphics
   *     .setStrokeStyle({
   *         width: 4,
   *         color: 0xff0000,
   *         alpha: 0.5,
   *         join: 'round',
   *         cap: 'round',
   *         alignment: 0.5
   *     })
   *     .circle(100, 100, 50)
   *     .stroke();
   *
   * // Gradient stroke
   * const gradient = new FillGradient({
   *    end: { x: 1, y: 0 },
   *    colorStops: [
   *         { offset: 0, color: 0xff0000 }, // Red at start
   *         { offset: 0.5, color: 0x00ff00 }, // Green at middle
   *         { offset: 1, color: 0x0000ff }, // Blue at end
   *    ],
   * });
   *
   * graphics
   *     .setStrokeStyle({
   *         width: 10,
   *         fill: gradient
   *     })
   *     .poly([0,0, 100,50, 0,100])
   *     .stroke();
   * ```
   * @param {StrokeInput} args - The stroke style to apply
   * @returns The Graphics instance for chaining
   * @see {@link StrokeStyle} For stroke style options
   * @see {@link FillGradient} For gradient strokes
   * @see {@link FillPattern} For pattern strokes
   */
  setStrokeStyle(...args) {
    return this._callContextMethod("setStrokeStyle", args);
  }
  fill(...args) {
    return this._callContextMethod("fill", args);
  }
  /**
   * Strokes the current path with the current stroke style or specified style.
   * Outlines the shape using the stroke settings.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Stroke with direct color
   * graphics
   *     .circle(50, 50, 25)
   *     .stroke({
   *         width: 2,
   *         color: 0xff0000
   *     }); // 2px red stroke
   *
   * // Fill with texture
   * graphics
   *    .rect(0, 0, 100, 100)
   *    .stroke(myTexture); // Fill with texture
   *
   * // Stroke with gradient
   * const gradient = new FillGradient({
   *     end: { x: 1, y: 0 },
   *     colorStops: [
   *         { offset: 0, color: 0xff0000 },
   *         { offset: 0.5, color: 0x00ff00 },
   *         { offset: 1, color: 0x0000ff },
   *     ],
   * });
   *
   * graphics
   *     .rect(0, 0, 100, 100)
   *     .stroke({
   *         width: 4,
   *         fill: gradient,
   *         alignment: 0.5,
   *         join: 'round'
   *     });
   * ```
   * @param {StrokeStyle} args - Optional stroke style to apply. Can be:
   * - A stroke style object with width, color, etc.
   * - A gradient
   * - A pattern
   * If omitted, uses current stroke style.
   * @returns The Graphics instance for chaining
   * @see {@link StrokeStyle} For stroke style options
   * @see {@link FillGradient} For gradient strokes
   * @see {@link setStrokeStyle} For setting default stroke style
   */
  stroke(...args) {
    return this._callContextMethod("stroke", args);
  }
  texture(...args) {
    return this._callContextMethod("texture", args);
  }
  /**
   * Resets the current path. Any previous path and its commands are discarded and a new path is
   * started. This is typically called before beginning a new shape or series of drawing commands.
   * @example
   * ```ts
   * const graphics = new Graphics();
   * graphics
   *     .circle(150, 150, 50)
   *     .fill({ color: 0x00ff00 })
   *     .beginPath() // Starts a new path
   *     .circle(250, 150, 50)
   *     .fill({ color: 0x0000ff });
   * ```
   * @returns The Graphics instance for chaining
   * @see {@link Graphics#moveTo} For starting a new subpath
   * @see {@link Graphics#closePath} For closing the current path
   */
  beginPath() {
    return this._callContextMethod("beginPath", []);
  }
  /**
   * Applies a cutout to the last drawn shape. This is used to create holes or complex shapes by
   * subtracting a path from the previously drawn path.
   *
   * If a hole is not completely in a shape, it will fail to cut correctly.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Draw outer circle
   * graphics
   *     .circle(100, 100, 50)
   *     .fill({ color: 0xff0000 });
   *     .circle(100, 100, 25) // Inner circle
   *     .cut() // Cuts out the inner circle from the outer circle
   * ```
   */
  cut() {
    return this._callContextMethod("cut", []);
  }
  arc(...args) {
    return this._callContextMethod("arc", args);
  }
  arcTo(...args) {
    return this._callContextMethod("arcTo", args);
  }
  arcToSvg(...args) {
    return this._callContextMethod("arcToSvg", args);
  }
  bezierCurveTo(...args) {
    return this._callContextMethod("bezierCurveTo", args);
  }
  /**
   * Closes the current path by drawing a straight line back to the start point.
   *
   * This is useful for completing shapes and ensuring they are properly closed for fills.
   * @example
   * ```ts
   * // Create a triangle with closed path
   * const graphics = new Graphics();
   * graphics
   *     .moveTo(50, 50)
   *     .lineTo(100, 100)
   *     .lineTo(0, 100)
   *     .closePath()
   * ```
   * @returns The Graphics instance for method chaining
   * @see {@link Graphics#beginPath} For starting a new path
   * @see {@link Graphics#fill} For filling closed paths
   * @see {@link Graphics#stroke} For stroking paths
   */
  closePath() {
    return this._callContextMethod("closePath", []);
  }
  ellipse(...args) {
    return this._callContextMethod("ellipse", args);
  }
  circle(...args) {
    return this._callContextMethod("circle", args);
  }
  path(...args) {
    return this._callContextMethod("path", args);
  }
  lineTo(...args) {
    return this._callContextMethod("lineTo", args);
  }
  moveTo(...args) {
    return this._callContextMethod("moveTo", args);
  }
  quadraticCurveTo(...args) {
    return this._callContextMethod("quadraticCurveTo", args);
  }
  rect(...args) {
    return this._callContextMethod("rect", args);
  }
  roundRect(...args) {
    return this._callContextMethod("roundRect", args);
  }
  poly(...args) {
    return this._callContextMethod("poly", args);
  }
  regularPoly(...args) {
    return this._callContextMethod("regularPoly", args);
  }
  roundPoly(...args) {
    return this._callContextMethod("roundPoly", args);
  }
  roundShape(...args) {
    return this._callContextMethod("roundShape", args);
  }
  filletRect(...args) {
    return this._callContextMethod("filletRect", args);
  }
  chamferRect(...args) {
    return this._callContextMethod("chamferRect", args);
  }
  star(...args) {
    return this._callContextMethod("star", args);
  }
  svg(...args) {
    return this._callContextMethod("svg", args);
  }
  restore(...args) {
    return this._callContextMethod("restore", args);
  }
  /**
   * Saves the current graphics state onto a stack. The state includes:
   * - Current transformation matrix
   * - Current fill style
   * - Current stroke style
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Save state before complex operations
   * graphics.save();
   *
   * // Create transformed and styled shape
   * graphics
   *     .translateTransform(100, 100)
   *     .rotateTransform(Math.PI / 4)
   *     .setFillStyle({
   *         color: 0xff0000,
   *         alpha: 0.5
   *     })
   *     .rect(-25, -25, 50, 50)
   *     .fill();
   *
   * // Restore to original state
   * graphics.restore();
   *
   * // Continue drawing with previous state
   * graphics
   *     .circle(50, 50, 25)
   *     .fill();
   * ```
   * @returns The Graphics instance for method chaining
   * @see {@link Graphics#restore} For restoring the saved state
   * @see {@link Graphics#setTransform} For setting transformations
   */
  save() {
    return this._callContextMethod("save", []);
  }
  /**
   * Returns the current transformation matrix of the graphics context.
   * This matrix represents all accumulated transformations including translate, scale, and rotate.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Apply some transformations
   * graphics
   *     .translateTransform(100, 100)
   *     .rotateTransform(Math.PI / 4);
   *
   * // Get the current transform matrix
   * const matrix = graphics.getTransform();
   * console.log(matrix.tx, matrix.ty); // 100, 100
   *
   * // Use the matrix for other operations
   * graphics
   *     .setTransform(matrix)
   *     .circle(0, 0, 50)
   *     .fill({ color: 0xff0000 });
   * ```
   * @returns The current transformation matrix.
   * @see {@link Graphics#setTransform} For setting the transform matrix
   * @see {@link Matrix} For matrix operations
   */
  getTransform() {
    return this.context.getTransform();
  }
  /**
   * Resets the current transformation matrix to the identity matrix, effectively removing
   * any transformations (rotation, scaling, translation) previously applied.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Apply transformations
   * graphics
   *     .translateTransform(100, 100)
   *     .scaleTransform(2, 2)
   *     .circle(0, 0, 25)
   *     .fill({ color: 0xff0000 });
   * // Reset transform to default state
   * graphics
   *     .resetTransform()
   *     .circle(50, 50, 25) // Will draw at actual coordinates
   *     .fill({ color: 0x00ff00 });
   * ```
   * @returns The Graphics instance for method chaining
   * @see {@link Graphics#getTransform} For getting the current transform
   * @see {@link Graphics#setTransform} For setting a specific transform
   * @see {@link Graphics#save} For saving the current transform state
   * @see {@link Graphics#restore} For restoring a previous transform state
   */
  resetTransform() {
    return this._callContextMethod("resetTransform", []);
  }
  rotateTransform(...args) {
    return this._callContextMethod("rotate", args);
  }
  scaleTransform(...args) {
    return this._callContextMethod("scale", args);
  }
  setTransform(...args) {
    return this._callContextMethod("setTransform", args);
  }
  transform(...args) {
    return this._callContextMethod("transform", args);
  }
  translateTransform(...args) {
    return this._callContextMethod("translate", args);
  }
  /**
   * Clears all drawing commands from the graphics context, effectively resetting it.
   * This includes clearing the current path, fill style, stroke style, and transformations.
   *
   * > [!NOTE] Graphics objects are not designed to be continuously cleared and redrawn.
   * > Instead, they are intended to be used for static or semi-static graphics that
   * > can be redrawn as needed. Frequent clearing and redrawing may lead to performance issues.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Draw some shapes
   * graphics
   *     .circle(100, 100, 50)
   *     .fill({ color: 0xff0000 })
   *     .rect(200, 100, 100, 50)
   *     .fill({ color: 0x00ff00 });
   *
   * // Clear all graphics
   * graphics.clear();
   *
   * // Start fresh with new shapes
   * graphics
   *     .circle(150, 150, 30)
   *     .fill({ color: 0x0000ff });
   * ```
   * @returns The Graphics instance for method chaining
   * @see {@link Graphics#beginPath} For starting a new path without clearing styles
   * @see {@link Graphics#save} For saving the current state
   * @see {@link Graphics#restore} For restoring a previous state
   */
  clear() {
    return this._callContextMethod("clear", []);
  }
  /**
   * Gets or sets the current fill style for the graphics context. The fill style determines
   * how shapes are filled when using the fill() method.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Basic color fill
   * graphics.fillStyle = {
   *     color: 0xff0000,  // Red
   *     alpha: 1
   * };
   *
   * // Using gradients
   * const gradient = new FillGradient({
   *     end: { x: 0, y: 1 }, // Vertical gradient
   *     stops: [
   *         { offset: 0, color: 0xff0000, alpha: 1 }, // Start color
   *         { offset: 1, color: 0x0000ff, alpha: 1 }  // End color
   *     ]
   * });
   *
   * graphics.fillStyle = {
   *     fill: gradient,
   *     alpha: 0.8
   * };
   *
   * // Using patterns
   * graphics.fillStyle = {
   *     texture: myTexture,
   *     alpha: 1,
   *     matrix: new Matrix()
   *         .scale(0.5, 0.5)
   *         .rotate(Math.PI / 4)
   * };
   * ```
   * @type {ConvertedFillStyle}
   * @see {@link FillStyle} For all available fill style options
   * @see {@link FillGradient} For creating gradient fills
   * @see {@link Graphics#fill} For applying the fill to paths
   */
  get fillStyle() {
    return this._context.fillStyle;
  }
  set fillStyle(value) {
    this._context.fillStyle = value;
  }
  /**
   * Gets or sets the current stroke style for the graphics context. The stroke style determines
   * how paths are outlined when using the stroke() method.
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Basic stroke style
   * graphics.strokeStyle = {
   *     width: 2,
   *     color: 0xff0000,
   *     alpha: 1
   * };
   *
   * // Using with gradients
   * const gradient = new FillGradient({
   *   end: { x: 0, y: 1 },
   *   stops: [
   *       { offset: 0, color: 0xff0000, alpha: 1 },
   *       { offset: 1, color: 0x0000ff, alpha: 1 }
   *   ]
   * });
   *
   * graphics.strokeStyle = {
   *     width: 4,
   *     fill: gradient,
   *     alignment: 0.5,
   *     join: 'round',
   *     cap: 'round'
   * };
   *
   * // Complex stroke settings
   * graphics.strokeStyle = {
   *     width: 6,
   *     color: 0x00ff00,
   *     alpha: 0.5,
   *     join: 'miter',
   *     miterLimit: 10,
   * };
   * ```
   * @see {@link StrokeStyle} For all available stroke style options
   * @see {@link Graphics#stroke} For applying the stroke to paths
   */
  get strokeStyle() {
    return this._context.strokeStyle;
  }
  set strokeStyle(value) {
    this._context.strokeStyle = value;
  }
  /**
   * Creates a new Graphics object that copies the current graphics content.
   * The clone can either share the same context (shallow clone) or have its own independent
   * context (deep clone).
   * @example
   * ```ts
   * const graphics = new Graphics();
   *
   * // Create original graphics content
   * graphics
   *     .circle(100, 100, 50)
   *     .fill({ color: 0xff0000 });
   *
   * // Create a shallow clone (shared context)
   * const shallowClone = graphics.clone();
   *
   * // Changes to original affect the clone
   * graphics
   *     .circle(200, 100, 30)
   *     .fill({ color: 0x00ff00 });
   *
   * // Create a deep clone (independent context)
   * const deepClone = graphics.clone(true);
   *
   * // Modify deep clone independently
   * deepClone
   *     .translateTransform(100, 100)
   *     .circle(0, 0, 40)
   *     .fill({ color: 0x0000ff });
   * ```
   * @param deep - Whether to create a deep clone of the graphics object.
   *              If false (default), the context will be shared between objects.
   *              If true, creates an independent copy of the context.
   * @returns A new Graphics instance with either shared or copied context
   * @see {@link Graphics#context} For accessing the underlying graphics context
   * @see {@link GraphicsContext} For understanding the shared context behavior
   */
  clone(deep = false) {
    if (deep) {
      return new _Graphics(this._context.clone());
    }
    this._ownedContext = null;
    const clone = new _Graphics(this._context);
    return clone;
  }
  // -------- v7 deprecations ---------
  /**
   * @param width
   * @param color
   * @param alpha
   * @deprecated since 8.0.0 Use {@link Graphics#setStrokeStyle} instead
   */
  lineStyle(width, color, alpha) {
    deprecation(v8_0_0, "Graphics#lineStyle is no longer needed. Use Graphics#setStrokeStyle to set the stroke style.");
    const strokeStyle = {};
    width && (strokeStyle.width = width);
    color && (strokeStyle.color = color);
    alpha && (strokeStyle.alpha = alpha);
    this.context.strokeStyle = strokeStyle;
    return this;
  }
  /**
   * @param color
   * @param alpha
   * @deprecated since 8.0.0 Use {@link Graphics#fill} instead
   */
  beginFill(color, alpha) {
    deprecation(v8_0_0, "Graphics#beginFill is no longer needed. Use Graphics#fill to fill the shape with the desired style.");
    const fillStyle = {};
    if (color !== void 0) fillStyle.color = color;
    if (alpha !== void 0) fillStyle.alpha = alpha;
    this.context.fillStyle = fillStyle;
    return this;
  }
  /**
   * @deprecated since 8.0.0 Use {@link Graphics#fill} instead
   */
  endFill() {
    deprecation(v8_0_0, "Graphics#endFill is no longer needed. Use Graphics#fill to fill the shape with the desired style.");
    this.context.fill();
    const strokeStyle = this.context.strokeStyle;
    if (strokeStyle.width !== GraphicsContext.defaultStrokeStyle.width || strokeStyle.color !== GraphicsContext.defaultStrokeStyle.color || strokeStyle.alpha !== GraphicsContext.defaultStrokeStyle.alpha) {
      this.context.stroke();
    }
    return this;
  }
  /**
   * @param {...any} args
   * @deprecated since 8.0.0 Use {@link Graphics#circle} instead
   */
  drawCircle(...args) {
    deprecation(v8_0_0, "Graphics#drawCircle has been renamed to Graphics#circle");
    return this._callContextMethod("circle", args);
  }
  /**
   * @param {...any} args
   * @deprecated since 8.0.0 Use {@link Graphics#ellipse} instead
   */
  drawEllipse(...args) {
    deprecation(v8_0_0, "Graphics#drawEllipse has been renamed to Graphics#ellipse");
    return this._callContextMethod("ellipse", args);
  }
  /**
   * @param {...any} args
   * @deprecated since 8.0.0 Use {@link Graphics#poly} instead
   */
  drawPolygon(...args) {
    deprecation(v8_0_0, "Graphics#drawPolygon has been renamed to Graphics#poly");
    return this._callContextMethod("poly", args);
  }
  /**
   * @param {...any} args
   * @deprecated since 8.0.0 Use {@link Graphics#rect} instead
   */
  drawRect(...args) {
    deprecation(v8_0_0, "Graphics#drawRect has been renamed to Graphics#rect");
    return this._callContextMethod("rect", args);
  }
  /**
   * @param {...any} args
   * @deprecated since 8.0.0 Use {@link Graphics#roundRect} instead
   */
  drawRoundedRect(...args) {
    deprecation(v8_0_0, "Graphics#drawRoundedRect has been renamed to Graphics#roundRect");
    return this._callContextMethod("roundRect", args);
  }
  /**
   * @param {...any} args
   * @deprecated since 8.0.0 Use {@link Graphics#star} instead
   */
  drawStar(...args) {
    deprecation(v8_0_0, "Graphics#drawStar has been renamed to Graphics#star");
    return this._callContextMethod("star", args);
  }
};

// node_modules/pixi.js/lib/rendering/mask/stencil/CanvasStencilMaskPipe.mjs
function buildRoundedRectPath2(context, x, y, width, height, radius) {
  radius = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
  context.moveTo(x + radius, y);
  context.lineTo(x + width - radius, y);
  context.quadraticCurveTo(x + width, y, x + width, y + radius);
  context.lineTo(x + width, y + height - radius);
  context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  context.lineTo(x + radius, y + height);
  context.quadraticCurveTo(x, y + height, x, y + height - radius);
  context.lineTo(x, y + radius);
  context.quadraticCurveTo(x, y, x + radius, y);
}
function buildShapePath2(context, shape) {
  switch (shape.type) {
    case "rectangle": {
      const rect = shape;
      context.rect(rect.x, rect.y, rect.width, rect.height);
      break;
    }
    case "roundedRectangle": {
      const rect = shape;
      buildRoundedRectPath2(context, rect.x, rect.y, rect.width, rect.height, rect.radius);
      break;
    }
    case "circle": {
      const circle = shape;
      context.moveTo(circle.x + circle.radius, circle.y);
      context.arc(circle.x, circle.y, circle.radius, 0, Math.PI * 2);
      break;
    }
    case "ellipse": {
      const ellipse = shape;
      if (context.ellipse) {
        context.moveTo(ellipse.x + ellipse.halfWidth, ellipse.y);
        context.ellipse(ellipse.x, ellipse.y, ellipse.halfWidth, ellipse.halfHeight, 0, 0, Math.PI * 2);
      } else {
        context.save();
        context.translate(ellipse.x, ellipse.y);
        context.scale(ellipse.halfWidth, ellipse.halfHeight);
        context.moveTo(1, 0);
        context.arc(0, 0, 1, 0, Math.PI * 2);
        context.restore();
      }
      break;
    }
    case "triangle": {
      const tri = shape;
      context.moveTo(tri.x, tri.y);
      context.lineTo(tri.x2, tri.y2);
      context.lineTo(tri.x3, tri.y3);
      context.closePath();
      break;
    }
    case "polygon":
    default: {
      const poly = shape;
      const points = poly.points;
      if (!points?.length) break;
      context.moveTo(points[0], points[1]);
      for (let i = 2; i < points.length; i += 2) {
        context.lineTo(points[i], points[i + 1]);
      }
      if (poly.closePath) {
        context.closePath();
      }
      break;
    }
  }
}
function buildStrokeMaskPath(context, shape, strokeStyle) {
  const points = [];
  const vertices = [];
  const indices = [];
  const shapeBuilder = shapeBuilders[shape.type];
  if (!shapeBuilder?.build(shape, points)) return false;
  const close = shape.closePath ?? true;
  buildLine(points, strokeStyle, false, close, vertices, indices);
  for (let i = 0; i < indices.length; i += 3) {
    const i0 = indices[i] * 2;
    const i1 = indices[i + 1] * 2;
    const i2 = indices[i + 2] * 2;
    context.moveTo(vertices[i0], vertices[i0 + 1]);
    context.lineTo(vertices[i1], vertices[i1 + 1]);
    context.lineTo(vertices[i2], vertices[i2 + 1]);
    context.closePath();
  }
  return true;
}
function addHolePaths2(context, holes) {
  if (!holes?.length) return false;
  for (let i = 0; i < holes.length; i++) {
    const hole = holes[i];
    if (!hole?.shape) continue;
    const transform = hole.transform;
    const hasTransform = transform && !transform.isIdentity();
    if (hasTransform) {
      context.save();
      context.transform(transform.a, transform.b, transform.c, transform.d, transform.tx, transform.ty);
    }
    buildShapePath2(context, hole.shape);
    if (hasTransform) {
      context.restore();
    }
  }
  return true;
}
var CanvasStencilMaskPipe = class {
  constructor(renderer) {
    this._warnedMaskTypes = /* @__PURE__ */ new Set();
    this._canvasMaskStack = [];
    this._renderer = renderer;
  }
  push(mask, _container, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add({
      renderPipeId: "stencilMask",
      action: "pushMaskBegin",
      mask,
      inverse: _container._maskOptions.inverse,
      canBundle: false
    });
  }
  pop(_mask, _container, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add({
      renderPipeId: "stencilMask",
      action: "popMaskEnd",
      mask: _mask,
      inverse: _container._maskOptions.inverse,
      canBundle: false
    });
  }
  execute(instruction) {
    if (instruction.action !== "pushMaskBegin" && instruction.action !== "popMaskEnd") {
      return;
    }
    const canvasRenderer = this._renderer;
    const contextSystem = canvasRenderer.canvasContext;
    const context = contextSystem?.activeContext;
    if (!context) return;
    if (instruction.action === "popMaskEnd") {
      const didClip = this._canvasMaskStack.pop();
      if (didClip) {
        context.restore();
      }
      return;
    }
    if (instruction.inverse) {
      this._warnOnce(
        "inverse",
        "CanvasRenderer: inverse masks are not supported on Canvas2D; ignoring inverse flag."
      );
    }
    const maskContainer = instruction.mask.mask;
    if (!(maskContainer instanceof Graphics)) {
      this._warnOnce(
        "nonGraphics",
        "CanvasRenderer: only Graphics masks are supported in Canvas2D; skipping mask."
      );
      this._canvasMaskStack.push(false);
      return;
    }
    const graphics = maskContainer;
    const instructions = graphics.context?.instructions;
    if (!instructions?.length) {
      this._canvasMaskStack.push(false);
      return;
    }
    context.save();
    contextSystem.setContextTransform(
      graphics.groupTransform,
      (canvasRenderer._roundPixels | graphics._roundPixels) === 1
    );
    context.beginPath();
    let drewPath = false;
    let hasHoles = false;
    for (let i = 0; i < instructions.length; i++) {
      const instructionData = instructions[i];
      const action = instructionData.action;
      if (action !== "fill" && action !== "stroke") continue;
      const data = instructionData.data;
      const shapePath = data?.path?.shapePath;
      if (!shapePath?.shapePrimitives?.length) continue;
      const isStroke = action === "stroke";
      const shapePrimitives = shapePath.shapePrimitives;
      for (let j = 0; j < shapePrimitives.length; j++) {
        const primitive = shapePrimitives[j];
        if (!primitive?.shape) continue;
        const transform = primitive.transform;
        const hasTransform = transform && !transform.isIdentity();
        if (hasTransform) {
          context.save();
          context.transform(transform.a, transform.b, transform.c, transform.d, transform.tx, transform.ty);
        }
        if (isStroke && data.style) {
          drewPath = buildStrokeMaskPath(
            context,
            primitive.shape,
            data.style
          ) || drewPath;
        } else {
          buildShapePath2(context, primitive.shape);
          hasHoles = addHolePaths2(context, primitive.holes) || hasHoles;
          drewPath = true;
        }
        if (hasTransform) {
          context.restore();
        }
      }
    }
    if (!drewPath) {
      context.restore();
      this._canvasMaskStack.push(false);
      return;
    }
    if (hasHoles) {
      context.clip("evenodd");
    } else {
      context.clip();
    }
    this._canvasMaskStack.push(true);
  }
  destroy() {
    this._renderer = null;
    this._warnedMaskTypes = null;
    this._canvasMaskStack = null;
  }
  _warnOnce(key, message) {
    if (this._warnedMaskTypes.has(key)) return;
    this._warnedMaskTypes.add(key);
    warn(message);
  }
};
CanvasStencilMaskPipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "stencilMask"
};

// node_modules/pixi.js/lib/rendering/renderers/canvas/utils/mapCanvasBlendModesToPixi.mjs
var FALLBACK_BLEND = "source-over";
function mapCanvasBlendModesToPixi() {
  const supportsAdvanced = canUseNewCanvasBlendModes();
  const map = /* @__PURE__ */ Object.create(null);
  map.inherit = FALLBACK_BLEND;
  map.none = FALLBACK_BLEND;
  map.normal = "source-over";
  map.add = "lighter";
  map.multiply = supportsAdvanced ? "multiply" : FALLBACK_BLEND;
  map.screen = supportsAdvanced ? "screen" : FALLBACK_BLEND;
  map.overlay = supportsAdvanced ? "overlay" : FALLBACK_BLEND;
  map.darken = supportsAdvanced ? "darken" : FALLBACK_BLEND;
  map.lighten = supportsAdvanced ? "lighten" : FALLBACK_BLEND;
  map["color-dodge"] = supportsAdvanced ? "color-dodge" : FALLBACK_BLEND;
  map["color-burn"] = supportsAdvanced ? "color-burn" : FALLBACK_BLEND;
  map["hard-light"] = supportsAdvanced ? "hard-light" : FALLBACK_BLEND;
  map["soft-light"] = supportsAdvanced ? "soft-light" : FALLBACK_BLEND;
  map.difference = supportsAdvanced ? "difference" : FALLBACK_BLEND;
  map.exclusion = supportsAdvanced ? "exclusion" : FALLBACK_BLEND;
  map.saturation = supportsAdvanced ? "saturation" : FALLBACK_BLEND;
  map.color = supportsAdvanced ? "color" : FALLBACK_BLEND;
  map.luminosity = supportsAdvanced ? "luminosity" : FALLBACK_BLEND;
  map["linear-burn"] = supportsAdvanced ? "color-burn" : FALLBACK_BLEND;
  map["linear-dodge"] = supportsAdvanced ? "color-dodge" : FALLBACK_BLEND;
  map["linear-light"] = supportsAdvanced ? "hard-light" : FALLBACK_BLEND;
  map["pin-light"] = supportsAdvanced ? "hard-light" : FALLBACK_BLEND;
  map["vivid-light"] = supportsAdvanced ? "hard-light" : FALLBACK_BLEND;
  map["hard-mix"] = FALLBACK_BLEND;
  map.negation = supportsAdvanced ? "difference" : FALLBACK_BLEND;
  map["normal-npm"] = map.normal;
  map["add-npm"] = map.add;
  map["screen-npm"] = map.screen;
  map.erase = "destination-out";
  map.subtract = FALLBACK_BLEND;
  map.divide = FALLBACK_BLEND;
  map.min = FALLBACK_BLEND;
  map.max = FALLBACK_BLEND;
  return map;
}

// node_modules/pixi.js/lib/rendering/renderers/canvas/CanvasContextSystem.mjs
var tempMatrix2 = new Matrix();
var CanvasContextSystem = class {
  /**
   * @param renderer - The owning CanvasRenderer.
   */
  constructor(renderer) {
    this.activeResolution = 1;
    this.smoothProperty = "imageSmoothingEnabled";
    this.blendModes = mapCanvasBlendModesToPixi();
    this._activeBlendMode = "normal";
    this._projTransform = null;
    this._outerBlend = false;
    this._warnedBlendModes = /* @__PURE__ */ new Set();
    this._renderer = renderer;
  }
  resolutionChange(resolution) {
    this.activeResolution = resolution;
  }
  /** Initializes the root context and smoothing flag selection. */
  init() {
    const alpha = this._renderer.background.alpha < 1;
    this.rootContext = this._renderer.canvas.getContext(
      "2d",
      { alpha }
    );
    this.activeContext = this.rootContext;
    this.activeResolution = this._renderer.resolution;
    if (!this.rootContext.imageSmoothingEnabled) {
      const rc = this.rootContext;
      if (rc.webkitImageSmoothingEnabled) {
        this.smoothProperty = "webkitImageSmoothingEnabled";
      } else if (rc.mozImageSmoothingEnabled) {
        this.smoothProperty = "mozImageSmoothingEnabled";
      } else if (rc.oImageSmoothingEnabled) {
        this.smoothProperty = "oImageSmoothingEnabled";
      } else if (rc.msImageSmoothingEnabled) {
        this.smoothProperty = "msImageSmoothingEnabled";
      }
    }
  }
  /**
   * Sets the current transform on the active context.
   * @param transform - Transform to apply.
   * @param roundPixels - Whether to round translation to integers.
   * @param localResolution - Optional local resolution multiplier.
   * @param skipGlobalTransform - If true, skip applying the global world transform matrix.
   */
  setContextTransform(transform, roundPixels, localResolution, skipGlobalTransform) {
    const globalTransform = skipGlobalTransform ? Matrix.IDENTITY : this._renderer.globalUniforms.globalUniformData?.worldTransformMatrix || Matrix.IDENTITY;
    let mat = tempMatrix2;
    mat.copyFrom(globalTransform);
    mat.append(transform);
    const proj = this._projTransform;
    const contextResolution = this.activeResolution;
    localResolution = localResolution || contextResolution;
    if (proj) {
      const finalMat = Matrix.shared;
      finalMat.copyFrom(mat);
      finalMat.prepend(proj);
      mat = finalMat;
    }
    if (roundPixels) {
      this.activeContext.setTransform(
        mat.a * localResolution,
        mat.b * localResolution,
        mat.c * localResolution,
        mat.d * localResolution,
        mat.tx * contextResolution | 0,
        mat.ty * contextResolution | 0
      );
    } else {
      this.activeContext.setTransform(
        mat.a * localResolution,
        mat.b * localResolution,
        mat.c * localResolution,
        mat.d * localResolution,
        mat.tx * contextResolution,
        mat.ty * contextResolution
      );
    }
  }
  /**
   * Clears the current render target, optionally filling with a color.
   * @param clearColor - Color to fill after clearing.
   * @param alpha - Alpha override for the clear color.
   */
  clear(clearColor, alpha) {
    const context = this.activeContext;
    const renderer = this._renderer;
    context.clearRect(0, 0, renderer.width, renderer.height);
    if (clearColor) {
      const color = Color.shared.setValue(clearColor);
      context.globalAlpha = alpha ?? color.alpha;
      context.fillStyle = color.toHex();
      context.fillRect(0, 0, renderer.width, renderer.height);
      context.globalAlpha = 1;
    }
  }
  /**
   * Sets the active blend mode.
   * @param blendMode - Pixi blend mode.
   */
  setBlendMode(blendMode) {
    if (this._activeBlendMode === blendMode) return;
    this._activeBlendMode = blendMode;
    this._outerBlend = false;
    const mappedBlend = this.blendModes[blendMode];
    if (!mappedBlend) {
      if (!this._warnedBlendModes.has(blendMode)) {
        console.warn(
          `CanvasRenderer: blend mode "${blendMode}" is not supported in Canvas2D; falling back to "source-over".`
        );
        this._warnedBlendModes.add(blendMode);
      }
      this.activeContext.globalCompositeOperation = "source-over";
      return;
    }
    this.activeContext.globalCompositeOperation = mappedBlend;
  }
  /** Releases context references. */
  destroy() {
    this.rootContext = null;
    this.activeContext = null;
    this._warnedBlendModes.clear();
  }
};
CanvasContextSystem.extension = {
  type: [
    ExtensionType.CanvasSystem
  ],
  name: "canvasContext"
};

// node_modules/pixi.js/lib/rendering/renderers/canvas/CanvasLimitsSystem.mjs
var CanvasLimitsSystem = class {
  constructor() {
    this.maxTextures = 16;
    this.maxBatchableTextures = 16;
    this.maxUniformBindings = 0;
  }
  init() {
  }
};
CanvasLimitsSystem.extension = {
  type: [
    ExtensionType.CanvasSystem
  ],
  name: "limits"
};

// node_modules/pixi.js/lib/rendering/renderers/canvas/renderTarget/CanvasRenderTargetAdaptor.mjs
var CanvasRenderTargetAdaptor = class {
  /**
   * Initializes the adaptor.
   * @param renderer - Canvas renderer instance.
   * @param renderTargetSystem - The render target system.
   * @advanced
   */
  init(renderer, renderTargetSystem) {
    this._renderer = renderer;
    this._renderTargetSystem = renderTargetSystem;
  }
  /**
   * Creates a GPU render target for canvas.
   * @param renderTarget - Render target to initialize.
   * @advanced
   */
  initGpuRenderTarget(renderTarget) {
    const colorTexture = renderTarget.colorTexture;
    const { canvas, context } = this._ensureCanvas(colorTexture);
    return {
      canvas,
      context,
      width: canvas.width,
      height: canvas.height
    };
  }
  /**
   * Resizes the backing canvas for a render target.
   * @param renderTarget - Render target to resize.
   * @advanced
   */
  resizeGpuRenderTarget(renderTarget) {
    const colorTexture = renderTarget.colorTexture;
    const { canvas } = this._ensureCanvas(colorTexture);
    canvas.width = renderTarget.pixelWidth;
    canvas.height = renderTarget.pixelHeight;
  }
  /**
   * Starts a render pass on the canvas target.
   * @param renderTarget - Target to render to.
   * @param clear - Clear mode.
   * @param clearColor - Optional clear color.
   * @param viewport - Optional viewport.
   * @advanced
   */
  startRenderPass(renderTarget, clear, clearColor, viewport) {
    const gpuRenderTarget = this._renderTargetSystem.getGpuRenderTarget(renderTarget);
    this._renderer.canvasContext.activeContext = gpuRenderTarget.context;
    this._renderer.canvasContext.activeResolution = renderTarget.resolution;
    if (clear) {
      this.clear(renderTarget, clear, clearColor, viewport);
    }
  }
  /**
   * Clears the render target.
   * @param renderTarget - Target to clear.
   * @param _clear - Clear mode (unused).
   * @param clearColor - Optional clear color.
   * @param viewport - Optional viewport rectangle.
   * @advanced
   */
  clear(renderTarget, _clear, clearColor, viewport) {
    const gpuRenderTarget = this._renderTargetSystem.getGpuRenderTarget(renderTarget);
    const context = gpuRenderTarget.context;
    const bounds = viewport || { x: 0, y: 0, width: renderTarget.pixelWidth, height: renderTarget.pixelHeight };
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.clearRect(bounds.x, bounds.y, bounds.width, bounds.height);
    if (clearColor) {
      const color = Color.shared.setValue(clearColor);
      if (color.alpha > 0) {
        context.globalAlpha = color.alpha;
        context.fillStyle = color.toHex();
        context.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
        context.globalAlpha = 1;
      }
    }
  }
  /**
   * Finishes the render pass (no-op for canvas).
   * @advanced
   */
  finishRenderPass() {
  }
  /**
   * Copies a render target into a texture source.
   * @param {RenderTarget} sourceRenderSurfaceTexture - Source render target.
   * @param {Texture} destinationTexture - Destination texture.
   * @param {object} originSrc - Source origin.
   * @param {number} originSrc.x - Source x origin.
   * @param {number} originSrc.y - Source y origin.
   * @param {object} size - Copy size.
   * @param {number} size.width - Copy width.
   * @param {number} size.height - Copy height.
   * @param {object} [originDest] - Destination origin.
   * @param {number} originDest.x - Destination x origin.
   * @param {number} originDest.y - Destination y origin.
   * @advanced
   */
  copyToTexture(sourceRenderSurfaceTexture, destinationTexture, originSrc, size, originDest) {
    const sourceGpuTarget = this._renderTargetSystem.getGpuRenderTarget(sourceRenderSurfaceTexture);
    const sourceCanvas = sourceGpuTarget.canvas;
    const destSource = destinationTexture.source;
    const { context } = this._ensureCanvas(destSource);
    const dx = originDest?.x ?? 0;
    const dy = originDest?.y ?? 0;
    context.drawImage(
      sourceCanvas,
      originSrc.x,
      originSrc.y,
      size.width,
      size.height,
      dx,
      dy,
      size.width,
      size.height
    );
    destSource.update();
    return destinationTexture;
  }
  /**
   * Copies the depth attachment of a render target into a texture (not supported in canvas).
   * @param _source - Source render target.
   * @param _destination - Destination depth/stencil texture.
   * @param _originSrc - Source origin of the copy.
   * @param _originSrc.x
   * @param _originSrc.y
   * @param _size - Size of the copy.
   * @param _size.width
   * @param _size.height
   * @param _originDest - Destination origin of the copy.
   * @param _originDest.x
   * @param _originDest.y
   * @advanced
   */
  copyDepthTexture(_source, _destination, _originSrc, _size, _originDest) {
    warn("[CanvasRenderTargetAdaptor] copyDepthTexture is not supported in the canvas renderer");
  }
  /**
   * Destroys a GPU render target (no-op for canvas).
   * @param _gpuRenderTarget - Target to destroy.
   * @advanced
   */
  destroyGpuRenderTarget(_gpuRenderTarget) {
  }
  _ensureCanvas(source) {
    let canvas = source.resource;
    if (!canvas || !CanvasSource.test(canvas)) {
      canvas = DOMAdapter.get().createCanvas(source.pixelWidth, source.pixelHeight);
      source.resource = canvas;
    }
    if (canvas.width !== source.pixelWidth || canvas.height !== source.pixelHeight) {
      canvas.width = source.pixelWidth;
      canvas.height = source.pixelHeight;
    }
    const context = canvas.getContext("2d");
    return { canvas, context };
  }
};

// node_modules/pixi.js/lib/rendering/renderers/canvas/renderTarget/CanvasRenderTargetSystem.mjs
var CanvasRenderTargetSystem = class extends RenderTargetSystem {
  constructor(renderer) {
    super(renderer);
    this.adaptor = new CanvasRenderTargetAdaptor();
    this.adaptor.init(renderer, this);
  }
};
CanvasRenderTargetSystem.extension = {
  type: [ExtensionType.CanvasSystem],
  name: "renderTarget"
};

// node_modules/pixi.js/lib/rendering/renderers/canvas/texture/CanvasTextureSystem.mjs
var CanvasTextureSystem = class {
  /**
   * @param renderer - The owning CanvasRenderer.
   */
  constructor(renderer) {
    void renderer;
  }
  /** Initializes the system (no-op for canvas). */
  init() {
  }
  /**
   * Initializes a texture source (no-op for canvas).
   * @param _source - Texture source.
   */
  initSource(_source) {
  }
  /**
   * Creates a canvas containing the texture's frame.
   * @param texture - Texture to render.
   */
  generateCanvas(texture) {
    const canvas = DOMAdapter.get().createCanvas();
    const context = canvas.getContext("2d");
    const source = canvasUtils.getCanvasSource(texture);
    if (!source) {
      return canvas;
    }
    const frame = texture.frame;
    const resolution = texture.source._resolution ?? texture.source.resolution ?? 1;
    const sx = frame.x * resolution;
    const sy = frame.y * resolution;
    const sw = frame.width * resolution;
    const sh = frame.height * resolution;
    canvas.width = Math.ceil(sw);
    canvas.height = Math.ceil(sh);
    context.drawImage(
      source,
      sx,
      sy,
      sw,
      sh,
      0,
      0,
      sw,
      sh
    );
    return canvas;
  }
  /**
   * Reads pixel data from a texture.
   * @param texture - Texture to read.
   */
  getPixels(texture) {
    const canvas = this.generateCanvas(texture);
    const context = canvas.getContext("2d", { willReadFrequently: true });
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    return {
      pixels: imageData.data,
      width: canvas.width,
      height: canvas.height
    };
  }
  /** Destroys the system (no-op for canvas). */
  destroy() {
  }
};
CanvasTextureSystem.extension = {
  type: [
    ExtensionType.CanvasSystem
  ],
  name: "texture"
};

// node_modules/pixi.js/lib/rendering/renderers/canvas/CanvasRenderer.mjs
var DefaultCanvasSystems = [
  ...SharedSystems,
  CanvasContextSystem,
  CanvasLimitsSystem,
  CanvasTextureSystem,
  CanvasRenderTargetSystem
];
var DefaultCanvasPipes = [
  BlendModePipe,
  BatcherPipe,
  SpritePipe,
  RenderGroupPipe,
  AlphaMaskPipe,
  CanvasStencilMaskPipe,
  CanvasColorMaskPipe,
  CustomRenderPipe
];
var DefaultCanvasAdapters = [
  CanvasBatchAdaptor,
  CanvasGraphicsAdaptor
];
var systems = [];
var renderPipes = [];
var renderPipeAdaptors = [];
var loaders = [];
extensions.handleByNamedList(ExtensionType.CanvasSystem, systems);
extensions.handleByNamedList(ExtensionType.CanvasPipes, renderPipes);
extensions.handleByNamedList(ExtensionType.CanvasPipesAdaptor, renderPipeAdaptors);
extensions.handleByNamedList(ExtensionType.CanvasLoader, loaders);
extensions.add(...DefaultCanvasSystems, ...DefaultCanvasPipes, ...DefaultCanvasAdapters);
var CanvasRenderer = class extends AbstractRenderer {
  constructor() {
    const systemConfig = {
      name: "canvas",
      type: RendererType.CANVAS,
      systems,
      renderPipes,
      renderPipeAdaptors,
      loaders
    };
    super(systemConfig);
  }
};

export {
  CanvasGraphicsAdaptor,
  CanvasBatchAdaptor,
  CanvasColorMaskPipe,
  CanvasGraphicsContextSystem,
  CanvasGraphicsPipe,
  GraphicsGpuData,
  GraphicsPipe,
  Graphics,
  CanvasStencilMaskPipe,
  mapCanvasBlendModesToPixi,
  CanvasContextSystem,
  CanvasLimitsSystem,
  CanvasRenderTargetAdaptor,
  CanvasRenderTargetSystem,
  CanvasTextureSystem,
  CanvasRenderer
};
//# sourceMappingURL=chunk-P6WOYLNL.js.map
