import {
  AccessibilitySystem,
  CanvasObserver,
  DOMContainer,
  DOMPipe,
  EventBoundary,
  EventSystem,
  EventsTicker,
  FederatedContainer,
  FederatedEvent,
  FederatedMouseEvent,
  FederatedPointerEvent,
  FederatedWheelEvent,
  accessibilityTarget,
  isMobile
} from "./chunk-EYAHMOIP.js";
import {
  AlphaMask,
  CanvasFilterSystem,
  ColorMask,
  FilterPipe,
  FilterSystem,
  LoaderParserPriority,
  PassthroughFilter,
  Resolver,
  Spritesheet,
  StencilMask,
  Triangle,
  VideoSource,
  addMaskBounds,
  addMaskLocalBounds,
  autoDetectSource,
  copySearchParams,
  createStringVariations,
  detectVideoAlphaMode,
  fragment,
  getGlobalRenderableBounds,
  getPo2TextureFromSource,
  getUrlExtension,
  isCanvasFilterCapable,
  isSingleItem,
  path,
  pointInTriangle,
  resourceToTexture,
  source,
  spritesheetAsset,
  textureFrom,
  vertex
} from "./chunk-2TIJWRQZ.js";
import {
  BindGroupSystem,
  GPUTextureGpuData,
  Gpu3dMipmapGenerator,
  GpuBatchAdaptor,
  GpuBlendModesToPixi,
  GpuBufferData,
  GpuBufferSystem,
  GpuColorMaskSystem,
  GpuDeviceSystem,
  GpuEncoderSystem,
  GpuGraphicsAdaptor,
  GpuLimitsSystem,
  GpuMeshAdapter,
  GpuMipmapGenerator,
  GpuMsaaRestore,
  GpuRenderTarget,
  GpuRenderTargetAdaptor,
  GpuRenderTargetSystem,
  GpuShaderSystem,
  GpuStateSystem,
  GpuStencilSystem,
  GpuTextureSystem,
  GpuUboSystem,
  GpuUniformBatchPipe,
  PipelineSystem,
  RenderBundle,
  UboBatch,
  WGSL_ALIGN_SIZE_DATA,
  WebGPURenderer,
  assertMipmap3dTexture,
  bakeOverridesIntoSource,
  blockDataMap,
  createGpuUploadCubeTextureResource,
  createUboElementsWGSL,
  createUboSyncFunctionWGSL,
  generateArraySyncWGSL,
  gpuUploadBufferImageResource,
  gpuUploadCompressedTextureResource,
  gpuUploadImageResource,
  gpuUploadVideoResource
} from "./chunk-JTBH3JLP.js";
import {
  BUFFER_TYPE,
  GL_FORMATS,
  GL_TARGETS,
  GL_TYPES,
  GL_WRAP_MODES,
  GlBackBufferSystem,
  GlBatchAdaptor,
  GlBuffer,
  GlBufferSystem,
  GlColorMaskSystem,
  GlContextSystem,
  GlEncoderSystem,
  GlGeometryGpuData,
  GlGeometrySystem,
  GlGraphicsAdaptor,
  GlLimitsSystem,
  GlMeshAdaptor,
  GlProgramData,
  GlRenderTarget,
  GlRenderTargetAdaptor,
  GlRenderTargetSystem,
  GlShaderSystem,
  GlStateSystem,
  GlStencilSystem,
  GlTexture,
  GlTextureSystem,
  GlUboSystem,
  GlUniformGroupSystem,
  IGLUniformData,
  TextureView,
  UNIFORM_TO_ARRAY_SETTERS,
  UNIFORM_TO_SINGLE_SETTERS,
  WGSL_TO_STD40_SIZE,
  WebGLRenderer,
  applyStyleParams,
  compareModeToGlCompare,
  compileShader,
  createGlUploadCubeTextureResource,
  createUboElementsSTD40,
  createUboSyncFunctionSTD40,
  defaultValue,
  extractAttributesFromGlProgram,
  generateArraySyncSTD40,
  generateProgram,
  generateShaderSyncCode,
  generateUniformsSync,
  getGlTypeFromFormat,
  getUboData,
  getUniformData,
  glUploadBufferImageResource,
  glUploadCompressedTextureResource,
  glUploadImageResource,
  glUploadVideoResource,
  isSafari,
  logProgramError,
  mapFormatToGlFormat,
  mapFormatToGlInternalFormat,
  mapFormatToGlType,
  mapGlToVertexFormat,
  mapType,
  mapViewDimensionToGlTarget,
  mapWebGLBlendModesToPixi,
  mipmapScaleModeToGlFilter,
  scaleModeToGlFilter,
  unpremultiplyAlpha,
  wrapModeToGlAddress
} from "./chunk-PW4ZLAFG.js";
import {
  BufferResource,
  GpuStencilModesToPixi,
  UboSystem,
  compileBufferSync,
  ensureAttributes,
  getTexelRangeRects,
  localUniformBit,
  localUniformBitGl,
  localUniformBitGroup2,
  textureBit,
  textureBitGl,
  uboSyncFunctionsSTD40,
  uboSyncFunctionsWGSL,
  uniformParsers
} from "./chunk-P4Q4RSHI.js";
import {
  CanvasBatchAdaptor,
  CanvasColorMaskPipe,
  CanvasContextSystem,
  CanvasGraphicsAdaptor,
  CanvasGraphicsContextSystem,
  CanvasGraphicsPipe,
  CanvasLimitsSystem,
  CanvasRenderTargetAdaptor,
  CanvasRenderTargetSystem,
  CanvasRenderer,
  CanvasStencilMaskPipe,
  CanvasTextureSystem,
  Graphics,
  GraphicsGpuData,
  GraphicsPipe,
  mapCanvasBlendModesToPixi
} from "./chunk-P6WOYLNL.js";
import {
  AbstractRenderer,
  AlphaMaskPipe,
  ApplicationInitHook,
  BackgroundSystem,
  BatchableSprite,
  BatcherPipe,
  BlendModePipe,
  CLEAR,
  ColorMaskPipe,
  CustomRenderPipe,
  DATA_URI,
  ExtractSystem,
  GCSystem,
  GenerateTextureSystem,
  GlobalUniformSystem,
  HelloSystem,
  MaskFilter,
  RenderGroupPipe,
  RenderGroupSystem,
  RenderTarget,
  RenderTargetSystem,
  RenderTexture,
  RenderableGCSystem,
  RendererInitHook,
  SchedulerSystem,
  SharedRenderPipes,
  SharedSystems,
  SpritePipe,
  StencilMaskPipe,
  SystemRunner,
  TextureGCSystem,
  VERSION,
  ViewSystem,
  autoDetectEnvironment,
  calculateProjection,
  cleanArray,
  cleanHash,
  clearList,
  color32BitToUniform,
  colorToUniform,
  executeInstructions,
  fragment as fragment2,
  getCanvasTexture,
  hasCachedCanvasTexture,
  isRenderingToScreen,
  loadEnvironmentExtensions,
  sayHello,
  source as source2,
  unsafeEvalSupported,
  updateRenderGroupTransform,
  updateRenderGroupTransforms,
  updateTransformAndChildren,
  validateRenderables,
  vertex as vertex2
} from "./chunk-C7R4GKG4.js";
import {
  CanvasSource,
  Container,
  Filter,
  FilterEffect,
  MaskEffectManager,
  MaskEffectManagerClass,
  ObservablePoint,
  RenderGroup,
  STATE_BITS,
  Sprite,
  State,
  TexturePool,
  TexturePoolClass,
  Ticker,
  TickerListener,
  UPDATE_BLEND,
  UPDATE_COLOR,
  UPDATE_PRIORITY,
  UPDATE_TRANSFORM,
  UPDATE_VISIBLE,
  ViewContainer,
  assignWithIgnore,
  bgr2rgb,
  boundsPool,
  cacheAsTextureMixin,
  checkChildrenDidChange,
  childrenHelperMixin,
  collectRenderablesMixin,
  cullingMixin,
  effectsMixin,
  findMixin,
  getFastGlobalBoundsMixin,
  getGlobalBounds,
  getGlobalMixin,
  getLocalBounds,
  matrixPool,
  measureMixin,
  multiplyColors,
  onRenderMixin,
  removeItems,
  sortMixin,
  toLocalGlobalMixin,
  updateQuadBounds,
  updateTransformBackwards
} from "./chunk-RSU6N5IH.js";
import {
  AbstractBitmapFont,
  BREAKING_SPACES,
  BREAKING_SPACES_SET,
  BREAK_AFTER_CHARS,
  BREAK_AFTER_CHARS_SET,
  BitmapFont,
  BitmapFontManager,
  COLLAPSIBLE_SPACES,
  COLLAPSIBLE_SPACES_SET,
  CanvasTextMetrics,
  DynamicBitmapFont,
  NEWLINES,
  NEWLINES_SET,
  NEWLINE_MATCH_REGEX,
  NEWLINE_SPLIT_REGEX,
  TextStyle,
  collapseNewlines,
  collapseSpaces,
  fontStringFromTextStyle,
  getBitmapTextLayout,
  getCanvasFillStyle,
  getCharacterGroups,
  getPlainText,
  hasTagMarkup,
  hasTagStyles,
  isBreakAfterChar,
  isBreakingSpace,
  isCollapsibleSpace,
  isNewline,
  measureTaggedText,
  parseTaggedText,
  resolveCharacters,
  tokenize,
  tokenizeTaggedRuns,
  trimRight,
  wordWrap,
  wordWrapTaggedLines
} from "./chunk-TH4WA54N.js";
import {
  Cache,
  convertToList
} from "./chunk-A5DJO54Z.js";
import {
  BatchableGraphics,
  FillGradient,
  FillPattern,
  GpuGraphicsContext,
  GraphicsContext,
  GraphicsContextRenderData,
  GraphicsContextSystem,
  GraphicsPath,
  SVGParser,
  ShapePath,
  appendSVGPath,
  buildAdaptiveBezier,
  buildAdaptiveQuadratic,
  buildArc,
  buildArcTo,
  buildArcToSvg,
  buildCircle,
  buildContextBatches,
  buildEllipse,
  buildLine,
  buildPixelLine,
  buildPolygon,
  buildRectangle,
  buildRoundedRectangle,
  buildSimpleUvs,
  buildTriangle,
  buildUvs,
  calculatePathArea,
  checkForNestedPattern,
  closePointEps,
  curveEps,
  extractSubpaths,
  extractSvgUrlId,
  generateTextureMatrix,
  getFillInstructionData,
  getMaxMiterRatio,
  parseSVGDefinitions,
  parseSVGFloatAttribute,
  parseSVGPath,
  parseSVGStyle,
  roundedShapeArc,
  roundedShapeQuadraticCurve,
  shapeBuilders,
  styleAttributes,
  toFillStyle,
  toStrokeStyle,
  transformVertices,
  triangulateWithHoles
} from "./chunk-MGJ7YREG.js";
import {
  Circle,
  Ellipse,
  ImageSource,
  Polygon,
  RoundedRectangle,
  canUseNewCanvasBlendModes,
  canvasUtils,
  getOrientationOfPoints,
  squaredDistanceToLineSegment
} from "./chunk-DBITZEUE.js";
import {
  getTextureBatchBindGroup
} from "./chunk-RBG5Z5MZ.js";
import {
  BLEND_TO_NPM,
  Batch,
  BatchGeometry,
  BatchTextureArray,
  Batcher,
  DefaultBatcher,
  DefaultShader,
  GCManagedHash,
  STENCIL_MODES,
  ViewableBuffer,
  addBits,
  checkMaxIfStatementsInShader,
  colorBit,
  colorBitGl,
  compileHighShader,
  compileHighShaderGl,
  compileHighShaderGlProgram,
  compileHighShaderGpuProgram,
  compileHooks,
  compileInputs,
  compileOutputs,
  earcut,
  fastCopy,
  fragmentGPUTemplate,
  fragmentGlTemplate,
  generateTextureBatchBit,
  generateTextureBatchBitGl,
  getAdjustedBlendModeBlend,
  getBatchSamplersUniformGroup,
  getMaxTexturesPerBatch,
  globalUniformsBit,
  globalUniformsBitGl,
  globalUniformsUBOBitGl,
  injectBits,
  roundPixelsBit,
  roundPixelsBitGl,
  vertexGPUTemplate,
  vertexGlTemplate
} from "./chunk-XZ3F7MYX.js";
import {
  BigPool,
  BindGroup,
  Bounds,
  BrowserAdapter,
  Buffer,
  BufferImageSource,
  BufferUsage,
  CanvasPool,
  CanvasPoolClass,
  Color,
  DEG_TO_RAD,
  DOMAdapter,
  ExtensionType,
  Geometry,
  GlProgram,
  GlobalResourceRegistry,
  GpuProgram,
  InstructionSet,
  Matrix,
  NOOP,
  PI_2,
  Point,
  Pool,
  PoolGroupClass,
  RAD_TO_DEG,
  Rectangle,
  RendererType,
  ScreenSizeRegistry,
  Shader,
  ShaderOverrides,
  ShaderStage,
  Texture,
  TextureMatrix,
  TextureSource,
  TextureStyle,
  UNIFORM_TYPES_MAP,
  UNIFORM_TYPES_VALUES,
  UniformGroup,
  addProgramDefines,
  createIdFromString,
  definedProps,
  deprecation,
  ensureIsBuffer,
  ensurePrecision,
  eventemitter3_default,
  extensions,
  extractAttributesFromGpuProgram,
  extractStructAndGroups,
  generateGpuLayoutGroups,
  generateLayoutHash,
  getAttributeInfoFromFormat,
  getDefaultUniformValue,
  getGeometryBounds,
  getMaxFragmentPrecision,
  getTestContext,
  groupD8,
  insertVersion,
  isIntegerFormat,
  isPow2,
  log2,
  multiplyHexColors,
  nextPow2,
  normalizeExtensionPriority,
  removeStructAndGroupDuplicates,
  resetUids,
  setProgramName,
  stripVersion,
  uid,
  v8_0_0,
  v8_21_0,
  v8_22_0,
  v8_3_4,
  warn
} from "./chunk-YC5XMVVP.js";
import {
  __async,
  __commonJS,
  __objRest,
  __spreadProps,
  __spreadValues,
  __toESM
} from "./chunk-I6DCS273.js";

// node_modules/@xmldom/xmldom/lib/conventions.js
var require_conventions = __commonJS({
  "node_modules/@xmldom/xmldom/lib/conventions.js"(exports) {
    "use strict";
    function find(list, predicate, ac) {
      if (ac === void 0) {
        ac = Array.prototype;
      }
      if (list && typeof ac.find === "function") {
        return ac.find.call(list, predicate);
      }
      for (var i = 0; i < list.length; i++) {
        if (Object.prototype.hasOwnProperty.call(list, i)) {
          var item = list[i];
          if (predicate.call(void 0, item, i, list)) {
            return item;
          }
        }
      }
    }
    function freeze(object, oc) {
      if (oc === void 0) {
        oc = Object;
      }
      return oc && typeof oc.freeze === "function" ? oc.freeze(object) : object;
    }
    function assign(target, source8) {
      if (target === null || typeof target !== "object") {
        throw new TypeError("target is not an object");
      }
      for (var key in source8) {
        if (Object.prototype.hasOwnProperty.call(source8, key)) {
          target[key] = source8[key];
        }
      }
      return target;
    }
    var MIME_TYPE = freeze({
      /**
       * `text/html`, the only mime type that triggers treating an XML document as HTML.
       *
       * @see DOMParser.SupportedType.isHTML
       * @see https://www.iana.org/assignments/media-types/text/html IANA MimeType registration
       * @see https://en.wikipedia.org/wiki/HTML Wikipedia
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMParser/parseFromString MDN
       * @see https://html.spec.whatwg.org/multipage/dynamic-markup-insertion.html#dom-domparser-parsefromstring WHATWG HTML Spec
       */
      HTML: "text/html",
      /**
       * Helper method to check a mime type if it indicates an HTML document
       *
       * @param {string} [value]
       * @returns {boolean}
       *
       * @see https://www.iana.org/assignments/media-types/text/html IANA MimeType registration
       * @see https://en.wikipedia.org/wiki/HTML Wikipedia
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMParser/parseFromString MDN
       * @see https://html.spec.whatwg.org/multipage/dynamic-markup-insertion.html#dom-domparser-parsefromstring 	 */
      isHTML: function(value) {
        return value === MIME_TYPE.HTML;
      },
      /**
       * `application/xml`, the standard mime type for XML documents.
       *
       * @see https://www.iana.org/assignments/media-types/application/xml IANA MimeType registration
       * @see https://tools.ietf.org/html/rfc7303#section-9.1 RFC 7303
       * @see https://en.wikipedia.org/wiki/XML_and_MIME Wikipedia
       */
      XML_APPLICATION: "application/xml",
      /**
       * `text/html`, an alias for `application/xml`.
       *
       * @see https://tools.ietf.org/html/rfc7303#section-9.2 RFC 7303
       * @see https://www.iana.org/assignments/media-types/text/xml IANA MimeType registration
       * @see https://en.wikipedia.org/wiki/XML_and_MIME Wikipedia
       */
      XML_TEXT: "text/xml",
      /**
       * `application/xhtml+xml`, indicates an XML document that has the default HTML namespace,
       * but is parsed as an XML document.
       *
       * @see https://www.iana.org/assignments/media-types/application/xhtml+xml IANA MimeType registration
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-createdocument WHATWG DOM Spec
       * @see https://en.wikipedia.org/wiki/XHTML Wikipedia
       */
      XML_XHTML_APPLICATION: "application/xhtml+xml",
      /**
       * `image/svg+xml`,
       *
       * @see https://www.iana.org/assignments/media-types/image/svg+xml IANA MimeType registration
       * @see https://www.w3.org/TR/SVG11/ W3C SVG 1.1
       * @see https://en.wikipedia.org/wiki/Scalable_Vector_Graphics Wikipedia
       */
      XML_SVG_IMAGE: "image/svg+xml"
    });
    var NAMESPACE = freeze({
      /**
       * The XHTML namespace.
       *
       * @see http://www.w3.org/1999/xhtml
       */
      HTML: "http://www.w3.org/1999/xhtml",
      /**
       * Checks if `uri` equals `NAMESPACE.HTML`.
       *
       * @param {string} [uri]
       *
       * @see NAMESPACE.HTML
       */
      isHTML: function(uri) {
        return uri === NAMESPACE.HTML;
      },
      /**
       * The SVG namespace.
       *
       * @see http://www.w3.org/2000/svg
       */
      SVG: "http://www.w3.org/2000/svg",
      /**
       * The `xml:` namespace.
       *
       * @see http://www.w3.org/XML/1998/namespace
       */
      XML: "http://www.w3.org/XML/1998/namespace",
      /**
       * The `xmlns:` namespace
       *
       * @see https://www.w3.org/2000/xmlns/
       */
      XMLNS: "http://www.w3.org/2000/xmlns/"
    });
    var nameStartChar = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
    var nameChar = new RegExp("[\\-\\.0-9" + nameStartChar.source.slice(1, -1) + "\\u00B7\\u0300-\\u036F\\u203F-\\u2040]");
    var tagNamePattern = new RegExp("^" + nameStartChar.source + nameChar.source + "*(?::" + nameStartChar.source + nameChar.source + "*)?$");
    exports.assign = assign;
    exports.find = find;
    exports.freeze = freeze;
    exports.MIME_TYPE = MIME_TYPE;
    exports.NAMESPACE = NAMESPACE;
    exports.nameStartChar = nameStartChar;
    exports.nameChar = nameChar;
    exports.tagNamePattern = tagNamePattern;
  }
});

// node_modules/@xmldom/xmldom/lib/dom.js
var require_dom = __commonJS({
  "node_modules/@xmldom/xmldom/lib/dom.js"(exports) {
    var conventions = require_conventions();
    var find = conventions.find;
    var NAMESPACE = conventions.NAMESPACE;
    var tagNamePattern = conventions.tagNamePattern;
    function notEmptyString(input) {
      return input !== "";
    }
    function splitOnASCIIWhitespace(input) {
      return input ? input.split(/[\t\n\f\r ]+/).filter(notEmptyString) : [];
    }
    function orderedSetReducer(current, element) {
      if (!current.hasOwnProperty(element)) {
        current[element] = true;
      }
      return current;
    }
    function toOrderedSet(input) {
      if (!input) return [];
      var list = splitOnASCIIWhitespace(input);
      return Object.keys(list.reduce(orderedSetReducer, {}));
    }
    function arrayIncludes(list) {
      return function(element) {
        return list && list.indexOf(element) !== -1;
      };
    }
    function copy(src, dest) {
      for (var p in src) {
        if (Object.prototype.hasOwnProperty.call(src, p)) {
          dest[p] = src[p];
        }
      }
    }
    function _extends(Class, Super) {
      var pt2 = Class.prototype;
      if (!(pt2 instanceof Super)) {
        let t2 = function() {
        };
        var t = t2;
        ;
        t2.prototype = Super.prototype;
        t2 = new t2();
        copy(pt2, t2);
        Class.prototype = pt2 = t2;
      }
      if (pt2.constructor != Class) {
        if (typeof Class != "function") {
          console.error("unknown Class:" + Class);
        }
        pt2.constructor = Class;
      }
    }
    var NodeType = {};
    var ELEMENT_NODE = NodeType.ELEMENT_NODE = 1;
    var ATTRIBUTE_NODE = NodeType.ATTRIBUTE_NODE = 2;
    var TEXT_NODE = NodeType.TEXT_NODE = 3;
    var CDATA_SECTION_NODE = NodeType.CDATA_SECTION_NODE = 4;
    var ENTITY_REFERENCE_NODE = NodeType.ENTITY_REFERENCE_NODE = 5;
    var ENTITY_NODE = NodeType.ENTITY_NODE = 6;
    var PROCESSING_INSTRUCTION_NODE = NodeType.PROCESSING_INSTRUCTION_NODE = 7;
    var COMMENT_NODE = NodeType.COMMENT_NODE = 8;
    var DOCUMENT_NODE = NodeType.DOCUMENT_NODE = 9;
    var DOCUMENT_TYPE_NODE = NodeType.DOCUMENT_TYPE_NODE = 10;
    var DOCUMENT_FRAGMENT_NODE = NodeType.DOCUMENT_FRAGMENT_NODE = 11;
    var NOTATION_NODE = NodeType.NOTATION_NODE = 12;
    var ExceptionCode = {};
    var ExceptionMessage = {};
    var INDEX_SIZE_ERR = ExceptionCode.INDEX_SIZE_ERR = (ExceptionMessage[1] = "Index size error", 1);
    var DOMSTRING_SIZE_ERR = ExceptionCode.DOMSTRING_SIZE_ERR = (ExceptionMessage[2] = "DOMString size error", 2);
    var HIERARCHY_REQUEST_ERR = ExceptionCode.HIERARCHY_REQUEST_ERR = (ExceptionMessage[3] = "Hierarchy request error", 3);
    var WRONG_DOCUMENT_ERR = ExceptionCode.WRONG_DOCUMENT_ERR = (ExceptionMessage[4] = "Wrong document", 4);
    var INVALID_CHARACTER_ERR = ExceptionCode.INVALID_CHARACTER_ERR = (ExceptionMessage[5] = "Invalid character", 5);
    var NO_DATA_ALLOWED_ERR = ExceptionCode.NO_DATA_ALLOWED_ERR = (ExceptionMessage[6] = "No data allowed", 6);
    var NO_MODIFICATION_ALLOWED_ERR = ExceptionCode.NO_MODIFICATION_ALLOWED_ERR = (ExceptionMessage[7] = "No modification allowed", 7);
    var NOT_FOUND_ERR = ExceptionCode.NOT_FOUND_ERR = (ExceptionMessage[8] = "Not found", 8);
    var NOT_SUPPORTED_ERR = ExceptionCode.NOT_SUPPORTED_ERR = (ExceptionMessage[9] = "Not supported", 9);
    var INUSE_ATTRIBUTE_ERR = ExceptionCode.INUSE_ATTRIBUTE_ERR = (ExceptionMessage[10] = "Attribute in use", 10);
    var INVALID_STATE_ERR = ExceptionCode.INVALID_STATE_ERR = (ExceptionMessage[11] = "Invalid state", 11);
    var SYNTAX_ERR = ExceptionCode.SYNTAX_ERR = (ExceptionMessage[12] = "Syntax error", 12);
    var INVALID_MODIFICATION_ERR = ExceptionCode.INVALID_MODIFICATION_ERR = (ExceptionMessage[13] = "Invalid modification", 13);
    var NAMESPACE_ERR = ExceptionCode.NAMESPACE_ERR = (ExceptionMessage[14] = "Invalid namespace", 14);
    var INVALID_ACCESS_ERR = ExceptionCode.INVALID_ACCESS_ERR = (ExceptionMessage[15] = "Invalid access", 15);
    function DOMException(code, message) {
      if (message instanceof Error) {
        var error = message;
      } else {
        error = this;
        Error.call(this, ExceptionMessage[code]);
        this.message = ExceptionMessage[code];
        if (Error.captureStackTrace) Error.captureStackTrace(this, DOMException);
      }
      error.code = code;
      if (message) this.message = this.message + ": " + message;
      return error;
    }
    DOMException.prototype = Error.prototype;
    copy(ExceptionCode, DOMException);
    function NodeList() {
    }
    NodeList.prototype = {
      /**
       * The number of nodes in the list. The range of valid child node indices is 0 to length-1 inclusive.
       * @standard level1
       */
      length: 0,
      /**
       * Returns the indexth item in the collection. If index is greater than or equal to the number of nodes in the list, this returns null.
       * @standard level1
       * @param index  unsigned long
       *   Index into the collection.
       * @return Node
       * 	The node at the indexth position in the NodeList, or null if that is not a valid index.
       */
      item: function(index) {
        return index >= 0 && index < this.length ? this[index] : null;
      },
      toString: function(isHTML, nodeFilter, options) {
        var requireWellFormed = !!options && !!options.requireWellFormed;
        for (var buf = [], i = 0; i < this.length; i++) {
          serializeToString(this[i], buf, isHTML, nodeFilter, null, requireWellFormed);
        }
        return buf.join("");
      },
      /**
       * @private
       * @param {function (Node):boolean} predicate
       * @returns {Node[]}
       */
      filter: function(predicate) {
        return Array.prototype.filter.call(this, predicate);
      },
      /**
       * @private
       * @param {Node} item
       * @returns {number}
       */
      indexOf: function(item) {
        return Array.prototype.indexOf.call(this, item);
      }
    };
    function LiveNodeList(node, refresh) {
      this._node = node;
      this._refresh = refresh;
      _updateLiveList(this);
    }
    function _updateLiveList(list) {
      var inc = list._node._inc || list._node.ownerDocument._inc;
      if (list._inc !== inc) {
        var ls = list._refresh(list._node);
        __set__(list, "length", ls.length);
        if (!list.$$length || ls.length < list.$$length) {
          for (var i = ls.length; i in list; i++) {
            if (Object.prototype.hasOwnProperty.call(list, i)) {
              delete list[i];
            }
          }
        }
        copy(ls, list);
        list._inc = inc;
      }
    }
    LiveNodeList.prototype.item = function(i) {
      _updateLiveList(this);
      return this[i] || null;
    };
    _extends(LiveNodeList, NodeList);
    function NamedNodeMap() {
      this._nameIndex = /* @__PURE__ */ Object.create(null);
    }
    function _findNodeIndex(list, node) {
      var i = list.length;
      while (i--) {
        if (list[i] === node) {
          return i;
        }
      }
    }
    function _nnmIndexAdd(list, attr) {
      list._nameIndex[attr.nodeName] = attr;
    }
    function _nnmIndexRemove(list, attr) {
      if (list._nameIndex[attr.nodeName] === attr) {
        delete list._nameIndex[attr.nodeName];
      }
    }
    function _addNamedNode(el, list, newAttr, oldAttr) {
      if (oldAttr) {
        list[_findNodeIndex(list, oldAttr)] = newAttr;
        _nnmIndexRemove(list, oldAttr);
      } else {
        list[list.length++] = newAttr;
      }
      _nnmIndexAdd(list, newAttr);
      if (el) {
        newAttr.ownerElement = el;
        var doc = el.ownerDocument;
        if (doc) {
          oldAttr && _onRemoveAttribute(doc, el, oldAttr);
          _onAddAttribute(doc, el, newAttr);
        }
      }
    }
    function _removeNamedNode(el, list, attr) {
      var i = _findNodeIndex(list, attr);
      if (i >= 0) {
        var lastIndex = list.length - 1;
        while (i < lastIndex) {
          list[i] = list[++i];
        }
        list.length = lastIndex;
        _nnmIndexRemove(list, attr);
        if (el) {
          var doc = el.ownerDocument;
          if (doc) {
            _onRemoveAttribute(doc, el, attr);
            attr.ownerElement = null;
          }
        }
      } else {
        throw new DOMException(NOT_FOUND_ERR, new Error(el.tagName + "@" + attr));
      }
    }
    NamedNodeMap.prototype = {
      length: 0,
      item: NodeList.prototype.item,
      getNamedItem: function(key) {
        var i = this.length;
        while (i--) {
          var attr = this[i];
          if (attr.nodeName == key) {
            return attr;
          }
        }
      },
      setNamedItem: function(attr) {
        var el = attr.ownerElement;
        if (el && el != this._ownerElement) {
          throw new DOMException(INUSE_ATTRIBUTE_ERR);
        }
        var oldAttr = this._nameIndex[attr.nodeName];
        _addNamedNode(this._ownerElement, this, attr, oldAttr);
        return oldAttr;
      },
      /* returns Node */
      setNamedItemNS: function(attr) {
        var el = attr.ownerElement, oldAttr;
        if (el && el != this._ownerElement) {
          throw new DOMException(INUSE_ATTRIBUTE_ERR);
        }
        oldAttr = this.getNamedItemNS(attr.namespaceURI, attr.localName);
        _addNamedNode(this._ownerElement, this, attr, oldAttr);
        return oldAttr;
      },
      /* returns Node */
      removeNamedItem: function(key) {
        var attr = this.getNamedItem(key);
        _removeNamedNode(this._ownerElement, this, attr);
        return attr;
      },
      // raises: NOT_FOUND_ERR,NO_MODIFICATION_ALLOWED_ERR
      //for level2
      removeNamedItemNS: function(namespaceURI, localName) {
        var attr = this.getNamedItemNS(namespaceURI, localName);
        _removeNamedNode(this._ownerElement, this, attr);
        return attr;
      },
      getNamedItemNS: function(namespaceURI, localName) {
        var i = this.length;
        while (i--) {
          var node = this[i];
          if (node.localName == localName && node.namespaceURI == namespaceURI) {
            return node;
          }
        }
        return null;
      }
    };
    function DOMImplementation() {
    }
    DOMImplementation.prototype = {
      /**
       * The DOMImplementation.hasFeature() method returns a Boolean flag indicating if a given feature is supported.
       * The different implementations fairly diverged in what kind of features were reported.
       * The latest version of the spec settled to force this method to always return true, where the functionality was accurate and in use.
       *
       * @deprecated It is deprecated and modern browsers return true in all cases.
       *
       * @param {string} feature
       * @param {string} [version]
       * @returns {boolean} always true
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMImplementation/hasFeature MDN
       * @see https://www.w3.org/TR/REC-DOM-Level-1/level-one-core.html#ID-5CED94D7 DOM Level 1 Core
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-hasfeature DOM Living Standard
       */
      hasFeature: function(feature, version) {
        return true;
      },
      /**
       * Creates an XML Document object of the specified type with its document element.
       *
       * __It behaves slightly different from the description in the living standard__:
       * - There is no interface/class `XMLDocument`, it returns a `Document` instance.
       * - `contentType`, `encoding`, `mode`, `origin`, `url` fields are currently not declared.
       * - this implementation is not validating names or qualified names
       *   (when parsing XML strings, the SAX parser takes care of that)
       *
       * @param {string|null} namespaceURI
       * @param {string} qualifiedName
       * @param {DocumentType=null} doctype
       * @returns {Document}
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMImplementation/createDocument MDN
       * @see https://www.w3.org/TR/DOM-Level-2-Core/core.html#Level-2-Core-DOM-createDocument DOM Level 2 Core (initial)
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-createdocument  DOM Level 2 Core
       *
       * @see https://dom.spec.whatwg.org/#validate-and-extract DOM: Validate and extract
       * @see https://www.w3.org/TR/xml/#NT-NameStartChar XML Spec: Names
       * @see https://www.w3.org/TR/xml-names/#ns-qualnames XML Namespaces: Qualified names
       */
      createDocument: function(namespaceURI, qualifiedName, doctype) {
        var doc = new Document();
        doc.implementation = this;
        doc.childNodes = new NodeList();
        doc.doctype = doctype || null;
        if (doctype) {
          doc.appendChild(doctype);
        }
        if (qualifiedName) {
          var root = doc.createElementNS(namespaceURI, qualifiedName);
          doc.appendChild(root);
        }
        return doc;
      },
      /**
       * Returns a doctype, with the given `qualifiedName`, `publicId`, and `systemId`.
       *
       * __This implementation differs from the specification:__
       * - this implementation is not validating names or qualified names
       *   (when parsing XML strings, the SAX parser takes care of that)
       *
       * Note: `internalSubset` can only be introduced via a direct property write to `node.internalSubset` after creation.
       * Creation-time validation of `publicId`, `systemId` is not enforced.
       * The serializer-level check covers all mutation vectors, including direct property writes.
       * `internalSubset` is only serialized as `[ ... ]` when both `publicId` and `systemId` are
       * absent (empty or `'.'`) — if either external identifier is present, `internalSubset` is
       * silently omitted from the serialized output.
       *
       * @param {string} qualifiedName
       * @param {string} [publicId]
       * The external subset public identifier. Stored verbatim including surrounding quotes.
       * When serialized with `requireWellFormed: true` (via the 4th-parameter options object),
       * throws `DOMException` with code `INVALID_STATE_ERR` if the value is non-empty and does
       * not match the XML `PubidLiteral` production (W3C DOM Parsing §3.2.1.3; XML 1.0 [12]).
       * @param {string} [systemId]
       * The external subset system identifier. Stored verbatim including surrounding quotes.
       * When serialized with `requireWellFormed: true`, throws `DOMException` with code
       * `INVALID_STATE_ERR` if the value is non-empty and does not match the XML `SystemLiteral`
       * production (W3C DOM Parsing §3.2.1.3; XML 1.0 [11]).
       * @returns {DocumentType} which can either be used with `DOMImplementation.createDocument` upon document creation
       * 				  or can be put into the document via methods like `Node.insertBefore()` or `Node.replaceChild()`
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/DOMImplementation/createDocumentType MDN
       * @see https://www.w3.org/TR/DOM-Level-2-Core/core.html#Level-2-Core-DOM-createDocType DOM Level 2 Core
       * @see https://dom.spec.whatwg.org/#dom-domimplementation-createdocumenttype DOM Living Standard
       *
       * @see https://dom.spec.whatwg.org/#validate-and-extract DOM: Validate and extract
       * @see https://www.w3.org/TR/xml/#NT-NameStartChar XML Spec: Names
       * @see https://www.w3.org/TR/xml-names/#ns-qualnames XML Namespaces: Qualified names
       */
      createDocumentType: function(qualifiedName, publicId, systemId) {
        var node = new DocumentType();
        node.name = qualifiedName;
        node.nodeName = qualifiedName;
        node.publicId = publicId || "";
        node.systemId = systemId || "";
        return node;
      }
    };
    function Node() {
    }
    Node.prototype = {
      firstChild: null,
      lastChild: null,
      previousSibling: null,
      nextSibling: null,
      attributes: null,
      parentNode: null,
      childNodes: null,
      ownerDocument: null,
      nodeValue: null,
      namespaceURI: null,
      prefix: null,
      localName: null,
      // Modified in DOM Level 2:
      insertBefore: function(newChild, refChild) {
        return _insertBefore(this, newChild, refChild);
      },
      replaceChild: function(newChild, oldChild) {
        _insertBefore(this, newChild, oldChild, assertPreReplacementValidityInDocument);
        if (oldChild) {
          this.removeChild(oldChild);
        }
      },
      removeChild: function(oldChild) {
        return _removeChild(this, oldChild);
      },
      appendChild: function(newChild) {
        return this.insertBefore(newChild, null);
      },
      hasChildNodes: function() {
        return this.firstChild != null;
      },
      cloneNode: function(deep) {
        return cloneNode(this.ownerDocument || this, this, deep);
      },
      // Modified in DOM Level 2:
      /**
       * Puts the specified node and all of its subtree into a "normalized" form. In a normalized
       * subtree, no text nodes in the subtree are empty and there are no adjacent text nodes.
       *
       * Specifically, this method merges any adjacent text nodes (i.e., nodes for which `nodeType`
       * is `TEXT_NODE`) into a single node with the combined data. It also removes any empty text
       * nodes.
       *
       * This method iteratively traverses all child nodes to normalize all descendant nodes within
       * the subtree.
       *
       * @throws {DOMException}
       * May throw a DOMException if operations within removeChild or appendData (which are
       * potentially invoked in this method) do not meet their specific constraints.
       * @see {@link Node.removeChild}
       * @see {@link CharacterData.appendData}
       * @see ../docs/walk-dom.md.
       */
      normalize: function() {
        walkDOM(this, null, {
          enter: function(node) {
            var child = node.firstChild;
            while (child) {
              var next = child.nextSibling;
              if (next !== null && next.nodeType === TEXT_NODE && child.nodeType === TEXT_NODE) {
                var tail = [];
                var sibling = next;
                while (sibling !== null && sibling.nodeType === TEXT_NODE) {
                  tail.push(sibling.data);
                  sibling = sibling.nextSibling;
                }
                var removed = child.nextSibling;
                while (removed !== sibling) {
                  var following = removed.nextSibling;
                  removed.parentNode = null;
                  removed.previousSibling = null;
                  removed.nextSibling = null;
                  removed = following;
                }
                child.nextSibling = sibling;
                if (sibling !== null) {
                  sibling.previousSibling = child;
                } else {
                  node.lastChild = child;
                }
                child.appendData(tail.join(""));
                _onUpdateChild(node.ownerDocument, node);
                child = sibling;
              } else {
                child = next;
              }
            }
            return true;
          }
        });
      },
      // Introduced in DOM Level 2:
      isSupported: function(feature, version) {
        return this.ownerDocument.implementation.hasFeature(feature, version);
      },
      // Introduced in DOM Level 2:
      hasAttributes: function() {
        return this.attributes.length > 0;
      },
      /**
       * Look up the prefix associated to the given namespace URI, starting from this node.
       * **The default namespace declarations are ignored by this method.**
       * See Namespace Prefix Lookup for details on the algorithm used by this method.
       *
       * _Note: The implementation seems to be incomplete when compared to the algorithm described in the specs._
       *
       * @param {string | null} namespaceURI
       * @returns {string | null}
       * @see https://www.w3.org/TR/DOM-Level-3-Core/core.html#Node3-lookupNamespacePrefix
       * @see https://www.w3.org/TR/DOM-Level-3-Core/namespaces-algorithms.html#lookupNamespacePrefixAlgo
       * @see https://dom.spec.whatwg.org/#dom-node-lookupprefix
       * @see https://github.com/xmldom/xmldom/issues/322
       */
      lookupPrefix: function(namespaceURI) {
        var el = this;
        while (el) {
          var map = el._nsMap;
          if (map) {
            for (var n2 in map) {
              if (Object.prototype.hasOwnProperty.call(map, n2) && map[n2] === namespaceURI) {
                return n2;
              }
            }
          }
          el = el.nodeType == ATTRIBUTE_NODE ? el.ownerDocument : el.parentNode;
        }
        return null;
      },
      // Introduced in DOM Level 3:
      lookupNamespaceURI: function(prefix) {
        var el = this;
        while (el) {
          var map = el._nsMap;
          if (map) {
            if (Object.prototype.hasOwnProperty.call(map, prefix)) {
              return map[prefix];
            }
          }
          el = el.nodeType == ATTRIBUTE_NODE ? el.ownerDocument : el.parentNode;
        }
        return null;
      },
      // Introduced in DOM Level 3:
      isDefaultNamespace: function(namespaceURI) {
        var prefix = this.lookupPrefix(namespaceURI);
        return prefix == null;
      }
    };
    function _xmlEncoder(c) {
      return c == "<" && "&lt;" || c == ">" && "&gt;" || c == "&" && "&amp;" || c == '"' && "&quot;" || "&#" + c.charCodeAt() + ";";
    }
    copy(NodeType, Node);
    copy(NodeType, Node.prototype);
    function _visitNode(node, callback) {
      return walkDOM(node, null, { enter: function(n2) {
        return callback(n2) ? walkDOM.STOP : true;
      } }) === walkDOM.STOP;
    }
    function walkDOM(node, context, callbacks) {
      var stack = [{ node, context, phase: walkDOM.ENTER }];
      while (stack.length > 0) {
        var frame = stack.pop();
        if (frame.phase === walkDOM.ENTER) {
          var childContext = callbacks.enter(frame.node, frame.context);
          if (childContext === walkDOM.STOP) {
            return walkDOM.STOP;
          }
          stack.push({ node: frame.node, context: childContext, phase: walkDOM.EXIT });
          if (childContext === null || childContext === void 0) {
            continue;
          }
          var child = frame.node.lastChild;
          while (child) {
            stack.push({ node: child, context: childContext, phase: walkDOM.ENTER });
            child = child.previousSibling;
          }
        } else {
          if (callbacks.exit) {
            callbacks.exit(frame.node, frame.context);
          }
        }
      }
    }
    walkDOM.STOP = /* @__PURE__ */ Symbol("walkDOM.STOP");
    walkDOM.ENTER = 0;
    walkDOM.EXIT = 1;
    function Document() {
      this.ownerDocument = this;
    }
    function _onAddAttribute(doc, el, newAttr) {
      doc && doc._inc++;
      var ns = newAttr.namespaceURI;
      if (ns === NAMESPACE.XMLNS) {
        el._nsMap[newAttr.prefix ? newAttr.localName : ""] = newAttr.value;
      }
    }
    function _onRemoveAttribute(doc, el, newAttr, remove) {
      doc && doc._inc++;
      var ns = newAttr.namespaceURI;
      if (ns === NAMESPACE.XMLNS) {
        delete el._nsMap[newAttr.prefix ? newAttr.localName : ""];
      }
    }
    function _onUpdateChild(doc, el, newChild) {
      if (doc && doc._inc) {
        doc._inc++;
        var cs = el.childNodes;
        if (newChild) {
          cs[cs.length++] = newChild;
        } else {
          var child = el.firstChild;
          var i = 0;
          while (child) {
            cs[i++] = child;
            child = child.nextSibling;
          }
          cs.length = i;
          delete cs[cs.length];
        }
      }
    }
    function _removeChild(parentNode, child) {
      var previous = child.previousSibling;
      var next = child.nextSibling;
      if (previous) {
        previous.nextSibling = next;
      } else {
        parentNode.firstChild = next;
      }
      if (next) {
        next.previousSibling = previous;
      } else {
        parentNode.lastChild = previous;
      }
      child.parentNode = null;
      child.previousSibling = null;
      child.nextSibling = null;
      _onUpdateChild(parentNode.ownerDocument, parentNode);
      return child;
    }
    function hasValidParentNodeType(node) {
      return node && (node.nodeType === Node.DOCUMENT_NODE || node.nodeType === Node.DOCUMENT_FRAGMENT_NODE || node.nodeType === Node.ELEMENT_NODE);
    }
    function hasInsertableNodeType(node) {
      return node && (isElementNode(node) || isTextNode(node) || isDocTypeNode(node) || node.nodeType === Node.DOCUMENT_FRAGMENT_NODE || node.nodeType === Node.COMMENT_NODE || node.nodeType === Node.PROCESSING_INSTRUCTION_NODE);
    }
    function isDocTypeNode(node) {
      return node && node.nodeType === Node.DOCUMENT_TYPE_NODE;
    }
    function isElementNode(node) {
      return node && node.nodeType === Node.ELEMENT_NODE;
    }
    function isTextNode(node) {
      return node && node.nodeType === Node.TEXT_NODE;
    }
    function isElementInsertionPossible(doc, child) {
      var parentChildNodes = doc.childNodes || [];
      if (find(parentChildNodes, isElementNode) || isDocTypeNode(child)) {
        return false;
      }
      var docTypeNode = find(parentChildNodes, isDocTypeNode);
      return !(child && docTypeNode && parentChildNodes.indexOf(docTypeNode) > parentChildNodes.indexOf(child));
    }
    function isElementReplacementPossible(doc, child) {
      var parentChildNodes = doc.childNodes || [];
      function hasElementChildThatIsNotChild(node) {
        return isElementNode(node) && node !== child;
      }
      if (find(parentChildNodes, hasElementChildThatIsNotChild)) {
        return false;
      }
      var docTypeNode = find(parentChildNodes, isDocTypeNode);
      return !(child && docTypeNode && parentChildNodes.indexOf(docTypeNode) > parentChildNodes.indexOf(child));
    }
    function assertPreInsertionValidity1to5(parent, node, child) {
      if (!hasValidParentNodeType(parent)) {
        throw new DOMException(HIERARCHY_REQUEST_ERR, "Unexpected parent node type " + parent.nodeType);
      }
      if (child && child.parentNode !== parent) {
        throw new DOMException(NOT_FOUND_ERR, "child not in parent");
      }
      if (
        // 4. If `node` is not a DocumentFragment, DocumentType, Element, or CharacterData node, then throw a "HierarchyRequestError" DOMException.
        !hasInsertableNodeType(node) || // 5. If either `node` is a Text node and `parent` is a document,
        // the sax parser currently adds top level text nodes, this will be fixed in 0.9.0
        // || (node.nodeType === Node.TEXT_NODE && parent.nodeType === Node.DOCUMENT_NODE)
        // or `node` is a doctype and `parent` is not a document, then throw a "HierarchyRequestError" DOMException.
        isDocTypeNode(node) && parent.nodeType !== Node.DOCUMENT_NODE
      ) {
        throw new DOMException(
          HIERARCHY_REQUEST_ERR,
          "Unexpected node type " + node.nodeType + " for parent node type " + parent.nodeType
        );
      }
    }
    function assertPreInsertionValidityInDocument(parent, node, child) {
      var parentChildNodes = parent.childNodes || [];
      var nodeChildNodes = node.childNodes || [];
      if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
        var nodeChildElements = nodeChildNodes.filter(isElementNode);
        if (nodeChildElements.length > 1 || find(nodeChildNodes, isTextNode)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "More than one element or text in fragment");
        }
        if (nodeChildElements.length === 1 && !isElementInsertionPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Element in fragment can not be inserted before doctype");
        }
      }
      if (isElementNode(node)) {
        if (!isElementInsertionPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one element can be added and only after doctype");
        }
      }
      if (isDocTypeNode(node)) {
        if (find(parentChildNodes, isDocTypeNode)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one doctype is allowed");
        }
        var parentElementChild = find(parentChildNodes, isElementNode);
        if (child && parentChildNodes.indexOf(parentElementChild) < parentChildNodes.indexOf(child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Doctype can only be inserted before an element");
        }
        if (!child && parentElementChild) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Doctype can not be appended since element is present");
        }
      }
    }
    function assertPreReplacementValidityInDocument(parent, node, child) {
      var parentChildNodes = parent.childNodes || [];
      var nodeChildNodes = node.childNodes || [];
      if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
        var nodeChildElements = nodeChildNodes.filter(isElementNode);
        if (nodeChildElements.length > 1 || find(nodeChildNodes, isTextNode)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "More than one element or text in fragment");
        }
        if (nodeChildElements.length === 1 && !isElementReplacementPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Element in fragment can not be inserted before doctype");
        }
      }
      if (isElementNode(node)) {
        if (!isElementReplacementPossible(parent, child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one element can be added and only after doctype");
        }
      }
      if (isDocTypeNode(node)) {
        let hasDoctypeChildThatIsNotChild2 = function(node2) {
          return isDocTypeNode(node2) && node2 !== child;
        };
        var hasDoctypeChildThatIsNotChild = hasDoctypeChildThatIsNotChild2;
        if (find(parentChildNodes, hasDoctypeChildThatIsNotChild2)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Only one doctype is allowed");
        }
        var parentElementChild = find(parentChildNodes, isElementNode);
        if (child && parentChildNodes.indexOf(parentElementChild) < parentChildNodes.indexOf(child)) {
          throw new DOMException(HIERARCHY_REQUEST_ERR, "Doctype can only be inserted before an element");
        }
      }
    }
    function _insertBefore(parent, node, child, _inDocumentAssertion) {
      assertPreInsertionValidity1to5(parent, node, child);
      if (parent.nodeType === Node.DOCUMENT_NODE) {
        (_inDocumentAssertion || assertPreInsertionValidityInDocument)(parent, node, child);
      }
      var cp = node.parentNode;
      if (cp) {
        cp.removeChild(node);
      }
      if (node.nodeType === DOCUMENT_FRAGMENT_NODE) {
        var newFirst = node.firstChild;
        if (newFirst == null) {
          return node;
        }
        var newLast = node.lastChild;
      } else {
        newFirst = newLast = node;
      }
      var pre = child ? child.previousSibling : parent.lastChild;
      newFirst.previousSibling = pre;
      newLast.nextSibling = child;
      if (pre) {
        pre.nextSibling = newFirst;
      } else {
        parent.firstChild = newFirst;
      }
      if (child == null) {
        parent.lastChild = newLast;
      } else {
        child.previousSibling = newLast;
      }
      do {
        newFirst.parentNode = parent;
        var targetDoc = parent.ownerDocument || parent;
        _updateOwnerDocument(newFirst, targetDoc);
      } while (newFirst !== newLast && (newFirst = newFirst.nextSibling));
      _onUpdateChild(parent.ownerDocument || parent, parent);
      if (node.nodeType == DOCUMENT_FRAGMENT_NODE) {
        node.firstChild = node.lastChild = null;
      }
      return node;
    }
    function _updateOwnerDocument(node, newOwnerDocument) {
      if (node.ownerDocument === newOwnerDocument) {
        return;
      }
      node.ownerDocument = newOwnerDocument;
      if (node.nodeType === ELEMENT_NODE && node.attributes) {
        for (var i = 0; i < node.attributes.length; i++) {
          var attr = node.attributes.item(i);
          if (attr) {
            attr.ownerDocument = newOwnerDocument;
          }
        }
      }
      var child = node.firstChild;
      while (child) {
        _updateOwnerDocument(child, newOwnerDocument);
        child = child.nextSibling;
      }
    }
    function _appendSingleChild(parentNode, newChild) {
      if (newChild.parentNode) {
        newChild.parentNode.removeChild(newChild);
      }
      newChild.parentNode = parentNode;
      newChild.previousSibling = parentNode.lastChild;
      newChild.nextSibling = null;
      if (newChild.previousSibling) {
        newChild.previousSibling.nextSibling = newChild;
      } else {
        parentNode.firstChild = newChild;
      }
      parentNode.lastChild = newChild;
      _onUpdateChild(parentNode.ownerDocument, parentNode, newChild);
      var targetDoc = parentNode.ownerDocument || parentNode;
      _updateOwnerDocument(newChild, targetDoc);
      return newChild;
    }
    Document.prototype = {
      //implementation : null,
      nodeName: "#document",
      nodeType: DOCUMENT_NODE,
      /**
       * The DocumentType node of the document.
       *
       * @readonly
       * @type DocumentType
       */
      doctype: null,
      documentElement: null,
      _inc: 1,
      insertBefore: function(newChild, refChild) {
        if (newChild.nodeType == DOCUMENT_FRAGMENT_NODE) {
          var child = newChild.firstChild;
          while (child) {
            var next = child.nextSibling;
            this.insertBefore(child, refChild);
            child = next;
          }
          return newChild;
        }
        _insertBefore(this, newChild, refChild);
        _updateOwnerDocument(newChild, this);
        if (this.documentElement === null && newChild.nodeType === ELEMENT_NODE) {
          this.documentElement = newChild;
        }
        return newChild;
      },
      removeChild: function(oldChild) {
        if (this.documentElement == oldChild) {
          this.documentElement = null;
        }
        return _removeChild(this, oldChild);
      },
      replaceChild: function(newChild, oldChild) {
        _insertBefore(this, newChild, oldChild, assertPreReplacementValidityInDocument);
        _updateOwnerDocument(newChild, this);
        if (oldChild) {
          this.removeChild(oldChild);
        }
        if (isElementNode(newChild)) {
          this.documentElement = newChild;
        }
      },
      // Introduced in DOM Level 2:
      importNode: function(importedNode, deep) {
        return importNode(this, importedNode, deep);
      },
      // Introduced in DOM Level 2:
      getElementById: function(id) {
        var rtv = null;
        _visitNode(this.documentElement, function(node) {
          if (node.nodeType == ELEMENT_NODE) {
            if (node.getAttribute("id") == id) {
              rtv = node;
              return true;
            }
          }
        });
        return rtv;
      },
      /**
       * The `getElementsByClassName` method of `Document` interface returns an array-like object
       * of all child elements which have **all** of the given class name(s).
       *
       * Returns an empty list if `classeNames` is an empty string or only contains HTML white space characters.
       *
       *
       * Warning: This is a live LiveNodeList.
       * Changes in the DOM will reflect in the array as the changes occur.
       * If an element selected by this array no longer qualifies for the selector,
       * it will automatically be removed. Be aware of this for iteration purposes.
       *
       * @param {string} classNames is a string representing the class name(s) to match; multiple class names are separated by (ASCII-)whitespace
       *
       * @see https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementsByClassName
       * @see https://dom.spec.whatwg.org/#concept-getelementsbyclassname
       */
      getElementsByClassName: function(classNames) {
        var classNamesSet = toOrderedSet(classNames);
        return new LiveNodeList(this, function(base) {
          var ls = [];
          if (classNamesSet.length > 0) {
            _visitNode(base.documentElement, function(node) {
              if (node !== base && node.nodeType === ELEMENT_NODE) {
                var nodeClassNames = node.getAttribute("class");
                if (nodeClassNames) {
                  var matches = classNames === nodeClassNames;
                  if (!matches) {
                    var nodeClassNamesSet = toOrderedSet(nodeClassNames);
                    matches = classNamesSet.every(arrayIncludes(nodeClassNamesSet));
                  }
                  if (matches) {
                    ls.push(node);
                  }
                }
              }
            });
          }
          return ls;
        });
      },
      //document factory method:
      createElement: function(tagName) {
        var node = new Element();
        node.ownerDocument = this;
        node.nodeName = tagName;
        node.tagName = tagName;
        node.localName = tagName;
        node.childNodes = new NodeList();
        var attrs = node.attributes = new NamedNodeMap();
        attrs._ownerElement = node;
        return node;
      },
      createDocumentFragment: function() {
        var node = new DocumentFragment();
        node.ownerDocument = this;
        node.childNodes = new NodeList();
        return node;
      },
      createTextNode: function(data) {
        var node = new Text2();
        node.ownerDocument = this;
        node.appendData(data);
        return node;
      },
      createComment: function(data) {
        var node = new Comment();
        node.ownerDocument = this;
        node.appendData(data);
        return node;
      },
      /**
       * Returns a new CDATASection node whose data is `data`.
       *
       * __This implementation differs from the specification:__
       * - calling this method on an HTML document does not throw `NotSupportedError`.
       *
       * @param {string} data
       * @returns {CDATASection}
       * @throws DOMException with code `INVALID_CHARACTER_ERR` if `data` contains `"]]>"`.
       * @see https://developer.mozilla.org/en-US/docs/Web/API/Document/createCDATASection
       * @see https://dom.spec.whatwg.org/#dom-document-createcdatasection
       */
      createCDATASection: function(data) {
        if (data.indexOf("]]>") !== -1) {
          throw new DOMException(INVALID_CHARACTER_ERR, 'data contains "]]>"');
        }
        var node = new CDATASection();
        node.ownerDocument = this;
        node.appendData(data);
        return node;
      },
      /**
       * Returns a ProcessingInstruction node whose target is target and data is data.
       *
       * __This implementation differs from the specification:__
       * - it does not do any input validation on the arguments and doesn't throw "InvalidCharacterError".
       *
       * Note: When the resulting document is serialized with `requireWellFormed: true`, the
       * serializer throws with code `INVALID_STATE_ERR` if `.target` is not a valid XML `NCName`
       * (a `Name` with no colon) or is an ASCII case-insensitive match for `"xml"`, or if `.data`
       * contains `?>` (W3C DOM Parsing §3.2.1.7). Without that option the target and data are
       * emitted verbatim.
       *
       * @param {string} target
       * @param {string} data
       * @returns {ProcessingInstruction}
       * @see https://developer.mozilla.org/docs/Web/API/Document/createProcessingInstruction
       * @see https://dom.spec.whatwg.org/#dom-document-createprocessinginstruction
       * @see https://www.w3.org/TR/DOM-Parsing/#dfn-concept-serialize-xml §3.2.1.7
       */
      createProcessingInstruction: function(target, data) {
        var node = new ProcessingInstruction();
        node.ownerDocument = this;
        node.tagName = node.nodeName = node.target = target;
        node.nodeValue = node.data = data;
        return node;
      },
      createAttribute: function(name) {
        var node = new Attr();
        node.ownerDocument = this;
        node.name = name;
        node.nodeName = name;
        node.localName = name;
        node.specified = true;
        return node;
      },
      /**
       * Creates an EntityReference object, serialized as `&name;`.
       *
       * The `name` is validated against the XML `Name` production at creation time; an invalid name
       * throws a `DOMException` with code `INVALID_CHARACTER_ERR`. When the resulting node is
       * serialized with `requireWellFormed: true`, the serializer re-validates `nodeName` and throws
       * a `DOMException` with code `INVALID_STATE_ERR` if a later `nodeName` mutation made it invalid;
       * without that option the name is emitted verbatim.
       *
       * Note: xmldom does not expand entities — the parser resolves entity references inline and never
       * constructs `EntityReference` nodes, so this method is the only producer.
       *
       * @param {string} name The name of the entity to reference.
       * @returns {EntityReference}
       * @throws {DOMException} With code `INVALID_CHARACTER_ERR` when `name` is not a valid XML `Name`.
       * @see https://www.w3.org/TR/DOM-Level-3-Core/core.html#ID-392B75AE
       */
      createEntityReference: function(name) {
        if (!tagNamePattern.test(name)) {
          throw new DOMException(INVALID_CHARACTER_ERR, 'not a valid xml name "' + name + '"');
        }
        var node = new EntityReference();
        node.ownerDocument = this;
        node.nodeName = name;
        return node;
      },
      // Introduced in DOM Level 2:
      createElementNS: function(namespaceURI, qualifiedName) {
        var node = new Element();
        var pl = qualifiedName.split(":");
        var attrs = node.attributes = new NamedNodeMap();
        node.childNodes = new NodeList();
        node.ownerDocument = this;
        node.nodeName = qualifiedName;
        node.tagName = qualifiedName;
        node.namespaceURI = namespaceURI;
        if (pl.length == 2) {
          node.prefix = pl[0];
          node.localName = pl[1];
        } else {
          node.localName = qualifiedName;
        }
        attrs._ownerElement = node;
        return node;
      },
      // Introduced in DOM Level 2:
      createAttributeNS: function(namespaceURI, qualifiedName) {
        var node = new Attr();
        var pl = qualifiedName.split(":");
        node.ownerDocument = this;
        node.nodeName = qualifiedName;
        node.name = qualifiedName;
        node.namespaceURI = namespaceURI;
        node.specified = true;
        if (pl.length == 2) {
          node.prefix = pl[0];
          node.localName = pl[1];
        } else {
          node.localName = qualifiedName;
        }
        return node;
      }
    };
    _extends(Document, Node);
    function Element() {
      this._nsMap = {};
    }
    Element.prototype = {
      nodeType: ELEMENT_NODE,
      hasAttribute: function(name) {
        return this.getAttributeNode(name) != null;
      },
      getAttribute: function(name) {
        var attr = this.getAttributeNode(name);
        return attr && attr.value || "";
      },
      getAttributeNode: function(name) {
        return this.attributes.getNamedItem(name);
      },
      setAttribute: function(name, value) {
        var attr = this.ownerDocument.createAttribute(name);
        attr.value = attr.nodeValue = "" + value;
        this.setAttributeNode(attr);
      },
      removeAttribute: function(name) {
        var attr = this.getAttributeNode(name);
        attr && this.removeAttributeNode(attr);
      },
      //four real opeartion method
      appendChild: function(newChild) {
        if (newChild.nodeType === DOCUMENT_FRAGMENT_NODE) {
          return this.insertBefore(newChild, null);
        } else {
          return _appendSingleChild(this, newChild);
        }
      },
      setAttributeNode: function(newAttr) {
        return this.attributes.setNamedItem(newAttr);
      },
      setAttributeNodeNS: function(newAttr) {
        return this.attributes.setNamedItemNS(newAttr);
      },
      removeAttributeNode: function(oldAttr) {
        return this.attributes.removeNamedItem(oldAttr.nodeName);
      },
      //get real attribute name,and remove it by removeAttributeNode
      removeAttributeNS: function(namespaceURI, localName) {
        var old = this.getAttributeNodeNS(namespaceURI, localName);
        old && this.removeAttributeNode(old);
      },
      hasAttributeNS: function(namespaceURI, localName) {
        return this.getAttributeNodeNS(namespaceURI, localName) != null;
      },
      getAttributeNS: function(namespaceURI, localName) {
        var attr = this.getAttributeNodeNS(namespaceURI, localName);
        return attr && attr.value || "";
      },
      setAttributeNS: function(namespaceURI, qualifiedName, value) {
        var attr = this.ownerDocument.createAttributeNS(namespaceURI, qualifiedName);
        attr.value = attr.nodeValue = "" + value;
        this.setAttributeNode(attr);
      },
      getAttributeNodeNS: function(namespaceURI, localName) {
        return this.attributes.getNamedItemNS(namespaceURI, localName);
      },
      getElementsByTagName: function(tagName) {
        return new LiveNodeList(this, function(base) {
          var ls = [];
          _visitNode(base, function(node) {
            if (node !== base && node.nodeType == ELEMENT_NODE && (tagName === "*" || node.tagName == tagName)) {
              ls.push(node);
            }
          });
          return ls;
        });
      },
      getElementsByTagNameNS: function(namespaceURI, localName) {
        return new LiveNodeList(this, function(base) {
          var ls = [];
          _visitNode(base, function(node) {
            if (node !== base && node.nodeType === ELEMENT_NODE && (namespaceURI === "*" || node.namespaceURI === namespaceURI) && (localName === "*" || node.localName == localName)) {
              ls.push(node);
            }
          });
          return ls;
        });
      }
    };
    Document.prototype.getElementsByTagName = Element.prototype.getElementsByTagName;
    Document.prototype.getElementsByTagNameNS = Element.prototype.getElementsByTagNameNS;
    _extends(Element, Node);
    function Attr() {
    }
    Attr.prototype.nodeType = ATTRIBUTE_NODE;
    _extends(Attr, Node);
    function CharacterData() {
    }
    CharacterData.prototype = {
      data: "",
      substringData: function(offset, count) {
        return this.data.substring(offset, offset + count);
      },
      appendData: function(text) {
        text = this.data + text;
        this.nodeValue = this.data = text;
        this.length = text.length;
      },
      insertData: function(offset, text) {
        this.replaceData(offset, 0, text);
      },
      appendChild: function(newChild) {
        throw new Error(ExceptionMessage[HIERARCHY_REQUEST_ERR]);
      },
      deleteData: function(offset, count) {
        this.replaceData(offset, count, "");
      },
      replaceData: function(offset, count, text) {
        var start = this.data.substring(0, offset);
        var end = this.data.substring(offset + count);
        text = start + text + end;
        this.nodeValue = this.data = text;
        this.length = text.length;
      }
    };
    _extends(CharacterData, Node);
    function Text2() {
    }
    Text2.prototype = {
      nodeName: "#text",
      nodeType: TEXT_NODE,
      splitText: function(offset) {
        var text = this.data;
        var newText = text.substring(offset);
        text = text.substring(0, offset);
        this.data = this.nodeValue = text;
        this.length = text.length;
        var newNode = this.ownerDocument.createTextNode(newText);
        if (this.parentNode) {
          this.parentNode.insertBefore(newNode, this.nextSibling);
        }
        return newNode;
      }
    };
    _extends(Text2, CharacterData);
    function Comment() {
    }
    Comment.prototype = {
      nodeName: "#comment",
      nodeType: COMMENT_NODE
    };
    _extends(Comment, CharacterData);
    function CDATASection() {
    }
    CDATASection.prototype = {
      nodeName: "#cdata-section",
      nodeType: CDATA_SECTION_NODE
    };
    _extends(CDATASection, CharacterData);
    function DocumentType() {
    }
    DocumentType.prototype.nodeType = DOCUMENT_TYPE_NODE;
    _extends(DocumentType, Node);
    function Notation() {
    }
    Notation.prototype.nodeType = NOTATION_NODE;
    _extends(Notation, Node);
    function Entity() {
    }
    Entity.prototype.nodeType = ENTITY_NODE;
    _extends(Entity, Node);
    function EntityReference() {
    }
    EntityReference.prototype.nodeType = ENTITY_REFERENCE_NODE;
    _extends(EntityReference, Node);
    function DocumentFragment() {
    }
    DocumentFragment.prototype.nodeName = "#document-fragment";
    DocumentFragment.prototype.nodeType = DOCUMENT_FRAGMENT_NODE;
    _extends(DocumentFragment, Node);
    function ProcessingInstruction() {
    }
    ProcessingInstruction.prototype.nodeType = PROCESSING_INSTRUCTION_NODE;
    _extends(ProcessingInstruction, Node);
    function XMLSerializer2() {
    }
    XMLSerializer2.prototype.serializeToString = function(node, isHtml, nodeFilter, options) {
      return nodeSerializeToString.call(node, isHtml, nodeFilter, options);
    };
    Node.prototype.toString = nodeSerializeToString;
    function nodeSerializeToString(isHtml, nodeFilter, options) {
      var requireWellFormed = !!options && !!options.requireWellFormed;
      var buf = [];
      var refNode = this.nodeType == 9 && this.documentElement || this;
      var prefix = refNode.prefix;
      var uri = refNode.namespaceURI;
      if (uri && prefix == null) {
        var prefix = refNode.lookupPrefix(uri);
        if (prefix == null) {
          var visibleNamespaces = [
            { namespace: uri, prefix: null }
            //{namespace:uri,prefix:''}
          ];
        }
      }
      serializeToString(this, buf, isHtml, nodeFilter, visibleNamespaces, requireWellFormed);
      return buf.join("");
    }
    function needNamespaceDefine(node, isHTML, visibleNamespaces) {
      var prefix = node.prefix || "";
      var uri = node.namespaceURI;
      if (!uri) {
        return false;
      }
      if (prefix === "xml" && uri === NAMESPACE.XML || uri === NAMESPACE.XMLNS) {
        return false;
      }
      var i = visibleNamespaces.length;
      while (i--) {
        var ns = visibleNamespaces[i];
        if (ns.prefix === prefix) {
          return ns.namespace !== uri;
        }
      }
      return true;
    }
    function addSerializedAttribute(buf, qualifiedName, value, requireWellFormed) {
      if (requireWellFormed && !tagNamePattern.test(qualifiedName)) {
        throw new DOMException(INVALID_STATE_ERR, 'The attribute name "' + qualifiedName + '" is not a valid XML QName');
      }
      buf.push(" ", qualifiedName, '="', value.replace(/[<>&"\t\n\r]/g, _xmlEncoder), '"');
    }
    function serializeToString(node, buf, isHTML, nodeFilter, visibleNamespaces, requireWellFormed) {
      if (!visibleNamespaces) {
        visibleNamespaces = [];
      }
      walkDOM(node, { ns: visibleNamespaces, isHTML }, {
        enter: function(n2, ctx) {
          var ns = ctx.ns;
          var html = ctx.isHTML;
          if (nodeFilter) {
            n2 = nodeFilter(n2);
            if (n2) {
              if (typeof n2 == "string") {
                buf.push(n2);
                return null;
              }
            } else {
              return null;
            }
          }
          switch (n2.nodeType) {
            case ELEMENT_NODE:
              var attrs = n2.attributes;
              var len = attrs.length;
              var nodeName = n2.tagName;
              html = NAMESPACE.isHTML(n2.namespaceURI) || html;
              var prefixedNodeName = nodeName;
              if (!html && !n2.prefix && n2.namespaceURI) {
                var defaultNS;
                for (var ai = 0; ai < attrs.length; ai++) {
                  if (attrs.item(ai).name === "xmlns") {
                    defaultNS = attrs.item(ai).value;
                    break;
                  }
                }
                if (!defaultNS) {
                  for (var nsi = ns.length - 1; nsi >= 0; nsi--) {
                    var nsEntry = ns[nsi];
                    if (nsEntry.prefix === "" && nsEntry.namespace === n2.namespaceURI) {
                      defaultNS = nsEntry.namespace;
                      break;
                    }
                  }
                }
                if (defaultNS !== n2.namespaceURI) {
                  for (var nsi = ns.length - 1; nsi >= 0; nsi--) {
                    var nsEntry = ns[nsi];
                    if (nsEntry.namespace === n2.namespaceURI) {
                      if (nsEntry.prefix) {
                        prefixedNodeName = nsEntry.prefix + ":" + nodeName;
                      }
                      break;
                    }
                  }
                }
              }
              if (requireWellFormed && !tagNamePattern.test(prefixedNodeName)) {
                throw new DOMException(INVALID_STATE_ERR, 'The element name "' + prefixedNodeName + '" is not a valid XML QName');
              }
              buf.push("<", prefixedNodeName);
              var childNs = ns.slice();
              for (var i = 0; i < len; i++) {
                var attr = attrs.item(i);
                if (attr.prefix == "xmlns") {
                  childNs.push({ prefix: attr.localName, namespace: attr.value });
                } else if (attr.nodeName == "xmlns") {
                  childNs.push({ prefix: "", namespace: attr.value });
                }
              }
              for (var i = 0; i < len; i++) {
                var attr = attrs.item(i);
                if (needNamespaceDefine(attr, html, childNs)) {
                  var attrPrefix = attr.prefix || "";
                  var uri = attr.namespaceURI;
                  addSerializedAttribute(buf, attrPrefix ? "xmlns:" + attrPrefix : "xmlns", uri, requireWellFormed);
                  childNs.push({ prefix: attrPrefix, namespace: uri });
                }
                var filteredAttr = nodeFilter ? nodeFilter(attr) : attr;
                if (filteredAttr) {
                  if (typeof filteredAttr === "string") {
                    buf.push(filteredAttr);
                  } else {
                    addSerializedAttribute(buf, filteredAttr.name, filteredAttr.value, requireWellFormed);
                  }
                }
              }
              if (nodeName === prefixedNodeName && needNamespaceDefine(n2, html, childNs)) {
                var nodePrefix = n2.prefix || "";
                var uri = n2.namespaceURI;
                addSerializedAttribute(buf, nodePrefix ? "xmlns:" + nodePrefix : "xmlns", uri, requireWellFormed);
                childNs.push({ prefix: nodePrefix, namespace: uri });
              }
              var child = n2.firstChild;
              if (child || html && !/^(?:meta|link|img|br|hr|input)$/i.test(nodeName)) {
                buf.push(">");
                if (html && /^script$/i.test(nodeName)) {
                  while (child) {
                    if (child.data) {
                      buf.push(child.data);
                    } else {
                      serializeToString(child, buf, html, nodeFilter, childNs.slice(), requireWellFormed);
                    }
                    child = child.nextSibling;
                  }
                  buf.push("</", nodeName, ">");
                  return null;
                }
                return { ns: childNs, isHTML: html, tag: prefixedNodeName };
              } else {
                buf.push("/>");
                return null;
              }
            case DOCUMENT_NODE:
            case DOCUMENT_FRAGMENT_NODE:
              return { ns: ns.slice(), isHTML: html, tag: null };
            case ATTRIBUTE_NODE:
              addSerializedAttribute(buf, n2.name, n2.value, requireWellFormed);
              return null;
            case TEXT_NODE:
              buf.push(n2.data.replace(/[<&>]/g, _xmlEncoder));
              return null;
            case CDATA_SECTION_NODE:
              if (requireWellFormed && n2.data.indexOf("]]>") !== -1) {
                throw new DOMException(INVALID_STATE_ERR, 'The CDATASection data contains "]]>"');
              }
              buf.push("<![CDATA[", n2.data.replace(/]]>/g, "]]]]><![CDATA[>"), "]]>");
              return null;
            case COMMENT_NODE:
              if (requireWellFormed && n2.data.indexOf("-->") !== -1) {
                throw new DOMException(INVALID_STATE_ERR, 'The comment node data contains "-->"');
              }
              buf.push("<!--", n2.data, "-->");
              return null;
            case DOCUMENT_TYPE_NODE:
              if (requireWellFormed) {
                if (!tagNamePattern.test(n2.name)) {
                  throw new DOMException(INVALID_STATE_ERR, 'The doctype name "' + n2.name + '" is not a valid XML Name');
                }
                if (n2.publicId && !/^("[\x20\r\na-zA-Z0-9\-()+,.\/:=?;!*#@$_%']*"|'[\x20\r\na-zA-Z0-9\-()+,.\/:=?;!*#@$_%'"]*')$/.test(n2.publicId)) {
                  throw new DOMException(INVALID_STATE_ERR, "DocumentType publicId is not a valid PubidLiteral");
                }
                if (n2.systemId && !/^("[^"]*"|'[^']*')$/.test(n2.systemId)) {
                  throw new DOMException(INVALID_STATE_ERR, "DocumentType systemId is not a valid SystemLiteral");
                }
                if (n2.internalSubset && n2.internalSubset.indexOf("]>") !== -1) {
                  throw new DOMException(INVALID_STATE_ERR, 'DocumentType internalSubset contains "]>"');
                }
              }
              var pubid = n2.publicId;
              var sysid = n2.systemId;
              buf.push("<!DOCTYPE ", n2.name);
              if (pubid) {
                buf.push(" PUBLIC ", pubid);
                if (sysid && sysid != ".") {
                  buf.push(" ", sysid);
                }
                buf.push(">");
              } else if (sysid && sysid != ".") {
                buf.push(" SYSTEM ", sysid, ">");
              } else {
                var sub = n2.internalSubset;
                if (sub) {
                  buf.push(" [", sub, "]");
                }
                buf.push(">");
              }
              return null;
            case PROCESSING_INSTRUCTION_NODE:
              if (requireWellFormed) {
                if (!tagNamePattern.test(n2.target) || n2.target.indexOf(":") !== -1 || n2.target.toLowerCase() === "xml") {
                  throw new DOMException(
                    INVALID_STATE_ERR,
                    'The processing instruction target "' + n2.target + '" is not a valid XML NCName or is reserved'
                  );
                }
                if (n2.data.indexOf("?>") !== -1) {
                  throw new DOMException(INVALID_STATE_ERR, 'The ProcessingInstruction data contains "?>"');
                }
              }
              buf.push("<?", n2.target, " ", n2.data, "?>");
              return null;
            case ENTITY_REFERENCE_NODE:
              if (requireWellFormed && !tagNamePattern.test(n2.nodeName)) {
                throw new DOMException(
                  INVALID_STATE_ERR,
                  'The entity reference name "' + n2.nodeName + '" is not a valid XML Name'
                );
              }
              buf.push("&", n2.nodeName, ";");
              return null;
            //case ENTITY_NODE:
            //case NOTATION_NODE:
            default:
              buf.push("??", n2.nodeName);
              return null;
          }
        },
        exit: function(n2, childCtx) {
          if (childCtx && childCtx.tag) {
            buf.push("</", childCtx.tag, ">");
          }
        }
      });
    }
    function importNode(doc, node, deep) {
      var destRoot;
      walkDOM(node, null, {
        enter: function(srcNode, destParent) {
          var destNode = srcNode.cloneNode(false);
          destNode.ownerDocument = doc;
          destNode.parentNode = null;
          if (destParent === null) {
            destRoot = destNode;
          } else {
            destParent.appendChild(destNode);
          }
          var shouldDeep = srcNode.nodeType === ATTRIBUTE_NODE || deep;
          return shouldDeep ? destNode : null;
        }
      });
      return destRoot;
    }
    function cloneNode(doc, node, deep) {
      var destRoot;
      walkDOM(node, null, {
        enter: function(srcNode, destParent) {
          var destNode = new srcNode.constructor();
          for (var n2 in srcNode) {
            if (Object.prototype.hasOwnProperty.call(srcNode, n2)) {
              var v = srcNode[n2];
              if (typeof v != "object") {
                if (v != destNode[n2]) {
                  destNode[n2] = v;
                }
              }
            }
          }
          if (srcNode.childNodes) {
            destNode.childNodes = new NodeList();
          }
          destNode.ownerDocument = doc;
          var shouldDeep = deep;
          switch (destNode.nodeType) {
            case ELEMENT_NODE:
              var attrs = srcNode.attributes;
              var attrs2 = destNode.attributes = new NamedNodeMap();
              var len = attrs.length;
              attrs2._ownerElement = destNode;
              for (var i = 0; i < len; i++) {
                destNode.setAttributeNode(cloneNode(doc, attrs.item(i), true));
              }
              break;
            case ATTRIBUTE_NODE:
              shouldDeep = true;
          }
          if (destParent !== null) {
            destParent.appendChild(destNode);
          } else {
            destRoot = destNode;
          }
          return shouldDeep ? destNode : null;
        }
      });
      return destRoot;
    }
    function __set__(object, key, value) {
      object[key] = value;
    }
    try {
      if (Object.defineProperty) {
        Object.defineProperty(LiveNodeList.prototype, "length", {
          get: function() {
            _updateLiveList(this);
            return this.$$length;
          }
        });
        Object.defineProperty(Node.prototype, "textContent", {
          get: function() {
            if (this.nodeType === ELEMENT_NODE || this.nodeType === DOCUMENT_FRAGMENT_NODE) {
              var buf = [];
              walkDOM(this, null, {
                enter: function(n2) {
                  if (n2.nodeType === ELEMENT_NODE || n2.nodeType === DOCUMENT_FRAGMENT_NODE) {
                    return true;
                  }
                  if (n2.nodeType === PROCESSING_INSTRUCTION_NODE || n2.nodeType === COMMENT_NODE) {
                    return null;
                  }
                  buf.push(n2.nodeValue);
                }
              });
              return buf.join("");
            }
            return this.nodeValue;
          },
          set: function(data) {
            switch (this.nodeType) {
              case ELEMENT_NODE:
              case DOCUMENT_FRAGMENT_NODE:
                while (this.firstChild) {
                  this.removeChild(this.firstChild);
                }
                if (data || String(data)) {
                  this.appendChild(this.ownerDocument.createTextNode(data));
                }
                break;
              default:
                this.data = data;
                this.value = data;
                this.nodeValue = data;
            }
          }
        });
        __set__ = function(object, key, value) {
          object["$$" + key] = value;
        };
      }
    } catch (e) {
    }
    exports.DocumentType = DocumentType;
    exports.DOMException = DOMException;
    exports.DOMImplementation = DOMImplementation;
    exports.Element = Element;
    exports.Node = Node;
    exports.NodeList = NodeList;
    exports.walkDOM = walkDOM;
    exports.XMLSerializer = XMLSerializer2;
  }
});

// node_modules/@xmldom/xmldom/lib/entities.js
var require_entities = __commonJS({
  "node_modules/@xmldom/xmldom/lib/entities.js"(exports) {
    "use strict";
    var freeze = require_conventions().freeze;
    exports.XML_ENTITIES = freeze({
      amp: "&",
      apos: "'",
      gt: ">",
      lt: "<",
      quot: '"'
    });
    exports.HTML_ENTITIES = freeze({
      Aacute: "Á",
      aacute: "á",
      Abreve: "Ă",
      abreve: "ă",
      ac: "∾",
      acd: "∿",
      acE: "∾̳",
      Acirc: "Â",
      acirc: "â",
      acute: "´",
      Acy: "А",
      acy: "а",
      AElig: "Æ",
      aelig: "æ",
      af: "⁡",
      Afr: "𝔄",
      afr: "𝔞",
      Agrave: "À",
      agrave: "à",
      alefsym: "ℵ",
      aleph: "ℵ",
      Alpha: "Α",
      alpha: "α",
      Amacr: "Ā",
      amacr: "ā",
      amalg: "⨿",
      AMP: "&",
      amp: "&",
      And: "⩓",
      and: "∧",
      andand: "⩕",
      andd: "⩜",
      andslope: "⩘",
      andv: "⩚",
      ang: "∠",
      ange: "⦤",
      angle: "∠",
      angmsd: "∡",
      angmsdaa: "⦨",
      angmsdab: "⦩",
      angmsdac: "⦪",
      angmsdad: "⦫",
      angmsdae: "⦬",
      angmsdaf: "⦭",
      angmsdag: "⦮",
      angmsdah: "⦯",
      angrt: "∟",
      angrtvb: "⊾",
      angrtvbd: "⦝",
      angsph: "∢",
      angst: "Å",
      angzarr: "⍼",
      Aogon: "Ą",
      aogon: "ą",
      Aopf: "𝔸",
      aopf: "𝕒",
      ap: "≈",
      apacir: "⩯",
      apE: "⩰",
      ape: "≊",
      apid: "≋",
      apos: "'",
      ApplyFunction: "⁡",
      approx: "≈",
      approxeq: "≊",
      Aring: "Å",
      aring: "å",
      Ascr: "𝒜",
      ascr: "𝒶",
      Assign: "≔",
      ast: "*",
      asymp: "≈",
      asympeq: "≍",
      Atilde: "Ã",
      atilde: "ã",
      Auml: "Ä",
      auml: "ä",
      awconint: "∳",
      awint: "⨑",
      backcong: "≌",
      backepsilon: "϶",
      backprime: "‵",
      backsim: "∽",
      backsimeq: "⋍",
      Backslash: "∖",
      Barv: "⫧",
      barvee: "⊽",
      Barwed: "⌆",
      barwed: "⌅",
      barwedge: "⌅",
      bbrk: "⎵",
      bbrktbrk: "⎶",
      bcong: "≌",
      Bcy: "Б",
      bcy: "б",
      bdquo: "„",
      becaus: "∵",
      Because: "∵",
      because: "∵",
      bemptyv: "⦰",
      bepsi: "϶",
      bernou: "ℬ",
      Bernoullis: "ℬ",
      Beta: "Β",
      beta: "β",
      beth: "ℶ",
      between: "≬",
      Bfr: "𝔅",
      bfr: "𝔟",
      bigcap: "⋂",
      bigcirc: "◯",
      bigcup: "⋃",
      bigodot: "⨀",
      bigoplus: "⨁",
      bigotimes: "⨂",
      bigsqcup: "⨆",
      bigstar: "★",
      bigtriangledown: "▽",
      bigtriangleup: "△",
      biguplus: "⨄",
      bigvee: "⋁",
      bigwedge: "⋀",
      bkarow: "⤍",
      blacklozenge: "⧫",
      blacksquare: "▪",
      blacktriangle: "▴",
      blacktriangledown: "▾",
      blacktriangleleft: "◂",
      blacktriangleright: "▸",
      blank: "␣",
      blk12: "▒",
      blk14: "░",
      blk34: "▓",
      block: "█",
      bne: "=⃥",
      bnequiv: "≡⃥",
      bNot: "⫭",
      bnot: "⌐",
      Bopf: "𝔹",
      bopf: "𝕓",
      bot: "⊥",
      bottom: "⊥",
      bowtie: "⋈",
      boxbox: "⧉",
      boxDL: "╗",
      boxDl: "╖",
      boxdL: "╕",
      boxdl: "┐",
      boxDR: "╔",
      boxDr: "╓",
      boxdR: "╒",
      boxdr: "┌",
      boxH: "═",
      boxh: "─",
      boxHD: "╦",
      boxHd: "╤",
      boxhD: "╥",
      boxhd: "┬",
      boxHU: "╩",
      boxHu: "╧",
      boxhU: "╨",
      boxhu: "┴",
      boxminus: "⊟",
      boxplus: "⊞",
      boxtimes: "⊠",
      boxUL: "╝",
      boxUl: "╜",
      boxuL: "╛",
      boxul: "┘",
      boxUR: "╚",
      boxUr: "╙",
      boxuR: "╘",
      boxur: "└",
      boxV: "║",
      boxv: "│",
      boxVH: "╬",
      boxVh: "╫",
      boxvH: "╪",
      boxvh: "┼",
      boxVL: "╣",
      boxVl: "╢",
      boxvL: "╡",
      boxvl: "┤",
      boxVR: "╠",
      boxVr: "╟",
      boxvR: "╞",
      boxvr: "├",
      bprime: "‵",
      Breve: "˘",
      breve: "˘",
      brvbar: "¦",
      Bscr: "ℬ",
      bscr: "𝒷",
      bsemi: "⁏",
      bsim: "∽",
      bsime: "⋍",
      bsol: "\\",
      bsolb: "⧅",
      bsolhsub: "⟈",
      bull: "•",
      bullet: "•",
      bump: "≎",
      bumpE: "⪮",
      bumpe: "≏",
      Bumpeq: "≎",
      bumpeq: "≏",
      Cacute: "Ć",
      cacute: "ć",
      Cap: "⋒",
      cap: "∩",
      capand: "⩄",
      capbrcup: "⩉",
      capcap: "⩋",
      capcup: "⩇",
      capdot: "⩀",
      CapitalDifferentialD: "ⅅ",
      caps: "∩︀",
      caret: "⁁",
      caron: "ˇ",
      Cayleys: "ℭ",
      ccaps: "⩍",
      Ccaron: "Č",
      ccaron: "č",
      Ccedil: "Ç",
      ccedil: "ç",
      Ccirc: "Ĉ",
      ccirc: "ĉ",
      Cconint: "∰",
      ccups: "⩌",
      ccupssm: "⩐",
      Cdot: "Ċ",
      cdot: "ċ",
      cedil: "¸",
      Cedilla: "¸",
      cemptyv: "⦲",
      cent: "¢",
      CenterDot: "·",
      centerdot: "·",
      Cfr: "ℭ",
      cfr: "𝔠",
      CHcy: "Ч",
      chcy: "ч",
      check: "✓",
      checkmark: "✓",
      Chi: "Χ",
      chi: "χ",
      cir: "○",
      circ: "ˆ",
      circeq: "≗",
      circlearrowleft: "↺",
      circlearrowright: "↻",
      circledast: "⊛",
      circledcirc: "⊚",
      circleddash: "⊝",
      CircleDot: "⊙",
      circledR: "®",
      circledS: "Ⓢ",
      CircleMinus: "⊖",
      CirclePlus: "⊕",
      CircleTimes: "⊗",
      cirE: "⧃",
      cire: "≗",
      cirfnint: "⨐",
      cirmid: "⫯",
      cirscir: "⧂",
      ClockwiseContourIntegral: "∲",
      CloseCurlyDoubleQuote: "”",
      CloseCurlyQuote: "’",
      clubs: "♣",
      clubsuit: "♣",
      Colon: "∷",
      colon: ":",
      Colone: "⩴",
      colone: "≔",
      coloneq: "≔",
      comma: ",",
      commat: "@",
      comp: "∁",
      compfn: "∘",
      complement: "∁",
      complexes: "ℂ",
      cong: "≅",
      congdot: "⩭",
      Congruent: "≡",
      Conint: "∯",
      conint: "∮",
      ContourIntegral: "∮",
      Copf: "ℂ",
      copf: "𝕔",
      coprod: "∐",
      Coproduct: "∐",
      COPY: "©",
      copy: "©",
      copysr: "℗",
      CounterClockwiseContourIntegral: "∳",
      crarr: "↵",
      Cross: "⨯",
      cross: "✗",
      Cscr: "𝒞",
      cscr: "𝒸",
      csub: "⫏",
      csube: "⫑",
      csup: "⫐",
      csupe: "⫒",
      ctdot: "⋯",
      cudarrl: "⤸",
      cudarrr: "⤵",
      cuepr: "⋞",
      cuesc: "⋟",
      cularr: "↶",
      cularrp: "⤽",
      Cup: "⋓",
      cup: "∪",
      cupbrcap: "⩈",
      CupCap: "≍",
      cupcap: "⩆",
      cupcup: "⩊",
      cupdot: "⊍",
      cupor: "⩅",
      cups: "∪︀",
      curarr: "↷",
      curarrm: "⤼",
      curlyeqprec: "⋞",
      curlyeqsucc: "⋟",
      curlyvee: "⋎",
      curlywedge: "⋏",
      curren: "¤",
      curvearrowleft: "↶",
      curvearrowright: "↷",
      cuvee: "⋎",
      cuwed: "⋏",
      cwconint: "∲",
      cwint: "∱",
      cylcty: "⌭",
      Dagger: "‡",
      dagger: "†",
      daleth: "ℸ",
      Darr: "↡",
      dArr: "⇓",
      darr: "↓",
      dash: "‐",
      Dashv: "⫤",
      dashv: "⊣",
      dbkarow: "⤏",
      dblac: "˝",
      Dcaron: "Ď",
      dcaron: "ď",
      Dcy: "Д",
      dcy: "д",
      DD: "ⅅ",
      dd: "ⅆ",
      ddagger: "‡",
      ddarr: "⇊",
      DDotrahd: "⤑",
      ddotseq: "⩷",
      deg: "°",
      Del: "∇",
      Delta: "Δ",
      delta: "δ",
      demptyv: "⦱",
      dfisht: "⥿",
      Dfr: "𝔇",
      dfr: "𝔡",
      dHar: "⥥",
      dharl: "⇃",
      dharr: "⇂",
      DiacriticalAcute: "´",
      DiacriticalDot: "˙",
      DiacriticalDoubleAcute: "˝",
      DiacriticalGrave: "`",
      DiacriticalTilde: "˜",
      diam: "⋄",
      Diamond: "⋄",
      diamond: "⋄",
      diamondsuit: "♦",
      diams: "♦",
      die: "¨",
      DifferentialD: "ⅆ",
      digamma: "ϝ",
      disin: "⋲",
      div: "÷",
      divide: "÷",
      divideontimes: "⋇",
      divonx: "⋇",
      DJcy: "Ђ",
      djcy: "ђ",
      dlcorn: "⌞",
      dlcrop: "⌍",
      dollar: "$",
      Dopf: "𝔻",
      dopf: "𝕕",
      Dot: "¨",
      dot: "˙",
      DotDot: "⃜",
      doteq: "≐",
      doteqdot: "≑",
      DotEqual: "≐",
      dotminus: "∸",
      dotplus: "∔",
      dotsquare: "⊡",
      doublebarwedge: "⌆",
      DoubleContourIntegral: "∯",
      DoubleDot: "¨",
      DoubleDownArrow: "⇓",
      DoubleLeftArrow: "⇐",
      DoubleLeftRightArrow: "⇔",
      DoubleLeftTee: "⫤",
      DoubleLongLeftArrow: "⟸",
      DoubleLongLeftRightArrow: "⟺",
      DoubleLongRightArrow: "⟹",
      DoubleRightArrow: "⇒",
      DoubleRightTee: "⊨",
      DoubleUpArrow: "⇑",
      DoubleUpDownArrow: "⇕",
      DoubleVerticalBar: "∥",
      DownArrow: "↓",
      Downarrow: "⇓",
      downarrow: "↓",
      DownArrowBar: "⤓",
      DownArrowUpArrow: "⇵",
      DownBreve: "̑",
      downdownarrows: "⇊",
      downharpoonleft: "⇃",
      downharpoonright: "⇂",
      DownLeftRightVector: "⥐",
      DownLeftTeeVector: "⥞",
      DownLeftVector: "↽",
      DownLeftVectorBar: "⥖",
      DownRightTeeVector: "⥟",
      DownRightVector: "⇁",
      DownRightVectorBar: "⥗",
      DownTee: "⊤",
      DownTeeArrow: "↧",
      drbkarow: "⤐",
      drcorn: "⌟",
      drcrop: "⌌",
      Dscr: "𝒟",
      dscr: "𝒹",
      DScy: "Ѕ",
      dscy: "ѕ",
      dsol: "⧶",
      Dstrok: "Đ",
      dstrok: "đ",
      dtdot: "⋱",
      dtri: "▿",
      dtrif: "▾",
      duarr: "⇵",
      duhar: "⥯",
      dwangle: "⦦",
      DZcy: "Џ",
      dzcy: "џ",
      dzigrarr: "⟿",
      Eacute: "É",
      eacute: "é",
      easter: "⩮",
      Ecaron: "Ě",
      ecaron: "ě",
      ecir: "≖",
      Ecirc: "Ê",
      ecirc: "ê",
      ecolon: "≕",
      Ecy: "Э",
      ecy: "э",
      eDDot: "⩷",
      Edot: "Ė",
      eDot: "≑",
      edot: "ė",
      ee: "ⅇ",
      efDot: "≒",
      Efr: "𝔈",
      efr: "𝔢",
      eg: "⪚",
      Egrave: "È",
      egrave: "è",
      egs: "⪖",
      egsdot: "⪘",
      el: "⪙",
      Element: "∈",
      elinters: "⏧",
      ell: "ℓ",
      els: "⪕",
      elsdot: "⪗",
      Emacr: "Ē",
      emacr: "ē",
      empty: "∅",
      emptyset: "∅",
      EmptySmallSquare: "◻",
      emptyv: "∅",
      EmptyVerySmallSquare: "▫",
      emsp: " ",
      emsp13: " ",
      emsp14: " ",
      ENG: "Ŋ",
      eng: "ŋ",
      ensp: " ",
      Eogon: "Ę",
      eogon: "ę",
      Eopf: "𝔼",
      eopf: "𝕖",
      epar: "⋕",
      eparsl: "⧣",
      eplus: "⩱",
      epsi: "ε",
      Epsilon: "Ε",
      epsilon: "ε",
      epsiv: "ϵ",
      eqcirc: "≖",
      eqcolon: "≕",
      eqsim: "≂",
      eqslantgtr: "⪖",
      eqslantless: "⪕",
      Equal: "⩵",
      equals: "=",
      EqualTilde: "≂",
      equest: "≟",
      Equilibrium: "⇌",
      equiv: "≡",
      equivDD: "⩸",
      eqvparsl: "⧥",
      erarr: "⥱",
      erDot: "≓",
      Escr: "ℰ",
      escr: "ℯ",
      esdot: "≐",
      Esim: "⩳",
      esim: "≂",
      Eta: "Η",
      eta: "η",
      ETH: "Ð",
      eth: "ð",
      Euml: "Ë",
      euml: "ë",
      euro: "€",
      excl: "!",
      exist: "∃",
      Exists: "∃",
      expectation: "ℰ",
      ExponentialE: "ⅇ",
      exponentiale: "ⅇ",
      fallingdotseq: "≒",
      Fcy: "Ф",
      fcy: "ф",
      female: "♀",
      ffilig: "ﬃ",
      fflig: "ﬀ",
      ffllig: "ﬄ",
      Ffr: "𝔉",
      ffr: "𝔣",
      filig: "ﬁ",
      FilledSmallSquare: "◼",
      FilledVerySmallSquare: "▪",
      fjlig: "fj",
      flat: "♭",
      fllig: "ﬂ",
      fltns: "▱",
      fnof: "ƒ",
      Fopf: "𝔽",
      fopf: "𝕗",
      ForAll: "∀",
      forall: "∀",
      fork: "⋔",
      forkv: "⫙",
      Fouriertrf: "ℱ",
      fpartint: "⨍",
      frac12: "½",
      frac13: "⅓",
      frac14: "¼",
      frac15: "⅕",
      frac16: "⅙",
      frac18: "⅛",
      frac23: "⅔",
      frac25: "⅖",
      frac34: "¾",
      frac35: "⅗",
      frac38: "⅜",
      frac45: "⅘",
      frac56: "⅚",
      frac58: "⅝",
      frac78: "⅞",
      frasl: "⁄",
      frown: "⌢",
      Fscr: "ℱ",
      fscr: "𝒻",
      gacute: "ǵ",
      Gamma: "Γ",
      gamma: "γ",
      Gammad: "Ϝ",
      gammad: "ϝ",
      gap: "⪆",
      Gbreve: "Ğ",
      gbreve: "ğ",
      Gcedil: "Ģ",
      Gcirc: "Ĝ",
      gcirc: "ĝ",
      Gcy: "Г",
      gcy: "г",
      Gdot: "Ġ",
      gdot: "ġ",
      gE: "≧",
      ge: "≥",
      gEl: "⪌",
      gel: "⋛",
      geq: "≥",
      geqq: "≧",
      geqslant: "⩾",
      ges: "⩾",
      gescc: "⪩",
      gesdot: "⪀",
      gesdoto: "⪂",
      gesdotol: "⪄",
      gesl: "⋛︀",
      gesles: "⪔",
      Gfr: "𝔊",
      gfr: "𝔤",
      Gg: "⋙",
      gg: "≫",
      ggg: "⋙",
      gimel: "ℷ",
      GJcy: "Ѓ",
      gjcy: "ѓ",
      gl: "≷",
      gla: "⪥",
      glE: "⪒",
      glj: "⪤",
      gnap: "⪊",
      gnapprox: "⪊",
      gnE: "≩",
      gne: "⪈",
      gneq: "⪈",
      gneqq: "≩",
      gnsim: "⋧",
      Gopf: "𝔾",
      gopf: "𝕘",
      grave: "`",
      GreaterEqual: "≥",
      GreaterEqualLess: "⋛",
      GreaterFullEqual: "≧",
      GreaterGreater: "⪢",
      GreaterLess: "≷",
      GreaterSlantEqual: "⩾",
      GreaterTilde: "≳",
      Gscr: "𝒢",
      gscr: "ℊ",
      gsim: "≳",
      gsime: "⪎",
      gsiml: "⪐",
      Gt: "≫",
      GT: ">",
      gt: ">",
      gtcc: "⪧",
      gtcir: "⩺",
      gtdot: "⋗",
      gtlPar: "⦕",
      gtquest: "⩼",
      gtrapprox: "⪆",
      gtrarr: "⥸",
      gtrdot: "⋗",
      gtreqless: "⋛",
      gtreqqless: "⪌",
      gtrless: "≷",
      gtrsim: "≳",
      gvertneqq: "≩︀",
      gvnE: "≩︀",
      Hacek: "ˇ",
      hairsp: " ",
      half: "½",
      hamilt: "ℋ",
      HARDcy: "Ъ",
      hardcy: "ъ",
      hArr: "⇔",
      harr: "↔",
      harrcir: "⥈",
      harrw: "↭",
      Hat: "^",
      hbar: "ℏ",
      Hcirc: "Ĥ",
      hcirc: "ĥ",
      hearts: "♥",
      heartsuit: "♥",
      hellip: "…",
      hercon: "⊹",
      Hfr: "ℌ",
      hfr: "𝔥",
      HilbertSpace: "ℋ",
      hksearow: "⤥",
      hkswarow: "⤦",
      hoarr: "⇿",
      homtht: "∻",
      hookleftarrow: "↩",
      hookrightarrow: "↪",
      Hopf: "ℍ",
      hopf: "𝕙",
      horbar: "―",
      HorizontalLine: "─",
      Hscr: "ℋ",
      hscr: "𝒽",
      hslash: "ℏ",
      Hstrok: "Ħ",
      hstrok: "ħ",
      HumpDownHump: "≎",
      HumpEqual: "≏",
      hybull: "⁃",
      hyphen: "‐",
      Iacute: "Í",
      iacute: "í",
      ic: "⁣",
      Icirc: "Î",
      icirc: "î",
      Icy: "И",
      icy: "и",
      Idot: "İ",
      IEcy: "Е",
      iecy: "е",
      iexcl: "¡",
      iff: "⇔",
      Ifr: "ℑ",
      ifr: "𝔦",
      Igrave: "Ì",
      igrave: "ì",
      ii: "ⅈ",
      iiiint: "⨌",
      iiint: "∭",
      iinfin: "⧜",
      iiota: "℩",
      IJlig: "Ĳ",
      ijlig: "ĳ",
      Im: "ℑ",
      Imacr: "Ī",
      imacr: "ī",
      image: "ℑ",
      ImaginaryI: "ⅈ",
      imagline: "ℐ",
      imagpart: "ℑ",
      imath: "ı",
      imof: "⊷",
      imped: "Ƶ",
      Implies: "⇒",
      in: "∈",
      incare: "℅",
      infin: "∞",
      infintie: "⧝",
      inodot: "ı",
      Int: "∬",
      int: "∫",
      intcal: "⊺",
      integers: "ℤ",
      Integral: "∫",
      intercal: "⊺",
      Intersection: "⋂",
      intlarhk: "⨗",
      intprod: "⨼",
      InvisibleComma: "⁣",
      InvisibleTimes: "⁢",
      IOcy: "Ё",
      iocy: "ё",
      Iogon: "Į",
      iogon: "į",
      Iopf: "𝕀",
      iopf: "𝕚",
      Iota: "Ι",
      iota: "ι",
      iprod: "⨼",
      iquest: "¿",
      Iscr: "ℐ",
      iscr: "𝒾",
      isin: "∈",
      isindot: "⋵",
      isinE: "⋹",
      isins: "⋴",
      isinsv: "⋳",
      isinv: "∈",
      it: "⁢",
      Itilde: "Ĩ",
      itilde: "ĩ",
      Iukcy: "І",
      iukcy: "і",
      Iuml: "Ï",
      iuml: "ï",
      Jcirc: "Ĵ",
      jcirc: "ĵ",
      Jcy: "Й",
      jcy: "й",
      Jfr: "𝔍",
      jfr: "𝔧",
      jmath: "ȷ",
      Jopf: "𝕁",
      jopf: "𝕛",
      Jscr: "𝒥",
      jscr: "𝒿",
      Jsercy: "Ј",
      jsercy: "ј",
      Jukcy: "Є",
      jukcy: "є",
      Kappa: "Κ",
      kappa: "κ",
      kappav: "ϰ",
      Kcedil: "Ķ",
      kcedil: "ķ",
      Kcy: "К",
      kcy: "к",
      Kfr: "𝔎",
      kfr: "𝔨",
      kgreen: "ĸ",
      KHcy: "Х",
      khcy: "х",
      KJcy: "Ќ",
      kjcy: "ќ",
      Kopf: "𝕂",
      kopf: "𝕜",
      Kscr: "𝒦",
      kscr: "𝓀",
      lAarr: "⇚",
      Lacute: "Ĺ",
      lacute: "ĺ",
      laemptyv: "⦴",
      lagran: "ℒ",
      Lambda: "Λ",
      lambda: "λ",
      Lang: "⟪",
      lang: "⟨",
      langd: "⦑",
      langle: "⟨",
      lap: "⪅",
      Laplacetrf: "ℒ",
      laquo: "«",
      Larr: "↞",
      lArr: "⇐",
      larr: "←",
      larrb: "⇤",
      larrbfs: "⤟",
      larrfs: "⤝",
      larrhk: "↩",
      larrlp: "↫",
      larrpl: "⤹",
      larrsim: "⥳",
      larrtl: "↢",
      lat: "⪫",
      lAtail: "⤛",
      latail: "⤙",
      late: "⪭",
      lates: "⪭︀",
      lBarr: "⤎",
      lbarr: "⤌",
      lbbrk: "❲",
      lbrace: "{",
      lbrack: "[",
      lbrke: "⦋",
      lbrksld: "⦏",
      lbrkslu: "⦍",
      Lcaron: "Ľ",
      lcaron: "ľ",
      Lcedil: "Ļ",
      lcedil: "ļ",
      lceil: "⌈",
      lcub: "{",
      Lcy: "Л",
      lcy: "л",
      ldca: "⤶",
      ldquo: "“",
      ldquor: "„",
      ldrdhar: "⥧",
      ldrushar: "⥋",
      ldsh: "↲",
      lE: "≦",
      le: "≤",
      LeftAngleBracket: "⟨",
      LeftArrow: "←",
      Leftarrow: "⇐",
      leftarrow: "←",
      LeftArrowBar: "⇤",
      LeftArrowRightArrow: "⇆",
      leftarrowtail: "↢",
      LeftCeiling: "⌈",
      LeftDoubleBracket: "⟦",
      LeftDownTeeVector: "⥡",
      LeftDownVector: "⇃",
      LeftDownVectorBar: "⥙",
      LeftFloor: "⌊",
      leftharpoondown: "↽",
      leftharpoonup: "↼",
      leftleftarrows: "⇇",
      LeftRightArrow: "↔",
      Leftrightarrow: "⇔",
      leftrightarrow: "↔",
      leftrightarrows: "⇆",
      leftrightharpoons: "⇋",
      leftrightsquigarrow: "↭",
      LeftRightVector: "⥎",
      LeftTee: "⊣",
      LeftTeeArrow: "↤",
      LeftTeeVector: "⥚",
      leftthreetimes: "⋋",
      LeftTriangle: "⊲",
      LeftTriangleBar: "⧏",
      LeftTriangleEqual: "⊴",
      LeftUpDownVector: "⥑",
      LeftUpTeeVector: "⥠",
      LeftUpVector: "↿",
      LeftUpVectorBar: "⥘",
      LeftVector: "↼",
      LeftVectorBar: "⥒",
      lEg: "⪋",
      leg: "⋚",
      leq: "≤",
      leqq: "≦",
      leqslant: "⩽",
      les: "⩽",
      lescc: "⪨",
      lesdot: "⩿",
      lesdoto: "⪁",
      lesdotor: "⪃",
      lesg: "⋚︀",
      lesges: "⪓",
      lessapprox: "⪅",
      lessdot: "⋖",
      lesseqgtr: "⋚",
      lesseqqgtr: "⪋",
      LessEqualGreater: "⋚",
      LessFullEqual: "≦",
      LessGreater: "≶",
      lessgtr: "≶",
      LessLess: "⪡",
      lesssim: "≲",
      LessSlantEqual: "⩽",
      LessTilde: "≲",
      lfisht: "⥼",
      lfloor: "⌊",
      Lfr: "𝔏",
      lfr: "𝔩",
      lg: "≶",
      lgE: "⪑",
      lHar: "⥢",
      lhard: "↽",
      lharu: "↼",
      lharul: "⥪",
      lhblk: "▄",
      LJcy: "Љ",
      ljcy: "љ",
      Ll: "⋘",
      ll: "≪",
      llarr: "⇇",
      llcorner: "⌞",
      Lleftarrow: "⇚",
      llhard: "⥫",
      lltri: "◺",
      Lmidot: "Ŀ",
      lmidot: "ŀ",
      lmoust: "⎰",
      lmoustache: "⎰",
      lnap: "⪉",
      lnapprox: "⪉",
      lnE: "≨",
      lne: "⪇",
      lneq: "⪇",
      lneqq: "≨",
      lnsim: "⋦",
      loang: "⟬",
      loarr: "⇽",
      lobrk: "⟦",
      LongLeftArrow: "⟵",
      Longleftarrow: "⟸",
      longleftarrow: "⟵",
      LongLeftRightArrow: "⟷",
      Longleftrightarrow: "⟺",
      longleftrightarrow: "⟷",
      longmapsto: "⟼",
      LongRightArrow: "⟶",
      Longrightarrow: "⟹",
      longrightarrow: "⟶",
      looparrowleft: "↫",
      looparrowright: "↬",
      lopar: "⦅",
      Lopf: "𝕃",
      lopf: "𝕝",
      loplus: "⨭",
      lotimes: "⨴",
      lowast: "∗",
      lowbar: "_",
      LowerLeftArrow: "↙",
      LowerRightArrow: "↘",
      loz: "◊",
      lozenge: "◊",
      lozf: "⧫",
      lpar: "(",
      lparlt: "⦓",
      lrarr: "⇆",
      lrcorner: "⌟",
      lrhar: "⇋",
      lrhard: "⥭",
      lrm: "‎",
      lrtri: "⊿",
      lsaquo: "‹",
      Lscr: "ℒ",
      lscr: "𝓁",
      Lsh: "↰",
      lsh: "↰",
      lsim: "≲",
      lsime: "⪍",
      lsimg: "⪏",
      lsqb: "[",
      lsquo: "‘",
      lsquor: "‚",
      Lstrok: "Ł",
      lstrok: "ł",
      Lt: "≪",
      LT: "<",
      lt: "<",
      ltcc: "⪦",
      ltcir: "⩹",
      ltdot: "⋖",
      lthree: "⋋",
      ltimes: "⋉",
      ltlarr: "⥶",
      ltquest: "⩻",
      ltri: "◃",
      ltrie: "⊴",
      ltrif: "◂",
      ltrPar: "⦖",
      lurdshar: "⥊",
      luruhar: "⥦",
      lvertneqq: "≨︀",
      lvnE: "≨︀",
      macr: "¯",
      male: "♂",
      malt: "✠",
      maltese: "✠",
      Map: "⤅",
      map: "↦",
      mapsto: "↦",
      mapstodown: "↧",
      mapstoleft: "↤",
      mapstoup: "↥",
      marker: "▮",
      mcomma: "⨩",
      Mcy: "М",
      mcy: "м",
      mdash: "—",
      mDDot: "∺",
      measuredangle: "∡",
      MediumSpace: " ",
      Mellintrf: "ℳ",
      Mfr: "𝔐",
      mfr: "𝔪",
      mho: "℧",
      micro: "µ",
      mid: "∣",
      midast: "*",
      midcir: "⫰",
      middot: "·",
      minus: "−",
      minusb: "⊟",
      minusd: "∸",
      minusdu: "⨪",
      MinusPlus: "∓",
      mlcp: "⫛",
      mldr: "…",
      mnplus: "∓",
      models: "⊧",
      Mopf: "𝕄",
      mopf: "𝕞",
      mp: "∓",
      Mscr: "ℳ",
      mscr: "𝓂",
      mstpos: "∾",
      Mu: "Μ",
      mu: "μ",
      multimap: "⊸",
      mumap: "⊸",
      nabla: "∇",
      Nacute: "Ń",
      nacute: "ń",
      nang: "∠⃒",
      nap: "≉",
      napE: "⩰̸",
      napid: "≋̸",
      napos: "ŉ",
      napprox: "≉",
      natur: "♮",
      natural: "♮",
      naturals: "ℕ",
      nbsp: " ",
      nbump: "≎̸",
      nbumpe: "≏̸",
      ncap: "⩃",
      Ncaron: "Ň",
      ncaron: "ň",
      Ncedil: "Ņ",
      ncedil: "ņ",
      ncong: "≇",
      ncongdot: "⩭̸",
      ncup: "⩂",
      Ncy: "Н",
      ncy: "н",
      ndash: "–",
      ne: "≠",
      nearhk: "⤤",
      neArr: "⇗",
      nearr: "↗",
      nearrow: "↗",
      nedot: "≐̸",
      NegativeMediumSpace: "​",
      NegativeThickSpace: "​",
      NegativeThinSpace: "​",
      NegativeVeryThinSpace: "​",
      nequiv: "≢",
      nesear: "⤨",
      nesim: "≂̸",
      NestedGreaterGreater: "≫",
      NestedLessLess: "≪",
      NewLine: "\n",
      nexist: "∄",
      nexists: "∄",
      Nfr: "𝔑",
      nfr: "𝔫",
      ngE: "≧̸",
      nge: "≱",
      ngeq: "≱",
      ngeqq: "≧̸",
      ngeqslant: "⩾̸",
      nges: "⩾̸",
      nGg: "⋙̸",
      ngsim: "≵",
      nGt: "≫⃒",
      ngt: "≯",
      ngtr: "≯",
      nGtv: "≫̸",
      nhArr: "⇎",
      nharr: "↮",
      nhpar: "⫲",
      ni: "∋",
      nis: "⋼",
      nisd: "⋺",
      niv: "∋",
      NJcy: "Њ",
      njcy: "њ",
      nlArr: "⇍",
      nlarr: "↚",
      nldr: "‥",
      nlE: "≦̸",
      nle: "≰",
      nLeftarrow: "⇍",
      nleftarrow: "↚",
      nLeftrightarrow: "⇎",
      nleftrightarrow: "↮",
      nleq: "≰",
      nleqq: "≦̸",
      nleqslant: "⩽̸",
      nles: "⩽̸",
      nless: "≮",
      nLl: "⋘̸",
      nlsim: "≴",
      nLt: "≪⃒",
      nlt: "≮",
      nltri: "⋪",
      nltrie: "⋬",
      nLtv: "≪̸",
      nmid: "∤",
      NoBreak: "⁠",
      NonBreakingSpace: " ",
      Nopf: "ℕ",
      nopf: "𝕟",
      Not: "⫬",
      not: "¬",
      NotCongruent: "≢",
      NotCupCap: "≭",
      NotDoubleVerticalBar: "∦",
      NotElement: "∉",
      NotEqual: "≠",
      NotEqualTilde: "≂̸",
      NotExists: "∄",
      NotGreater: "≯",
      NotGreaterEqual: "≱",
      NotGreaterFullEqual: "≧̸",
      NotGreaterGreater: "≫̸",
      NotGreaterLess: "≹",
      NotGreaterSlantEqual: "⩾̸",
      NotGreaterTilde: "≵",
      NotHumpDownHump: "≎̸",
      NotHumpEqual: "≏̸",
      notin: "∉",
      notindot: "⋵̸",
      notinE: "⋹̸",
      notinva: "∉",
      notinvb: "⋷",
      notinvc: "⋶",
      NotLeftTriangle: "⋪",
      NotLeftTriangleBar: "⧏̸",
      NotLeftTriangleEqual: "⋬",
      NotLess: "≮",
      NotLessEqual: "≰",
      NotLessGreater: "≸",
      NotLessLess: "≪̸",
      NotLessSlantEqual: "⩽̸",
      NotLessTilde: "≴",
      NotNestedGreaterGreater: "⪢̸",
      NotNestedLessLess: "⪡̸",
      notni: "∌",
      notniva: "∌",
      notnivb: "⋾",
      notnivc: "⋽",
      NotPrecedes: "⊀",
      NotPrecedesEqual: "⪯̸",
      NotPrecedesSlantEqual: "⋠",
      NotReverseElement: "∌",
      NotRightTriangle: "⋫",
      NotRightTriangleBar: "⧐̸",
      NotRightTriangleEqual: "⋭",
      NotSquareSubset: "⊏̸",
      NotSquareSubsetEqual: "⋢",
      NotSquareSuperset: "⊐̸",
      NotSquareSupersetEqual: "⋣",
      NotSubset: "⊂⃒",
      NotSubsetEqual: "⊈",
      NotSucceeds: "⊁",
      NotSucceedsEqual: "⪰̸",
      NotSucceedsSlantEqual: "⋡",
      NotSucceedsTilde: "≿̸",
      NotSuperset: "⊃⃒",
      NotSupersetEqual: "⊉",
      NotTilde: "≁",
      NotTildeEqual: "≄",
      NotTildeFullEqual: "≇",
      NotTildeTilde: "≉",
      NotVerticalBar: "∤",
      npar: "∦",
      nparallel: "∦",
      nparsl: "⫽⃥",
      npart: "∂̸",
      npolint: "⨔",
      npr: "⊀",
      nprcue: "⋠",
      npre: "⪯̸",
      nprec: "⊀",
      npreceq: "⪯̸",
      nrArr: "⇏",
      nrarr: "↛",
      nrarrc: "⤳̸",
      nrarrw: "↝̸",
      nRightarrow: "⇏",
      nrightarrow: "↛",
      nrtri: "⋫",
      nrtrie: "⋭",
      nsc: "⊁",
      nsccue: "⋡",
      nsce: "⪰̸",
      Nscr: "𝒩",
      nscr: "𝓃",
      nshortmid: "∤",
      nshortparallel: "∦",
      nsim: "≁",
      nsime: "≄",
      nsimeq: "≄",
      nsmid: "∤",
      nspar: "∦",
      nsqsube: "⋢",
      nsqsupe: "⋣",
      nsub: "⊄",
      nsubE: "⫅̸",
      nsube: "⊈",
      nsubset: "⊂⃒",
      nsubseteq: "⊈",
      nsubseteqq: "⫅̸",
      nsucc: "⊁",
      nsucceq: "⪰̸",
      nsup: "⊅",
      nsupE: "⫆̸",
      nsupe: "⊉",
      nsupset: "⊃⃒",
      nsupseteq: "⊉",
      nsupseteqq: "⫆̸",
      ntgl: "≹",
      Ntilde: "Ñ",
      ntilde: "ñ",
      ntlg: "≸",
      ntriangleleft: "⋪",
      ntrianglelefteq: "⋬",
      ntriangleright: "⋫",
      ntrianglerighteq: "⋭",
      Nu: "Ν",
      nu: "ν",
      num: "#",
      numero: "№",
      numsp: " ",
      nvap: "≍⃒",
      nVDash: "⊯",
      nVdash: "⊮",
      nvDash: "⊭",
      nvdash: "⊬",
      nvge: "≥⃒",
      nvgt: ">⃒",
      nvHarr: "⤄",
      nvinfin: "⧞",
      nvlArr: "⤂",
      nvle: "≤⃒",
      nvlt: "<⃒",
      nvltrie: "⊴⃒",
      nvrArr: "⤃",
      nvrtrie: "⊵⃒",
      nvsim: "∼⃒",
      nwarhk: "⤣",
      nwArr: "⇖",
      nwarr: "↖",
      nwarrow: "↖",
      nwnear: "⤧",
      Oacute: "Ó",
      oacute: "ó",
      oast: "⊛",
      ocir: "⊚",
      Ocirc: "Ô",
      ocirc: "ô",
      Ocy: "О",
      ocy: "о",
      odash: "⊝",
      Odblac: "Ő",
      odblac: "ő",
      odiv: "⨸",
      odot: "⊙",
      odsold: "⦼",
      OElig: "Œ",
      oelig: "œ",
      ofcir: "⦿",
      Ofr: "𝔒",
      ofr: "𝔬",
      ogon: "˛",
      Ograve: "Ò",
      ograve: "ò",
      ogt: "⧁",
      ohbar: "⦵",
      ohm: "Ω",
      oint: "∮",
      olarr: "↺",
      olcir: "⦾",
      olcross: "⦻",
      oline: "‾",
      olt: "⧀",
      Omacr: "Ō",
      omacr: "ō",
      Omega: "Ω",
      omega: "ω",
      Omicron: "Ο",
      omicron: "ο",
      omid: "⦶",
      ominus: "⊖",
      Oopf: "𝕆",
      oopf: "𝕠",
      opar: "⦷",
      OpenCurlyDoubleQuote: "“",
      OpenCurlyQuote: "‘",
      operp: "⦹",
      oplus: "⊕",
      Or: "⩔",
      or: "∨",
      orarr: "↻",
      ord: "⩝",
      order: "ℴ",
      orderof: "ℴ",
      ordf: "ª",
      ordm: "º",
      origof: "⊶",
      oror: "⩖",
      orslope: "⩗",
      orv: "⩛",
      oS: "Ⓢ",
      Oscr: "𝒪",
      oscr: "ℴ",
      Oslash: "Ø",
      oslash: "ø",
      osol: "⊘",
      Otilde: "Õ",
      otilde: "õ",
      Otimes: "⨷",
      otimes: "⊗",
      otimesas: "⨶",
      Ouml: "Ö",
      ouml: "ö",
      ovbar: "⌽",
      OverBar: "‾",
      OverBrace: "⏞",
      OverBracket: "⎴",
      OverParenthesis: "⏜",
      par: "∥",
      para: "¶",
      parallel: "∥",
      parsim: "⫳",
      parsl: "⫽",
      part: "∂",
      PartialD: "∂",
      Pcy: "П",
      pcy: "п",
      percnt: "%",
      period: ".",
      permil: "‰",
      perp: "⊥",
      pertenk: "‱",
      Pfr: "𝔓",
      pfr: "𝔭",
      Phi: "Φ",
      phi: "φ",
      phiv: "ϕ",
      phmmat: "ℳ",
      phone: "☎",
      Pi: "Π",
      pi: "π",
      pitchfork: "⋔",
      piv: "ϖ",
      planck: "ℏ",
      planckh: "ℎ",
      plankv: "ℏ",
      plus: "+",
      plusacir: "⨣",
      plusb: "⊞",
      pluscir: "⨢",
      plusdo: "∔",
      plusdu: "⨥",
      pluse: "⩲",
      PlusMinus: "±",
      plusmn: "±",
      plussim: "⨦",
      plustwo: "⨧",
      pm: "±",
      Poincareplane: "ℌ",
      pointint: "⨕",
      Popf: "ℙ",
      popf: "𝕡",
      pound: "£",
      Pr: "⪻",
      pr: "≺",
      prap: "⪷",
      prcue: "≼",
      prE: "⪳",
      pre: "⪯",
      prec: "≺",
      precapprox: "⪷",
      preccurlyeq: "≼",
      Precedes: "≺",
      PrecedesEqual: "⪯",
      PrecedesSlantEqual: "≼",
      PrecedesTilde: "≾",
      preceq: "⪯",
      precnapprox: "⪹",
      precneqq: "⪵",
      precnsim: "⋨",
      precsim: "≾",
      Prime: "″",
      prime: "′",
      primes: "ℙ",
      prnap: "⪹",
      prnE: "⪵",
      prnsim: "⋨",
      prod: "∏",
      Product: "∏",
      profalar: "⌮",
      profline: "⌒",
      profsurf: "⌓",
      prop: "∝",
      Proportion: "∷",
      Proportional: "∝",
      propto: "∝",
      prsim: "≾",
      prurel: "⊰",
      Pscr: "𝒫",
      pscr: "𝓅",
      Psi: "Ψ",
      psi: "ψ",
      puncsp: " ",
      Qfr: "𝔔",
      qfr: "𝔮",
      qint: "⨌",
      Qopf: "ℚ",
      qopf: "𝕢",
      qprime: "⁗",
      Qscr: "𝒬",
      qscr: "𝓆",
      quaternions: "ℍ",
      quatint: "⨖",
      quest: "?",
      questeq: "≟",
      QUOT: '"',
      quot: '"',
      rAarr: "⇛",
      race: "∽̱",
      Racute: "Ŕ",
      racute: "ŕ",
      radic: "√",
      raemptyv: "⦳",
      Rang: "⟫",
      rang: "⟩",
      rangd: "⦒",
      range: "⦥",
      rangle: "⟩",
      raquo: "»",
      Rarr: "↠",
      rArr: "⇒",
      rarr: "→",
      rarrap: "⥵",
      rarrb: "⇥",
      rarrbfs: "⤠",
      rarrc: "⤳",
      rarrfs: "⤞",
      rarrhk: "↪",
      rarrlp: "↬",
      rarrpl: "⥅",
      rarrsim: "⥴",
      Rarrtl: "⤖",
      rarrtl: "↣",
      rarrw: "↝",
      rAtail: "⤜",
      ratail: "⤚",
      ratio: "∶",
      rationals: "ℚ",
      RBarr: "⤐",
      rBarr: "⤏",
      rbarr: "⤍",
      rbbrk: "❳",
      rbrace: "}",
      rbrack: "]",
      rbrke: "⦌",
      rbrksld: "⦎",
      rbrkslu: "⦐",
      Rcaron: "Ř",
      rcaron: "ř",
      Rcedil: "Ŗ",
      rcedil: "ŗ",
      rceil: "⌉",
      rcub: "}",
      Rcy: "Р",
      rcy: "р",
      rdca: "⤷",
      rdldhar: "⥩",
      rdquo: "”",
      rdquor: "”",
      rdsh: "↳",
      Re: "ℜ",
      real: "ℜ",
      realine: "ℛ",
      realpart: "ℜ",
      reals: "ℝ",
      rect: "▭",
      REG: "®",
      reg: "®",
      ReverseElement: "∋",
      ReverseEquilibrium: "⇋",
      ReverseUpEquilibrium: "⥯",
      rfisht: "⥽",
      rfloor: "⌋",
      Rfr: "ℜ",
      rfr: "𝔯",
      rHar: "⥤",
      rhard: "⇁",
      rharu: "⇀",
      rharul: "⥬",
      Rho: "Ρ",
      rho: "ρ",
      rhov: "ϱ",
      RightAngleBracket: "⟩",
      RightArrow: "→",
      Rightarrow: "⇒",
      rightarrow: "→",
      RightArrowBar: "⇥",
      RightArrowLeftArrow: "⇄",
      rightarrowtail: "↣",
      RightCeiling: "⌉",
      RightDoubleBracket: "⟧",
      RightDownTeeVector: "⥝",
      RightDownVector: "⇂",
      RightDownVectorBar: "⥕",
      RightFloor: "⌋",
      rightharpoondown: "⇁",
      rightharpoonup: "⇀",
      rightleftarrows: "⇄",
      rightleftharpoons: "⇌",
      rightrightarrows: "⇉",
      rightsquigarrow: "↝",
      RightTee: "⊢",
      RightTeeArrow: "↦",
      RightTeeVector: "⥛",
      rightthreetimes: "⋌",
      RightTriangle: "⊳",
      RightTriangleBar: "⧐",
      RightTriangleEqual: "⊵",
      RightUpDownVector: "⥏",
      RightUpTeeVector: "⥜",
      RightUpVector: "↾",
      RightUpVectorBar: "⥔",
      RightVector: "⇀",
      RightVectorBar: "⥓",
      ring: "˚",
      risingdotseq: "≓",
      rlarr: "⇄",
      rlhar: "⇌",
      rlm: "‏",
      rmoust: "⎱",
      rmoustache: "⎱",
      rnmid: "⫮",
      roang: "⟭",
      roarr: "⇾",
      robrk: "⟧",
      ropar: "⦆",
      Ropf: "ℝ",
      ropf: "𝕣",
      roplus: "⨮",
      rotimes: "⨵",
      RoundImplies: "⥰",
      rpar: ")",
      rpargt: "⦔",
      rppolint: "⨒",
      rrarr: "⇉",
      Rrightarrow: "⇛",
      rsaquo: "›",
      Rscr: "ℛ",
      rscr: "𝓇",
      Rsh: "↱",
      rsh: "↱",
      rsqb: "]",
      rsquo: "’",
      rsquor: "’",
      rthree: "⋌",
      rtimes: "⋊",
      rtri: "▹",
      rtrie: "⊵",
      rtrif: "▸",
      rtriltri: "⧎",
      RuleDelayed: "⧴",
      ruluhar: "⥨",
      rx: "℞",
      Sacute: "Ś",
      sacute: "ś",
      sbquo: "‚",
      Sc: "⪼",
      sc: "≻",
      scap: "⪸",
      Scaron: "Š",
      scaron: "š",
      sccue: "≽",
      scE: "⪴",
      sce: "⪰",
      Scedil: "Ş",
      scedil: "ş",
      Scirc: "Ŝ",
      scirc: "ŝ",
      scnap: "⪺",
      scnE: "⪶",
      scnsim: "⋩",
      scpolint: "⨓",
      scsim: "≿",
      Scy: "С",
      scy: "с",
      sdot: "⋅",
      sdotb: "⊡",
      sdote: "⩦",
      searhk: "⤥",
      seArr: "⇘",
      searr: "↘",
      searrow: "↘",
      sect: "§",
      semi: ";",
      seswar: "⤩",
      setminus: "∖",
      setmn: "∖",
      sext: "✶",
      Sfr: "𝔖",
      sfr: "𝔰",
      sfrown: "⌢",
      sharp: "♯",
      SHCHcy: "Щ",
      shchcy: "щ",
      SHcy: "Ш",
      shcy: "ш",
      ShortDownArrow: "↓",
      ShortLeftArrow: "←",
      shortmid: "∣",
      shortparallel: "∥",
      ShortRightArrow: "→",
      ShortUpArrow: "↑",
      shy: "­",
      Sigma: "Σ",
      sigma: "σ",
      sigmaf: "ς",
      sigmav: "ς",
      sim: "∼",
      simdot: "⩪",
      sime: "≃",
      simeq: "≃",
      simg: "⪞",
      simgE: "⪠",
      siml: "⪝",
      simlE: "⪟",
      simne: "≆",
      simplus: "⨤",
      simrarr: "⥲",
      slarr: "←",
      SmallCircle: "∘",
      smallsetminus: "∖",
      smashp: "⨳",
      smeparsl: "⧤",
      smid: "∣",
      smile: "⌣",
      smt: "⪪",
      smte: "⪬",
      smtes: "⪬︀",
      SOFTcy: "Ь",
      softcy: "ь",
      sol: "/",
      solb: "⧄",
      solbar: "⌿",
      Sopf: "𝕊",
      sopf: "𝕤",
      spades: "♠",
      spadesuit: "♠",
      spar: "∥",
      sqcap: "⊓",
      sqcaps: "⊓︀",
      sqcup: "⊔",
      sqcups: "⊔︀",
      Sqrt: "√",
      sqsub: "⊏",
      sqsube: "⊑",
      sqsubset: "⊏",
      sqsubseteq: "⊑",
      sqsup: "⊐",
      sqsupe: "⊒",
      sqsupset: "⊐",
      sqsupseteq: "⊒",
      squ: "□",
      Square: "□",
      square: "□",
      SquareIntersection: "⊓",
      SquareSubset: "⊏",
      SquareSubsetEqual: "⊑",
      SquareSuperset: "⊐",
      SquareSupersetEqual: "⊒",
      SquareUnion: "⊔",
      squarf: "▪",
      squf: "▪",
      srarr: "→",
      Sscr: "𝒮",
      sscr: "𝓈",
      ssetmn: "∖",
      ssmile: "⌣",
      sstarf: "⋆",
      Star: "⋆",
      star: "☆",
      starf: "★",
      straightepsilon: "ϵ",
      straightphi: "ϕ",
      strns: "¯",
      Sub: "⋐",
      sub: "⊂",
      subdot: "⪽",
      subE: "⫅",
      sube: "⊆",
      subedot: "⫃",
      submult: "⫁",
      subnE: "⫋",
      subne: "⊊",
      subplus: "⪿",
      subrarr: "⥹",
      Subset: "⋐",
      subset: "⊂",
      subseteq: "⊆",
      subseteqq: "⫅",
      SubsetEqual: "⊆",
      subsetneq: "⊊",
      subsetneqq: "⫋",
      subsim: "⫇",
      subsub: "⫕",
      subsup: "⫓",
      succ: "≻",
      succapprox: "⪸",
      succcurlyeq: "≽",
      Succeeds: "≻",
      SucceedsEqual: "⪰",
      SucceedsSlantEqual: "≽",
      SucceedsTilde: "≿",
      succeq: "⪰",
      succnapprox: "⪺",
      succneqq: "⪶",
      succnsim: "⋩",
      succsim: "≿",
      SuchThat: "∋",
      Sum: "∑",
      sum: "∑",
      sung: "♪",
      Sup: "⋑",
      sup: "⊃",
      sup1: "¹",
      sup2: "²",
      sup3: "³",
      supdot: "⪾",
      supdsub: "⫘",
      supE: "⫆",
      supe: "⊇",
      supedot: "⫄",
      Superset: "⊃",
      SupersetEqual: "⊇",
      suphsol: "⟉",
      suphsub: "⫗",
      suplarr: "⥻",
      supmult: "⫂",
      supnE: "⫌",
      supne: "⊋",
      supplus: "⫀",
      Supset: "⋑",
      supset: "⊃",
      supseteq: "⊇",
      supseteqq: "⫆",
      supsetneq: "⊋",
      supsetneqq: "⫌",
      supsim: "⫈",
      supsub: "⫔",
      supsup: "⫖",
      swarhk: "⤦",
      swArr: "⇙",
      swarr: "↙",
      swarrow: "↙",
      swnwar: "⤪",
      szlig: "ß",
      Tab: "	",
      target: "⌖",
      Tau: "Τ",
      tau: "τ",
      tbrk: "⎴",
      Tcaron: "Ť",
      tcaron: "ť",
      Tcedil: "Ţ",
      tcedil: "ţ",
      Tcy: "Т",
      tcy: "т",
      tdot: "⃛",
      telrec: "⌕",
      Tfr: "𝔗",
      tfr: "𝔱",
      there4: "∴",
      Therefore: "∴",
      therefore: "∴",
      Theta: "Θ",
      theta: "θ",
      thetasym: "ϑ",
      thetav: "ϑ",
      thickapprox: "≈",
      thicksim: "∼",
      ThickSpace: "  ",
      thinsp: " ",
      ThinSpace: " ",
      thkap: "≈",
      thksim: "∼",
      THORN: "Þ",
      thorn: "þ",
      Tilde: "∼",
      tilde: "˜",
      TildeEqual: "≃",
      TildeFullEqual: "≅",
      TildeTilde: "≈",
      times: "×",
      timesb: "⊠",
      timesbar: "⨱",
      timesd: "⨰",
      tint: "∭",
      toea: "⤨",
      top: "⊤",
      topbot: "⌶",
      topcir: "⫱",
      Topf: "𝕋",
      topf: "𝕥",
      topfork: "⫚",
      tosa: "⤩",
      tprime: "‴",
      TRADE: "™",
      trade: "™",
      triangle: "▵",
      triangledown: "▿",
      triangleleft: "◃",
      trianglelefteq: "⊴",
      triangleq: "≜",
      triangleright: "▹",
      trianglerighteq: "⊵",
      tridot: "◬",
      trie: "≜",
      triminus: "⨺",
      TripleDot: "⃛",
      triplus: "⨹",
      trisb: "⧍",
      tritime: "⨻",
      trpezium: "⏢",
      Tscr: "𝒯",
      tscr: "𝓉",
      TScy: "Ц",
      tscy: "ц",
      TSHcy: "Ћ",
      tshcy: "ћ",
      Tstrok: "Ŧ",
      tstrok: "ŧ",
      twixt: "≬",
      twoheadleftarrow: "↞",
      twoheadrightarrow: "↠",
      Uacute: "Ú",
      uacute: "ú",
      Uarr: "↟",
      uArr: "⇑",
      uarr: "↑",
      Uarrocir: "⥉",
      Ubrcy: "Ў",
      ubrcy: "ў",
      Ubreve: "Ŭ",
      ubreve: "ŭ",
      Ucirc: "Û",
      ucirc: "û",
      Ucy: "У",
      ucy: "у",
      udarr: "⇅",
      Udblac: "Ű",
      udblac: "ű",
      udhar: "⥮",
      ufisht: "⥾",
      Ufr: "𝔘",
      ufr: "𝔲",
      Ugrave: "Ù",
      ugrave: "ù",
      uHar: "⥣",
      uharl: "↿",
      uharr: "↾",
      uhblk: "▀",
      ulcorn: "⌜",
      ulcorner: "⌜",
      ulcrop: "⌏",
      ultri: "◸",
      Umacr: "Ū",
      umacr: "ū",
      uml: "¨",
      UnderBar: "_",
      UnderBrace: "⏟",
      UnderBracket: "⎵",
      UnderParenthesis: "⏝",
      Union: "⋃",
      UnionPlus: "⊎",
      Uogon: "Ų",
      uogon: "ų",
      Uopf: "𝕌",
      uopf: "𝕦",
      UpArrow: "↑",
      Uparrow: "⇑",
      uparrow: "↑",
      UpArrowBar: "⤒",
      UpArrowDownArrow: "⇅",
      UpDownArrow: "↕",
      Updownarrow: "⇕",
      updownarrow: "↕",
      UpEquilibrium: "⥮",
      upharpoonleft: "↿",
      upharpoonright: "↾",
      uplus: "⊎",
      UpperLeftArrow: "↖",
      UpperRightArrow: "↗",
      Upsi: "ϒ",
      upsi: "υ",
      upsih: "ϒ",
      Upsilon: "Υ",
      upsilon: "υ",
      UpTee: "⊥",
      UpTeeArrow: "↥",
      upuparrows: "⇈",
      urcorn: "⌝",
      urcorner: "⌝",
      urcrop: "⌎",
      Uring: "Ů",
      uring: "ů",
      urtri: "◹",
      Uscr: "𝒰",
      uscr: "𝓊",
      utdot: "⋰",
      Utilde: "Ũ",
      utilde: "ũ",
      utri: "▵",
      utrif: "▴",
      uuarr: "⇈",
      Uuml: "Ü",
      uuml: "ü",
      uwangle: "⦧",
      vangrt: "⦜",
      varepsilon: "ϵ",
      varkappa: "ϰ",
      varnothing: "∅",
      varphi: "ϕ",
      varpi: "ϖ",
      varpropto: "∝",
      vArr: "⇕",
      varr: "↕",
      varrho: "ϱ",
      varsigma: "ς",
      varsubsetneq: "⊊︀",
      varsubsetneqq: "⫋︀",
      varsupsetneq: "⊋︀",
      varsupsetneqq: "⫌︀",
      vartheta: "ϑ",
      vartriangleleft: "⊲",
      vartriangleright: "⊳",
      Vbar: "⫫",
      vBar: "⫨",
      vBarv: "⫩",
      Vcy: "В",
      vcy: "в",
      VDash: "⊫",
      Vdash: "⊩",
      vDash: "⊨",
      vdash: "⊢",
      Vdashl: "⫦",
      Vee: "⋁",
      vee: "∨",
      veebar: "⊻",
      veeeq: "≚",
      vellip: "⋮",
      Verbar: "‖",
      verbar: "|",
      Vert: "‖",
      vert: "|",
      VerticalBar: "∣",
      VerticalLine: "|",
      VerticalSeparator: "❘",
      VerticalTilde: "≀",
      VeryThinSpace: " ",
      Vfr: "𝔙",
      vfr: "𝔳",
      vltri: "⊲",
      vnsub: "⊂⃒",
      vnsup: "⊃⃒",
      Vopf: "𝕍",
      vopf: "𝕧",
      vprop: "∝",
      vrtri: "⊳",
      Vscr: "𝒱",
      vscr: "𝓋",
      vsubnE: "⫋︀",
      vsubne: "⊊︀",
      vsupnE: "⫌︀",
      vsupne: "⊋︀",
      Vvdash: "⊪",
      vzigzag: "⦚",
      Wcirc: "Ŵ",
      wcirc: "ŵ",
      wedbar: "⩟",
      Wedge: "⋀",
      wedge: "∧",
      wedgeq: "≙",
      weierp: "℘",
      Wfr: "𝔚",
      wfr: "𝔴",
      Wopf: "𝕎",
      wopf: "𝕨",
      wp: "℘",
      wr: "≀",
      wreath: "≀",
      Wscr: "𝒲",
      wscr: "𝓌",
      xcap: "⋂",
      xcirc: "◯",
      xcup: "⋃",
      xdtri: "▽",
      Xfr: "𝔛",
      xfr: "𝔵",
      xhArr: "⟺",
      xharr: "⟷",
      Xi: "Ξ",
      xi: "ξ",
      xlArr: "⟸",
      xlarr: "⟵",
      xmap: "⟼",
      xnis: "⋻",
      xodot: "⨀",
      Xopf: "𝕏",
      xopf: "𝕩",
      xoplus: "⨁",
      xotime: "⨂",
      xrArr: "⟹",
      xrarr: "⟶",
      Xscr: "𝒳",
      xscr: "𝓍",
      xsqcup: "⨆",
      xuplus: "⨄",
      xutri: "△",
      xvee: "⋁",
      xwedge: "⋀",
      Yacute: "Ý",
      yacute: "ý",
      YAcy: "Я",
      yacy: "я",
      Ycirc: "Ŷ",
      ycirc: "ŷ",
      Ycy: "Ы",
      ycy: "ы",
      yen: "¥",
      Yfr: "𝔜",
      yfr: "𝔶",
      YIcy: "Ї",
      yicy: "ї",
      Yopf: "𝕐",
      yopf: "𝕪",
      Yscr: "𝒴",
      yscr: "𝓎",
      YUcy: "Ю",
      yucy: "ю",
      Yuml: "Ÿ",
      yuml: "ÿ",
      Zacute: "Ź",
      zacute: "ź",
      Zcaron: "Ž",
      zcaron: "ž",
      Zcy: "З",
      zcy: "з",
      Zdot: "Ż",
      zdot: "ż",
      zeetrf: "ℨ",
      ZeroWidthSpace: "​",
      Zeta: "Ζ",
      zeta: "ζ",
      Zfr: "ℨ",
      zfr: "𝔷",
      ZHcy: "Ж",
      zhcy: "ж",
      zigrarr: "⇝",
      Zopf: "ℤ",
      zopf: "𝕫",
      Zscr: "𝒵",
      zscr: "𝓏",
      zwj: "‍",
      zwnj: "‌"
    });
    exports.entityMap = exports.HTML_ENTITIES;
  }
});

// node_modules/@xmldom/xmldom/lib/sax.js
var require_sax = __commonJS({
  "node_modules/@xmldom/xmldom/lib/sax.js"(exports) {
    var NAMESPACE = require_conventions().NAMESPACE;
    var tagNamePattern = require_conventions().tagNamePattern;
    var S_TAG = 0;
    var S_ATTR = 1;
    var S_ATTR_SPACE = 2;
    var S_EQ = 3;
    var S_ATTR_NOQUOT_VALUE = 4;
    var S_ATTR_END = 5;
    var S_TAG_SPACE = 6;
    var S_TAG_CLOSE = 7;
    function ParseError(message, locator) {
      this.message = message;
      this.locator = locator;
      if (Error.captureStackTrace) Error.captureStackTrace(this, ParseError);
    }
    ParseError.prototype = new Error();
    ParseError.prototype.name = ParseError.name;
    function XMLReader() {
    }
    XMLReader.prototype = {
      parse: function(source8, defaultNSMap, entityMap) {
        var domBuilder = this.domBuilder;
        domBuilder.startDocument();
        _copy(defaultNSMap, defaultNSMap = {});
        parse(
          source8,
          defaultNSMap,
          entityMap,
          domBuilder,
          this.errorHandler
        );
        domBuilder.endDocument();
      }
    };
    function parse(source8, defaultNSMapCopy, entityMap, domBuilder, errorHandler) {
      function fixedFromCharCode(code) {
        if (code > 65535) {
          code -= 65536;
          var surrogate1 = 55296 + (code >> 10), surrogate2 = 56320 + (code & 1023);
          return String.fromCharCode(surrogate1, surrogate2);
        } else {
          return String.fromCharCode(code);
        }
      }
      function entityReplacer(a2) {
        var k = a2.slice(1, -1);
        if (Object.hasOwnProperty.call(entityMap, k)) {
          return entityMap[k];
        } else if (k.charAt(0) === "#") {
          return fixedFromCharCode(parseInt(k.substr(1).replace("x", "0x")));
        } else {
          errorHandler.error("entity not found:" + a2);
          return a2;
        }
      }
      function appendText(end2) {
        if (end2 > start) {
          var xt = source8.substring(start, end2).replace(/&#?\w+;/g, entityReplacer);
          locator && position(start);
          domBuilder.characters(xt, 0, end2 - start);
          start = end2;
        }
      }
      function position(p, m) {
        while (p >= lineEnd && (m = linePattern.exec(source8))) {
          lineStart = m.index;
          lineEnd = lineStart + m[0].length;
          locator.lineNumber++;
        }
        locator.columnNumber = p - lineStart + 1;
      }
      var lineStart = 0;
      var lineEnd = 0;
      var linePattern = /.*(?:\r\n?|\n)|.*$/g;
      var locator = domBuilder.locator;
      var parseStack = [{ currentNSMap: defaultNSMapCopy }];
      var closeMap = {};
      var start = 0;
      while (true) {
        try {
          var tagStart = source8.indexOf("<", start);
          if (tagStart < 0) {
            if (!source8.substr(start).match(/^\s*$/)) {
              var doc = domBuilder.doc;
              var text = doc.createTextNode(source8.substr(start));
              doc.appendChild(text);
              domBuilder.currentElement = text;
            }
            return;
          }
          if (tagStart > start) {
            appendText(tagStart);
          }
          switch (source8.charAt(tagStart + 1)) {
            case "/":
              var end = source8.indexOf(">", tagStart + 3);
              var tagName = source8.substring(tagStart + 2, end).replace(/^([\s\S]*?[^ \t\n\r])?[ \t\n\r]*$/, "$1");
              var config = parseStack.pop();
              if (end < 0) {
                tagName = source8.substring(tagStart + 2).replace(/[\s<].*/, "");
                errorHandler.error("end tag name: " + tagName + " is not complete:" + config.tagName);
                end = tagStart + 1 + tagName.length;
              } else if (tagName.match(/\s</)) {
                tagName = tagName.replace(/[\s<].*/, "");
                errorHandler.error("end tag name: " + tagName + " maybe not complete");
                end = tagStart + 1 + tagName.length;
              } else if (/[ \t\n\r]/.test(tagName) && tagNamePattern.test(tagName.split(/[ \t\n\r]/)[0])) {
                errorHandler.error('end tag name is followed by whitespace and trailing content: "' + tagName + '"');
              }
              var localNSMap = config.localNSMap;
              var endMatch = config.tagName == tagName;
              var endIgnoreCaseMach = endMatch || config.tagName && config.tagName.toLowerCase() == tagName.toLowerCase();
              if (endIgnoreCaseMach) {
                domBuilder.endElement(config.uri, config.localName, tagName);
                if (localNSMap) {
                  for (var prefix in localNSMap) {
                    if (Object.prototype.hasOwnProperty.call(localNSMap, prefix)) {
                      domBuilder.endPrefixMapping(prefix);
                    }
                  }
                }
                if (!endMatch) {
                  errorHandler.fatalError("end tag name: " + tagName + " is not match the current start tagName:" + config.tagName);
                }
              } else {
                parseStack.push(config);
              }
              end++;
              break;
            // end elment
            case "?":
              locator && position(tagStart);
              end = parseInstruction(source8, tagStart, domBuilder);
              break;
            case "!":
              locator && position(tagStart);
              end = parseDCC(source8, tagStart, domBuilder, errorHandler);
              break;
            default:
              locator && position(tagStart);
              var el = new ElementAttributes();
              var currentNSMap = parseStack[parseStack.length - 1].currentNSMap;
              var end = parseElementStartPart(source8, tagStart, el, currentNSMap, entityReplacer, errorHandler);
              var len = el.length;
              if (!el.closed && fixSelfClosed(source8, end, el.tagName, closeMap)) {
                el.closed = true;
                if (!entityMap.nbsp) {
                  errorHandler.warning("unclosed xml attribute");
                }
              }
              if (locator && len) {
                var locator2 = copyLocator(locator, {});
                for (var i = 0; i < len; i++) {
                  var a = el[i];
                  position(a.offset);
                  a.locator = copyLocator(locator, {});
                }
                domBuilder.locator = locator2;
                if (appendElement(el, domBuilder, currentNSMap)) {
                  parseStack.push(el);
                }
                domBuilder.locator = locator;
              } else {
                if (appendElement(el, domBuilder, currentNSMap)) {
                  parseStack.push(el);
                }
              }
              if (NAMESPACE.isHTML(el.uri) && !el.closed) {
                end = parseHtmlSpecialContent(source8, end, el.tagName, entityReplacer, domBuilder);
              } else {
                end++;
              }
          }
        } catch (e) {
          if (e instanceof ParseError) {
            throw e;
          }
          errorHandler.error("element parse error: " + e);
          end = -1;
        }
        if (end > start) {
          start = end;
        } else {
          appendText(Math.max(tagStart, start) + 1);
        }
      }
    }
    function copyLocator(f, t) {
      t.lineNumber = f.lineNumber;
      t.columnNumber = f.columnNumber;
      return t;
    }
    function parseElementStartPart(source8, start, el, currentNSMap, entityReplacer, errorHandler) {
      function addAttribute(qname, value2, startIndex) {
        if (el.attributeNames.hasOwnProperty(qname)) {
          errorHandler.fatalError("Attribute " + qname + " redefined");
        }
        el.addValue(
          qname,
          // @see https://www.w3.org/TR/xml/#AVNormalize
          // since the xmldom sax parser does not "interpret" DTD the following is not implemented:
          // - recursive replacement of (DTD) entity references
          // - trimming and collapsing multiple spaces into a single one for attributes that are not of type CDATA
          value2.replace(/[\t\n\r]/g, " ").replace(/&#?\w+;/g, entityReplacer),
          startIndex
        );
      }
      var attrName;
      var value;
      var p = ++start;
      var s = S_TAG;
      while (true) {
        var c = source8.charAt(p);
        if (s === S_TAG && c === "<") {
          throw new Error("unexpected < in tag name: " + source8.slice(start, p));
        }
        switch (c) {
          case "=":
            if (s === S_ATTR) {
              attrName = source8.slice(start, p);
              s = S_EQ;
            } else if (s === S_ATTR_SPACE) {
              s = S_EQ;
            } else {
              throw new Error("attribute equal must after attrName");
            }
            break;
          case "'":
          case '"':
            if (s === S_EQ || s === S_ATTR) {
              if (s === S_ATTR) {
                errorHandler.warning('attribute value must after "="');
                attrName = source8.slice(start, p);
              }
              start = p + 1;
              p = source8.indexOf(c, start);
              if (p > 0) {
                value = source8.slice(start, p);
                addAttribute(attrName, value, start - 1);
                s = S_ATTR_END;
              } else {
                throw new Error("attribute value no end '" + c + "' match");
              }
            } else if (s == S_ATTR_NOQUOT_VALUE) {
              value = source8.slice(start, p);
              addAttribute(attrName, value, start);
              errorHandler.warning('attribute "' + attrName + '" missed start quot(' + c + ")!!");
              start = p + 1;
              s = S_ATTR_END;
            } else {
              throw new Error('attribute value must after "="');
            }
            break;
          case "/":
            switch (s) {
              case S_TAG:
                el.setTagName(source8.slice(start, p));
              case S_ATTR_END:
              case S_TAG_SPACE:
              case S_TAG_CLOSE:
                s = S_TAG_CLOSE;
                el.closed = true;
              case S_ATTR_NOQUOT_VALUE:
              case S_ATTR:
                break;
              case S_ATTR_SPACE:
                el.closed = true;
                break;
              //case S_EQ:
              default:
                throw new Error("attribute invalid close char('/')");
            }
            break;
          case "":
            errorHandler.error("unexpected end of input");
            if (s == S_TAG) {
              el.setTagName(source8.slice(start, p));
            }
            return p;
          case ">":
            switch (s) {
              case S_TAG:
                el.setTagName(source8.slice(start, p));
              case S_ATTR_END:
              case S_TAG_SPACE:
              case S_TAG_CLOSE:
                break;
              //normal
              case S_ATTR_NOQUOT_VALUE:
              //Compatible state
              case S_ATTR:
                value = source8.slice(start, p);
                if (value.slice(-1) === "/") {
                  el.closed = true;
                  value = value.slice(0, -1);
                }
              case S_ATTR_SPACE:
                if (s === S_ATTR_SPACE) {
                  value = attrName;
                }
                if (s == S_ATTR_NOQUOT_VALUE) {
                  errorHandler.warning('attribute "' + value + '" missed quot(")!');
                  addAttribute(attrName, value, start);
                } else {
                  if (!NAMESPACE.isHTML(currentNSMap[""]) || !value.match(/^(?:disabled|checked|selected)$/i)) {
                    errorHandler.warning('attribute "' + value + '" missed value!! "' + value + '" instead!!');
                  }
                  addAttribute(value, value, start);
                }
                break;
              case S_EQ:
                throw new Error("attribute value missed!!");
            }
            return p;
          /*xml space '\x20' | #x9 | #xD | #xA; */
          case "":
            c = " ";
          default:
            if (c <= " ") {
              switch (s) {
                case S_TAG:
                  el.setTagName(source8.slice(start, p));
                  s = S_TAG_SPACE;
                  break;
                case S_ATTR:
                  attrName = source8.slice(start, p);
                  s = S_ATTR_SPACE;
                  break;
                case S_ATTR_NOQUOT_VALUE:
                  var value = source8.slice(start, p);
                  errorHandler.warning('attribute "' + value + '" missed quot(")!!');
                  addAttribute(attrName, value, start);
                case S_ATTR_END:
                  s = S_TAG_SPACE;
                  break;
              }
            } else {
              switch (s) {
                //case S_TAG:void();break;
                //case S_ATTR:void();break;
                //case S_ATTR_NOQUOT_VALUE:void();break;
                case S_ATTR_SPACE:
                  var tagName = el.tagName;
                  if (!NAMESPACE.isHTML(currentNSMap[""]) || !attrName.match(/^(?:disabled|checked|selected)$/i)) {
                    errorHandler.warning('attribute "' + attrName + '" missed value!! "' + attrName + '" instead2!!');
                  }
                  addAttribute(attrName, attrName, start);
                  start = p;
                  s = S_ATTR;
                  break;
                case S_ATTR_END:
                  errorHandler.warning('attribute space is required"' + attrName + '"!!');
                case S_TAG_SPACE:
                  s = S_ATTR;
                  start = p;
                  break;
                case S_EQ:
                  s = S_ATTR_NOQUOT_VALUE;
                  start = p;
                  break;
                case S_TAG_CLOSE:
                  throw new Error("elements closed character '/' and '>' must be connected to");
              }
            }
        }
        p++;
      }
    }
    function appendElement(el, domBuilder, currentNSMap) {
      var tagName = el.tagName;
      var localNSMap = null;
      var i = el.length;
      while (i--) {
        var a = el[i];
        var qName = a.qName;
        var value = a.value;
        var nsp = qName.indexOf(":");
        if (nsp > 0) {
          var prefix = a.prefix = qName.slice(0, nsp);
          var localName = qName.slice(nsp + 1);
          var nsPrefix = prefix === "xmlns" && localName;
        } else {
          localName = qName;
          prefix = null;
          nsPrefix = qName === "xmlns" && "";
        }
        a.localName = localName;
        if (nsPrefix !== false) {
          if (localNSMap == null) {
            localNSMap = {};
            currentNSMap = Object.create(currentNSMap);
          }
          currentNSMap[nsPrefix] = localNSMap[nsPrefix] = value;
          a.uri = NAMESPACE.XMLNS;
          domBuilder.startPrefixMapping(nsPrefix, value);
        }
      }
      var i = el.length;
      while (i--) {
        a = el[i];
        var prefix = a.prefix;
        if (prefix) {
          if (prefix === "xml") {
            a.uri = NAMESPACE.XML;
          }
          if (prefix !== "xmlns") {
            a.uri = currentNSMap[prefix || ""];
          }
        }
      }
      var nsp = tagName.indexOf(":");
      if (nsp > 0) {
        prefix = el.prefix = tagName.slice(0, nsp);
        localName = el.localName = tagName.slice(nsp + 1);
      } else {
        prefix = null;
        localName = el.localName = tagName;
      }
      var ns = el.uri = currentNSMap[prefix || ""];
      domBuilder.startElement(ns, localName, tagName, el);
      if (el.closed) {
        domBuilder.endElement(ns, localName, tagName);
        if (localNSMap) {
          for (prefix in localNSMap) {
            if (Object.prototype.hasOwnProperty.call(localNSMap, prefix)) {
              domBuilder.endPrefixMapping(prefix);
            }
          }
        }
      } else {
        el.currentNSMap = currentNSMap;
        el.localNSMap = localNSMap;
        return true;
      }
    }
    function parseHtmlSpecialContent(source8, elStartEnd, tagName, entityReplacer, domBuilder) {
      if (/^(?:script|textarea)$/i.test(tagName)) {
        var elEndStart = source8.indexOf("</" + tagName + ">", elStartEnd);
        var text = source8.substring(elStartEnd + 1, elEndStart);
        if (/[&<]/.test(text)) {
          if (/^script$/i.test(tagName)) {
            domBuilder.characters(text, 0, text.length);
            return elEndStart;
          }
          text = text.replace(/&#?\w+;/g, entityReplacer);
          domBuilder.characters(text, 0, text.length);
          return elEndStart;
        }
      }
      return elStartEnd + 1;
    }
    function fixSelfClosed(source8, elStartEnd, tagName, closeMap) {
      var pos = closeMap[tagName];
      if (pos == null) {
        pos = source8.lastIndexOf("</" + tagName + ">");
        if (pos < elStartEnd) {
          pos = source8.lastIndexOf("</" + tagName);
        }
        closeMap[tagName] = pos;
      }
      return pos < elStartEnd;
    }
    function _copy(source8, target) {
      for (var n2 in source8) {
        if (Object.prototype.hasOwnProperty.call(source8, n2)) {
          target[n2] = source8[n2];
        }
      }
    }
    function parseDCC(source8, start, domBuilder, errorHandler) {
      var next = source8.charAt(start + 2);
      switch (next) {
        case "-":
          if (source8.charAt(start + 3) === "-") {
            var end = source8.indexOf("-->", start + 4);
            if (end > start) {
              domBuilder.comment(source8, start + 4, end - start - 4);
              return end + 3;
            } else {
              errorHandler.error("Unclosed comment");
              return -1;
            }
          } else {
            return -1;
          }
        default:
          if (source8.substr(start + 3, 6) == "CDATA[") {
            var end = source8.indexOf("]]>", start + 9);
            domBuilder.startCDATA();
            domBuilder.characters(source8, start + 9, end - start - 9);
            domBuilder.endCDATA();
            return end + 3;
          }
          var matchs = split(source8, start);
          var len = matchs.length;
          if (len > 1 && /!doctype/i.test(matchs[0][0])) {
            var name = matchs[1][0];
            var pubid = false;
            var sysid = false;
            if (len > 3) {
              if (/^public$/i.test(matchs[2][0])) {
                pubid = matchs[3][0];
                sysid = len > 4 && matchs[4][0];
              } else if (/^system$/i.test(matchs[2][0])) {
                sysid = matchs[3][0];
              }
            }
            var lastMatch = matchs[len - 1];
            domBuilder.startDTD(name, pubid, sysid);
            domBuilder.endDTD();
            return lastMatch.index + lastMatch[0].length;
          }
      }
      return -1;
    }
    function parseInstruction(source8, start, domBuilder) {
      var end = source8.indexOf("?>", start);
      if (end) {
        var match = source8.substring(start, end).match(/^<\?(\S*)\s*([\s\S]*?)$/);
        if (match) {
          var len = match[0].length;
          domBuilder.processingInstruction(match[1], match[2]);
          return end + 2;
        } else {
          return -1;
        }
      }
      return -1;
    }
    function ElementAttributes() {
      this.attributeNames = {};
    }
    ElementAttributes.prototype = {
      setTagName: function(tagName) {
        if (!tagNamePattern.test(tagName)) {
          throw new Error("invalid tagName:" + tagName);
        }
        this.tagName = tagName;
      },
      addValue: function(qName, value, offset) {
        if (!tagNamePattern.test(qName)) {
          throw new Error("invalid attribute:" + qName);
        }
        this.attributeNames[qName] = this.length;
        this[this.length++] = { qName, value, offset };
      },
      length: 0,
      getLocalName: function(i) {
        return this[i].localName;
      },
      getLocator: function(i) {
        return this[i].locator;
      },
      getQName: function(i) {
        return this[i].qName;
      },
      getURI: function(i) {
        return this[i].uri;
      },
      getValue: function(i) {
        return this[i].value;
      }
      //	,getIndex:function(uri, localName)){
      //		if(localName){
      //
      //		}else{
      //			var qName = uri
      //		}
      //	},
      //	getValue:function(){return this.getValue(this.getIndex.apply(this,arguments))},
      //	getType:function(uri,localName){}
      //	getType:function(i){},
    };
    function split(source8, start) {
      var match;
      var buf = [];
      var reg = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
      reg.lastIndex = start;
      reg.exec(source8);
      while (match = reg.exec(source8)) {
        buf.push(match);
        if (match[1]) return buf;
      }
    }
    exports.XMLReader = XMLReader;
    exports.ParseError = ParseError;
  }
});

// node_modules/@xmldom/xmldom/lib/dom-parser.js
var require_dom_parser = __commonJS({
  "node_modules/@xmldom/xmldom/lib/dom-parser.js"(exports) {
    var conventions = require_conventions();
    var dom = require_dom();
    var entities = require_entities();
    var sax = require_sax();
    var DOMImplementation = dom.DOMImplementation;
    var NAMESPACE = conventions.NAMESPACE;
    var ParseError = sax.ParseError;
    var XMLReader = sax.XMLReader;
    function normalizeLineEndings(input) {
      return input.replace(/\r[\n\u0085]/g, "\n").replace(/[\r\u0085\u2028]/g, "\n");
    }
    function DOMParser2(options) {
      this.options = options || { locator: {} };
    }
    DOMParser2.prototype.parseFromString = function(source8, mimeType) {
      var options = this.options;
      var sax2 = new XMLReader();
      var domBuilder = options.domBuilder || new DOMHandler();
      var errorHandler = options.errorHandler;
      var locator = options.locator;
      var defaultNSMap = options.xmlns || {};
      var isHTML = /\/x?html?$/.test(mimeType);
      var entityMap = isHTML ? entities.HTML_ENTITIES : entities.XML_ENTITIES;
      if (locator) {
        domBuilder.setDocumentLocator(locator);
      }
      sax2.errorHandler = buildErrorHandler(errorHandler, domBuilder, locator);
      sax2.domBuilder = options.domBuilder || domBuilder;
      if (isHTML) {
        defaultNSMap[""] = NAMESPACE.HTML;
      }
      defaultNSMap.xml = defaultNSMap.xml || NAMESPACE.XML;
      var normalize = options.normalizeLineEndings || normalizeLineEndings;
      if (source8 && typeof source8 === "string") {
        sax2.parse(
          normalize(source8),
          defaultNSMap,
          entityMap
        );
      } else {
        sax2.errorHandler.error("invalid doc source");
      }
      return domBuilder.doc;
    };
    function buildErrorHandler(errorImpl, domBuilder, locator) {
      if (!errorImpl) {
        if (domBuilder instanceof DOMHandler) {
          return domBuilder;
        }
        errorImpl = domBuilder;
      }
      var errorHandler = {};
      var isCallback = errorImpl instanceof Function;
      locator = locator || {};
      function build(key) {
        var fn = errorImpl[key];
        if (!fn && isCallback) {
          fn = errorImpl.length == 2 ? function(msg) {
            errorImpl(key, msg);
          } : errorImpl;
        }
        errorHandler[key] = fn && function(msg) {
          fn("[xmldom " + key + "]	" + msg + _locator(locator));
        } || function() {
        };
      }
      build("warning");
      build("error");
      build("fatalError");
      return errorHandler;
    }
    function DOMHandler() {
      this.cdata = false;
    }
    function position(locator, node) {
      node.lineNumber = locator.lineNumber;
      node.columnNumber = locator.columnNumber;
    }
    DOMHandler.prototype = {
      startDocument: function() {
        this.doc = new DOMImplementation().createDocument(null, null, null);
        if (this.locator) {
          this.doc.documentURI = this.locator.systemId;
        }
      },
      startElement: function(namespaceURI, localName, qName, attrs) {
        var doc = this.doc;
        var el = doc.createElementNS(namespaceURI, qName || localName);
        var len = attrs.length;
        appendElement(this, el);
        this.currentElement = el;
        this.locator && position(this.locator, el);
        for (var i = 0; i < len; i++) {
          var namespaceURI = attrs.getURI(i);
          var value = attrs.getValue(i);
          var qName = attrs.getQName(i);
          var attr = doc.createAttributeNS(namespaceURI, qName);
          this.locator && position(attrs.getLocator(i), attr);
          attr.value = attr.nodeValue = value;
          el.setAttributeNode(attr);
        }
      },
      endElement: function(namespaceURI, localName, qName) {
        var current = this.currentElement;
        var tagName = current.tagName;
        this.currentElement = current.parentNode;
      },
      startPrefixMapping: function(prefix, uri) {
      },
      endPrefixMapping: function(prefix) {
      },
      processingInstruction: function(target, data) {
        var ins = this.doc.createProcessingInstruction(target, data);
        this.locator && position(this.locator, ins);
        appendElement(this, ins);
      },
      ignorableWhitespace: function(ch, start, length) {
      },
      characters: function(chars, start, length) {
        chars = _toString.apply(this, arguments);
        if (chars) {
          if (this.cdata) {
            var charNode = this.doc.createCDATASection(chars);
          } else {
            var charNode = this.doc.createTextNode(chars);
          }
          if (this.currentElement) {
            this.currentElement.appendChild(charNode);
          } else if (/^\s*$/.test(chars)) {
            this.doc.appendChild(charNode);
          }
          this.locator && position(this.locator, charNode);
        }
      },
      skippedEntity: function(name) {
      },
      endDocument: function() {
        this.doc.normalize();
      },
      setDocumentLocator: function(locator) {
        if (this.locator = locator) {
          locator.lineNumber = 0;
        }
      },
      //LexicalHandler
      comment: function(chars, start, length) {
        chars = _toString.apply(this, arguments);
        var comm = this.doc.createComment(chars);
        this.locator && position(this.locator, comm);
        appendElement(this, comm);
      },
      startCDATA: function() {
        this.cdata = true;
      },
      endCDATA: function() {
        this.cdata = false;
      },
      startDTD: function(name, publicId, systemId) {
        var impl = this.doc.implementation;
        if (impl && impl.createDocumentType) {
          var dt = impl.createDocumentType(name, publicId, systemId);
          this.locator && position(this.locator, dt);
          appendElement(this, dt);
          this.doc.doctype = dt;
        }
      },
      /**
       * @see org.xml.sax.ErrorHandler
       * @link http://www.saxproject.org/apidoc/org/xml/sax/ErrorHandler.html
       */
      warning: function(error) {
        console.warn("[xmldom warning]	" + error, _locator(this.locator));
      },
      error: function(error) {
        console.error("[xmldom error]	" + error, _locator(this.locator));
      },
      fatalError: function(error) {
        throw new ParseError(error, this.locator);
      }
    };
    function _locator(l) {
      if (l) {
        return "\n@" + (l.systemId || "") + "#[line:" + l.lineNumber + ",col:" + l.columnNumber + "]";
      }
    }
    function _toString(chars, start, length) {
      if (typeof chars == "string") {
        return chars.substr(start, length);
      } else {
        if (chars.length >= start + length || start) {
          return new java.lang.String(chars, start, length) + "";
        }
        return chars;
      }
    }
    "endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g, function(key) {
      DOMHandler.prototype[key] = function() {
        return null;
      };
    });
    function appendElement(hander, node) {
      if (!hander.currentElement) {
        hander.doc.appendChild(node);
      } else {
        hander.currentElement.appendChild(node);
      }
    }
    exports.__DOMHandler = DOMHandler;
    exports.normalizeLineEndings = normalizeLineEndings;
    exports.DOMParser = DOMParser2;
  }
});

// node_modules/@xmldom/xmldom/lib/index.js
var require_lib = __commonJS({
  "node_modules/@xmldom/xmldom/lib/index.js"(exports) {
    var dom = require_dom();
    exports.DOMImplementation = dom.DOMImplementation;
    exports.XMLSerializer = dom.XMLSerializer;
    exports.DOMParser = require_dom_parser().DOMParser;
  }
});

// node_modules/pixi.js/lib/environment-browser/browserExt.mjs
var browserExt = {
  extension: {
    type: ExtensionType.Environment,
    name: "browser",
    priority: -1
  },
  test: () => true,
  load: () => __async(null, null, function* () {
    yield import("./browserAll-YUSGZAPF.js");
  })
};

// node_modules/pixi.js/lib/environment-webworker/webworkerExt.mjs
var webworkerExt = {
  extension: {
    type: ExtensionType.Environment,
    name: "webworker",
    priority: 0
  },
  test: () => typeof self !== "undefined" && self.WorkerGlobalScope !== void 0,
  load: () => __async(null, null, function* () {
    yield import("./webworkerAll-NAR5WXTL.js");
  })
};

// node_modules/pixi.js/lib/filters/blend-modes/blend-template.frag.mjs
var blendTemplateFrag = "\nin vec2 vTextureCoord;\nin vec4 vColor;\n\nout vec4 finalColor;\n\nuniform float uBlend;\n\nuniform sampler2D uTexture;\nuniform sampler2D uBackTexture;\n\n{FUNCTIONS}\n\nvoid main()\n{ \n    vec4 back = texture(uBackTexture, vTextureCoord);\n    vec4 front = texture(uTexture, vTextureCoord);\n    float blendedAlpha = front.a + back.a * (1.0 - front.a);\n    \n    {MAIN}\n}\n";

// node_modules/pixi.js/lib/filters/blend-modes/blend-template.vert.mjs
var blendTemplateVert = "in vec2 aPosition;\nout vec2 vTextureCoord;\nout vec2 backgroundUv;\n\nuniform vec4 uInputSize;\nuniform vec4 uOutputFrame;\nuniform vec4 uOutputTexture;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;\n    \n    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aPosition * (uOutputFrame.zw * uInputSize.zw);\n}\n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition();\n    vTextureCoord = filterTextureCoord();\n}\n";

// node_modules/pixi.js/lib/filters/blend-modes/blend-template.wgsl.mjs
var blendTemplate = "\nstruct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct BlendUniforms {\n  uBlend:f32,\n};\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n@group(0) @binding(3) var uBackTexture: texture_2d<f32>;\n\n@group(1) @binding(0) var<uniform> blendUniforms : BlendUniforms;\n\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>\n  };\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);  \n}\n  \n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>, \n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition)\n  );\n}\n\n{FUNCTIONS}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>\n) -> @location(0) vec4<f32> {\n\n\n   var back =  textureSample(uBackTexture, uSampler, uv);\n   var front = textureSample(uTexture, uSampler, uv);\n   var blendedAlpha = front.a + back.a * (1.0 - front.a);\n   \n   var out = vec4<f32>(0.0,0.0,0.0,0.0);\n\n   {MAIN}\n\n   return out;\n}";

// node_modules/pixi.js/lib/filters/blend-modes/BlendModeFilter.mjs
var BlendModeFilter = class extends Filter {
  constructor(options) {
    const gpuOptions = options.gpu;
    const gpuSource = compileBlendModeShader(__spreadValues({ source: blendTemplate }, gpuOptions));
    const gpuProgram3 = GpuProgram.from({
      vertex: {
        source: gpuSource,
        entryPoint: "mainVertex"
      },
      fragment: {
        source: gpuSource,
        entryPoint: "mainFragment"
      }
    });
    const glOptions = options.gl;
    const glSource = compileBlendModeShader(__spreadValues({ source: blendTemplateFrag }, glOptions));
    const glProgram3 = GlProgram.from({
      vertex: blendTemplateVert,
      fragment: glSource
    });
    const uniformGroup = new UniformGroup({
      uBlend: {
        value: 1,
        type: "f32"
      }
    });
    super({
      gpuProgram: gpuProgram3,
      glProgram: glProgram3,
      blendRequired: true,
      resources: {
        blendUniforms: uniformGroup,
        uBackTexture: Texture.EMPTY
      }
    });
  }
};
function compileBlendModeShader(options) {
  const { source: source8, functions, main } = options;
  return source8.replace("{FUNCTIONS}", functions).replace("{MAIN}", main);
}

// node_modules/pixi.js/lib/filters/blend-modes/hls/GLhls.mjs
var hslgl = `
	float getLuminosity(vec3 c) {
		return 0.3 * c.r + 0.59 * c.g + 0.11 * c.b;
	}

	vec3 setLuminosity(vec3 c, float lum) {
		float modLum = lum - getLuminosity(c);
		vec3 color = c.rgb + vec3(modLum);

		// clip back into legal range
		modLum = getLuminosity(color);
		vec3 modLumVec = vec3(modLum);

		float cMin = min(color.r, min(color.g, color.b));
		float cMax = max(color.r, max(color.g, color.b));

		if(cMin < 0.0) {
			color = mix(modLumVec, color, modLum / (modLum - cMin));
		}

		if(cMax > 1.0) {
			color = mix(modLumVec, color, (1.0 - modLum) / (cMax - modLum));
		}

		return color;
	}

	float getSaturation(vec3 c) {
		return max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
	}

	vec3 setSaturationMinMidMax(vec3 cSorted, float s) {
		vec3 colorSorted = cSorted;

		if(colorSorted.z > colorSorted.x) {
			colorSorted.y = (((colorSorted.y - colorSorted.x) * s) / (colorSorted.z - colorSorted.x));
			colorSorted.z = s;
		}
		else {
			colorSorted.y = 0.0;
			colorSorted.z = 0.0;
		}

		colorSorted.x = 0.0;

		return colorSorted;
	}

	vec3 setSaturation(vec3 c, float s) {
		vec3 color = c;

		if(color.r <= color.g && color.r <= color.b) {
			if(color.g <= color.b) {
				color = setSaturationMinMidMax(color.rgb, s).rgb;
			}
			else {
				color = setSaturationMinMidMax(color.rbg, s).rbg;
			}
		}
		else if(color.g <= color.r && color.g <= color.b) {
			if(color.r <= color.b) {
				color = setSaturationMinMidMax(color.grb, s).grb;
			}
			else {
				color = setSaturationMinMidMax(color.gbr, s).gbr;
			}
		}
		else {
			// Using bgr for both fixes part of hue
			if(color.r <= color.g) {
				color = setSaturationMinMidMax(color.brg, s).brg;
			}
			else {
				color = setSaturationMinMidMax(color.bgr, s).bgr;
			}
		}

		return color;
	}
    `;

// node_modules/pixi.js/lib/filters/blend-modes/hls/GPUhls.mjs
var hslgpu = `
	fn getLuminosity(c: vec3<f32>) -> f32
	{
		return 0.3*c.r + 0.59*c.g + 0.11*c.b;
	}

	fn setLuminosity(c: vec3<f32>, lum: f32) -> vec3<f32>
	{
		var modLum: f32 = lum - getLuminosity(c);
		var color: vec3<f32> = c.rgb + modLum;

		// clip back into legal range
		modLum = getLuminosity(color);
		let modLumVec = vec3<f32>(modLum);

		let cMin: f32 = min(color.r, min(color.g, color.b));
		let cMax: f32 = max(color.r, max(color.g, color.b));

		if(cMin < 0.0)
		{
			color = mix(modLumVec, color, modLum / (modLum - cMin));
		}

		if(cMax > 1.0)
		{
			color = mix(modLumVec, color, (1 - modLum) / (cMax - modLum));
		}

		return color;
	}

	fn getSaturation(c: vec3<f32>) -> f32
	{
		return max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
	}

	fn setSaturationMinMidMax(cSorted: vec3<f32>, s: f32) -> vec3<f32>
	{
		var colorSorted = cSorted;

		if(colorSorted.z > colorSorted.x)
		{
			colorSorted.y = (((colorSorted.y - colorSorted.x) * s) / (colorSorted.z - colorSorted.x));
			colorSorted.z = s;
		}
		else
		{
			colorSorted.y = 0;
			colorSorted.z = 0;
		}

		colorSorted.x = 0;

		return colorSorted;
	}

	fn setSaturation(c: vec3<f32>, s: f32) -> vec3<f32>
	{
		var color = c;

		if (color.r <= color.g && color.r <= color.b)
		{
			if (color.g <= color.b)
			{
				color = vec3<f32>(setSaturationMinMidMax(color.rgb, s)).rgb;
			}
			else
			{
				color = vec3<f32>(setSaturationMinMidMax(color.rbg, s)).rbg;
			}
		}
		else if (color.g <= color.r && color.g <= color.b)
		{
			if (color.r <= color.b)
			{
				color = vec3<f32>(setSaturationMinMidMax(color.grb, s)).grb;
			}
			else
			{
				color = vec3<f32>(setSaturationMinMidMax(color.gbr, s)).gbr;
			}
		}
		else
		{
			// Using bgr for both fixes part of hue
			if (color.r <= color.g)
			{
				color = vec3<f32>(setSaturationMinMidMax(color.brg, s)).brg;
			}
			else
			{
				color  = vec3<f32>(setSaturationMinMidMax(color.bgr, s)).bgr;
			}
		}

		return color;
	}
	`;

// node_modules/pixi.js/lib/advanced-blend-modes/ColorBlend.mjs
var ColorBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                ${hslgl}

                vec3 blendColor(vec3 base, vec3 blend,  float opacity)
                {
                    return (setLuminosity(blend, getLuminosity(base)) * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendColor(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                ${hslgpu}

                fn blendColorOpacity(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    return (setLuminosity(blend, getLuminosity(base)) * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendColorOpacity(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
ColorBlend.extension = {
  name: "color",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/ColorBurnBlend.mjs
var ColorBurnBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float colorBurn(float base, float blend)
                {
                    return max((1.0 - ((1.0 - base) / blend)), 0.0);
                }

                vec3 blendColorBurn(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        colorBurn(base.r, blend.r),
                        colorBurn(base.g, blend.g),
                        colorBurn(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendColorBurn(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
            `
      },
      gpu: {
        functions: `
                fn colorBurn(base:f32, blend:f32) -> f32
                {
                    return max((1.0-((1.0-base)/blend)),0.0);
                }

                fn blendColorBurn(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        colorBurn(base.r, blend.r),
                        colorBurn(base.g, blend.g),
                        colorBurn(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendColorBurn(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
ColorBurnBlend.extension = {
  name: "color-burn",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/ColorDodgeBlend.mjs
var ColorDodgeBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float colorDodge(float base, float blend)
                {
                    return base / (1.0 - blend);
                }

                vec3 blendColorDodge(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        colorDodge(base.r, blend.r),
                        colorDodge(base.g, blend.g),
                        colorDodge(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendColorDodge(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn colorDodge(base: f32, blend: f32) -> f32
                {
                    return base / (1.0 - blend);
                }

                fn blendColorDodge(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        colorDodge(base.r, blend.r),
                        colorDodge(base.g, blend.g),
                        colorDodge(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                    out = vec4<f32>(blendColorDodge(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
ColorDodgeBlend.extension = {
  name: "color-dodge",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/DarkenBlend.mjs
var DarkenBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                vec3 blendDarken(vec3 base, vec3 blend, float opacity)
                {
                    return (min(base, blend) * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendDarken(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn blendDarken(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    return (min(blend,base) * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendDarken(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
DarkenBlend.extension = {
  name: "darken",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/DifferenceBlend.mjs
var DifferenceBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                vec3 blendDifference(vec3 base, vec3 blend,  float opacity)
                {
                    return (abs(blend - base) * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendDifference(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
            `
      },
      gpu: {
        functions: `
                fn blendDifference(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    return (abs(blend - base) * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendDifference(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
DifferenceBlend.extension = {
  name: "difference",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/DivideBlend.mjs
var DivideBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float divide(float base, float blend)
                {
                    return (blend > 0.0) ? clamp(base / blend, 0.0, 1.0) : 1.0;
                }

                vec3 blendDivide(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        divide(base.r, blend.r),
                        divide(base.g, blend.g),
                        divide(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendDivide(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn divide(base: f32, blend: f32) -> f32
                {
                    return select(1.0, clamp(base / blend, 0.0, 1.0), blend > 0.0);
                }

                fn blendDivide(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        divide(base.r, blend.r),
                        divide(base.g, blend.g),
                        divide(base.b, blend.b)
                    );
                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendDivide(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
DivideBlend.extension = {
  name: "divide",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/ExclusionBlend.mjs
var ExclusionBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                vec3 exclusion(vec3 base, vec3 blend)
                {
                    return base + blend - 2.0 * base * blend;
                }

                vec3 blendExclusion(vec3 base, vec3 blend, float opacity)
                {
                    return (exclusion(base, blend) * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendExclusion(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn exclusion(base: vec3<f32>, blend: vec3<f32>) -> vec3<f32>
                {
                    return base+blend-2.0*base*blend;
                }

                fn blendExclusion(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    return (exclusion(base, blend) * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendExclusion(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
ExclusionBlend.extension = {
  name: "exclusion",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/HardLightBlend.mjs
var HardLightBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float hardLight(float base, float blend)
                {
                    return (blend < 0.5) ? 2.0 * base * blend : 1.0 - 2.0 * (1.0 - base) * (1.0 - blend);
                }

                vec3 blendHardLight(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        hardLight(base.r, blend.r),
                        hardLight(base.g, blend.g),
                        hardLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendHardLight(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
            `
      },
      gpu: {
        functions: `
                fn hardLight(base: f32, blend: f32) -> f32
                {
                    return select(1.0 - 2.0 * (1.0 - base) * (1.0 - blend), 2.0 * base * blend, blend < 0.5);
                }

                fn blendHardLight(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        hardLight(base.r, blend.r),
                        hardLight(base.g, blend.g),
                        hardLight(base.b, blend.b)
                    );
                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendHardLight(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
HardLightBlend.extension = {
  name: "hard-light",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/HardMixBlend.mjs
var HardMixBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float hardMix(float base, float blend)
                {
                    return (base + blend >= 1.0) ? 1.0 : 0.0;
                }

                vec3 blendHardMix(vec3 base, vec3 blend,  float opacity)
                {
                    vec3 blended = vec3(
                        hardMix(base.r, blend.r),
                        hardMix(base.g, blend.g),
                        hardMix(base.b, blend.b)
                    );
                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendHardMix(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
            `
      },
      gpu: {
        functions: `
                fn hardMix(base: f32, blend: f32) -> f32
                {
                    return select(0.0, 1.0, base + blend >= 1.0);
                }

                fn blendHardMix(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blended: vec3<f32> = vec3<f32>(
                        hardMix(base.r, blend.r),
                        hardMix(base.g, blend.g),
                        hardMix(base.b, blend.b)
                    );
                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendHardMix(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
HardMixBlend.extension = {
  name: "hard-mix",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/LightenBlend.mjs
var LightenBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                vec3 blendLighten(vec3 base, vec3 blend, float opacity)
                {
                    return (max(base, blend) * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendLighten(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn blendLighten(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    return (max(base, blend) * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendLighten(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
LightenBlend.extension = {
  name: "lighten",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/LinearBurnBlend.mjs
var LinearBurnBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float linearBurn(float base, float blend)
                {
                    return max(0.0, base + blend - 1.0);
                }

                vec3 blendLinearBurn(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        linearBurn(base.r, blend.r),
                        linearBurn(base.g, blend.g),
                        linearBurn(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendLinearBurn(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn linearBurn(base: f32, blend: f32) -> f32
                {
                    return max(0.0, base + blend - 1.0);
                }

                fn blendLinearBurn(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        linearBurn(base.r, blend.r),
                        linearBurn(base.g, blend.g),
                        linearBurn(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendLinearBurn(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
LinearBurnBlend.extension = {
  name: "linear-burn",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/LinearDodgeBlend.mjs
var LinearDodgeBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float linearDodge(float base, float blend) {
                    return min(1.0, base + blend);
                }

                vec3 blendLinearDodge(vec3 base, vec3 blend, float opacity) {
                    vec3 blended = vec3(
                        linearDodge(base.r, blend.r),
                        linearDodge(base.g, blend.g),
                        linearDodge(base.b, blend.b)
                    );
                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendLinearDodge(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn linearDodge(base: f32, blend: f32) -> f32
                {
                    return min(1, base + blend);
                }

                fn blendLinearDodge(base:vec3<f32>, blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        linearDodge(base.r, blend.r),
                        linearDodge(base.g, blend.g),
                        linearDodge(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendLinearDodge(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
LinearDodgeBlend.extension = {
  name: "linear-dodge",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/LinearLightBlend.mjs
var LinearLightBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float linearBurn(float base, float blend) {
                    return max(0.0, base + blend - 1.0);
                }

                float linearDodge(float base, float blend) {
                    return min(1.0, base + blend);
                }

                float linearLight(float base, float blend) {
                    return (blend <= 0.5) ? linearBurn(base,2.0*blend) : linearBurn(base,2.0*(blend-0.5));
                }

                vec3 blendLinearLight(vec3 base, vec3 blend, float opacity) {
                    vec3 blended = vec3(
                        linearLight(base.r, blend.r),
                        linearLight(base.g, blend.g),
                        linearLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendLinearLight(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn linearBurn(base: f32, blend: f32) -> f32
                {
                    return max(0.0, base + blend - 1.0);
                }

                fn linearDodge(base: f32, blend: f32) -> f32
                {
                    return min(1.0, base + blend);
                }

                fn linearLight(base: f32, blend: f32) -> f32
                {
                    return select(linearBurn(base,2.0*(blend-0.5)), linearBurn(base,2.0*blend), blend <= 0.5);
                }

                fn blendLinearLightOpacity(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        linearLight(base.r, blend.r),
                        linearLight(base.g, blend.g),
                        linearLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendLinearLightOpacity(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
LinearLightBlend.extension = {
  name: "linear-light",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/LuminosityBlend.mjs
var LuminosityBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                ${hslgl}

                vec3 blendLuminosity(vec3 base, vec3 blend,  float opacity)
                {
                    vec3 blendLuminosity = setLuminosity(base, getLuminosity(blend));
                    return (blendLuminosity * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendLuminosity(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                ${hslgpu}

                fn blendLuminosity(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blendLuminosity: vec3<f32> = setLuminosity(base, getLuminosity(blend));
                    return (blendLuminosity * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendLuminosity(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
LuminosityBlend.extension = {
  name: "luminosity",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/NegationBlend.mjs
var NegationBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                vec3 negation(vec3 base, vec3 blend)
                {
                    return 1.0-abs(1.0-base-blend);
                }

                vec3 blendNegation(vec3 base, vec3 blend, float opacity)
                {
                    return (negation(base, blend) * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendNegation(back.rgb, front.rgb, front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn blendNegation(base: vec3<f32>, blend: vec3<f32>) -> vec3<f32>
                {
                    return 1.0-abs(1.0-base-blend);
                }

                fn blendNegationOpacity(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    return (blendNegation(base, blend) * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendNegationOpacity(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
NegationBlend.extension = {
  name: "negation",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/OverlayBlend.mjs
var OverlayBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float overlay(float base, float blend)
                {
                    return (base < 0.5) ? (2.0*base*blend) : (1.0-2.0*(1.0-base)*(1.0-blend));
                }

                vec3 blendOverlay(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        overlay(base.r, blend.r),
                        overlay(base.g, blend.g),
                        overlay(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendOverlay(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn overlay(base: f32, blend: f32) -> f32
                {
                    return select((1.0-2.0*(1.0-base)*(1.0-blend)), (2.0*base*blend), base < 0.5);
                }

                fn blendOverlay(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        overlay(base.r, blend.r),
                        overlay(base.g, blend.g),
                        overlay(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendOverlay(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
OverlayBlend.extension = {
  name: "overlay",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/PinLightBlend.mjs
var PinLightBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float pinLight(float base, float blend)
                {
                    return (blend <= 0.5) ? min(base, 2.0 * blend) : max(base, 2.0 * (blend - 0.5));
                }

                vec3 blendPinLight(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        pinLight(base.r, blend.r),
                        pinLight(base.g, blend.g),
                        pinLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendPinLight(back.rgb, front.rgb, front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn pinLight(base: f32, blend: f32) -> f32
                {
                    return select(max(base,2.0*(blend-0.5)), min(base,2.0*blend), blend <= 0.5);
                }

                fn blendPinLight(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        pinLight(base.r, blend.r),
                        pinLight(base.g, blend.g),
                        pinLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendPinLight(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
PinLightBlend.extension = {
  name: "pin-light",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/SaturationBlend.mjs
var SaturationBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                ${hslgl}

                vec3 blendSaturation(vec3 base, vec3 blend,  float opacity)
                {
                    vec3 blendSaturation = setLuminosity(setSaturation(base, getSaturation(blend)), getLuminosity(base));
                    return (blendSaturation * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendSaturation(back.rgb, front.rgb, front.a), blendedAlpha) * uBlend;
            `
      },
      gpu: {
        functions: `
                ${hslgpu}

                fn blendSaturation(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blendSaturation = setLuminosity(setSaturation(base, getSaturation(blend)), getLuminosity(base));
                    return (blendSaturation * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                out = vec4<f32>(blendSaturation(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
            `
      }
    });
  }
};
SaturationBlend.extension = {
  name: "saturation",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/SoftLightBlend.mjs
var SoftLightBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float softLight(float base, float blend)
                {
                    return (blend < 0.5) ? (2.0 * base * blend + base * base * (1.0 - 2.0 * blend)) : (sqrt(base) * (2.0 * blend - 1.0) + 2.0 * base * (1.0 - blend));
                }

                vec3 blendSoftLight(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        softLight(base.r, blend.r),
                        softLight(base.g, blend.g),
                        softLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendSoftLight(back.rgb, front.rgb, front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn softLight(base: f32, blend: f32) -> f32
                {
                    return select(2.0 * base * blend + base * base * (1.0 - 2.0 * blend), sqrt(base) * (2.0 * blend - 1.0) + 2.0 * base * (1.0 - blend), blend < 0.5);
                }

                fn blendSoftLight(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blended: vec3<f32> = vec3<f32>(
                        softLight(base.r, blend.r),
                        softLight(base.g, blend.g),
                        softLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendSoftLight(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
SoftLightBlend.extension = {
  name: "soft-light",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/SubtractBlend.mjs
var SubtractBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float subtract(float base, float blend)
                {
                    return max(0.0, base - blend);
                }

                vec3 blendSubtract(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        subtract(base.r, blend.r),
                        subtract(base.g, blend.g),
                        subtract(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                finalColor = vec4(blendSubtract(back.rgb, front.rgb, front.a), blendedAlpha) * uBlend;
                `
      },
      gpu: {
        functions: `
                fn subtract(base: f32, blend: f32) -> f32
                {
                    return max(0, base - blend);
                }

                fn blendSubtract(base:vec3<f32>,  blend:vec3<f32>,  opacity:f32) -> vec3<f32>
                {
                    let blended = vec3<f32>(
                        subtract(base.r, blend.r),
                        subtract(base.g, blend.g),
                        subtract(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendSubtract(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
SubtractBlend.extension = {
  name: "subtract",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/advanced-blend-modes/VividLightBlend.mjs
var VividLightBlend = class extends BlendModeFilter {
  constructor() {
    super({
      gl: {
        functions: `
                float colorBurn(float base, float blend)
                {
                    return max((1.0-((1.0-base)/blend)),0.0);
                }

                float colorDodge(float base, float blend)
                {
                    return min(1.0, base / (1.0-blend));
                }

                float vividLight(float base, float blend)
                {
                    return (blend < 0.5) ? colorBurn(base,(2.0*blend)) : colorDodge(base,(2.0*(blend-0.5)));
                }

                vec3 blendVividLight(vec3 base, vec3 blend, float opacity)
                {
                    vec3 blended = vec3(
                        vividLight(base.r, blend.r),
                        vividLight(base.g, blend.g),
                        vividLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
            `,
        main: `
                finalColor = vec4(blendVividLight(back.rgb, front.rgb,front.a), blendedAlpha) * uBlend;
            `
      },
      gpu: {
        functions: `
                fn colorBurn(base:f32, blend:f32) -> f32
                {
                    return max((1.0-((1.0-base)/blend)),0.0);
                }

                fn colorDodge(base: f32, blend: f32) -> f32
                {
                    return min(1.0, base / (1.0-blend));
                }

                fn vividLight(base: f32, blend: f32) -> f32
                {
                    return select(colorDodge(base,(2.0*(blend-0.5))), colorBurn(base,(2.0*blend)), blend<0.5);
                }

                fn blendVividLight(base: vec3<f32>, blend: vec3<f32>, opacity: f32) -> vec3<f32>
                {
                    let blended: vec3<f32> = vec3<f32>(
                        vividLight(base.r, blend.r),
                        vividLight(base.g, blend.g),
                        vividLight(base.b, blend.b)
                    );

                    return (blended * opacity + base * (1.0 - opacity));
                }
                `,
        main: `
                out = vec4<f32>(blendVividLight(back.rgb, front.rgb, front.a), blendedAlpha) * blendUniforms.uBlend;
                `
      }
    });
  }
};
VividLightBlend.extension = {
  name: "vivid-light",
  type: ExtensionType.BlendMode
};

// node_modules/pixi.js/lib/utils/browser/isWebGLSupported.mjs
var _isWebGLSupported;
function isWebGLSupported(failIfMajorPerformanceCaveat) {
  if (_isWebGLSupported !== void 0) return _isWebGLSupported;
  _isWebGLSupported = (() => {
    const contextOptions = {
      stencil: true,
      failIfMajorPerformanceCaveat: failIfMajorPerformanceCaveat ?? AbstractRenderer.defaultOptions.failIfMajorPerformanceCaveat
    };
    try {
      if (!DOMAdapter.get().getWebGLRenderingContext()) {
        return false;
      }
      const canvas = DOMAdapter.get().createCanvas();
      let gl = canvas.getContext("webgl", contextOptions);
      const success = !!gl?.getContextAttributes()?.stencil;
      if (gl) {
        const loseContext = gl.getExtension("WEBGL_lose_context");
        if (loseContext) {
          loseContext.loseContext();
        }
      }
      gl = null;
      return success;
    } catch (_e) {
      return false;
    }
  })();
  return _isWebGLSupported;
}

// node_modules/pixi.js/lib/utils/browser/isWebGPUSupported.mjs
var _isWebGPUSupported;
function isWebGPUSupported() {
  return __async(this, arguments, function* (options = {}) {
    if (_isWebGPUSupported !== void 0) return _isWebGPUSupported;
    _isWebGPUSupported = yield (() => __async(null, null, function* () {
      const gpu = DOMAdapter.get().getNavigator().gpu;
      if (!gpu) {
        return false;
      }
      try {
        const adapter = yield gpu.requestAdapter(options);
        yield adapter.requestDevice();
        return true;
      } catch (_e) {
        return false;
      }
    }))();
    return _isWebGPUSupported;
  });
}

// node_modules/pixi.js/lib/rendering/renderers/autoDetectRenderer.mjs
var renderPriority = ["webgl", "webgpu", "canvas"];
function autoDetectRenderer(options) {
  return __async(this, null, function* () {
    let preferredOrder = [];
    if (options.preference) {
      if (Array.isArray(options.preference)) {
        preferredOrder = options.preference.slice();
      } else {
        preferredOrder.push(options.preference);
        renderPriority.forEach((item) => {
          if (item !== options.preference) {
            preferredOrder.push(item);
          }
        });
      }
    } else {
      preferredOrder = renderPriority.slice();
    }
    let RendererClass;
    let finalOptions = {};
    for (let i = 0; i < preferredOrder.length; i++) {
      const rendererType = preferredOrder[i];
      if (rendererType === "webgpu" && (yield isWebGPUSupported())) {
        const { WebGPURenderer: WebGPURenderer2 } = yield import("./WebGPURenderer-HYTYRWLU.js");
        RendererClass = WebGPURenderer2;
        finalOptions = __spreadValues(__spreadValues({}, options), options.webgpu);
        break;
      } else if (rendererType === "webgl" && isWebGLSupported(
        options.failIfMajorPerformanceCaveat ?? AbstractRenderer.defaultOptions.failIfMajorPerformanceCaveat
      )) {
        const { WebGLRenderer: WebGLRenderer2 } = yield import("./WebGLRenderer-ASOFXKTU.js");
        RendererClass = WebGLRenderer2;
        finalOptions = __spreadValues(__spreadValues({}, options), options.webgl);
        break;
      } else if (rendererType === "canvas") {
        const { CanvasRenderer: CanvasRenderer2 } = yield import("./CanvasRenderer-PQOLHXV7.js");
        RendererClass = CanvasRenderer2;
        finalOptions = __spreadValues(__spreadValues({}, options), options.canvasOptions);
        break;
      }
    }
    delete finalOptions.webgpu;
    delete finalOptions.webgl;
    delete finalOptions.canvasOptions;
    if (!RendererClass) {
      throw new Error("No available renderer for the current environment");
    }
    const renderer = new RendererClass();
    yield renderer.init(finalOptions);
    return renderer;
  });
}

// node_modules/pixi.js/lib/app/ResizePlugin.mjs
var ResizePlugin = class {
  /**
   * Initialize the plugin with scope of application instance
   * @private
   * @param {object} [options] - See application options
   */
  static init(options) {
    Object.defineProperty(
      this,
      "resizeTo",
      {
        configurable: true,
        set(dom) {
          globalThis.removeEventListener("resize", this.queueResize);
          this._resizeTo = dom;
          if (dom) {
            globalThis.addEventListener("resize", this.queueResize);
            this.resize();
          }
        },
        get() {
          return this._resizeTo;
        }
      }
    );
    this.queueResize = () => {
      if (!this._resizeTo) {
        return;
      }
      this._cancelResize();
      this._resizeId = requestAnimationFrame(() => this.resize());
    };
    this._cancelResize = () => {
      if (this._resizeId) {
        cancelAnimationFrame(this._resizeId);
        this._resizeId = null;
      }
    };
    this.resize = () => {
      if (!this._resizeTo) {
        return;
      }
      this._cancelResize();
      let width;
      let height;
      if (this._resizeTo === globalThis.window) {
        width = globalThis.innerWidth;
        height = globalThis.innerHeight;
      } else {
        const { clientWidth, clientHeight } = this._resizeTo;
        width = clientWidth;
        height = clientHeight;
      }
      this.renderer.resize(width, height);
      this.render();
    };
    this._resizeId = null;
    this._resizeTo = null;
    this.resizeTo = options.resizeTo || null;
  }
  /**
   * Clean up the ticker, scoped to application
   * @private
   */
  static destroy() {
    globalThis.removeEventListener("resize", this.queueResize);
    this._cancelResize();
    this._cancelResize = null;
    this.queueResize = null;
    this.resizeTo = null;
    this.resize = null;
  }
};
ResizePlugin.extension = ExtensionType.Application;

// node_modules/pixi.js/lib/app/TickerPlugin.mjs
var TickerPlugin = class {
  /**
   * Initialize the plugin with scope of application instance
   * @private
   * @param {object} [options] - See application options
   */
  static init(options) {
    options = Object.assign({
      autoStart: true,
      sharedTicker: false
    }, options);
    Object.defineProperty(
      this,
      "ticker",
      {
        configurable: true,
        set(ticker) {
          if (this._ticker) {
            this._ticker.remove(this.render, this);
          }
          this._ticker = ticker;
          if (ticker) {
            ticker.add(this.render, this, UPDATE_PRIORITY.LOW);
          }
        },
        get() {
          return this._ticker;
        }
      }
    );
    this.stop = () => {
      this._ticker.stop();
    };
    this.start = () => {
      this._ticker.start();
    };
    this._ticker = null;
    this.ticker = options.sharedTicker ? Ticker.shared : new Ticker();
    if (options.autoStart) {
      this.start();
    }
  }
  /**
   * Clean up the ticker, scoped to application.
   * @private
   */
  static destroy() {
    if (this._ticker) {
      const oldTicker = this._ticker;
      this.ticker = null;
      oldTicker.destroy();
    }
  }
};
TickerPlugin.extension = ExtensionType.Application;

// node_modules/pixi.js/lib/app/init.mjs
extensions.add(ResizePlugin);
extensions.add(TickerPlugin);

// node_modules/pixi.js/lib/app/Application.mjs
var _Application = class _Application2 {
  constructor(...args) {
    this.stage = new Container();
    if (args[0] !== void 0) {
      deprecation(v8_0_0, "Application constructor options are deprecated, please use Application.init() instead.");
    }
  }
  /**
   * Initializes the PixiJS application with the specified options.
   *
   * This method must be called after creating a new Application instance.
   * @param options - Configuration options for the application and renderer
   * @returns A promise that resolves when initialization is complete
   * @example
   * ```js
   * const app = new Application();
   *
   * // Initialize with custom options
   * await app.init({
   *     width: 800,
   *     height: 600,
   *     backgroundColor: 0x1099bb,
   *     preference: 'webgl', // or 'webgpu'
   * });
   * ```
   */
  init(options) {
    return __async(this, null, function* () {
      options = __spreadValues({}, options);
      this.stage || (this.stage = new Container());
      this.renderer = yield autoDetectRenderer(options);
      _Application2._plugins.forEach((plugin) => {
        plugin.init.call(this, options);
      });
    });
  }
  /**
   * Renders the current stage to the screen.
   *
   * When using the default setup with {@link TickerPlugin} (enabled by default), you typically don't need to call
   * this method directly as rendering is handled automatically.
   *
   * Only use this method if you've disabled the {@link TickerPlugin} or need custom
   * render timing control.
   * @example
   * ```js
   * // Example 1: Default setup (TickerPlugin handles rendering)
   * const app = new Application();
   * await app.init();
   * // No need to call render() - TickerPlugin handles it
   *
   * // Example 2: Custom rendering loop (if TickerPlugin is disabled)
   * const app = new Application();
   * await app.init({ autoStart: false }); // Disable automatic rendering
   *
   * function animate() {
   *     app.render();
   *     requestAnimationFrame(animate);
   * }
   * animate();
   * ```
   */
  render() {
    this.renderer.render({ container: this.stage });
  }
  /**
   * Reference to the renderer's canvas element. This is the HTML element
   * that displays your application's graphics.
   * @readonly
   * @type {HTMLCanvasElement}
   * @example
   * ```js
   * // Create a new application
   * const app = new Application();
   * // Initialize the application
   * await app.init({...});
   * // Add canvas to the page
   * document.body.appendChild(app.canvas);
   *
   * // Access the canvas directly
   * console.log(app.canvas); // HTMLCanvasElement
   * ```
   */
  get canvas() {
    return this.renderer.canvas;
  }
  /**
   * Reference to the renderer's canvas element.
   * @type {HTMLCanvasElement}
   * @deprecated since 8.0.0
   * @see {@link Application#canvas}
   */
  get view() {
    deprecation(v8_0_0, "Application.view is deprecated, please use Application.canvas instead.");
    return this.renderer.canvas;
  }
  /**
   * Reference to the renderer's screen rectangle. This represents the visible area of your application.
   *
   * It's commonly used for:
   * - Setting filter areas for full-screen effects
   * - Defining hit areas for screen-wide interaction
   * - Determining the visible bounds of your application
   * @readonly
   * @example
   * ```js
   * // Use as filter area for a full-screen effect
   * const blurFilter = new BlurFilter();
   * sprite.filterArea = app.screen;
   *
   * // Use as hit area for screen-wide interaction
   * const screenSprite = new Sprite();
   * screenSprite.hitArea = app.screen;
   *
   * // Get screen dimensions
   * console.log(app.screen.width, app.screen.height);
   * ```
   * @see {@link Rectangle} For all available properties and methods
   */
  get screen() {
    return this.renderer.screen;
  }
  /**
   * Get the html div element that holds all DOM Container elements.
   * @readonly
   * @type {HTMLDivElement}
   */
  get domContainerRoot() {
    return this.renderer.renderPipes.dom?._domElement;
  }
  /**
   * Destroys the application and all of its resources.
   *
   * This method should be called when you want to completely
   * clean up the application and free all associated memory.
   * @param rendererDestroyOptions - Options for destroying the renderer:
   *  - `false` or `undefined`: Preserves the canvas element (default)
   *  - `true`: Removes the canvas element
   *  - `{ removeView: boolean }`: Object with removeView property to control canvas removal
   * @param options - Options for destroying the application:
   *  - `false` or `undefined`: Basic cleanup (default)
   *  - `true`: Complete cleanup including children
   *  - Detailed options object:
   *    - `children`: Remove children
   *    - `texture`: Destroy textures
   *    - `textureSource`: Destroy texture sources
   *    - `context`: Destroy WebGL context
   * @example
   * ```js
   * // Basic cleanup
   * app.destroy();
   *
   * // Remove canvas and do complete cleanup
   * app.destroy(true, true);
   *
   * // Remove canvas with explicit options
   * app.destroy({ removeView: true }, true);
   *
   * // Detailed cleanup with specific options
   * app.destroy(
   *     { removeView: true },
   *     {
   *         children: true,
   *         texture: true,
   *         textureSource: true,
   *         context: true
   *     }
   * );
   * ```
   * > [!WARNING] After calling destroy, the application instance should no longer be used.
   * > All properties will be null and further operations will throw errors.
   */
  destroy(rendererDestroyOptions = false, options = false) {
    const plugins = _Application2._plugins.slice(0);
    plugins.reverse();
    plugins.forEach((plugin) => {
      plugin.destroy.call(this);
    });
    this.stage.destroy(options);
    this.stage = null;
    this.renderer.destroy(rendererDestroyOptions);
    this.renderer = null;
  }
};
_Application._plugins = [];
var Application = _Application;
extensions.handleByList(ExtensionType.Application, Application._plugins);
extensions.add(ApplicationInitHook);

// node_modules/pixi.js/lib/scene/text-bitmap/asset/bitmapFontTextParser.mjs
var bitmapFontTextParser = {
  test(data) {
    return typeof data === "string" && data.startsWith("info face=");
  },
  parse(txt) {
    const items = txt.match(/^[a-z]+\s+.+$/gm);
    const rawData = {
      info: [],
      common: [],
      page: [],
      char: [],
      chars: [],
      kerning: [],
      kernings: [],
      distanceField: []
    };
    for (const i in items) {
      const name = items[i].match(/^[a-z]+/gm)[0];
      const attributeList = items[i].match(/[a-zA-Z]+=([^\s"']+|"([^"]*)")/gm);
      const itemData = {};
      for (const i2 in attributeList) {
        const split = attributeList[i2].split("=");
        const key = split[0];
        const strValue = split[1].replace(/"/gm, "");
        const floatValue = parseFloat(strValue);
        const value = isNaN(floatValue) ? strValue : floatValue;
        itemData[key] = value;
      }
      rawData[name].push(itemData);
    }
    const font = {
      chars: {},
      pages: [],
      lineHeight: 0,
      fontSize: 0,
      fontFamily: "",
      distanceField: null,
      baseLineOffset: 0
    };
    const [info] = rawData.info;
    const [common] = rawData.common;
    const [distanceField] = rawData.distanceField ?? [];
    if (distanceField) {
      font.distanceField = {
        range: parseInt(distanceField.distanceRange, 10),
        type: distanceField.fieldType
      };
    }
    font.fontSize = parseInt(info.size, 10);
    font.fontFamily = info.face;
    font.lineHeight = parseInt(common.lineHeight, 10);
    const page = rawData.page;
    for (let i = 0; i < page.length; i++) {
      font.pages.push({
        id: parseInt(page[i].id, 10) || 0,
        file: page[i].file
      });
    }
    const map = {};
    font.baseLineOffset = common.base === void 0 ? 0 : font.lineHeight - parseInt(common.base, 10);
    const char = rawData.char;
    for (let i = 0; i < char.length; i++) {
      const charNode = char[i];
      const id = parseInt(charNode.id, 10);
      let letter = charNode.letter ?? charNode.char ?? String.fromCharCode(id);
      if (letter === "space") letter = " ";
      map[id] = letter;
      font.chars[letter] = {
        id,
        // texture deets..
        page: parseInt(charNode.page, 10) || 0,
        x: parseInt(charNode.x, 10),
        y: parseInt(charNode.y, 10),
        width: parseInt(charNode.width, 10),
        height: parseInt(charNode.height, 10),
        xOffset: parseInt(charNode.xoffset, 10),
        yOffset: parseInt(charNode.yoffset, 10),
        xAdvance: parseInt(charNode.xadvance, 10),
        kerning: {}
      };
    }
    const kerning = rawData.kerning || [];
    for (let i = 0; i < kerning.length; i++) {
      const first = parseInt(kerning[i].first, 10);
      const second = parseInt(kerning[i].second, 10);
      const amount = parseInt(kerning[i].amount, 10);
      if (font.chars[map[second]]) font.chars[map[second]].kerning[map[first]] = amount;
    }
    return font;
  }
};

// node_modules/pixi.js/lib/scene/text-bitmap/asset/bitmapFontXMLParser.mjs
var bitmapFontXMLParser = {
  test(data) {
    const xml = data;
    return typeof xml !== "string" && "getElementsByTagName" in xml && xml.getElementsByTagName("page").length && xml.getElementsByTagName("info")[0].getAttribute("face") !== null;
  },
  parse(xml) {
    const data = {
      chars: {},
      pages: [],
      lineHeight: 0,
      fontSize: 0,
      fontFamily: "",
      distanceField: null,
      baseLineOffset: 0
    };
    const info = xml.getElementsByTagName("info")[0];
    const common = xml.getElementsByTagName("common")[0];
    const distanceField = xml.getElementsByTagName("distanceField")[0];
    if (distanceField) {
      data.distanceField = {
        type: distanceField.getAttribute("fieldType"),
        range: parseInt(distanceField.getAttribute("distanceRange"), 10)
      };
    }
    const page = xml.getElementsByTagName("page");
    const char = xml.getElementsByTagName("char");
    const kerning = xml.getElementsByTagName("kerning");
    data.fontSize = parseInt(info.getAttribute("size"), 10);
    data.fontFamily = info.getAttribute("face");
    data.lineHeight = parseInt(common.getAttribute("lineHeight"), 10);
    for (let i = 0; i < page.length; i++) {
      data.pages.push({
        id: parseInt(page[i].getAttribute("id"), 10) || 0,
        file: page[i].getAttribute("file")
      });
    }
    const map = {};
    const base = common.getAttribute("base");
    data.baseLineOffset = base === null ? 0 : data.lineHeight - parseInt(base, 10);
    for (let i = 0; i < char.length; i++) {
      const charNode = char[i];
      const id = parseInt(charNode.getAttribute("id"), 10);
      let letter = charNode.getAttribute("letter") ?? charNode.getAttribute("char") ?? String.fromCharCode(id);
      if (letter === "space") letter = " ";
      map[id] = letter;
      data.chars[letter] = {
        id,
        // texture deets..
        page: parseInt(charNode.getAttribute("page"), 10) || 0,
        x: parseInt(charNode.getAttribute("x"), 10),
        y: parseInt(charNode.getAttribute("y"), 10),
        width: parseInt(charNode.getAttribute("width"), 10),
        height: parseInt(charNode.getAttribute("height"), 10),
        // render deets..
        xOffset: parseInt(charNode.getAttribute("xoffset"), 10),
        yOffset: parseInt(charNode.getAttribute("yoffset"), 10),
        // + baseLineOffset,
        xAdvance: parseInt(charNode.getAttribute("xadvance"), 10),
        kerning: {}
      };
    }
    for (let i = 0; i < kerning.length; i++) {
      const first = parseInt(kerning[i].getAttribute("first"), 10);
      const second = parseInt(kerning[i].getAttribute("second"), 10);
      const amount = parseInt(kerning[i].getAttribute("amount"), 10);
      if (data.chars[map[second]]) data.chars[map[second]].kerning[map[first]] = amount;
    }
    return data;
  }
};

// node_modules/pixi.js/lib/scene/text-bitmap/asset/bitmapFontXMLStringParser.mjs
var bitmapFontXMLStringParser = {
  test(data) {
    if (typeof data === "string" && data.match(/<font(\s|>)/)) {
      return bitmapFontXMLParser.test(DOMAdapter.get().parseXML(data));
    }
    return false;
  },
  parse(data) {
    return bitmapFontXMLParser.parse(DOMAdapter.get().parseXML(data));
  }
};

// node_modules/pixi.js/lib/scene/text-bitmap/asset/loadBitmapFont.mjs
var validExtensions = [".xml", ".fnt"];
var bitmapFontCachePlugin = {
  extension: {
    type: ExtensionType.CacheParser,
    name: "cacheBitmapFont"
  },
  test: (asset) => !!asset?.pages && !!asset?.chars && typeof asset?.fontFamily === "string" && asset.fontFamily !== "",
  getCacheableAssets(keys, asset) {
    const out = {};
    keys.forEach((key) => {
      out[key] = asset;
      out[`${key}-bitmap`] = asset;
    });
    out[`${asset.fontFamily}-bitmap`] = asset;
    return out;
  }
};
var loadBitmapFont = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.Normal
  },
  /** used for deprecation purposes */
  name: "loadBitmapFont",
  id: "bitmap-font",
  test(url) {
    return validExtensions.includes(path.extname(url).toLowerCase());
  },
  testParse(data) {
    return __async(this, null, function* () {
      return bitmapFontTextParser.test(data) || bitmapFontXMLStringParser.test(data);
    });
  },
  parse(asset, data, loader) {
    return __async(this, null, function* () {
      const bitmapFontData = bitmapFontTextParser.test(asset) ? bitmapFontTextParser.parse(asset) : bitmapFontXMLStringParser.parse(asset);
      const { src } = data;
      const { pages } = bitmapFontData;
      const textureUrls = [];
      const textureOptions = bitmapFontData.distanceField ? {
        scaleMode: "linear",
        alphaMode: "premultiply-alpha-on-upload",
        autoGenerateMipmaps: false,
        resolution: 1
      } : {};
      for (let i = 0; i < pages.length; ++i) {
        const pageFile = pages[i].file;
        let imagePath = path.join(path.dirname(src), pageFile);
        imagePath = copySearchParams(imagePath, src);
        textureUrls.push({
          src: imagePath,
          data: textureOptions
        });
      }
      const [loadedTextures, { BitmapFont: BitmapFont2 }] = yield Promise.all([
        loader.load(textureUrls),
        import("./BitmapFont-N2HTK7VB.js")
      ]);
      const textures = textureUrls.map((url) => loadedTextures[url.src]);
      const bitmapFont = new BitmapFont2({
        data: bitmapFontData,
        textures
      }, src);
      return bitmapFont;
    });
  },
  load(url, _options) {
    return __async(this, null, function* () {
      const response = yield DOMAdapter.get().fetch(url);
      return yield response.text();
    });
  },
  unload(bitmapFont, _resolvedAsset, loader) {
    return __async(this, null, function* () {
      yield Promise.all(bitmapFont.pages.map((page) => loader.unload(page.texture.source._sourceOrigin)));
      bitmapFont.destroy();
    });
  }
};

// node_modules/pixi.js/lib/assets/BackgroundLoader.mjs
var BackgroundLoader = class {
  /**
   * @param loader
   * @param verbose - should the loader log to the console
   */
  constructor(loader, verbose = false) {
    this._loader = loader;
    this._assetList = [];
    this._isLoading = false;
    this._maxConcurrent = 1;
    this.verbose = verbose;
  }
  /**
   * Adds assets to the background loading queue. Assets are loaded one at a time to minimize
   * performance impact.
   * @param assetUrls - Array of resolved assets to load in the background
   * @example
   * ```ts
   * // Add assets to background load queue
   * backgroundLoader.add([
   *     { src: 'images/level1/bg.png' },
   *     { src: 'images/level1/characters.json' }
   * ]);
   *
   * // Assets will load sequentially in the background
   * // The loader automatically pauses when high-priority loads occur
   * // e.g. Assets.load() is called
   * ```
   * @remarks
   * - Assets are loaded one at a time to minimize performance impact
   * - Loading automatically pauses when Assets.load() is called
   * - No progress tracking is available for background loading
   * - Assets are cached as they complete loading
   * @internal
   */
  add(assetUrls) {
    assetUrls.forEach((a) => {
      this._assetList.push(a);
    });
    if (this.verbose) {
      console.log("[BackgroundLoader] assets: ", this._assetList);
    }
    if (this._isActive && !this._isLoading) {
      void this._next();
    }
  }
  /**
   * Loads the next set of assets. Will try to load as many assets as it can at the same time.
   *
   * The max assets it will try to load at one time will be 4.
   */
  _next() {
    return __async(this, null, function* () {
      if (this._assetList.length && this._isActive) {
        this._isLoading = true;
        const toLoad = [];
        const toLoadAmount = Math.min(this._assetList.length, this._maxConcurrent);
        for (let i = 0; i < toLoadAmount; i++) {
          toLoad.push(this._assetList.pop());
        }
        yield this._loader.load(toLoad);
        this._isLoading = false;
        void this._next();
      }
    });
  }
  /**
   * Controls the active state of the background loader. When active, the loader will
   * continue processing its queue. When inactive, loading is paused.
   * @returns Whether the background loader is currently active
   * @example
   * ```ts
   * // Pause background loading
   * backgroundLoader.active = false;
   *
   * // Resume background loading
   * backgroundLoader.active = true;
   *
   * // Check current state
   * console.log(backgroundLoader.active); // true/false
   *
   * // Common use case: Pause during intensive operations
   * backgroundLoader.active = false;  // Pause background loading
   * ... // Perform high-priority tasks
   * backgroundLoader.active = true;   // Resume background loading
   * ```
   * @remarks
   * - Setting to true resumes loading immediately
   * - Setting to false pauses after current asset completes
   * - Background loading is automatically paused during `Assets.load()`
   * - Assets already being loaded will complete even when set to false
   */
  get active() {
    return this._isActive;
  }
  set active(value) {
    if (this._isActive === value) return;
    this._isActive = value;
    if (value && !this._isLoading) {
      void this._next();
    }
  }
};

// node_modules/pixi.js/lib/assets/cache/parsers/cacheTextureArray.mjs
var cacheTextureArray = {
  extension: {
    type: ExtensionType.CacheParser,
    name: "cacheTextureArray"
  },
  test: (asset) => Array.isArray(asset) && asset.every((t) => t instanceof Texture),
  getCacheableAssets: (keys, asset) => {
    const out = {};
    keys.forEach((key) => {
      asset.forEach((item, i) => {
        out[key + (i === 0 ? "" : i + 1)] = item;
      });
    });
    return out;
  }
};

// node_modules/pixi.js/lib/assets/detections/utils/testImageFormat.mjs
function testImageFormat(imageData) {
  return __async(this, null, function* () {
    if ("Image" in globalThis) {
      return new Promise((resolve) => {
        const image = new Image();
        image.onload = () => {
          resolve(true);
        };
        image.onerror = () => {
          resolve(false);
        };
        image.src = imageData;
      });
    }
    if ("createImageBitmap" in globalThis && "fetch" in globalThis) {
      try {
        const blob = yield (yield fetch(imageData)).blob();
        yield createImageBitmap(blob);
      } catch (_e) {
        return false;
      }
      return true;
    }
    return false;
  });
}

// node_modules/pixi.js/lib/assets/detections/parsers/detectAvif.mjs
var detectAvif = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: 1
  },
  test: () => __async(null, null, function* () {
    return testImageFormat(
      // eslint-disable-next-line max-len
      "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAAB0AAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAIAAAACAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQ0MAAAAABNjb2xybmNseAACAAIAAYAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAACVtZGF0EgAKCBgANogQEAwgMg8f8D///8WfhwB8+ErK42A="
    );
  }),
  add: (formats) => __async(null, null, function* () {
    return [...formats, "avif"];
  }),
  remove: (formats) => __async(null, null, function* () {
    return formats.filter((f) => f !== "avif");
  })
};

// node_modules/pixi.js/lib/assets/detections/parsers/detectDefaults.mjs
var imageFormats = ["png", "jpg", "jpeg"];
var detectDefaults = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: -1
  },
  test: () => Promise.resolve(true),
  add: (formats) => __async(null, null, function* () {
    return [...formats, ...imageFormats];
  }),
  remove: (formats) => __async(null, null, function* () {
    return formats.filter((f) => !imageFormats.includes(f));
  })
};

// node_modules/pixi.js/lib/assets/detections/utils/testVideoFormat.mjs
var inWorker = "WorkerGlobalScope" in globalThis && globalThis instanceof globalThis.WorkerGlobalScope;
function testVideoFormat(mimeType) {
  if (inWorker) {
    return false;
  }
  const video = document.createElement("video");
  return video.canPlayType(mimeType) !== "";
}

// node_modules/pixi.js/lib/assets/detections/parsers/detectMp4.mjs
var detectMp4 = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: 0
  },
  test: () => __async(null, null, function* () {
    return testVideoFormat("video/mp4");
  }),
  add: (formats) => __async(null, null, function* () {
    return [...formats, "mp4", "m4v"];
  }),
  remove: (formats) => __async(null, null, function* () {
    return formats.filter((f) => f !== "mp4" && f !== "m4v");
  })
};

// node_modules/pixi.js/lib/assets/detections/parsers/detectOgv.mjs
var detectOgv = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: 0
  },
  test: () => __async(null, null, function* () {
    return testVideoFormat("video/ogg");
  }),
  add: (formats) => __async(null, null, function* () {
    return [...formats, "ogv"];
  }),
  remove: (formats) => __async(null, null, function* () {
    return formats.filter((f) => f !== "ogv");
  })
};

// node_modules/pixi.js/lib/assets/detections/parsers/detectWebm.mjs
var detectWebm = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: 0
  },
  test: () => __async(null, null, function* () {
    return testVideoFormat("video/webm");
  }),
  add: (formats) => __async(null, null, function* () {
    return [...formats, "webm"];
  }),
  remove: (formats) => __async(null, null, function* () {
    return formats.filter((f) => f !== "webm");
  })
};

// node_modules/pixi.js/lib/assets/detections/parsers/detectWebp.mjs
var detectWebp = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: 0
  },
  test: () => __async(null, null, function* () {
    return testImageFormat(
      "data:image/webp;base64,UklGRh4AAABXRUJQVlA4TBEAAAAvAAAAAAfQ//73v/+BiOh/AAA="
    );
  }),
  add: (formats) => __async(null, null, function* () {
    return [...formats, "webp"];
  }),
  remove: (formats) => __async(null, null, function* () {
    return formats.filter((f) => f !== "webp");
  })
};

// node_modules/pixi.js/lib/assets/loader/Loader.mjs
var _Loader = class _Loader2 {
  constructor() {
    this.loadOptions = __spreadValues({}, _Loader2.defaultOptions);
    this._parsers = [];
    this._parsersValidated = false;
    this.parsers = new Proxy(this._parsers, {
      set: (target, key, value) => {
        this._parsersValidated = false;
        target[key] = value;
        return true;
      }
    });
    this.promiseCache = {};
  }
  /** function used for testing */
  reset() {
    this._parsersValidated = false;
    this.promiseCache = {};
  }
  /**
   * Used internally to generate a promise for the asset to be loaded.
   * @param url - The URL to be loaded
   * @param data - any custom additional information relevant to the asset being loaded
   * @returns - a promise that will resolve to an Asset for example a Texture of a JSON object
   */
  _getLoadPromiseAndParser(url, data) {
    const result = {
      promise: null,
      parser: null
    };
    result.promise = (() => __async(this, null, function* () {
      let asset = null;
      let parser = null;
      if (data.parser || data.loadParser) {
        parser = this._parserHash[data.parser || data.loadParser];
        if (data.loadParser) {
          warn(
            `[Assets] "loadParser" is deprecated, use "parser" instead for ${url}`
          );
        }
        if (!parser) {
          warn(
            `[Assets] specified load parser "${data.parser || data.loadParser}" not found while loading ${url}`
          );
        }
      }
      if (!parser) {
        for (let i = 0; i < this.parsers.length; i++) {
          const parserX = this.parsers[i];
          if (parserX.load && parserX.test?.(url, data, this)) {
            parser = parserX;
            break;
          }
        }
        if (!parser) {
          warn(`[Assets] ${url} could not be loaded as we don't know how to parse it, ensure the correct parser has been added`);
          return null;
        }
      }
      asset = yield parser.load(url, data, this);
      result.parser = parser;
      for (let i = 0; i < this.parsers.length; i++) {
        const parser2 = this.parsers[i];
        if (parser2.parse) {
          if (parser2.parse && (yield parser2.testParse?.(asset, data, this))) {
            asset = (yield parser2.parse(asset, data, this)) || asset;
            result.parser = parser2;
          }
        }
      }
      return asset;
    }))();
    return result;
  }
  load(assetsToLoadIn, onProgressOrOptions) {
    return __async(this, null, function* () {
      if (!this._parsersValidated) {
        this._validateParsers();
      }
      const options = typeof onProgressOrOptions === "function" ? __spreadProps(__spreadValues(__spreadValues({}, _Loader2.defaultOptions), this.loadOptions), { onProgress: onProgressOrOptions }) : __spreadValues(__spreadValues(__spreadValues({}, _Loader2.defaultOptions), this.loadOptions), onProgressOrOptions || {});
      const { onProgress, onError, strategy, retryCount, retryDelay } = options;
      let count = 0;
      const assets = {};
      const singleAsset = isSingleItem(assetsToLoadIn);
      const assetsToLoad = convertToList(assetsToLoadIn, (item) => ({
        alias: [item],
        src: item,
        data: {}
      }));
      const total = assetsToLoad.reduce((sum, asset) => sum + (asset.progressSize || 1), 0);
      const promises = assetsToLoad.map((asset) => __async(this, null, function* () {
        const url = path.toAbsolute(asset.src);
        if (assets[asset.src]) return;
        yield this._loadAssetWithRetry(url, asset, { onProgress, onError, strategy, retryCount, retryDelay }, assets);
        count += asset.progressSize || 1;
        if (onProgress) onProgress(count / total);
      }));
      yield Promise.all(promises);
      return singleAsset ? assets[assetsToLoad[0].src] : assets;
    });
  }
  /**
   * Unloads one or more assets. Any unloaded assets will be destroyed, freeing up memory for your app.
   * The parser that created the asset, will be the one that unloads it.
   * @example
   * // Single asset:
   * const asset = await Loader.load('cool.png');
   *
   * await Loader.unload('cool.png');
   *
   * console.log(asset.destroyed); // true
   * @param assetsToUnloadIn - urls that you want to unload, or a single one!
   */
  unload(assetsToUnloadIn) {
    return __async(this, null, function* () {
      const assetsToUnload = convertToList(assetsToUnloadIn, (item) => ({
        alias: [item],
        src: item
      }));
      const promises = assetsToUnload.map((asset) => __async(this, null, function* () {
        const url = path.toAbsolute(asset.src);
        const loadPromise = this.promiseCache[url];
        if (loadPromise) {
          const loadedAsset = yield loadPromise.promise;
          delete this.promiseCache[url];
          yield loadPromise.parser?.unload?.(loadedAsset, asset, this);
        }
      }));
      yield Promise.all(promises);
    });
  }
  /** validates our parsers, right now it only checks for name conflicts but we can add more here as required! */
  _validateParsers() {
    this._parsersValidated = true;
    this._parserHash = this._parsers.filter((parser) => parser.name || parser.id).reduce((hash, parser) => {
      if (!parser.name && !parser.id) {
        warn(`[Assets] parser should have an id`);
      } else if (hash[parser.name] || hash[parser.id]) {
        warn(`[Assets] parser id conflict "${parser.id}"`);
      }
      hash[parser.name] = parser;
      if (parser.id) hash[parser.id] = parser;
      return hash;
    }, {});
  }
  _loadAssetWithRetry(url, asset, options, assets) {
    return __async(this, null, function* () {
      let attempt = 0;
      const { onError, strategy, retryCount, retryDelay } = options;
      const wait = (ms) => new Promise((r) => setTimeout(r, ms));
      while (true) {
        try {
          if (!this.promiseCache[url]) {
            this.promiseCache[url] = this._getLoadPromiseAndParser(url, asset);
          }
          assets[asset.src] = yield this.promiseCache[url].promise;
          return;
        } catch (e) {
          delete this.promiseCache[url];
          delete assets[asset.src];
          attempt++;
          const isLast = strategy !== "retry" || attempt > retryCount;
          if (strategy === "retry" && !isLast) {
            if (onError) onError(e, asset);
            yield wait(retryDelay);
            continue;
          }
          if (strategy === "skip") {
            if (onError) onError(e, asset);
            return;
          }
          if (onError) onError(e, asset);
          const error = new Error(`[Loader.load] Failed to load ${url}.
${e}`);
          if (e instanceof Error && e.stack) {
            error.stack = e.stack;
          }
          throw error;
        }
      }
    });
  }
};
_Loader.defaultOptions = {
  onProgress: void 0,
  onError: void 0,
  strategy: "throw",
  retryCount: 3,
  retryDelay: 250
};
var Loader = _Loader;

// node_modules/pixi.js/lib/assets/utils/checkDataUrl.mjs
function checkDataUrl(url, mimes) {
  if (Array.isArray(mimes)) {
    for (const mime of mimes) {
      if (url.startsWith(`data:${mime}`)) return true;
    }
    return false;
  }
  return url.startsWith(`data:${mimes}`);
}

// node_modules/pixi.js/lib/assets/utils/checkExtension.mjs
function checkExtension(url, extension) {
  const tempURL = url.split("?")[0];
  const ext = path.extname(tempURL).toLowerCase();
  if (Array.isArray(extension)) {
    return extension.includes(ext);
  }
  return ext === extension;
}

// node_modules/pixi.js/lib/assets/loader/parsers/loadJson.mjs
var validJSONExtension = ".json";
var validJSONMIME = "application/json";
var loadJson = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.Low
  },
  /** used for deprecation purposes */
  name: "loadJson",
  id: "json",
  test(url) {
    return checkDataUrl(url, validJSONMIME) || checkExtension(url, validJSONExtension);
  },
  load(url) {
    return __async(this, null, function* () {
      const response = yield DOMAdapter.get().fetch(url);
      const json = yield response.json();
      return json;
    });
  }
};

// node_modules/pixi.js/lib/assets/loader/parsers/loadTxt.mjs
var validTXTExtension = ".txt";
var validTXTMIME = "text/plain";
var loadTxt = {
  /** used for deprecation purposes */
  name: "loadTxt",
  id: "text",
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.Low,
    name: "loadTxt"
  },
  test(url) {
    return checkDataUrl(url, validTXTMIME) || checkExtension(url, validTXTExtension);
  },
  load(url) {
    return __async(this, null, function* () {
      const response = yield DOMAdapter.get().fetch(url);
      const txt = yield response.text();
      return txt;
    });
  }
};

// node_modules/pixi.js/lib/assets/loader/parsers/loadWebFont.mjs
var validWeights = [
  "normal",
  "bold",
  "100",
  "200",
  "300",
  "400",
  "500",
  "600",
  "700",
  "800",
  "900"
];
var validFontExtensions = [".ttf", ".otf", ".woff", ".woff2"];
var validFontMIMEs = [
  "font/ttf",
  "font/otf",
  "font/woff",
  "font/woff2"
];
var CSS_IDENT_TOKEN_REGEX = /^(--|-?[A-Z_])[0-9A-Z_-]*$/i;
function getFontFamilyName(url) {
  const ext = path.extname(url);
  const name = path.basename(url, ext);
  const nameWithSpaces = name.replace(/(-|_)/g, " ");
  const nameTokens = nameWithSpaces.toLowerCase().split(" ").map((word) => word.charAt(0).toUpperCase() + word.slice(1));
  let valid = nameTokens.length > 0;
  for (const token of nameTokens) {
    if (!token.match(CSS_IDENT_TOKEN_REGEX)) {
      valid = false;
      break;
    }
  }
  let fontFamilyName = nameTokens.join(" ");
  if (!valid) {
    fontFamilyName = `"${fontFamilyName.replace(/[\\"]/g, "\\$&")}"`;
  }
  return fontFamilyName;
}
var validURICharactersRegex = /^[0-9A-Za-z%:/?#\[\]@!\$&'()\*\+,;=\-._~]*$/;
function encodeURIWhenNeeded(uri) {
  if (validURICharactersRegex.test(uri)) {
    return uri;
  }
  return encodeURI(uri);
}
var loadWebFont = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.Low
  },
  /** used for deprecation purposes */
  name: "loadWebFont",
  id: "web-font",
  test(url) {
    return checkDataUrl(url, validFontMIMEs) || checkExtension(url, validFontExtensions);
  },
  load(url, options) {
    return __async(this, null, function* () {
      const fonts = DOMAdapter.get().getFontFaceSet();
      if (fonts) {
        const fontFaces = [];
        const name = options.data?.family ?? getFontFamilyName(url);
        const weights = options.data?.weights?.filter((weight) => validWeights.includes(weight)) ?? ["normal"];
        const data = options.data ?? {};
        for (let i = 0; i < weights.length; i++) {
          const weight = weights[i];
          const font = new FontFace(name, `url('${encodeURIWhenNeeded(url)}')`, __spreadProps(__spreadValues({}, data), {
            weight
          }));
          yield font.load();
          fonts.add(font);
          fontFaces.push(font);
        }
        if (Cache.has(`${name}-and-url`)) {
          const cached = Cache.get(`${name}-and-url`);
          cached.entries.push({ url, faces: fontFaces });
        } else {
          Cache.set(`${name}-and-url`, {
            entries: [{ url, faces: fontFaces }]
          });
        }
        return fontFaces.length === 1 ? fontFaces[0] : fontFaces;
      }
      warn("[loadWebFont] FontFace API is not supported. Skipping loading font");
      return null;
    });
  },
  unload(font) {
    const fonts = Array.isArray(font) ? font : [font];
    const fontFamily = fonts[0].family;
    const cached = Cache.get(`${fontFamily}-and-url`);
    const entry = cached.entries.find((f) => f.faces.some((t) => fonts.indexOf(t) !== -1));
    entry.faces = entry.faces.filter((f) => fonts.indexOf(f) === -1);
    if (entry.faces.length === 0) {
      cached.entries = cached.entries.filter((f) => f !== entry);
    }
    fonts.forEach((t) => {
      DOMAdapter.get().getFontFaceSet().delete(t);
    });
    if (cached.entries.length === 0) {
      Cache.remove(`${fontFamily}-and-url`);
    }
  }
};

// node_modules/pixi.js/lib/utils/network/getResolutionOfUrl.mjs
function getResolutionOfUrl(url, defaultValue2 = 1) {
  const resolution = Resolver.RETINA_PREFIX?.exec(url);
  if (resolution) {
    return parseFloat(resolution[1]);
  }
  return defaultValue2;
}

// node_modules/pixi.js/lib/assets/loader/parsers/textures/utils/createTexture.mjs
function createTexture(source8, loader, url) {
  source8.label = url;
  source8._sourceOrigin = url;
  const texture = new Texture({
    source: source8,
    label: url
  });
  const unload = () => {
    delete loader.promiseCache[url];
    if (Cache.has(url)) {
      Cache.remove(url);
    }
  };
  texture.source.once("destroy", () => {
    if (loader.promiseCache[url]) {
      warn("[Assets] A TextureSource managed by Assets was destroyed instead of unloaded! Use Assets.unload() instead of destroying the TextureSource.");
      unload();
    }
  });
  texture.once("destroy", () => {
    if (!source8.destroyed) {
      warn("[Assets] A Texture managed by Assets was destroyed instead of unloaded! Use Assets.unload() instead of destroying the Texture.");
      unload();
    }
  });
  return texture;
}

// node_modules/pixi.js/lib/assets/loader/parsers/textures/loadSVG.mjs
var validSVGExtension = ".svg";
var validSVGMIME = "image/svg+xml";
var loadSvg = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.Low,
    name: "loadSVG"
  },
  /** used for deprecation purposes */
  name: "loadSVG",
  id: "svg",
  config: {
    crossOrigin: "anonymous",
    parseAsGraphicsContext: false
  },
  test(url) {
    return checkDataUrl(url, validSVGMIME) || checkExtension(url, validSVGExtension);
  },
  load(url, asset, loader) {
    return __async(this, null, function* () {
      if (asset.data?.parseAsGraphicsContext ?? this.config.parseAsGraphicsContext) {
        return loadAsGraphics(url);
      }
      return loadAsTexture(url, asset, loader, this.config.crossOrigin);
    });
  },
  unload(asset) {
    asset.destroy(true);
  }
};
function loadAsTexture(url, asset, loader, crossOrigin2) {
  return __async(this, null, function* () {
    const response = yield DOMAdapter.get().fetch(url);
    const image = DOMAdapter.get().createImage();
    image.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(yield response.text())}`;
    image.crossOrigin = crossOrigin2;
    yield image.decode();
    const width = asset.data?.width ?? image.width;
    const height = asset.data?.height ?? image.height;
    const resolution = asset.data?.resolution || getResolutionOfUrl(url);
    const canvasWidth = Math.ceil(width * resolution);
    const canvasHeight = Math.ceil(height * resolution);
    const canvas = DOMAdapter.get().createCanvas(canvasWidth, canvasHeight);
    const context = canvas.getContext("2d");
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    context.drawImage(image, 0, 0, width * resolution, height * resolution);
    const _a = asset.data ?? {}, { parseAsGraphicsContext: _p } = _a, rest = __objRest(_a, ["parseAsGraphicsContext"]);
    const base = new ImageSource(__spreadValues({
      resource: canvas,
      alphaMode: "premultiply-alpha-on-upload",
      resolution
    }, rest));
    return createTexture(base, loader, url);
  });
}
function loadAsGraphics(url) {
  return __async(this, null, function* () {
    const response = yield DOMAdapter.get().fetch(url);
    const svgSource = yield response.text();
    const context = new GraphicsContext();
    context.svg(svgSource);
    return context;
  });
}

// node_modules/pixi.js/lib/_virtual/checkImageBitmap.worker.mjs
var WORKER_CODE = `(function () {
    'use strict';

    const WHITE_PNG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=";
    async function checkImageBitmap() {
      try {
        if (typeof createImageBitmap !== "function") return false;
        const response = await fetch(WHITE_PNG);
        const imageBlob = await response.blob();
        const imageBitmap = await createImageBitmap(imageBlob);
        return imageBitmap.width === 1 && imageBitmap.height === 1;
      } catch (_e) {
        return false;
      }
    }
    void checkImageBitmap().then((result) => {
      self.postMessage(result);
    });

})();
`;
var WORKER_URL = null;
var WorkerInstance = class {
  constructor() {
    if (!WORKER_URL) {
      WORKER_URL = URL.createObjectURL(new Blob([WORKER_CODE], { type: "application/javascript" }));
    }
    this.worker = new Worker(WORKER_URL);
  }
};
WorkerInstance.revokeObjectURL = function revokeObjectURL() {
  if (WORKER_URL) {
    URL.revokeObjectURL(WORKER_URL);
    WORKER_URL = null;
  }
};

// node_modules/pixi.js/lib/_virtual/loadImageBitmap.worker.mjs
var WORKER_CODE2 = '(function () {\n    \'use strict\';\n\n    async function loadImageBitmap(url, alphaMode) {\n      const response = await fetch(url);\n      if (!response.ok) {\n        throw new Error(`[WorkerManager.loadImageBitmap] Failed to fetch ${url}: ${response.status} ${response.statusText}`);\n      }\n      const imageBlob = await response.blob();\n      return alphaMode === "premultiplied-alpha" ? createImageBitmap(imageBlob, { premultiplyAlpha: "none" }) : createImageBitmap(imageBlob);\n    }\n    self.onmessage = async (event) => {\n      try {\n        const imageBitmap = await loadImageBitmap(event.data.data[0], event.data.data[1]);\n        self.postMessage({\n          data: imageBitmap,\n          uuid: event.data.uuid,\n          id: event.data.id\n        }, [imageBitmap]);\n      } catch (e) {\n        self.postMessage({\n          error: e,\n          uuid: event.data.uuid,\n          id: event.data.id\n        });\n      }\n    };\n\n})();\n';
var WORKER_URL2 = null;
var WorkerInstance2 = class {
  constructor() {
    if (!WORKER_URL2) {
      WORKER_URL2 = URL.createObjectURL(new Blob([WORKER_CODE2], { type: "application/javascript" }));
    }
    this.worker = new Worker(WORKER_URL2);
  }
};
WorkerInstance2.revokeObjectURL = function revokeObjectURL2() {
  if (WORKER_URL2) {
    URL.revokeObjectURL(WORKER_URL2);
    WORKER_URL2 = null;
  }
};

// node_modules/pixi.js/lib/assets/loader/workers/WorkerManager.mjs
var UUID = 0;
var MAX_WORKERS;
var WorkerManagerClass = class {
  constructor() {
    this._initialized = false;
    this._createdWorkers = 0;
    this._workerPool = [];
    this._queue = [];
    this._resolveHash = {};
  }
  /**
   * Checks if ImageBitmap is supported in the current environment.
   *
   * This method uses a dedicated worker to test ImageBitmap support
   * and caches the result for subsequent calls.
   * @returns Promise that resolves to true if ImageBitmap is supported, false otherwise
   */
  isImageBitmapSupported() {
    if (this._isImageBitmapSupported !== void 0) return this._isImageBitmapSupported;
    this._isImageBitmapSupported = new Promise((resolve) => {
      const { worker } = new WorkerInstance();
      worker.addEventListener("message", (event) => {
        worker.terminate();
        WorkerInstance.revokeObjectURL();
        resolve(event.data);
      });
    });
    return this._isImageBitmapSupported;
  }
  /**
   * Loads an image as an ImageBitmap using a web worker.
   * @param src - The source URL or path of the image to load
   * @param asset - Optional resolved asset containing additional texture source options
   * @returns Promise that resolves to the loaded ImageBitmap
   * @example
   * ```typescript
   * const bitmap = await WorkerManager.loadImageBitmap('image.png');
   * const bitmapWithOptions = await WorkerManager.loadImageBitmap('image.png', asset);
   * ```
   */
  loadImageBitmap(src, asset) {
    return this._run("loadImageBitmap", [src, asset?.data?.alphaMode]);
  }
  /**
   * Initializes the worker pool if not already initialized.
   * Currently a no-op but reserved for future initialization logic.
   */
  _initWorkers() {
    return __async(this, null, function* () {
      if (this._initialized) return;
      this._initialized = true;
    });
  }
  /**
   * Gets an available worker from the pool or creates a new one if needed.
   *
   * Workers are created up to the MAX_WORKERS limit (based on navigator.hardwareConcurrency).
   * Each worker is configured with a message handler for processing results.
   * @returns Available worker or undefined if pool is at capacity and no workers are free
   */
  _getWorker() {
    if (MAX_WORKERS === void 0) {
      MAX_WORKERS = navigator.hardwareConcurrency || 4;
    }
    let worker = this._workerPool.pop();
    if (!worker && this._createdWorkers < MAX_WORKERS) {
      this._createdWorkers++;
      worker = new WorkerInstance2().worker;
      worker.addEventListener("message", (event) => {
        this._complete(event.data);
        this._returnWorker(event.target);
        this._next();
      });
    }
    return worker;
  }
  /**
   * Returns a worker to the pool after completing a task.
   * @param worker - The worker to return to the pool
   */
  _returnWorker(worker) {
    this._workerPool.push(worker);
  }
  /**
   * Handles completion of a worker task by resolving or rejecting the corresponding promise.
   * @param data - Result data from the worker containing uuid, data, and optional error
   */
  _complete(data) {
    if (!this._resolveHash[data.uuid]) {
      return;
    }
    if (data.error !== void 0) {
      this._resolveHash[data.uuid].reject(data.error);
    } else {
      this._resolveHash[data.uuid].resolve(data.data);
    }
    delete this._resolveHash[data.uuid];
  }
  /**
   * Executes a task using the worker pool system.
   *
   * Queues the task and processes it when a worker becomes available.
   * @param id - Identifier for the type of task to run
   * @param args - Arguments to pass to the worker
   * @returns Promise that resolves with the worker's result
   */
  _run(id, args) {
    return __async(this, null, function* () {
      yield this._initWorkers();
      const promise = new Promise((resolve, reject) => {
        this._queue.push({ id, arguments: args, resolve, reject });
      });
      this._next();
      return promise;
    });
  }
  /**
   * Processes the next item in the queue if workers are available.
   *
   * This method is called after worker initialization and when workers
   * complete tasks to continue processing the queue.
   */
  _next() {
    if (!this._queue.length) return;
    const worker = this._getWorker();
    if (!worker) {
      return;
    }
    const toDo = this._queue.pop();
    const id = toDo.id;
    this._resolveHash[UUID] = { resolve: toDo.resolve, reject: toDo.reject };
    worker.postMessage({
      data: toDo.arguments,
      uuid: UUID++,
      id
    });
  }
  /**
   * Resets the worker manager, terminating all workers and clearing the queue.
   *
   * This method:
   * - Terminates all active workers
   * - Rejects all pending promises with an error
   * - Clears all internal state
   * - Resets initialization flags
   *
   * This should be called when the worker manager is no longer needed
   * to prevent memory leaks and ensure proper cleanup.
   * @example
   * ```typescript
   * // Clean up when shutting down
   * WorkerManager.reset();
   * ```
   */
  reset() {
    this._workerPool.forEach((worker) => worker.terminate());
    this._workerPool.length = 0;
    Object.values(this._resolveHash).forEach(({ reject }) => {
      reject?.(new Error("WorkerManager has been reset before completion"));
    });
    this._resolveHash = {};
    this._queue.length = 0;
    this._initialized = false;
    this._createdWorkers = 0;
  }
};
var WorkerManager = new WorkerManagerClass();

// node_modules/pixi.js/lib/assets/loader/parsers/textures/loadTextures.mjs
var validImageExtensions = [".jpeg", ".jpg", ".png", ".webp", ".avif"];
var validImageMIMEs = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/avif"
];
function loadImageBitmap(url, asset) {
  return __async(this, null, function* () {
    const response = yield DOMAdapter.get().fetch(url);
    if (!response.ok) {
      throw new Error(`[loadImageBitmap] Failed to fetch ${url}: ${response.status} ${response.statusText}`);
    }
    const imageBlob = yield response.blob();
    return asset?.data?.alphaMode === "premultiplied-alpha" ? createImageBitmap(imageBlob, { premultiplyAlpha: "none" }) : createImageBitmap(imageBlob);
  });
}
var loadTextures = {
  /** used for deprecation purposes */
  name: "loadTextures",
  id: "texture",
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.High,
    name: "loadTextures"
  },
  config: {
    preferWorkers: true,
    preferCreateImageBitmap: true,
    crossOrigin: "anonymous"
  },
  test(url) {
    return checkDataUrl(url, validImageMIMEs) || checkExtension(url, validImageExtensions);
  },
  load(url, asset, loader) {
    return __async(this, null, function* () {
      let src = null;
      if (globalThis.createImageBitmap && this.config.preferCreateImageBitmap) {
        if (this.config.preferWorkers && (yield WorkerManager.isImageBitmapSupported())) {
          src = yield WorkerManager.loadImageBitmap(url, asset);
        } else {
          src = yield loadImageBitmap(url, asset);
        }
      } else {
        src = yield new Promise((resolve, reject) => {
          src = DOMAdapter.get().createImage();
          src.crossOrigin = this.config.crossOrigin;
          src.src = url;
          if (src.complete) {
            resolve(src);
          } else {
            src.onload = () => {
              resolve(src);
            };
            src.onerror = reject;
          }
        });
      }
      const base = new ImageSource(__spreadValues({
        resource: src,
        alphaMode: "premultiply-alpha-on-upload",
        resolution: asset.data?.resolution || getResolutionOfUrl(url)
      }, asset.data));
      return createTexture(base, loader, url);
    });
  },
  unload(texture) {
    texture.destroy(true);
  }
};

// node_modules/pixi.js/lib/assets/loader/parsers/textures/loadVideoTextures.mjs
var potentialVideoExtensions = [".mp4", ".m4v", ".webm", ".ogg", ".ogv", ".h264", ".avi", ".mov"];
var validVideoExtensions;
var validVideoMIMEs;
function crossOrigin(element, url, crossorigin) {
  if (crossorigin === void 0 && !url.startsWith("data:")) {
    element.crossOrigin = determineCrossOrigin(url);
  } else if (crossorigin !== false) {
    element.crossOrigin = typeof crossorigin === "string" ? crossorigin : "anonymous";
  }
}
function preloadVideo(element) {
  return new Promise((resolve, reject) => {
    element.addEventListener("canplaythrough", loaded);
    element.addEventListener("error", error);
    element.load();
    function loaded() {
      cleanup();
      resolve();
    }
    function error(err) {
      cleanup();
      reject(err);
    }
    function cleanup() {
      element.removeEventListener("canplaythrough", loaded);
      element.removeEventListener("error", error);
    }
  });
}
function determineCrossOrigin(url, loc = globalThis.location) {
  if (url.startsWith("data:")) {
    return "";
  }
  loc || (loc = globalThis.location);
  const parsedUrl = new URL(url, document.baseURI);
  if (parsedUrl.hostname !== loc.hostname || parsedUrl.port !== loc.port || parsedUrl.protocol !== loc.protocol) {
    return "anonymous";
  }
  return "";
}
function getBrowserSupportedVideoExtensions() {
  const supportedExtensions = [];
  const supportedMimes = [];
  for (const ext of potentialVideoExtensions) {
    const mimeType = VideoSource.MIME_TYPES[ext.substring(1)] || `video/${ext.substring(1)}`;
    if (testVideoFormat(mimeType)) {
      supportedExtensions.push(ext);
      if (!supportedMimes.includes(mimeType)) {
        supportedMimes.push(mimeType);
      }
    }
  }
  return {
    validVideoExtensions: supportedExtensions,
    validVideoMime: supportedMimes
  };
}
var loadVideoTextures = {
  /** used for deprecation purposes */
  name: "loadVideo",
  id: "video",
  extension: {
    type: ExtensionType.LoadParser,
    name: "loadVideo"
  },
  test(url) {
    if (!validVideoExtensions || !validVideoMIMEs) {
      const { validVideoExtensions: ve, validVideoMime: vm } = getBrowserSupportedVideoExtensions();
      validVideoExtensions = ve;
      validVideoMIMEs = vm;
    }
    const isValidDataUrl = checkDataUrl(url, validVideoMIMEs);
    const isValidExtension = checkExtension(url, validVideoExtensions);
    return isValidDataUrl || isValidExtension;
  },
  load(url, asset, loader) {
    return __async(this, null, function* () {
      const options = __spreadValues(__spreadProps(__spreadValues({}, VideoSource.defaultOptions), {
        resolution: asset.data?.resolution || getResolutionOfUrl(url),
        alphaMode: asset.data?.alphaMode || (yield detectVideoAlphaMode())
      }), asset.data);
      const videoElement = document.createElement("video");
      const attributeMap = {
        preload: options.autoLoad !== false ? "auto" : void 0,
        "webkit-playsinline": options.playsinline !== false ? "" : void 0,
        playsinline: options.playsinline !== false ? "" : void 0,
        muted: options.muted === true ? "" : void 0,
        loop: options.loop === true ? "" : void 0,
        autoplay: options.autoPlay !== false ? "" : void 0
      };
      Object.keys(attributeMap).forEach((key) => {
        const value = attributeMap[key];
        if (value !== void 0) videoElement.setAttribute(key, value);
      });
      if (options.muted === true) {
        videoElement.muted = true;
      }
      crossOrigin(videoElement, url, options.crossorigin);
      const sourceElement = document.createElement("source");
      let mime;
      if (options.mime) {
        mime = options.mime;
      } else if (url.startsWith("data:")) {
        mime = url.slice(5, url.indexOf(";"));
      } else if (!url.startsWith("blob:")) {
        const ext = url.split("?")[0].slice(url.lastIndexOf(".") + 1).toLowerCase();
        mime = VideoSource.MIME_TYPES[ext] || `video/${ext}`;
      }
      sourceElement.src = url;
      if (mime) {
        sourceElement.type = mime;
      }
      return new Promise((resolve, reject) => {
        if (options.preload && !options.autoPlay) {
          videoElement.load();
        }
        videoElement.addEventListener("canplay", onCanPlay);
        videoElement.addEventListener("error", onError);
        sourceElement.addEventListener("error", onError);
        videoElement.appendChild(sourceElement);
        function onCanPlay() {
          return __async(this, null, function* () {
            const base = new VideoSource(__spreadProps(__spreadValues({}, options), { resource: videoElement }));
            cleanup();
            if (asset.data.preload) {
              yield preloadVideo(videoElement);
            }
            resolve(createTexture(base, loader, url));
          });
        }
        function onError(event) {
          cleanup();
          reject(event);
        }
        function cleanup() {
          videoElement.removeEventListener("canplay", onCanPlay);
          videoElement.removeEventListener("error", onError);
          sourceElement.removeEventListener("error", onError);
        }
      });
    });
  },
  unload(texture) {
    texture.destroy(true);
  }
};

// node_modules/pixi.js/lib/assets/resolver/parsers/resolveTextureUrl.mjs
var resolveTextureUrl = {
  extension: {
    type: ExtensionType.ResolveParser,
    name: "resolveTexture"
  },
  test: loadTextures.test,
  parse: (value) => ({
    resolution: parseFloat(Resolver.RETINA_PREFIX.exec(value)?.[1] ?? "1"),
    format: value.split(".").pop(),
    src: value
  })
};

// node_modules/pixi.js/lib/assets/resolver/parsers/resolveJsonUrl.mjs
var resolveJsonUrl = {
  extension: {
    type: ExtensionType.ResolveParser,
    priority: -2,
    name: "resolveJson"
  },
  test: (value) => Resolver.RETINA_PREFIX.test(value) && value.endsWith(".json"),
  parse: resolveTextureUrl.parse
};

// node_modules/pixi.js/lib/assets/Assets.mjs
var AssetsClass = class {
  constructor() {
    this._detections = [];
    this._initialized = false;
    this.resolver = new Resolver();
    this.loader = new Loader();
    this.cache = Cache;
    this._backgroundLoader = new BackgroundLoader(this.loader);
    this._backgroundLoader.active = true;
    this.reset();
  }
  /**
   * Initializes the Assets class with configuration options. While not required,
   * calling this before loading assets is recommended to set up default behaviors.
   * @param options - Configuration options for the Assets system
   * @example
   * ```ts
   * // Basic initialization (optional as Assets.load will call this automatically)
   * await Assets.init();
   *
   * // With CDN configuration
   * await Assets.init({
   *     basePath: 'https://my-cdn.com/assets/',
   *     defaultSearchParams: { version: '1.0.0' }
   * });
   *
   * // With manifest and preferences
   * await Assets.init({
   *     manifest: {
   *         bundles: [{
   *             name: 'game-screen',
   *             assets: [
   *                 {
   *                     alias: 'hero',
   *                     src: 'hero.{png,webp}',
   *                     data: { scaleMode: 'nearest' }
   *                 },
   *                 {
   *                     alias: 'map',
   *                     src: 'map.json'
   *                 }
   *             ]
   *         }]
   *     },
   *     // Optimize for device capabilities
   *     texturePreference: {
   *         resolution: window.devicePixelRatio,
   *         format: ['webp', 'png']
   *     },
   *     // Set global preferences
   *     preferences: {
   *         crossOrigin: 'anonymous',
   *     }
   * });
   *
   * // Load assets after initialization
   * const heroTexture = await Assets.load('hero');
   * ```
   * @remarks
   * - Can be called only once; subsequent calls will be ignored with a warning
   * - Format detection runs automatically unless `skipDetections` is true
   * - The manifest can be a URL to a JSON file or an inline object
   * @see {@link AssetInitOptions} For all available initialization options
   * @see {@link AssetsManifest} For manifest format details
   */
  init() {
    return __async(this, arguments, function* (options = {}) {
      if (this._initialized) {
        warn("[Assets]AssetManager already initialized, did you load before calling this Assets.init()?");
        return;
      }
      this._initialized = true;
      if (options.defaultSearchParams) {
        this.resolver.setDefaultSearchParams(options.defaultSearchParams);
      }
      if (options.basePath) {
        this.resolver.basePath = options.basePath;
      }
      if (options.bundleIdentifier) {
        this.resolver.setBundleIdentifier(options.bundleIdentifier);
      }
      if (options.manifest) {
        let manifest = options.manifest;
        if (typeof manifest === "string") {
          manifest = yield this.load(manifest);
        }
        this.resolver.addManifest(manifest);
      }
      const resolutionPref = options.texturePreference?.resolution ?? 1;
      const resolution = typeof resolutionPref === "number" ? [resolutionPref] : resolutionPref;
      const formats = yield this._detectFormats({
        preferredFormats: options.texturePreference?.format,
        skipDetections: options.skipDetections,
        detections: this._detections
      });
      this.resolver.prefer({
        params: {
          format: formats,
          resolution
        }
      });
      if (options.preferences) {
        this.setPreferences(options.preferences);
      }
      if (options.loadOptions) {
        this.loader.loadOptions = __spreadValues(__spreadValues({}, this.loader.loadOptions), options.loadOptions);
      }
    });
  }
  /**
   * Registers assets with the Assets resolver. This method maps keys (aliases) to asset sources,
   * allowing you to load assets using friendly names instead of direct URLs.
   * @param assets - The unresolved assets to add to the resolver
   * @example
   * ```ts
   * // Basic usage - single asset
   * Assets.add({
   *     alias: 'myTexture',
   *     src: 'assets/texture.png'
   * });
   * const texture = await Assets.load('myTexture');
   *
   * // Multiple aliases for the same asset
   * Assets.add({
   *     alias: ['hero', 'player'],
   *     src: 'hero.png'
   * });
   * const hero1 = await Assets.load('hero');
   * const hero2 = await Assets.load('player'); // Same texture
   *
   * // Multiple format support
   * Assets.add({
   *     alias: 'character',
   *     src: 'character.{webp,png}' // Will choose best format
   * });
   * Assets.add({
   *     alias: 'character',
   *     src: ['character.webp', 'character.png'], // Explicitly specify formats
   * });
   *
   * // With texture options
   * Assets.add({
   *     alias: 'sprite',
   *     src: 'sprite.png',
   *     data: { scaleMode: 'nearest' }
   * });
   *
   * // Multiple assets at once
   * Assets.add([
   *     { alias: 'bg', src: 'background.png' },
   *     { alias: 'music', src: 'music.mp3' },
   *     { alias: 'spritesheet', src: 'sheet.json', data: { ignoreMultiPack: false } }
   * ]);
   * ```
   * @remarks
   * - Assets are resolved when loaded, not when added
   * - Multiple formats use the best available format for the browser
   * - Adding with same alias overwrites previous definition
   * - The `data` property is passed to the asset loader
   * @see {@link Resolver} For details on asset resolution
   * @see {@link LoaderParser} For asset-specific data options
   * @advanced
   */
  add(assets) {
    this.resolver.add(assets);
  }
  load(urls, onProgress) {
    return __async(this, null, function* () {
      if (!this._initialized) {
        yield this.init();
      }
      const singleAsset = isSingleItem(urls);
      const urlArray = convertToList(urls).map((url) => {
        if (typeof url !== "string") {
          const aliases = this.resolver.getAlias(url);
          if (aliases.some((alias) => !this.resolver.hasKey(alias))) {
            this.add(url);
          }
          return Array.isArray(aliases) ? aliases[0] : aliases;
        }
        if (!this.resolver.hasKey(url)) this.add({ alias: url, src: url });
        return url;
      });
      const resolveResults = this.resolver.resolve(urlArray);
      const out = yield this._mapLoadToResolve(resolveResults, onProgress);
      return singleAsset ? out[urlArray[0]] : out;
    });
  }
  /**
   * Registers a bundle of assets that can be loaded as a group. Bundles are useful for organizing
   * assets into logical groups, such as game levels or UI screens.
   * @param bundleId - Unique identifier for the bundle
   * @param assets - Assets to include in the bundle
   * @example
   * ```ts
   * // Add a bundle using array format
   * Assets.addBundle('animals', [
   *     { alias: 'bunny', src: 'bunny.png' },
   *     { alias: 'chicken', src: 'chicken.png' },
   *     { alias: 'thumper', src: 'thumper.png' },
   * ]);
   *
   * // Add a bundle using object format
   * Assets.addBundle('animals', {
   *     bunny: 'bunny.png',
   *     chicken: 'chicken.png',
   *     thumper: 'thumper.png',
   * });
   *
   * // Add a bundle with advanced options
   * Assets.addBundle('ui', [
   *     {
   *         alias: 'button',
   *         src: 'button.{webp,png}',
   *         data: { scaleMode: 'nearest' }
   *     },
   *     {
   *         alias: ['logo', 'brand'],  // Multiple aliases
   *         src: 'logo.svg',
   *         data: { resolution: 2 }
   *     }
   * ]);
   *
   * // Load the bundle
   * await Assets.loadBundle('animals');
   *
   * // Use the loaded assets
   * const bunny = Sprite.from('bunny');
   * const chicken = Sprite.from('chicken');
   * ```
   * @remarks
   * - Bundle IDs must be unique
   * - Assets in bundles are not loaded until `loadBundle` is called
   * - Bundles can be background loaded using `backgroundLoadBundle`
   * - Assets in bundles can be loaded individually using their aliases
   * @see {@link Assets.loadBundle} For loading bundles
   * @see {@link Assets.backgroundLoadBundle} For background loading bundles
   * @see {@link Assets.unloadBundle} For unloading bundles
   * @see {@link AssetsManifest} For manifest format details
   */
  addBundle(bundleId, assets) {
    this.resolver.addBundle(bundleId, assets);
  }
  /**
   * Loads a bundle or multiple bundles of assets. Bundles are collections of related assets
   * that can be loaded together.
   * @param bundleIds - Single bundle ID or array of bundle IDs to load
   * @param onProgress - Optional callback for load progress (0.0 to 1.0)
   * @returns Promise that resolves with the loaded bundle assets
   * @example
   * ```ts
   * // Define bundles in your manifest
   * const manifest = {
   *     bundles: [
   *         {
   *             name: 'load-screen',
   *             assets: [
   *                 {
   *                     alias: 'background',
   *                     src: 'sunset.png',
   *                 },
   *                 {
   *                     alias: 'bar',
   *                     src: 'load-bar.{png,webp}', // use an array of individual assets
   *                 },
   *             ],
   *         },
   *         {
   *             name: 'game-screen',
   *             assets: [
   *                 {
   *                     alias: 'character',
   *                     src: 'robot.png',
   *                 },
   *                 {
   *                     alias: 'enemy',
   *                     src: 'bad-guy.png',
   *                 },
   *             ],
   *         },
   *     ]
   * };
   *
   * // Initialize with manifest
   * await Assets.init({ manifest });
   *
   * // Or add bundles programmatically
   * Assets.addBundle('load-screen', [...]);
   * Assets.loadBundle('load-screen');
   *
   * // Load a single bundle
   * await Assets.loadBundle('load-screen');
   * const bg = Sprite.from('background'); // Uses alias from bundle
   *
   * // Load multiple bundles
   * await Assets.loadBundle([
   *     'load-screen',
   *     'game-screen'
   * ]);
   *
   * // Load with progress tracking
   * await Assets.loadBundle('game-screen', (progress) => {
   *     console.log(`Loading: ${Math.round(progress * 100)}%`);
   * });
   * ```
   * @remarks
   * - Bundle assets are cached automatically
   * - Bundles can be pre-loaded using `backgroundLoadBundle`
   * - Assets in bundles can be accessed by their aliases
   * - Progress callback receives values from 0.0 to 1.0
   * @throws {Error} If the bundle ID doesn't exist in the manifest
   * @see {@link Assets.addBundle} For adding bundles programmatically
   * @see {@link Assets.backgroundLoadBundle} For background loading bundles
   * @see {@link Assets.unloadBundle} For unloading bundles
   * @see {@link AssetsManifest} For manifest format details
   */
  loadBundle(bundleIds, onProgress) {
    return __async(this, null, function* () {
      if (!this._initialized) {
        yield this.init();
      }
      let singleAsset = false;
      if (typeof bundleIds === "string") {
        singleAsset = true;
        bundleIds = [bundleIds];
      }
      const resolveResults = this.resolver.resolveBundle(bundleIds);
      const out = {};
      const keys = Object.keys(resolveResults);
      let total = 0;
      const counts = [];
      const _onProgress = () => {
        onProgress?.(counts.reduce((a, b) => a + b, 0) / total);
      };
      const promises = keys.map((bundleId, i) => {
        const resolveResult = resolveResults[bundleId];
        const values = Object.values(resolveResult);
        const totalAssetsToLoad = [...new Set(values.flat())];
        const progressSize = totalAssetsToLoad.reduce((sum, asset) => sum + (asset.progressSize || 1), 0);
        counts.push(0);
        total += progressSize;
        return this._mapLoadToResolve(resolveResult, (e) => {
          counts[i] = e * progressSize;
          _onProgress();
        }).then((resolveResult2) => {
          out[bundleId] = resolveResult2;
        });
      });
      yield Promise.all(promises);
      return singleAsset ? out[bundleIds[0]] : out;
    });
  }
  /**
   * Initiates background loading of assets. This allows assets to be loaded passively while other operations
   * continue, making them instantly available when needed later.
   *
   * Background loading is useful for:
   * - Preloading game levels while in a menu
   * - Loading non-critical assets during gameplay
   * - Reducing visible loading screens
   * @param urls - Single URL/alias or array of URLs/aliases to load in the background
   * @example
   * ```ts
   * // Basic background loading
   * Assets.backgroundLoad('images/level2-assets.png');
   *
   * // Background load multiple assets
   * Assets.backgroundLoad([
   *     'images/sprite1.png',
   *     'images/sprite2.png',
   *     'images/background.png'
   * ]);
   *
   * // Later, when you need the assets
   * const textures = await Assets.load([
   *     'images/sprite1.png',
   *     'images/sprite2.png'
   * ]); // Resolves immediately if background loading completed
   * ```
   * @remarks
   * - Background loading happens one asset at a time to avoid blocking the main thread
   * - Loading can be interrupted safely by calling `Assets.load()`
   * - Assets are cached as they complete loading
   * - No progress tracking is available for background loading
   */
  backgroundLoad(urls) {
    return __async(this, null, function* () {
      if (!this._initialized) {
        yield this.init();
      }
      if (typeof urls === "string") {
        urls = [urls];
      }
      const resolveResults = this.resolver.resolve(urls);
      this._backgroundLoader.add(Object.values(resolveResults));
    });
  }
  /**
   * Initiates background loading of asset bundles. Similar to backgroundLoad but works with
   * predefined bundles of assets.
   *
   * Perfect for:
   * - Preloading level bundles during gameplay
   * - Loading UI assets during splash screens
   * - Preparing assets for upcoming game states
   * @param bundleIds - Single bundle ID or array of bundle IDs to load in the background
   * @example
   * ```ts
   * // Define bundles in your manifest
   * await Assets.init({
   *     manifest: {
   *         bundles: [
   *             {
   *               name: 'home',
   *               assets: [
   *                 {
   *                     alias: 'background',
   *                     src: 'images/home-bg.png',
   *                 },
   *                 {
   *                     alias: 'logo',
   *                     src: 'images/logo.png',
   *                 }
   *              ]
   *            },
   *            {
   *             name: 'level-1',
   *             assets: [
   *                 {
   *                     alias: 'background',
   *                     src: 'images/level1/bg.png',
   *                 },
   *                 {
   *                     alias: 'sprites',
   *                     src: 'images/level1/sprites.json'
   *                 }
   *             ]
   *         }]
   *     }
   * });
   *
   * // Load the home screen assets right away
   * await Assets.loadBundle('home');
   * showHomeScreen();
   *
   * // Start background loading while showing home screen
   * Assets.backgroundLoadBundle('level-1');
   *
   * // When player starts level, load completes faster
   * await Assets.loadBundle('level-1');
   * hideHomeScreen();
   * startLevel();
   * ```
   * @remarks
   * - Bundle assets are loaded one at a time
   * - Loading can be interrupted safely by calling `Assets.loadBundle()`
   * - Assets are cached as they complete loading
   * - Requires bundles to be registered via manifest or `addBundle`
   * @see {@link Assets.addBundle} For adding bundles programmatically
   * @see {@link Assets.loadBundle} For immediate bundle loading
   * @see {@link AssetsManifest} For manifest format details
   */
  backgroundLoadBundle(bundleIds) {
    return __async(this, null, function* () {
      if (!this._initialized) {
        yield this.init();
      }
      if (typeof bundleIds === "string") {
        bundleIds = [bundleIds];
      }
      const resolveResults = this.resolver.resolveBundle(bundleIds);
      Object.values(resolveResults).forEach((resolveResult) => {
        this._backgroundLoader.add(Object.values(resolveResult));
      });
    });
  }
  /**
   * Only intended for development purposes.
   * This will wipe the resolver and caches.
   * You will need to reinitialize the Asset
   * @internal
   */
  reset() {
    this.resolver.reset();
    this.loader.reset();
    this.cache.reset();
    this._initialized = false;
  }
  get(keys) {
    if (typeof keys === "string") {
      return Cache.get(keys);
    }
    const assets = {};
    for (let i = 0; i < keys.length; i++) {
      assets[i] = Cache.get(keys[i]);
    }
    return assets;
  }
  /**
   * helper function to map resolved assets back to loaded assets
   * @param resolveResults - the resolve results from the resolver
   * @param progressOrLoadOptions - the progress callback or load options
   */
  _mapLoadToResolve(resolveResults, progressOrLoadOptions) {
    return __async(this, null, function* () {
      const resolveArray = [...new Set(Object.values(resolveResults))];
      this._backgroundLoader.active = false;
      const loadedAssets = yield this.loader.load(resolveArray, progressOrLoadOptions);
      this._backgroundLoader.active = true;
      const out = {};
      resolveArray.forEach((resolveResult) => {
        const asset = loadedAssets[resolveResult.src];
        const keys = [resolveResult.src];
        if (resolveResult.alias) {
          keys.push(...resolveResult.alias);
        }
        keys.forEach((key) => {
          out[key] = asset;
        });
        Cache.set(keys, asset);
      });
      return out;
    });
  }
  /**
   * Unloads assets and releases them from memory. This method ensures proper cleanup of
   * loaded assets when they're no longer needed.
   * @param urls - Single URL/alias or array of URLs/aliases to unload
   * @example
   * ```ts
   * // Unload a single asset
   * await Assets.unload('images/sprite.png');
   *
   * // Unload using an alias
   * await Assets.unload('hero'); // Unloads the asset registered with 'hero' alias
   *
   * // Unload multiple assets
   * await Assets.unload([
   *     'images/background.png',
   *     'images/character.png',
   *     'hero'
   * ]);
   *
   * // Unload and handle creation of new instances
   * await Assets.unload('hero');
   * const newHero = await Assets.load('hero'); // Will load fresh from source
   * ```
   * @remarks
   * > [!WARNING]
   * > Make sure assets aren't being used before unloading:
   * > - Remove sprites using the texture
   * > - Clear any references to the asset
   * > - Textures will be destroyed and can't be used after unloading
   * @throws {Error} If the asset is not found in cache
   */
  unload(urls) {
    return __async(this, null, function* () {
      if (!this._initialized) {
        yield this.init();
      }
      const urlArray = convertToList(urls).map((url) => typeof url !== "string" ? url.src : url);
      const resolveResults = this.resolver.resolve(urlArray);
      yield this._unloadFromResolved(resolveResults);
    });
  }
  /**
   * Unloads all assets in a bundle. Use this to free memory when a bundle's assets
   * are no longer needed, such as when switching game levels.
   * @param bundleIds - Single bundle ID or array of bundle IDs to unload
   * @example
   * ```ts
   * // Define and load a bundle
   * Assets.addBundle('level-1', {
   *     background: 'level1/bg.png',
   *     sprites: 'level1/sprites.json',
   *     music: 'level1/music.mp3'
   * });
   *
   * // Load the bundle
   * const level1 = await Assets.loadBundle('level-1');
   *
   * // Use the assets
   * const background = Sprite.from(level1.background);
   *
   * // When done with the level, unload everything
   * await Assets.unloadBundle('level-1');
   * // background sprite is now invalid!
   *
   * // Unload multiple bundles
   * await Assets.unloadBundle([
   *     'level-1',
   *     'level-2',
   *     'ui-elements'
   * ]);
   * ```
   * @remarks
   * > [!WARNING]
   * > - All assets in the bundle will be destroyed
   * > - Bundle needs to be reloaded to use assets again
   * > - Make sure no sprites or other objects are using the assets
   * @throws {Error} If the bundle is not found
   * @see {@link Assets.addBundle} For adding bundles
   * @see {@link Assets.loadBundle} For loading bundles
   */
  unloadBundle(bundleIds) {
    return __async(this, null, function* () {
      if (!this._initialized) {
        yield this.init();
      }
      bundleIds = convertToList(bundleIds);
      const resolveResults = this.resolver.resolveBundle(bundleIds);
      const promises = Object.keys(resolveResults).map((bundleId) => this._unloadFromResolved(resolveResults[bundleId]));
      yield Promise.all(promises);
    });
  }
  _unloadFromResolved(resolveResult) {
    return __async(this, null, function* () {
      const resolveArray = Object.values(resolveResult);
      resolveArray.forEach((resolveResult2) => {
        Cache.remove(resolveResult2.src);
      });
      yield this.loader.unload(resolveArray);
    });
  }
  /**
   * Detects the supported formats for the browser, and returns an array of supported formats, respecting
   * the users preferred formats order.
   * @param options - the options to use when detecting formats
   * @param options.preferredFormats - the preferred formats to use
   * @param options.skipDetections - if we should skip the detections altogether
   * @param options.detections - the detections to use
   * @returns - the detected formats
   */
  _detectFormats(options) {
    return __async(this, null, function* () {
      let formats = [];
      if (options.preferredFormats) {
        formats = Array.isArray(options.preferredFormats) ? options.preferredFormats : [options.preferredFormats];
      }
      for (const detection of options.detections) {
        if (options.skipDetections || (yield detection.test())) {
          formats = yield detection.add(formats);
        } else if (!options.skipDetections) {
          formats = yield detection.remove(formats);
        }
      }
      formats = formats.filter((format, index) => formats.indexOf(format) === index);
      return formats;
    });
  }
  /**
   * All the detection parsers currently added to the Assets class.
   * @advanced
   */
  get detections() {
    return this._detections;
  }
  /**
   * Sets global preferences for asset loading behavior. This method configures how assets
   * are loaded and processed across all parsers.
   * @param preferences - Asset loading preferences
   * @example
   * ```ts
   * // Basic preferences
   * Assets.setPreferences({
   *     crossOrigin: 'anonymous',
   *     parseAsGraphicsContext: false
   * });
   * ```
   * @remarks
   * Preferences are applied to all compatible parsers and affect future asset loading.
   * Common preferences include:
   * - `crossOrigin`: CORS setting for loaded assets
   * - `preferWorkers`: Whether to use web workers for loading textures
   * - `preferCreateImageBitmap`: Use `createImageBitmap` for texture creation. Turning this off will use the `Image` constructor instead.
   * @see {@link AssetsPreferences} For all available preferences
   */
  setPreferences(preferences) {
    this.loader.parsers.forEach((parser) => {
      if (!parser.config) return;
      Object.keys(parser.config).filter((key) => key in preferences).forEach((key) => {
        parser.config[key] = preferences[key];
      });
    });
  }
};
var Assets = new AssetsClass();
extensions.handleByList(ExtensionType.LoadParser, Assets.loader.parsers).handleByList(ExtensionType.ResolveParser, Assets.resolver.parsers).handleByList(ExtensionType.CacheParser, Assets.cache.parsers).handleByList(ExtensionType.DetectionParser, Assets.detections);
extensions.add(
  cacheTextureArray,
  detectDefaults,
  detectAvif,
  detectWebp,
  detectMp4,
  detectOgv,
  detectWebm,
  loadJson,
  loadTxt,
  loadWebFont,
  loadSvg,
  loadTextures,
  loadVideoTextures,
  loadBitmapFont,
  bitmapFontCachePlugin,
  resolveTextureUrl,
  resolveJsonUrl
);
var assetKeyMap = {
  loader: ExtensionType.LoadParser,
  resolver: ExtensionType.ResolveParser,
  cache: ExtensionType.CacheParser,
  detection: ExtensionType.DetectionParser
};
extensions.handle(ExtensionType.Asset, (extension) => {
  const ref = extension.ref;
  Object.entries(assetKeyMap).filter(([key]) => !!ref[key]).forEach(([key, type]) => extensions.add(Object.assign(
    ref[key],
    // Allow the function to optionally define it's own
    // ExtensionMetadata, the use cases here is priority for LoaderParsers
    { extension: ref[key].extension ?? type }
  )));
}, (extension) => {
  const ref = extension.ref;
  Object.keys(assetKeyMap).filter((key) => !!ref[key]).forEach((key) => extensions.remove(ref[key]));
});

// node_modules/pixi.js/lib/compressed-textures/basis/detectBasis.mjs
var detectBasis = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: 3
  },
  test: () => __async(null, null, function* () {
    if (yield isWebGPUSupported()) return true;
    if (isWebGLSupported()) return true;
    return false;
  }),
  add: (formats) => __async(null, null, function* () {
    return [...formats, "basis"];
  }),
  remove: (formats) => __async(null, null, function* () {
    return formats.filter((f) => f !== "basis");
  })
};

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/CompressedSource.mjs
var CompressedSource = class extends TextureSource {
  constructor(options) {
    super(__spreadProps(__spreadValues({}, options), {
      mipLevelCount: options.resource.length
    }));
    this.uploadMethodId = "compressed";
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gl/texture/utils/getSupportedGlCompressedTextureFormats.mjs
var supportedGLCompressedTextureFormats;
function getSupportedGlCompressedTextureFormats() {
  if (supportedGLCompressedTextureFormats) return supportedGLCompressedTextureFormats;
  const canvas = DOMAdapter.get().createCanvas(1, 1);
  const gl = canvas.getContext("webgl");
  if (!gl) {
    return [];
  }
  supportedGLCompressedTextureFormats = [
    // BC compressed formats usable if "texture-compression-bc" is both
    // supported by the device/user agent and enabled in requestDevice.
    // 'bc6h-rgb-ufloat'
    // 'bc6h-rgb-float'
    // 'bc7-rgba-unorm',
    // 'bc7-rgba-unorm-srgb',
    ...gl.getExtension("EXT_texture_compression_bptc") ? [
      "bc6h-rgb-ufloat",
      "bc6h-rgb-float",
      "bc7-rgba-unorm",
      "bc7-rgba-unorm-srgb"
    ] : [],
    // BC compressed formats usable if "texture-compression-bc" is both
    // supported by the device/user agent and enabled in requestDevice.
    // 'bc1-rgba-unorm',
    // 'bc1-rgba-unorm-srgb',
    // 'bc4-r-unorm'
    // 'bc4-r-snorm'
    // 'bc5-rg-unorm'
    // 'bc5-rg-snorm'
    ...gl.getExtension("WEBGL_compressed_texture_s3tc") ? [
      "bc1-rgba-unorm",
      "bc2-rgba-unorm",
      "bc3-rgba-unorm"
    ] : [],
    ...gl.getExtension("WEBGL_compressed_texture_s3tc_srgb") ? [
      "bc1-rgba-unorm-srgb",
      "bc2-rgba-unorm-srgb",
      "bc3-rgba-unorm-srgb"
    ] : [],
    ...gl.getExtension("EXT_texture_compression_rgtc") ? [
      "bc4-r-unorm",
      "bc4-r-snorm",
      "bc5-rg-unorm",
      "bc5-rg-snorm"
    ] : [],
    // ETC2 compressed formats usable if "texture-compression-etc2" is both
    // supported by the device/user agent and enabled in requestDevice.
    ...gl.getExtension("WEBGL_compressed_texture_etc") ? [
      "etc2-rgb8unorm",
      "etc2-rgb8unorm-srgb",
      "etc2-rgba8unorm",
      "etc2-rgba8unorm-srgb",
      "etc2-rgb8a1unorm",
      "etc2-rgb8a1unorm-srgb",
      "eac-r11unorm",
      "eac-rg11unorm"
    ] : [],
    // 'eac-r11snorm',
    // 'eac-rg11snorm',
    // ASTC compressed formats usable if "texture-compression-astc" is both
    // supported by the device/user agent and enabled in requestDevice.
    ...gl.getExtension("WEBGL_compressed_texture_astc") ? [
      "astc-4x4-unorm",
      "astc-4x4-unorm-srgb",
      "astc-5x4-unorm",
      "astc-5x4-unorm-srgb",
      "astc-5x5-unorm",
      "astc-5x5-unorm-srgb",
      "astc-6x5-unorm",
      "astc-6x5-unorm-srgb",
      "astc-6x6-unorm",
      "astc-6x6-unorm-srgb",
      "astc-8x5-unorm",
      "astc-8x5-unorm-srgb",
      "astc-8x6-unorm",
      "astc-8x6-unorm-srgb",
      "astc-8x8-unorm",
      "astc-8x8-unorm-srgb",
      "astc-10x5-unorm",
      "astc-10x5-unorm-srgb",
      "astc-10x6-unorm",
      "astc-10x6-unorm-srgb",
      "astc-10x8-unorm",
      "astc-10x8-unorm-srgb",
      "astc-10x10-unorm",
      "astc-10x10-unorm-srgb",
      "astc-12x10-unorm",
      "astc-12x10-unorm-srgb",
      "astc-12x12-unorm",
      "astc-12x12-unorm-srgb"
    ] : []
  ];
  return supportedGLCompressedTextureFormats;
}

// node_modules/pixi.js/lib/rendering/renderers/gpu/texture/utils/getSupportedGPUCompressedTextureFormats.mjs
var supportedGPUCompressedTextureFormats;
function getSupportedGPUCompressedTextureFormats() {
  return __async(this, null, function* () {
    if (supportedGPUCompressedTextureFormats) return supportedGPUCompressedTextureFormats;
    const adapter = yield DOMAdapter.get().getNavigator().gpu.requestAdapter();
    supportedGPUCompressedTextureFormats = [
      ...adapter.features.has("texture-compression-bc") ? [
        // BC compressed formats usable if "texture-compression-bc" is both
        // supported by the device/user agent and enabled in requestDevice.
        "bc1-rgba-unorm",
        "bc1-rgba-unorm-srgb",
        "bc2-rgba-unorm",
        "bc2-rgba-unorm-srgb",
        "bc3-rgba-unorm",
        "bc3-rgba-unorm-srgb",
        "bc4-r-unorm",
        "bc4-r-snorm",
        "bc5-rg-unorm",
        "bc5-rg-snorm",
        "bc6h-rgb-ufloat",
        "bc6h-rgb-float",
        "bc7-rgba-unorm",
        "bc7-rgba-unorm-srgb"
      ] : [],
      ...adapter.features.has("texture-compression-etc2") ? [
        // ETC2 compressed formats usable if "texture-compression-etc2" is both
        // supported by the device/user agent and enabled in requestDevice.
        "etc2-rgb8unorm",
        "etc2-rgb8unorm-srgb",
        "etc2-rgb8a1unorm",
        "etc2-rgb8a1unorm-srgb",
        "etc2-rgba8unorm",
        "etc2-rgba8unorm-srgb",
        "eac-r11unorm",
        "eac-r11snorm",
        "eac-rg11unorm",
        "eac-rg11snorm"
      ] : [],
      ...adapter.features.has("texture-compression-astc") ? [
        // ASTC compressed formats usable if "texture-compression-astc" is both
        // supported by the device/user agent and enabled in requestDevice.
        "astc-4x4-unorm",
        "astc-4x4-unorm-srgb",
        "astc-5x4-unorm",
        "astc-5x4-unorm-srgb",
        "astc-5x5-unorm",
        "astc-5x5-unorm-srgb",
        "astc-6x5-unorm",
        "astc-6x5-unorm-srgb",
        "astc-6x6-unorm",
        "astc-6x6-unorm-srgb",
        "astc-8x5-unorm",
        "astc-8x5-unorm-srgb",
        "astc-8x6-unorm",
        "astc-8x6-unorm-srgb",
        "astc-8x8-unorm",
        "astc-8x8-unorm-srgb",
        "astc-10x5-unorm",
        "astc-10x5-unorm-srgb",
        "astc-10x6-unorm",
        "astc-10x6-unorm-srgb",
        "astc-10x8-unorm",
        "astc-10x8-unorm-srgb",
        "astc-10x10-unorm",
        "astc-10x10-unorm-srgb",
        "astc-12x10-unorm",
        "astc-12x10-unorm-srgb",
        "astc-12x12-unorm",
        "astc-12x12-unorm-srgb"
      ] : []
    ];
    return supportedGPUCompressedTextureFormats;
  });
}

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/getSupportedCompressedTextureFormats.mjs
var supportedCompressedTextureFormats;
function getSupportedCompressedTextureFormats() {
  return __async(this, null, function* () {
    if (supportedCompressedTextureFormats !== void 0) return supportedCompressedTextureFormats;
    supportedCompressedTextureFormats = yield (() => __async(null, null, function* () {
      const _isWebGPUSupported2 = yield isWebGPUSupported();
      const _isWebGLSupported2 = isWebGLSupported();
      if (_isWebGPUSupported2 && _isWebGLSupported2) {
        const gpuTextureFormats = yield getSupportedGPUCompressedTextureFormats();
        const glTextureFormats = getSupportedGlCompressedTextureFormats();
        return gpuTextureFormats.filter((format) => glTextureFormats.includes(format));
      } else if (_isWebGPUSupported2) {
        return yield getSupportedGPUCompressedTextureFormats();
      } else if (_isWebGLSupported2) {
        return getSupportedGlCompressedTextureFormats();
      }
      return [];
    }))();
    return supportedCompressedTextureFormats;
  });
}

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/getSupportedTextureFormats.mjs
var nonCompressedFormats = [
  // 8-bit formats
  "r8unorm",
  "r8snorm",
  "r8uint",
  "r8sint",
  // 16-bit formats
  "r16uint",
  "r16sint",
  "r16float",
  "rg8unorm",
  "rg8snorm",
  "rg8uint",
  "rg8sint",
  // 32-bit formats
  "r32uint",
  "r32sint",
  "r32float",
  "rg16uint",
  "rg16sint",
  "rg16float",
  "rgba8unorm",
  "rgba8unorm-srgb",
  "rgba8snorm",
  "rgba8uint",
  "rgba8sint",
  "bgra8unorm",
  "bgra8unorm-srgb",
  // Packed 32-bit formats
  "rgb9e5ufloat",
  "rgb10a2unorm",
  "rg11b10ufloat",
  // 64-bit formats
  "rg32uint",
  "rg32sint",
  "rg32float",
  "rgba16uint",
  "rgba16sint",
  "rgba16float",
  // 128-bit formats
  "rgba32uint",
  "rgba32sint",
  "rgba32float",
  // Depth/stencil formats
  "stencil8",
  "depth16unorm",
  "depth24plus",
  "depth24plus-stencil8",
  "depth32float",
  // "depth32float-stencil8" feature
  "depth32float-stencil8"
];
var supportedTextureFormats;
function getSupportedTextureFormats() {
  return __async(this, null, function* () {
    if (supportedTextureFormats !== void 0) return supportedTextureFormats;
    const compressedTextureFormats = yield getSupportedCompressedTextureFormats();
    supportedTextureFormats = [
      ...nonCompressedFormats,
      ...compressedTextureFormats
    ];
    return supportedTextureFormats;
  });
}

// node_modules/pixi.js/lib/_virtual/basis.worker.mjs
var WORKER_CODE3 = '(function () {\n    \'use strict\';\n\n    function createLevelBuffers(basisTexture, basisTranscoderFormat) {\n      const images = basisTexture.getNumImages();\n      const levels = basisTexture.getNumLevels(0);\n      const success = basisTexture.startTranscoding();\n      if (!success) {\n        throw new Error("startTranscoding failed");\n      }\n      const levelBuffers = [];\n      for (let levelIndex = 0; levelIndex < levels; ++levelIndex) {\n        for (let sliceIndex = 0; sliceIndex < images; ++sliceIndex) {\n          const transcodeSize = basisTexture.getImageTranscodedSizeInBytes(sliceIndex, levelIndex, basisTranscoderFormat);\n          const levelBuffer = new Uint8Array(transcodeSize);\n          const success2 = basisTexture.transcodeImage(levelBuffer, sliceIndex, levelIndex, basisTranscoderFormat, 1, 0);\n          if (!success2) {\n            throw new Error("transcodeImage failed");\n          }\n          levelBuffers.push(levelBuffer);\n        }\n      }\n      return levelBuffers;\n    }\n\n    const gpuFormatToBasisTranscoderFormatMap = {\n      "bc3-rgba-unorm": 3,\n      // cTFBC3_RGBA\n      "bc7-rgba-unorm": 6,\n      // cTFBC7_RGBA,\n      "etc2-rgba8unorm": 1,\n      // cTFETC2_RGBA,\n      "astc-4x4-unorm": 10,\n      // cTFASTC_4x4_RGBA,\n      // Uncompressed\n      rgba8unorm: 13,\n      // cTFRGBA32,\n      rgba4unorm: 16\n      // cTFRGBA4444,\n    };\n    function gpuFormatToBasisTranscoderFormat(transcoderFormat) {\n      const format = gpuFormatToBasisTranscoderFormatMap[transcoderFormat];\n      if (format) {\n        return format;\n      }\n      throw new Error(`Unsupported transcoderFormat: ${transcoderFormat}`);\n    }\n\n    const settings = {\n      jsUrl: "basis/basis_transcoder.js",\n      wasmUrl: "basis/basis_transcoder.wasm"\n    };\n    let basisTranscoderFormat;\n    let basisTranscodedTextureFormat;\n    let basisPromise;\n    async function getBasis() {\n      if (!basisPromise) {\n        const absoluteJsUrl = new URL(settings.jsUrl, location.origin).href;\n        const absoluteWasmUrl = new URL(settings.wasmUrl, location.origin).href;\n        importScripts(absoluteJsUrl);\n        basisPromise = new Promise((resolve) => {\n          BASIS({\n            locateFile: (_file) => absoluteWasmUrl\n          }).then((module) => {\n            module.initializeBasis();\n            resolve(module.BasisFile);\n          });\n        });\n      }\n      return basisPromise;\n    }\n    async function fetchBasisTexture(url, BasisTexture) {\n      const basisResponse = await fetch(url);\n      if (basisResponse.ok) {\n        const basisArrayBuffer = await basisResponse.arrayBuffer();\n        return new BasisTexture(new Uint8Array(basisArrayBuffer));\n      }\n      throw new Error(`Failed to load Basis texture: ${url}`);\n    }\n    const preferredTranscodedFormat = [\n      "bc7-rgba-unorm",\n      "astc-4x4-unorm",\n      "etc2-rgba8unorm",\n      "bc3-rgba-unorm",\n      "rgba8unorm"\n    ];\n    async function load(url) {\n      const BasisTexture = await getBasis();\n      const basisTexture = await fetchBasisTexture(url, BasisTexture);\n      const levelBuffers = createLevelBuffers(basisTexture, basisTranscoderFormat);\n      return {\n        width: basisTexture.getImageWidth(0, 0),\n        height: basisTexture.getImageHeight(0, 0),\n        format: basisTranscodedTextureFormat,\n        resource: levelBuffers,\n        alphaMode: "no-premultiply-alpha"\n      };\n    }\n    async function init(jsUrl, wasmUrl, supportedTextures) {\n      if (jsUrl) settings.jsUrl = jsUrl;\n      if (wasmUrl) settings.wasmUrl = wasmUrl;\n      basisTranscodedTextureFormat = preferredTranscodedFormat.filter((format) => supportedTextures.includes(format))[0];\n      basisTranscoderFormat = gpuFormatToBasisTranscoderFormat(basisTranscodedTextureFormat);\n      await getBasis();\n    }\n    const messageHandlers = {\n      init: async (data) => {\n        const { jsUrl, wasmUrl, supportedTextures } = data;\n        await init(jsUrl, wasmUrl, supportedTextures);\n      },\n      load: async (data) => {\n        try {\n          const textureOptions = await load(data.url);\n          return {\n            type: "load",\n            url: data.url,\n            success: true,\n            textureOptions,\n            transferables: textureOptions.resource?.map((arr) => arr.buffer)\n          };\n        } catch (e) {\n          throw e;\n        }\n      }\n    };\n    self.onmessage = (async (messageEvent) => {\n      const message = messageEvent.data;\n      const response = await messageHandlers[message.type](message);\n      if (response) {\n        self.postMessage(response, response.transferables);\n      }\n    });\n\n})();\n';
var WORKER_URL3 = null;
var WorkerInstance3 = class {
  constructor() {
    if (!WORKER_URL3) {
      WORKER_URL3 = URL.createObjectURL(new Blob([WORKER_CODE3], { type: "application/javascript" }));
    }
    this.worker = new Worker(WORKER_URL3);
  }
};
WorkerInstance3.revokeObjectURL = function revokeObjectURL3() {
  if (WORKER_URL3) {
    URL.revokeObjectURL(WORKER_URL3);
    WORKER_URL3 = null;
  }
};

// node_modules/pixi.js/lib/compressed-textures/basis/utils/setBasisTranscoderPath.mjs
var basisTranscoderUrls = {
  jsUrl: "https://cdn.jsdelivr.net/npm/pixi.js/transcoders/basis/basis_transcoder.js",
  wasmUrl: "https://cdn.jsdelivr.net/npm/pixi.js/transcoders/basis/basis_transcoder.wasm"
};
function setBasisTranscoderPath(config) {
  Object.assign(basisTranscoderUrls, config);
}

// node_modules/pixi.js/lib/compressed-textures/basis/worker/loadBasisOnWorker.mjs
var basisWorker;
var urlHash = {};
function getBasisWorker(supportedTextures) {
  if (!basisWorker) {
    basisWorker = new WorkerInstance3().worker;
    basisWorker.onmessage = (messageEvent) => {
      const { success, url, textureOptions } = messageEvent.data;
      if (!success) {
        console.warn("Failed to load Basis texture", url);
      }
      urlHash[url](textureOptions);
    };
    basisWorker.postMessage({
      type: "init",
      jsUrl: basisTranscoderUrls.jsUrl,
      wasmUrl: basisTranscoderUrls.wasmUrl,
      supportedTextures
    });
  }
  return basisWorker;
}
function loadBasisOnWorker(url, supportedTextures) {
  const ktxWorker2 = getBasisWorker(supportedTextures);
  return new Promise((resolve) => {
    urlHash[url] = resolve;
    ktxWorker2.postMessage({ type: "load", url });
  });
}

// node_modules/pixi.js/lib/compressed-textures/basis/loadBasis.mjs
var loadBasis = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.High,
    name: "loadBasis"
  },
  /** used for deprecation purposes */
  name: "loadBasis",
  id: "basis",
  test(url) {
    return checkExtension(url, [".basis"]);
  },
  load(url, asset, loader) {
    return __async(this, null, function* () {
      const supportedTextures = yield getSupportedTextureFormats();
      const textureOptions = yield loadBasisOnWorker(url, supportedTextures);
      const compressedTextureSource = new CompressedSource(__spreadProps(__spreadValues({}, textureOptions), {
        resolution: asset.data?.resolution || getResolutionOfUrl(url)
      }));
      return createTexture(compressedTextureSource, loader, url);
    });
  },
  unload(texture) {
    if (Array.isArray(texture)) {
      texture.forEach((t) => t.destroy(true));
    } else {
      texture.destroy(true);
    }
  }
};

// node_modules/pixi.js/lib/compressed-textures/basis/utils/createLevelBuffers.mjs
function createLevelBuffers(basisTexture, basisTranscoderFormat) {
  const images = basisTexture.getNumImages();
  const levels = basisTexture.getNumLevels(0);
  const success = basisTexture.startTranscoding();
  if (!success) {
    throw new Error("startTranscoding failed");
  }
  const levelBuffers = [];
  for (let levelIndex = 0; levelIndex < levels; ++levelIndex) {
    for (let sliceIndex = 0; sliceIndex < images; ++sliceIndex) {
      const transcodeSize = basisTexture.getImageTranscodedSizeInBytes(sliceIndex, levelIndex, basisTranscoderFormat);
      const levelBuffer = new Uint8Array(transcodeSize);
      const success2 = basisTexture.transcodeImage(levelBuffer, sliceIndex, levelIndex, basisTranscoderFormat, 1, 0);
      if (!success2) {
        throw new Error("transcodeImage failed");
      }
      levelBuffers.push(levelBuffer);
    }
  }
  return levelBuffers;
}

// node_modules/pixi.js/lib/compressed-textures/basis/utils/gpuFormatToBasisTranscoderFormat.mjs
var gpuFormatToBasisTranscoderFormatMap = {
  "bc3-rgba-unorm": 3,
  // cTFBC3_RGBA
  "bc7-rgba-unorm": 6,
  // cTFBC7_RGBA,
  "etc2-rgba8unorm": 1,
  // cTFETC2_RGBA,
  "astc-4x4-unorm": 10,
  // cTFASTC_4x4_RGBA,
  // Uncompressed
  rgba8unorm: 13,
  // cTFRGBA32,
  rgba4unorm: 16
  // cTFRGBA4444,
};
function gpuFormatToBasisTranscoderFormat(transcoderFormat) {
  const format = gpuFormatToBasisTranscoderFormatMap[transcoderFormat];
  if (format) {
    return format;
  }
  throw new Error(`Unsupported transcoderFormat: ${transcoderFormat}`);
}

// node_modules/pixi.js/lib/compressed-textures/dds/const.mjs
var DDS_HEADER_FIELDS = {
  MAGIC: 0,
  SIZE: 1,
  FLAGS: 2,
  HEIGHT: 3,
  WIDTH: 4,
  MIPMAP_COUNT: 7,
  PIXEL_FORMAT: 19,
  PF_FLAGS: 20,
  FOURCC: 21,
  RGB_BITCOUNT: 22,
  R_BIT_MASK: 23,
  G_BIT_MASK: 24,
  B_BIT_MASK: 25,
  A_BIT_MASK: 26
};
var DDS_DX10_FIELDS = {
  DXGI_FORMAT: 0,
  RESOURCE_DIMENSION: 1,
  MISC_FLAG: 2,
  ARRAY_SIZE: 3,
  MISC_FLAGS2: 4
};
var DXGI_FORMAT = ((DXGI_FORMAT2) => {
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_UNKNOWN"] = 0] = "DXGI_FORMAT_UNKNOWN";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32A32_TYPELESS"] = 1] = "DXGI_FORMAT_R32G32B32A32_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32A32_FLOAT"] = 2] = "DXGI_FORMAT_R32G32B32A32_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32A32_UINT"] = 3] = "DXGI_FORMAT_R32G32B32A32_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32A32_SINT"] = 4] = "DXGI_FORMAT_R32G32B32A32_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32_TYPELESS"] = 5] = "DXGI_FORMAT_R32G32B32_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32_FLOAT"] = 6] = "DXGI_FORMAT_R32G32B32_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32_UINT"] = 7] = "DXGI_FORMAT_R32G32B32_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32B32_SINT"] = 8] = "DXGI_FORMAT_R32G32B32_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16B16A16_TYPELESS"] = 9] = "DXGI_FORMAT_R16G16B16A16_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16B16A16_FLOAT"] = 10] = "DXGI_FORMAT_R16G16B16A16_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16B16A16_UNORM"] = 11] = "DXGI_FORMAT_R16G16B16A16_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16B16A16_UINT"] = 12] = "DXGI_FORMAT_R16G16B16A16_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16B16A16_SNORM"] = 13] = "DXGI_FORMAT_R16G16B16A16_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16B16A16_SINT"] = 14] = "DXGI_FORMAT_R16G16B16A16_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32_TYPELESS"] = 15] = "DXGI_FORMAT_R32G32_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32_FLOAT"] = 16] = "DXGI_FORMAT_R32G32_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32_UINT"] = 17] = "DXGI_FORMAT_R32G32_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G32_SINT"] = 18] = "DXGI_FORMAT_R32G32_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32G8X24_TYPELESS"] = 19] = "DXGI_FORMAT_R32G8X24_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_D32_FLOAT_S8X24_UINT"] = 20] = "DXGI_FORMAT_D32_FLOAT_S8X24_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS"] = 21] = "DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_X32_TYPELESS_G8X24_UINT"] = 22] = "DXGI_FORMAT_X32_TYPELESS_G8X24_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R10G10B10A2_TYPELESS"] = 23] = "DXGI_FORMAT_R10G10B10A2_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R10G10B10A2_UNORM"] = 24] = "DXGI_FORMAT_R10G10B10A2_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R10G10B10A2_UINT"] = 25] = "DXGI_FORMAT_R10G10B10A2_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R11G11B10_FLOAT"] = 26] = "DXGI_FORMAT_R11G11B10_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8B8A8_TYPELESS"] = 27] = "DXGI_FORMAT_R8G8B8A8_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8B8A8_UNORM"] = 28] = "DXGI_FORMAT_R8G8B8A8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8B8A8_UNORM_SRGB"] = 29] = "DXGI_FORMAT_R8G8B8A8_UNORM_SRGB";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8B8A8_UINT"] = 30] = "DXGI_FORMAT_R8G8B8A8_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8B8A8_SNORM"] = 31] = "DXGI_FORMAT_R8G8B8A8_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8B8A8_SINT"] = 32] = "DXGI_FORMAT_R8G8B8A8_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16_TYPELESS"] = 33] = "DXGI_FORMAT_R16G16_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16_FLOAT"] = 34] = "DXGI_FORMAT_R16G16_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16_UNORM"] = 35] = "DXGI_FORMAT_R16G16_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16_UINT"] = 36] = "DXGI_FORMAT_R16G16_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16_SNORM"] = 37] = "DXGI_FORMAT_R16G16_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16G16_SINT"] = 38] = "DXGI_FORMAT_R16G16_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32_TYPELESS"] = 39] = "DXGI_FORMAT_R32_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_D32_FLOAT"] = 40] = "DXGI_FORMAT_D32_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32_FLOAT"] = 41] = "DXGI_FORMAT_R32_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32_UINT"] = 42] = "DXGI_FORMAT_R32_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R32_SINT"] = 43] = "DXGI_FORMAT_R32_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R24G8_TYPELESS"] = 44] = "DXGI_FORMAT_R24G8_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_D24_UNORM_S8_UINT"] = 45] = "DXGI_FORMAT_D24_UNORM_S8_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R24_UNORM_X8_TYPELESS"] = 46] = "DXGI_FORMAT_R24_UNORM_X8_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_X24_TYPELESS_G8_UINT"] = 47] = "DXGI_FORMAT_X24_TYPELESS_G8_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8_TYPELESS"] = 48] = "DXGI_FORMAT_R8G8_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8_UNORM"] = 49] = "DXGI_FORMAT_R8G8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8_UINT"] = 50] = "DXGI_FORMAT_R8G8_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8_SNORM"] = 51] = "DXGI_FORMAT_R8G8_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8_SINT"] = 52] = "DXGI_FORMAT_R8G8_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16_TYPELESS"] = 53] = "DXGI_FORMAT_R16_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16_FLOAT"] = 54] = "DXGI_FORMAT_R16_FLOAT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_D16_UNORM"] = 55] = "DXGI_FORMAT_D16_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16_UNORM"] = 56] = "DXGI_FORMAT_R16_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16_UINT"] = 57] = "DXGI_FORMAT_R16_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16_SNORM"] = 58] = "DXGI_FORMAT_R16_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R16_SINT"] = 59] = "DXGI_FORMAT_R16_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8_TYPELESS"] = 60] = "DXGI_FORMAT_R8_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8_UNORM"] = 61] = "DXGI_FORMAT_R8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8_UINT"] = 62] = "DXGI_FORMAT_R8_UINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8_SNORM"] = 63] = "DXGI_FORMAT_R8_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8_SINT"] = 64] = "DXGI_FORMAT_R8_SINT";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_A8_UNORM"] = 65] = "DXGI_FORMAT_A8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R1_UNORM"] = 66] = "DXGI_FORMAT_R1_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R9G9B9E5_SHAREDEXP"] = 67] = "DXGI_FORMAT_R9G9B9E5_SHAREDEXP";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R8G8_B8G8_UNORM"] = 68] = "DXGI_FORMAT_R8G8_B8G8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_G8R8_G8B8_UNORM"] = 69] = "DXGI_FORMAT_G8R8_G8B8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC1_TYPELESS"] = 70] = "DXGI_FORMAT_BC1_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC1_UNORM"] = 71] = "DXGI_FORMAT_BC1_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC1_UNORM_SRGB"] = 72] = "DXGI_FORMAT_BC1_UNORM_SRGB";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC2_TYPELESS"] = 73] = "DXGI_FORMAT_BC2_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC2_UNORM"] = 74] = "DXGI_FORMAT_BC2_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC2_UNORM_SRGB"] = 75] = "DXGI_FORMAT_BC2_UNORM_SRGB";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC3_TYPELESS"] = 76] = "DXGI_FORMAT_BC3_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC3_UNORM"] = 77] = "DXGI_FORMAT_BC3_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC3_UNORM_SRGB"] = 78] = "DXGI_FORMAT_BC3_UNORM_SRGB";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC4_TYPELESS"] = 79] = "DXGI_FORMAT_BC4_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC4_UNORM"] = 80] = "DXGI_FORMAT_BC4_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC4_SNORM"] = 81] = "DXGI_FORMAT_BC4_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC5_TYPELESS"] = 82] = "DXGI_FORMAT_BC5_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC5_UNORM"] = 83] = "DXGI_FORMAT_BC5_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC5_SNORM"] = 84] = "DXGI_FORMAT_BC5_SNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B5G6R5_UNORM"] = 85] = "DXGI_FORMAT_B5G6R5_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B5G5R5A1_UNORM"] = 86] = "DXGI_FORMAT_B5G5R5A1_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B8G8R8A8_UNORM"] = 87] = "DXGI_FORMAT_B8G8R8A8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B8G8R8X8_UNORM"] = 88] = "DXGI_FORMAT_B8G8R8X8_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_R10G10B10_XR_BIAS_A2_UNORM"] = 89] = "DXGI_FORMAT_R10G10B10_XR_BIAS_A2_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B8G8R8A8_TYPELESS"] = 90] = "DXGI_FORMAT_B8G8R8A8_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B8G8R8A8_UNORM_SRGB"] = 91] = "DXGI_FORMAT_B8G8R8A8_UNORM_SRGB";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B8G8R8X8_TYPELESS"] = 92] = "DXGI_FORMAT_B8G8R8X8_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B8G8R8X8_UNORM_SRGB"] = 93] = "DXGI_FORMAT_B8G8R8X8_UNORM_SRGB";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC6H_TYPELESS"] = 94] = "DXGI_FORMAT_BC6H_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC6H_UF16"] = 95] = "DXGI_FORMAT_BC6H_UF16";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC6H_SF16"] = 96] = "DXGI_FORMAT_BC6H_SF16";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC7_TYPELESS"] = 97] = "DXGI_FORMAT_BC7_TYPELESS";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC7_UNORM"] = 98] = "DXGI_FORMAT_BC7_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_BC7_UNORM_SRGB"] = 99] = "DXGI_FORMAT_BC7_UNORM_SRGB";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_AYUV"] = 100] = "DXGI_FORMAT_AYUV";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_Y410"] = 101] = "DXGI_FORMAT_Y410";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_Y416"] = 102] = "DXGI_FORMAT_Y416";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_NV12"] = 103] = "DXGI_FORMAT_NV12";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_P010"] = 104] = "DXGI_FORMAT_P010";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_P016"] = 105] = "DXGI_FORMAT_P016";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_420_OPAQUE"] = 106] = "DXGI_FORMAT_420_OPAQUE";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_YUY2"] = 107] = "DXGI_FORMAT_YUY2";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_Y210"] = 108] = "DXGI_FORMAT_Y210";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_Y216"] = 109] = "DXGI_FORMAT_Y216";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_NV11"] = 110] = "DXGI_FORMAT_NV11";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_AI44"] = 111] = "DXGI_FORMAT_AI44";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_IA44"] = 112] = "DXGI_FORMAT_IA44";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_P8"] = 113] = "DXGI_FORMAT_P8";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_A8P8"] = 114] = "DXGI_FORMAT_A8P8";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_B4G4R4A4_UNORM"] = 115] = "DXGI_FORMAT_B4G4R4A4_UNORM";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_P208"] = 116] = "DXGI_FORMAT_P208";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_V208"] = 117] = "DXGI_FORMAT_V208";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_V408"] = 118] = "DXGI_FORMAT_V408";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_SAMPLER_FEEDBACK_MIN_MIP_OPAQUE"] = 119] = "DXGI_FORMAT_SAMPLER_FEEDBACK_MIN_MIP_OPAQUE";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_SAMPLER_FEEDBACK_MIP_REGION_USED_OPAQUE"] = 120] = "DXGI_FORMAT_SAMPLER_FEEDBACK_MIP_REGION_USED_OPAQUE";
  DXGI_FORMAT2[DXGI_FORMAT2["DXGI_FORMAT_FORCE_UINT"] = 121] = "DXGI_FORMAT_FORCE_UINT";
  return DXGI_FORMAT2;
})(DXGI_FORMAT || {});
var D3D10_RESOURCE_DIMENSION = ((D3D10_RESOURCE_DIMENSION2) => {
  D3D10_RESOURCE_DIMENSION2[D3D10_RESOURCE_DIMENSION2["DDS_DIMENSION_TEXTURE1D"] = 2] = "DDS_DIMENSION_TEXTURE1D";
  D3D10_RESOURCE_DIMENSION2[D3D10_RESOURCE_DIMENSION2["DDS_DIMENSION_TEXTURE2D"] = 3] = "DDS_DIMENSION_TEXTURE2D";
  D3D10_RESOURCE_DIMENSION2[D3D10_RESOURCE_DIMENSION2["DDS_DIMENSION_TEXTURE3D"] = 6] = "DDS_DIMENSION_TEXTURE3D";
  return D3D10_RESOURCE_DIMENSION2;
})(D3D10_RESOURCE_DIMENSION || {});
function fourCCToInt32(value) {
  return value.charCodeAt(0) + (value.charCodeAt(1) << 8) + (value.charCodeAt(2) << 16) + (value.charCodeAt(3) << 24);
}
var D3DFMT = ((D3DFMT2) => {
  D3DFMT2[D3DFMT2["UNKNOWN"] = 0] = "UNKNOWN";
  D3DFMT2[D3DFMT2["R8G8B8"] = 20] = "R8G8B8";
  D3DFMT2[D3DFMT2["A8R8G8B8"] = 21] = "A8R8G8B8";
  D3DFMT2[D3DFMT2["X8R8G8B8"] = 22] = "X8R8G8B8";
  D3DFMT2[D3DFMT2["R5G6B5"] = 23] = "R5G6B5";
  D3DFMT2[D3DFMT2["X1R5G5B5"] = 24] = "X1R5G5B5";
  D3DFMT2[D3DFMT2["A1R5G5B5"] = 25] = "A1R5G5B5";
  D3DFMT2[D3DFMT2["A4R4G4B4"] = 26] = "A4R4G4B4";
  D3DFMT2[D3DFMT2["R3G3B2"] = 27] = "R3G3B2";
  D3DFMT2[D3DFMT2["A8"] = 28] = "A8";
  D3DFMT2[D3DFMT2["A8R3G3B2"] = 29] = "A8R3G3B2";
  D3DFMT2[D3DFMT2["X4R4G4B4"] = 30] = "X4R4G4B4";
  D3DFMT2[D3DFMT2["A2B10G10R10"] = 31] = "A2B10G10R10";
  D3DFMT2[D3DFMT2["A8B8G8R8"] = 32] = "A8B8G8R8";
  D3DFMT2[D3DFMT2["X8B8G8R8"] = 33] = "X8B8G8R8";
  D3DFMT2[D3DFMT2["G16R16"] = 34] = "G16R16";
  D3DFMT2[D3DFMT2["A2R10G10B10"] = 35] = "A2R10G10B10";
  D3DFMT2[D3DFMT2["A16B16G16R16"] = 36] = "A16B16G16R16";
  D3DFMT2[D3DFMT2["A8P8"] = 40] = "A8P8";
  D3DFMT2[D3DFMT2["P8"] = 41] = "P8";
  D3DFMT2[D3DFMT2["L8"] = 50] = "L8";
  D3DFMT2[D3DFMT2["A8L8"] = 51] = "A8L8";
  D3DFMT2[D3DFMT2["A4L4"] = 52] = "A4L4";
  D3DFMT2[D3DFMT2["V8U8"] = 60] = "V8U8";
  D3DFMT2[D3DFMT2["L6V5U5"] = 61] = "L6V5U5";
  D3DFMT2[D3DFMT2["X8L8V8U8"] = 62] = "X8L8V8U8";
  D3DFMT2[D3DFMT2["Q8W8V8U8"] = 63] = "Q8W8V8U8";
  D3DFMT2[D3DFMT2["V16U16"] = 64] = "V16U16";
  D3DFMT2[D3DFMT2["A2W10V10U10"] = 67] = "A2W10V10U10";
  D3DFMT2[D3DFMT2["Q16W16V16U16"] = 110] = "Q16W16V16U16";
  D3DFMT2[D3DFMT2["R16F"] = 111] = "R16F";
  D3DFMT2[D3DFMT2["G16R16F"] = 112] = "G16R16F";
  D3DFMT2[D3DFMT2["A16B16G16R16F"] = 113] = "A16B16G16R16F";
  D3DFMT2[D3DFMT2["R32F"] = 114] = "R32F";
  D3DFMT2[D3DFMT2["G32R32F"] = 115] = "G32R32F";
  D3DFMT2[D3DFMT2["A32B32G32R32F"] = 116] = "A32B32G32R32F";
  D3DFMT2[D3DFMT2["UYVY"] = fourCCToInt32("UYVY")] = "UYVY";
  D3DFMT2[D3DFMT2["R8G8_B8G8"] = fourCCToInt32("RGBG")] = "R8G8_B8G8";
  D3DFMT2[D3DFMT2["YUY2"] = fourCCToInt32("YUY2")] = "YUY2";
  D3DFMT2[D3DFMT2["D3DFMT_G8R8_G8B8"] = fourCCToInt32("GRGB")] = "D3DFMT_G8R8_G8B8";
  D3DFMT2[D3DFMT2["DXT1"] = fourCCToInt32("DXT1")] = "DXT1";
  D3DFMT2[D3DFMT2["DXT2"] = fourCCToInt32("DXT2")] = "DXT2";
  D3DFMT2[D3DFMT2["DXT3"] = fourCCToInt32("DXT3")] = "DXT3";
  D3DFMT2[D3DFMT2["DXT4"] = fourCCToInt32("DXT4")] = "DXT4";
  D3DFMT2[D3DFMT2["DXT5"] = fourCCToInt32("DXT5")] = "DXT5";
  D3DFMT2[D3DFMT2["ATI1"] = fourCCToInt32("ATI1")] = "ATI1";
  D3DFMT2[D3DFMT2["AT1N"] = fourCCToInt32("AT1N")] = "AT1N";
  D3DFMT2[D3DFMT2["ATI2"] = fourCCToInt32("ATI2")] = "ATI2";
  D3DFMT2[D3DFMT2["AT2N"] = fourCCToInt32("AT2N")] = "AT2N";
  D3DFMT2[D3DFMT2["BC4U"] = fourCCToInt32("BC4U")] = "BC4U";
  D3DFMT2[D3DFMT2["BC4S"] = fourCCToInt32("BC4S")] = "BC4S";
  D3DFMT2[D3DFMT2["BC5U"] = fourCCToInt32("BC5U")] = "BC5U";
  D3DFMT2[D3DFMT2["BC5S"] = fourCCToInt32("BC5S")] = "BC5S";
  D3DFMT2[D3DFMT2["DX10"] = fourCCToInt32("DX10")] = "DX10";
  return D3DFMT2;
})(D3DFMT || {});
var FOURCC_TO_TEXTURE_FORMAT = {
  [D3DFMT.DXT1]: "bc1-rgba-unorm",
  [D3DFMT.DXT2]: "bc2-rgba-unorm",
  [D3DFMT.DXT3]: "bc2-rgba-unorm",
  [D3DFMT.DXT4]: "bc3-rgba-unorm",
  [D3DFMT.DXT5]: "bc3-rgba-unorm",
  [D3DFMT.ATI1]: "bc4-r-unorm",
  [D3DFMT.BC4U]: "bc4-r-unorm",
  [D3DFMT.BC4S]: "bc4-r-snorm",
  [D3DFMT.ATI2]: "bc5-rg-unorm",
  [D3DFMT.BC5U]: "bc5-rg-unorm",
  [D3DFMT.BC5S]: "bc5-rg-snorm",
  [
    36
    /* A16B16G16R16 */
  ]: "rgba16uint",
  [
    110
    /* Q16W16V16U16 */
  ]: "rgba16sint",
  [
    111
    /* R16F */
  ]: "r16float",
  [
    112
    /* G16R16F */
  ]: "rg16float",
  [
    113
    /* A16B16G16R16F */
  ]: "rgba16float",
  [
    114
    /* R32F */
  ]: "r32float",
  [
    115
    /* G32R32F */
  ]: "rg32float",
  [
    116
    /* A32B32G32R32F */
  ]: "rgba32float"
};
var DXGI_TO_TEXTURE_FORMAT = {
  [
    70
    /* DXGI_FORMAT_BC1_TYPELESS */
  ]: "bc1-rgba-unorm",
  [
    71
    /* DXGI_FORMAT_BC1_UNORM */
  ]: "bc1-rgba-unorm",
  [
    72
    /* DXGI_FORMAT_BC1_UNORM_SRGB */
  ]: "bc1-rgba-unorm-srgb",
  [
    73
    /* DXGI_FORMAT_BC2_TYPELESS */
  ]: "bc2-rgba-unorm",
  [
    74
    /* DXGI_FORMAT_BC2_UNORM */
  ]: "bc2-rgba-unorm",
  [
    75
    /* DXGI_FORMAT_BC2_UNORM_SRGB */
  ]: "bc2-rgba-unorm-srgb",
  [
    76
    /* DXGI_FORMAT_BC3_TYPELESS */
  ]: "bc3-rgba-unorm",
  [
    77
    /* DXGI_FORMAT_BC3_UNORM */
  ]: "bc3-rgba-unorm",
  [
    78
    /* DXGI_FORMAT_BC3_UNORM_SRGB */
  ]: "bc3-rgba-unorm-srgb",
  [
    79
    /* DXGI_FORMAT_BC4_TYPELESS */
  ]: "bc4-r-unorm",
  [
    80
    /* DXGI_FORMAT_BC4_UNORM */
  ]: "bc4-r-unorm",
  [
    81
    /* DXGI_FORMAT_BC4_SNORM */
  ]: "bc4-r-snorm",
  [
    82
    /* DXGI_FORMAT_BC5_TYPELESS */
  ]: "bc5-rg-unorm",
  [
    83
    /* DXGI_FORMAT_BC5_UNORM */
  ]: "bc5-rg-unorm",
  [
    84
    /* DXGI_FORMAT_BC5_SNORM */
  ]: "bc5-rg-snorm",
  [
    94
    /* DXGI_FORMAT_BC6H_TYPELESS */
  ]: "bc6h-rgb-ufloat",
  [
    95
    /* DXGI_FORMAT_BC6H_UF16 */
  ]: "bc6h-rgb-ufloat",
  [
    96
    /* DXGI_FORMAT_BC6H_SF16 */
  ]: "bc6h-rgb-float",
  [
    97
    /* DXGI_FORMAT_BC7_TYPELESS */
  ]: "bc7-rgba-unorm",
  [
    98
    /* DXGI_FORMAT_BC7_UNORM */
  ]: "bc7-rgba-unorm",
  [
    99
    /* DXGI_FORMAT_BC7_UNORM_SRGB */
  ]: "bc7-rgba-unorm-srgb",
  [
    28
    /* DXGI_FORMAT_R8G8B8A8_UNORM */
  ]: "rgba8unorm",
  [
    29
    /* DXGI_FORMAT_R8G8B8A8_UNORM_SRGB */
  ]: "rgba8unorm-srgb",
  [
    87
    /* DXGI_FORMAT_B8G8R8A8_UNORM */
  ]: "bgra8unorm",
  [
    91
    /* DXGI_FORMAT_B8G8R8A8_UNORM_SRGB */
  ]: "bgra8unorm-srgb",
  [
    41
    /* DXGI_FORMAT_R32_FLOAT */
  ]: "r32float",
  [
    49
    /* DXGI_FORMAT_R8G8_UNORM */
  ]: "rg8unorm",
  [
    56
    /* DXGI_FORMAT_R16_UNORM */
  ]: "r16uint",
  [
    61
    /* DXGI_FORMAT_R8_UNORM */
  ]: "r8unorm",
  [
    24
    /* DXGI_FORMAT_R10G10B10A2_UNORM */
  ]: "rgb10a2unorm",
  [
    11
    /* DXGI_FORMAT_R16G16B16A16_UNORM */
  ]: "rgba16uint",
  [
    13
    /* DXGI_FORMAT_R16G16B16A16_SNORM */
  ]: "rgba16sint",
  [
    10
    /* DXGI_FORMAT_R16G16B16A16_FLOAT */
  ]: "rgba16float",
  [
    54
    /* DXGI_FORMAT_R16_FLOAT */
  ]: "r16float",
  [
    34
    /* DXGI_FORMAT_R16G16_FLOAT */
  ]: "rg16float",
  [
    16
    /* DXGI_FORMAT_R32G32_FLOAT */
  ]: "rg32float",
  [
    2
    /* DXGI_FORMAT_R32G32B32A32_FLOAT */
  ]: "rgba32float"
};
var DDS = {
  MAGIC_VALUE: 542327876,
  MAGIC_SIZE: 4,
  HEADER_SIZE: 124,
  HEADER_DX10_SIZE: 20,
  PIXEL_FORMAT_FLAGS: {
    // PIXEL_FORMAT flags
    // https://github.com/Microsoft/DirectXTex/blob/main/DirectXTex/DDS.h
    // https://learn.microsoft.com/en-us/windows/win32/direct3ddds/dds-pixelformat
    ALPHAPIXELS: 1,
    ALPHA: 2,
    FOURCC: 4,
    RGB: 64,
    RGBA: 65,
    YUV: 512,
    LUMINANCE: 131072,
    LUMINANCEA: 131073
  },
  RESOURCE_MISC_TEXTURECUBE: 4,
  HEADER_FIELDS: DDS_HEADER_FIELDS,
  HEADER_DX10_FIELDS: DDS_DX10_FIELDS,
  DXGI_FORMAT,
  D3D10_RESOURCE_DIMENSION,
  D3DFMT
};
var TEXTURE_FORMAT_BLOCK_SIZE = {
  "bc1-rgba-unorm": 8,
  "bc1-rgba-unorm-srgb": 8,
  "bc2-rgba-unorm": 16,
  "bc2-rgba-unorm-srgb": 16,
  "bc3-rgba-unorm": 16,
  "bc3-rgba-unorm-srgb": 16,
  "bc4-r-unorm": 8,
  "bc4-r-snorm": 8,
  "bc5-rg-unorm": 16,
  "bc5-rg-snorm": 16,
  "bc6h-rgb-ufloat": 16,
  "bc6h-rgb-float": 16,
  "bc7-rgba-unorm": 16,
  "bc7-rgba-unorm-srgb": 16
};

// node_modules/pixi.js/lib/compressed-textures/dds/parseDDS.mjs
function parseDDS(arrayBuffer, supportedFormats) {
  const {
    format,
    fourCC,
    width,
    height,
    dataOffset,
    mipmapCount
  } = parseDDSHeader(arrayBuffer);
  if (!supportedFormats.includes(format)) {
    throw new Error(`Unsupported texture format: ${fourCC} ${format}, supported: ${supportedFormats}`);
  }
  if (mipmapCount <= 1) {
    return {
      format,
      width,
      height,
      resource: [new Uint8Array(arrayBuffer, dataOffset)],
      alphaMode: "no-premultiply-alpha"
    };
  }
  const levelBuffers = getMipmapLevelBuffers(format, width, height, dataOffset, mipmapCount, arrayBuffer);
  const textureOptions = {
    format,
    width,
    height,
    resource: levelBuffers,
    alphaMode: "no-premultiply-alpha"
  };
  return textureOptions;
}
function getMipmapLevelBuffers(format, width, height, dataOffset, mipmapCount, arrayBuffer) {
  const levelBuffers = [];
  const blockBytes = TEXTURE_FORMAT_BLOCK_SIZE[format];
  let mipWidth = width;
  let mipHeight = height;
  let offset = dataOffset;
  for (let level = 0; level < mipmapCount; ++level) {
    const alignedWidth = Math.ceil(Math.max(4, mipWidth) / 4) * 4;
    const alignedHeight = Math.ceil(Math.max(4, mipHeight) / 4) * 4;
    const byteLength = blockBytes ? alignedWidth / 4 * alignedHeight / 4 * blockBytes : mipWidth * mipHeight * 4;
    const levelBuffer = new Uint8Array(arrayBuffer, offset, byteLength);
    levelBuffers.push(levelBuffer);
    offset += byteLength;
    mipWidth = Math.max(mipWidth >> 1, 1);
    mipHeight = Math.max(mipHeight >> 1, 1);
  }
  return levelBuffers;
}
function parseDDSHeader(buffer) {
  const header = new Uint32Array(buffer, 0, DDS.HEADER_SIZE / Uint32Array.BYTES_PER_ELEMENT);
  if (header[DDS.HEADER_FIELDS.MAGIC] !== DDS.MAGIC_VALUE) {
    throw new Error("Invalid magic number in DDS header");
  }
  const height = header[DDS.HEADER_FIELDS.HEIGHT];
  const width = header[DDS.HEADER_FIELDS.WIDTH];
  const mipmapCount = Math.max(1, header[DDS.HEADER_FIELDS.MIPMAP_COUNT]);
  const flags = header[DDS.HEADER_FIELDS.PF_FLAGS];
  const fourCC = header[DDS.HEADER_FIELDS.FOURCC];
  const format = getTextureFormat(header, flags, fourCC, buffer);
  const dataOffset = DDS.MAGIC_SIZE + DDS.HEADER_SIZE + (fourCC === DDS.D3DFMT.DX10 ? DDS.HEADER_DX10_SIZE : 0);
  return {
    format,
    fourCC,
    width,
    height,
    dataOffset,
    mipmapCount
  };
}
function getTextureFormat(header, flags, fourCC, buffer) {
  if (flags & DDS.PIXEL_FORMAT_FLAGS.FOURCC) {
    if (fourCC === DDS.D3DFMT.DX10) {
      const dx10Header = new Uint32Array(
        buffer,
        DDS.MAGIC_SIZE + DDS.HEADER_SIZE,
        // there is a 20-byte DDS_HEADER_DX10 after DDS_HEADER
        DDS.HEADER_DX10_SIZE / Uint32Array.BYTES_PER_ELEMENT
      );
      const miscFlag = dx10Header[DDS.HEADER_DX10_FIELDS.MISC_FLAG];
      if (miscFlag === DDS.RESOURCE_MISC_TEXTURECUBE) {
        throw new Error("DDSParser does not support cubemap textures");
      }
      const resourceDimension = dx10Header[DDS.HEADER_DX10_FIELDS.RESOURCE_DIMENSION];
      if (resourceDimension === DDS.D3D10_RESOURCE_DIMENSION.DDS_DIMENSION_TEXTURE3D) {
        throw new Error("DDSParser does not supported 3D texture data");
      }
      const dxgiFormat = dx10Header[DDS.HEADER_DX10_FIELDS.DXGI_FORMAT];
      if (dxgiFormat in DXGI_TO_TEXTURE_FORMAT) {
        return DXGI_TO_TEXTURE_FORMAT[dxgiFormat];
      }
      throw new Error(`DDSParser cannot parse texture data with DXGI format ${dxgiFormat}`);
    }
    if (fourCC in FOURCC_TO_TEXTURE_FORMAT) {
      return FOURCC_TO_TEXTURE_FORMAT[fourCC];
    }
    throw new Error(`DDSParser cannot parse texture data with fourCC format ${fourCC}`);
  }
  if (flags & DDS.PIXEL_FORMAT_FLAGS.RGB || flags & DDS.PIXEL_FORMAT_FLAGS.RGBA) {
    return getUncompressedTextureFormat(header);
  }
  if (flags & DDS.PIXEL_FORMAT_FLAGS.YUV) {
    throw new Error("DDSParser does not supported YUV uncompressed texture data.");
  }
  if (flags & DDS.PIXEL_FORMAT_FLAGS.LUMINANCE || flags & DDS.PIXEL_FORMAT_FLAGS.LUMINANCEA) {
    throw new Error("DDSParser does not support single-channel (lumninance) texture data!");
  }
  if (flags & DDS.PIXEL_FORMAT_FLAGS.ALPHA || flags & DDS.PIXEL_FORMAT_FLAGS.ALPHAPIXELS) {
    throw new Error("DDSParser does not support single-channel (alpha) texture data!");
  }
  throw new Error("DDSParser failed to load a texture file due to an unknown reason!");
}
function getUncompressedTextureFormat(header) {
  const bitCount = header[DDS.HEADER_FIELDS.RGB_BITCOUNT];
  const rBitMask = header[DDS.HEADER_FIELDS.R_BIT_MASK];
  const gBitMask = header[DDS.HEADER_FIELDS.G_BIT_MASK];
  const bBitMask = header[DDS.HEADER_FIELDS.B_BIT_MASK];
  const aBitMask = header[DDS.HEADER_FIELDS.A_BIT_MASK];
  switch (bitCount) {
    case 32:
      if (rBitMask === 255 && gBitMask === 65280 && bBitMask === 16711680 && aBitMask === 4278190080) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_R8G8B8A8_UNORM];
      }
      if (rBitMask === 16711680 && gBitMask === 65280 && bBitMask === 255 && aBitMask === 4278190080) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_B8G8R8A8_UNORM];
      }
      if (rBitMask === 1072693248 && gBitMask === 1047552 && bBitMask === 1023 && aBitMask === 3221225472) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_R10G10B10A2_UNORM];
      }
      if (rBitMask === 65535 && gBitMask === 4294901760 && bBitMask === 0 && aBitMask === 0) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_R16G16_UNORM];
      }
      if (rBitMask === 4294967295 && gBitMask === 0 && bBitMask === 0 && aBitMask === 0) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_R32_FLOAT];
      }
      break;
    case 24:
      if (rBitMask === 16711680 && gBitMask === 65280 && bBitMask === 255 && aBitMask === 32768) {
      }
      break;
    case 16:
      if (rBitMask === 31744 && gBitMask === 992 && bBitMask === 31 && aBitMask === 32768) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_B5G5R5A1_UNORM];
      }
      if (rBitMask === 63488 && gBitMask === 2016 && bBitMask === 31 && aBitMask === 0) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_B5G6R5_UNORM];
      }
      if (rBitMask === 3840 && gBitMask === 240 && bBitMask === 15 && aBitMask === 61440) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_B4G4R4A4_UNORM];
      }
      if (rBitMask === 255 && gBitMask === 0 && bBitMask === 0 && aBitMask === 65280) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_R8G8_UNORM];
      }
      if (rBitMask === 65535 && gBitMask === 0 && bBitMask === 0 && aBitMask === 0) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_R16_UNORM];
      }
      break;
    case 8:
      if (rBitMask === 255 && gBitMask === 0 && bBitMask === 0 && aBitMask === 0) {
        return DXGI_TO_TEXTURE_FORMAT[DDS.DXGI_FORMAT.DXGI_FORMAT_R8_UNORM];
      }
      break;
  }
  throw new Error(`DDSParser does not support uncompressed texture with configuration:
                bitCount = ${bitCount}, rBitMask = ${rBitMask}, gBitMask = ${gBitMask}, aBitMask = ${aBitMask}`);
}

// node_modules/pixi.js/lib/compressed-textures/dds/loadDDS.mjs
var loadDDS = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.High,
    name: "loadDDS"
  },
  /** used for deprecation purposes */
  name: "loadDDS",
  id: "dds",
  test(url) {
    return checkExtension(url, [".dds"]);
  },
  load(url, asset, loader) {
    return __async(this, null, function* () {
      const supportedTextures = yield getSupportedTextureFormats();
      const ddsResponse = yield fetch(url);
      const ddsArrayBuffer = yield ddsResponse.arrayBuffer();
      const textureOptions = parseDDS(ddsArrayBuffer, supportedTextures);
      const compressedTextureSource = new CompressedSource(__spreadProps(__spreadValues({}, textureOptions), {
        resolution: asset.data?.resolution || getResolutionOfUrl(url)
      }));
      return createTexture(compressedTextureSource, loader, url);
    });
  },
  unload(texture) {
    if (Array.isArray(texture)) {
      texture.forEach((t) => t.destroy(true));
    } else {
      texture.destroy(true);
    }
  }
};

// node_modules/pixi.js/lib/compressed-textures/ktx2/const.mjs
var GL_INTERNAL_FORMAT = ((GL_INTERNAL_FORMAT2) => {
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["RGBA8_SNORM"] = 36759] = "RGBA8_SNORM";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["RGBA"] = 6408] = "RGBA";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["RGBA8UI"] = 36220] = "RGBA8UI";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["SRGB8_ALPHA8"] = 35907] = "SRGB8_ALPHA8";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["RGBA8I"] = 36238] = "RGBA8I";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["RGBA8"] = 32856] = "RGBA8";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGB_S3TC_DXT1_EXT"] = 33776] = "COMPRESSED_RGB_S3TC_DXT1_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_S3TC_DXT1_EXT"] = 33777] = "COMPRESSED_RGBA_S3TC_DXT1_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_S3TC_DXT3_EXT"] = 33778] = "COMPRESSED_RGBA_S3TC_DXT3_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_S3TC_DXT5_EXT"] = 33779] = "COMPRESSED_RGBA_S3TC_DXT5_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT"] = 35917] = "COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT"] = 35918] = "COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT"] = 35919] = "COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB_S3TC_DXT1_EXT"] = 35916] = "COMPRESSED_SRGB_S3TC_DXT1_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RED_RGTC1_EXT"] = 36283] = "COMPRESSED_RED_RGTC1_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SIGNED_RED_RGTC1_EXT"] = 36284] = "COMPRESSED_SIGNED_RED_RGTC1_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RED_GREEN_RGTC2_EXT"] = 36285] = "COMPRESSED_RED_GREEN_RGTC2_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT"] = 36286] = "COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_R11_EAC"] = 37488] = "COMPRESSED_R11_EAC";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SIGNED_R11_EAC"] = 37489] = "COMPRESSED_SIGNED_R11_EAC";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RG11_EAC"] = 37490] = "COMPRESSED_RG11_EAC";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SIGNED_RG11_EAC"] = 37491] = "COMPRESSED_SIGNED_RG11_EAC";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGB8_ETC2"] = 37492] = "COMPRESSED_RGB8_ETC2";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA8_ETC2_EAC"] = 37496] = "COMPRESSED_RGBA8_ETC2_EAC";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ETC2"] = 37493] = "COMPRESSED_SRGB8_ETC2";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ETC2_EAC"] = 37497] = "COMPRESSED_SRGB8_ALPHA8_ETC2_EAC";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2"] = 37494] = "COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2"] = 37495] = "COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_4x4_KHR"] = 37808] = "COMPRESSED_RGBA_ASTC_4x4_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_5x4_KHR"] = 37809] = "COMPRESSED_RGBA_ASTC_5x4_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_5x5_KHR"] = 37810] = "COMPRESSED_RGBA_ASTC_5x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_6x5_KHR"] = 37811] = "COMPRESSED_RGBA_ASTC_6x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_6x6_KHR"] = 37812] = "COMPRESSED_RGBA_ASTC_6x6_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_8x5_KHR"] = 37813] = "COMPRESSED_RGBA_ASTC_8x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_8x6_KHR"] = 37814] = "COMPRESSED_RGBA_ASTC_8x6_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_8x8_KHR"] = 37815] = "COMPRESSED_RGBA_ASTC_8x8_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_10x5_KHR"] = 37816] = "COMPRESSED_RGBA_ASTC_10x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_10x6_KHR"] = 37817] = "COMPRESSED_RGBA_ASTC_10x6_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_10x8_KHR"] = 37818] = "COMPRESSED_RGBA_ASTC_10x8_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_10x10_KHR"] = 37819] = "COMPRESSED_RGBA_ASTC_10x10_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_12x10_KHR"] = 37820] = "COMPRESSED_RGBA_ASTC_12x10_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_ASTC_12x12_KHR"] = 37821] = "COMPRESSED_RGBA_ASTC_12x12_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR"] = 37840] = "COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR"] = 37841] = "COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR"] = 37842] = "COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR"] = 37843] = "COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR"] = 37844] = "COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR"] = 37845] = "COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR"] = 37846] = "COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR"] = 37847] = "COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR"] = 37848] = "COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR"] = 37849] = "COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR"] = 37850] = "COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR"] = 37851] = "COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR"] = 37852] = "COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR"] = 37853] = "COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGBA_BPTC_UNORM_EXT"] = 36492] = "COMPRESSED_RGBA_BPTC_UNORM_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT"] = 36493] = "COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT"] = 36494] = "COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT";
  GL_INTERNAL_FORMAT2[GL_INTERNAL_FORMAT2["COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT"] = 36495] = "COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT";
  return GL_INTERNAL_FORMAT2;
})(GL_INTERNAL_FORMAT || {});
var GL_FORMATS2 = ((GL_FORMATS22) => {
  GL_FORMATS22[GL_FORMATS22["RGBA"] = 6408] = "RGBA";
  GL_FORMATS22[GL_FORMATS22["RGB"] = 6407] = "RGB";
  GL_FORMATS22[GL_FORMATS22["RG"] = 33319] = "RG";
  GL_FORMATS22[GL_FORMATS22["RED"] = 6403] = "RED";
  GL_FORMATS22[GL_FORMATS22["RGBA_INTEGER"] = 36249] = "RGBA_INTEGER";
  GL_FORMATS22[GL_FORMATS22["RGB_INTEGER"] = 36248] = "RGB_INTEGER";
  GL_FORMATS22[GL_FORMATS22["RG_INTEGER"] = 33320] = "RG_INTEGER";
  GL_FORMATS22[GL_FORMATS22["RED_INTEGER"] = 36244] = "RED_INTEGER";
  GL_FORMATS22[GL_FORMATS22["ALPHA"] = 6406] = "ALPHA";
  GL_FORMATS22[GL_FORMATS22["LUMINANCE"] = 6409] = "LUMINANCE";
  GL_FORMATS22[GL_FORMATS22["LUMINANCE_ALPHA"] = 6410] = "LUMINANCE_ALPHA";
  GL_FORMATS22[GL_FORMATS22["DEPTH_COMPONENT"] = 6402] = "DEPTH_COMPONENT";
  GL_FORMATS22[GL_FORMATS22["DEPTH_STENCIL"] = 34041] = "DEPTH_STENCIL";
  return GL_FORMATS22;
})(GL_FORMATS2 || {});
var GL_TYPES2 = ((GL_TYPES22) => {
  GL_TYPES22[GL_TYPES22["UNSIGNED_BYTE"] = 5121] = "UNSIGNED_BYTE";
  GL_TYPES22[GL_TYPES22["UNSIGNED_SHORT"] = 5123] = "UNSIGNED_SHORT";
  GL_TYPES22[GL_TYPES22["UNSIGNED_SHORT_5_6_5"] = 33635] = "UNSIGNED_SHORT_5_6_5";
  GL_TYPES22[GL_TYPES22["UNSIGNED_SHORT_4_4_4_4"] = 32819] = "UNSIGNED_SHORT_4_4_4_4";
  GL_TYPES22[GL_TYPES22["UNSIGNED_SHORT_5_5_5_1"] = 32820] = "UNSIGNED_SHORT_5_5_5_1";
  GL_TYPES22[GL_TYPES22["UNSIGNED_INT"] = 5125] = "UNSIGNED_INT";
  GL_TYPES22[GL_TYPES22["UNSIGNED_INT_10F_11F_11F_REV"] = 35899] = "UNSIGNED_INT_10F_11F_11F_REV";
  GL_TYPES22[GL_TYPES22["UNSIGNED_INT_2_10_10_10_REV"] = 33640] = "UNSIGNED_INT_2_10_10_10_REV";
  GL_TYPES22[GL_TYPES22["UNSIGNED_INT_24_8"] = 34042] = "UNSIGNED_INT_24_8";
  GL_TYPES22[GL_TYPES22["UNSIGNED_INT_5_9_9_9_REV"] = 35902] = "UNSIGNED_INT_5_9_9_9_REV";
  GL_TYPES22[GL_TYPES22["BYTE"] = 5120] = "BYTE";
  GL_TYPES22[GL_TYPES22["SHORT"] = 5122] = "SHORT";
  GL_TYPES22[GL_TYPES22["INT"] = 5124] = "INT";
  GL_TYPES22[GL_TYPES22["FLOAT"] = 5126] = "FLOAT";
  GL_TYPES22[GL_TYPES22["FLOAT_32_UNSIGNED_INT_24_8_REV"] = 36269] = "FLOAT_32_UNSIGNED_INT_24_8_REV";
  GL_TYPES22[GL_TYPES22["HALF_FLOAT"] = 36193] = "HALF_FLOAT";
  return GL_TYPES22;
})(GL_TYPES2 || {});
var INTERNAL_FORMAT_TO_TEXTURE_FORMATS = {
  [
    33776
    /* COMPRESSED_RGB_S3TC_DXT1_EXT */
  ]: "bc1-rgba-unorm",
  // TODO: ???
  [
    33777
    /* COMPRESSED_RGBA_S3TC_DXT1_EXT */
  ]: "bc1-rgba-unorm",
  [
    33778
    /* COMPRESSED_RGBA_S3TC_DXT3_EXT */
  ]: "bc2-rgba-unorm",
  [
    33779
    /* COMPRESSED_RGBA_S3TC_DXT5_EXT */
  ]: "bc3-rgba-unorm",
  [
    35916
    /* COMPRESSED_SRGB_S3TC_DXT1_EXT */
  ]: "bc1-rgba-unorm-srgb",
  // TODO: ???
  [
    35917
    /* COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT */
  ]: "bc1-rgba-unorm-srgb",
  [
    35918
    /* COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT */
  ]: "bc2-rgba-unorm-srgb",
  [
    35919
    /* COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT */
  ]: "bc3-rgba-unorm-srgb",
  [
    36283
    /* COMPRESSED_RED_RGTC1_EXT */
  ]: "bc4-r-unorm",
  [
    36284
    /* COMPRESSED_SIGNED_RED_RGTC1_EXT */
  ]: "bc4-r-snorm",
  [
    36285
    /* COMPRESSED_RED_GREEN_RGTC2_EXT */
  ]: "bc5-rg-unorm",
  [
    36286
    /* COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT */
  ]: "bc5-rg-snorm",
  [
    37488
    /* COMPRESSED_R11_EAC */
  ]: "eac-r11unorm",
  // [GL_INTERNAL_FORMAT.COMPRESSED_SIGNED_R11_EAC]: 'eac-r11snorm',
  [
    37490
    /* COMPRESSED_RG11_EAC */
  ]: "eac-rg11snorm",
  // [GL_INTERNAL_FORMAT.COMPRESSED_SIGNED_RG11_EAC]: 'eac-rg11unorm',
  [
    37492
    /* COMPRESSED_RGB8_ETC2 */
  ]: "etc2-rgb8unorm",
  [
    37496
    /* COMPRESSED_RGBA8_ETC2_EAC */
  ]: "etc2-rgba8unorm",
  [
    37493
    /* COMPRESSED_SRGB8_ETC2 */
  ]: "etc2-rgb8unorm-srgb",
  [
    37497
    /* COMPRESSED_SRGB8_ALPHA8_ETC2_EAC */
  ]: "etc2-rgba8unorm-srgb",
  [
    37494
    /* COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2 */
  ]: "etc2-rgb8a1unorm",
  [
    37495
    /* COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2 */
  ]: "etc2-rgb8a1unorm-srgb",
  [
    37808
    /* COMPRESSED_RGBA_ASTC_4x4_KHR */
  ]: "astc-4x4-unorm",
  [
    37840
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR */
  ]: "astc-4x4-unorm-srgb",
  [
    37809
    /* COMPRESSED_RGBA_ASTC_5x4_KHR */
  ]: "astc-5x4-unorm",
  [
    37841
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR */
  ]: "astc-5x4-unorm-srgb",
  [
    37810
    /* COMPRESSED_RGBA_ASTC_5x5_KHR */
  ]: "astc-5x5-unorm",
  [
    37842
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR */
  ]: "astc-5x5-unorm-srgb",
  [
    37811
    /* COMPRESSED_RGBA_ASTC_6x5_KHR */
  ]: "astc-6x5-unorm",
  [
    37843
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR */
  ]: "astc-6x5-unorm-srgb",
  [
    37812
    /* COMPRESSED_RGBA_ASTC_6x6_KHR */
  ]: "astc-6x6-unorm",
  [
    37844
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR */
  ]: "astc-6x6-unorm-srgb",
  [
    37813
    /* COMPRESSED_RGBA_ASTC_8x5_KHR */
  ]: "astc-8x5-unorm",
  [
    37845
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR */
  ]: "astc-8x5-unorm-srgb",
  [
    37814
    /* COMPRESSED_RGBA_ASTC_8x6_KHR */
  ]: "astc-8x6-unorm",
  [
    37846
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR */
  ]: "astc-8x6-unorm-srgb",
  [
    37815
    /* COMPRESSED_RGBA_ASTC_8x8_KHR */
  ]: "astc-8x8-unorm",
  [
    37847
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR */
  ]: "astc-8x8-unorm-srgb",
  [
    37816
    /* COMPRESSED_RGBA_ASTC_10x5_KHR */
  ]: "astc-10x5-unorm",
  [
    37848
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR */
  ]: "astc-10x5-unorm-srgb",
  [
    37817
    /* COMPRESSED_RGBA_ASTC_10x6_KHR */
  ]: "astc-10x6-unorm",
  [
    37849
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR */
  ]: "astc-10x6-unorm-srgb",
  [
    37818
    /* COMPRESSED_RGBA_ASTC_10x8_KHR */
  ]: "astc-10x8-unorm",
  [
    37850
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR */
  ]: "astc-10x8-unorm-srgb",
  [
    37819
    /* COMPRESSED_RGBA_ASTC_10x10_KHR */
  ]: "astc-10x10-unorm",
  [
    37851
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR */
  ]: "astc-10x10-unorm-srgb",
  [
    37820
    /* COMPRESSED_RGBA_ASTC_12x10_KHR */
  ]: "astc-12x10-unorm",
  [
    37852
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR */
  ]: "astc-12x10-unorm-srgb",
  [
    37821
    /* COMPRESSED_RGBA_ASTC_12x12_KHR */
  ]: "astc-12x12-unorm",
  [
    37853
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR */
  ]: "astc-12x12-unorm-srgb",
  [
    36492
    /* COMPRESSED_RGBA_BPTC_UNORM_EXT */
  ]: "bc7-rgba-unorm",
  [
    36493
    /* COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT */
  ]: "bc7-rgba-unorm-srgb",
  [
    36494
    /* COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT */
  ]: "bc6h-rgb-float",
  [
    36495
    /* COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT */
  ]: "bc6h-rgb-ufloat",
  [
    35907
    /* SRGB8_ALPHA8 */
  ]: "rgba8unorm-srgb",
  [
    36759
    /* RGBA8_SNORM */
  ]: "rgba8snorm",
  [
    36220
    /* RGBA8UI */
  ]: "rgba8uint",
  [
    36238
    /* RGBA8I */
  ]: "rgba8sint",
  [
    6408
    /* RGBA */
  ]: "rgba8unorm"
  // [GL_INTERNAL_FORMAT.RGBA8]: 'bgra8unorm'
};
var FILE_IDENTIFIER = [171, 75, 84, 88, 32, 49, 49, 187, 13, 10, 26, 10];
var FIELDS = {
  FILE_IDENTIFIER: 0,
  ENDIANNESS: 12,
  GL_TYPE: 16,
  GL_TYPE_SIZE: 20,
  GL_FORMAT: 24,
  GL_INTERNAL_FORMAT: 28,
  GL_BASE_INTERNAL_FORMAT: 32,
  PIXEL_WIDTH: 36,
  PIXEL_HEIGHT: 40,
  PIXEL_DEPTH: 44,
  NUMBER_OF_ARRAY_ELEMENTS: 48,
  NUMBER_OF_FACES: 52,
  NUMBER_OF_MIPMAP_LEVELS: 56,
  BYTES_OF_KEY_VALUE_DATA: 60
};
var FILE_HEADER_SIZE = 64;
var ENDIANNESS = 67305985;
var TYPES_TO_BYTES_PER_COMPONENT = {
  [
    5121
    /* UNSIGNED_BYTE */
  ]: 1,
  [
    5123
    /* UNSIGNED_SHORT */
  ]: 2,
  [
    5124
    /* INT */
  ]: 4,
  [
    5125
    /* UNSIGNED_INT */
  ]: 4,
  [
    5126
    /* FLOAT */
  ]: 4,
  [
    36193
    /* HALF_FLOAT */
  ]: 8
};
var FORMATS_TO_COMPONENTS = {
  [
    6408
    /* RGBA */
  ]: 4,
  [
    6407
    /* RGB */
  ]: 3,
  [
    33319
    /* RG */
  ]: 2,
  [
    6403
    /* RED */
  ]: 1,
  [
    6409
    /* LUMINANCE */
  ]: 1,
  [
    6410
    /* LUMINANCE_ALPHA */
  ]: 2,
  [
    6406
    /* ALPHA */
  ]: 1
};
var TYPES_TO_BYTES_PER_PIXEL = {
  [
    32819
    /* UNSIGNED_SHORT_4_4_4_4 */
  ]: 2,
  [
    32820
    /* UNSIGNED_SHORT_5_5_5_1 */
  ]: 2,
  [
    33635
    /* UNSIGNED_SHORT_5_6_5 */
  ]: 2
};
var INTERNAL_FORMAT_TO_BYTES_PER_PIXEL = {
  [
    33776
    /* COMPRESSED_RGB_S3TC_DXT1_EXT */
  ]: 0.5,
  [
    33777
    /* COMPRESSED_RGBA_S3TC_DXT1_EXT */
  ]: 0.5,
  [
    33778
    /* COMPRESSED_RGBA_S3TC_DXT3_EXT */
  ]: 1,
  [
    33779
    /* COMPRESSED_RGBA_S3TC_DXT5_EXT */
  ]: 1,
  [
    35916
    /* COMPRESSED_SRGB_S3TC_DXT1_EXT */
  ]: 0.5,
  [
    35917
    /* COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT */
  ]: 0.5,
  [
    35918
    /* COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT */
  ]: 1,
  [
    35919
    /* COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT */
  ]: 1,
  [
    36283
    /* COMPRESSED_RED_RGTC1_EXT */
  ]: 0.5,
  [
    36284
    /* COMPRESSED_SIGNED_RED_RGTC1_EXT */
  ]: 0.5,
  [
    36285
    /* COMPRESSED_RED_GREEN_RGTC2_EXT */
  ]: 1,
  [
    36286
    /* COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT */
  ]: 1,
  [
    37488
    /* COMPRESSED_R11_EAC */
  ]: 0.5,
  [
    37489
    /* COMPRESSED_SIGNED_R11_EAC */
  ]: 0.5,
  [
    37490
    /* COMPRESSED_RG11_EAC */
  ]: 1,
  [
    37491
    /* COMPRESSED_SIGNED_RG11_EAC */
  ]: 1,
  [
    37492
    /* COMPRESSED_RGB8_ETC2 */
  ]: 0.5,
  [
    37496
    /* COMPRESSED_RGBA8_ETC2_EAC */
  ]: 1,
  [
    37493
    /* COMPRESSED_SRGB8_ETC2 */
  ]: 0.5,
  [
    37497
    /* COMPRESSED_SRGB8_ALPHA8_ETC2_EAC */
  ]: 1,
  [
    37494
    /* COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2 */
  ]: 0.5,
  [
    37495
    /* COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2 */
  ]: 0.5,
  [
    37808
    /* COMPRESSED_RGBA_ASTC_4x4_KHR */
  ]: 1,
  [
    37840
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR */
  ]: 1,
  [
    37809
    /* COMPRESSED_RGBA_ASTC_5x4_KHR */
  ]: 0.8,
  [
    37841
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR */
  ]: 0.8,
  [
    37810
    /* COMPRESSED_RGBA_ASTC_5x5_KHR */
  ]: 0.64,
  [
    37842
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR */
  ]: 0.64,
  [
    37811
    /* COMPRESSED_RGBA_ASTC_6x5_KHR */
  ]: 0.53375,
  [
    37843
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR */
  ]: 0.53375,
  [
    37812
    /* COMPRESSED_RGBA_ASTC_6x6_KHR */
  ]: 0.445,
  [
    37844
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR */
  ]: 0.445,
  [
    37813
    /* COMPRESSED_RGBA_ASTC_8x5_KHR */
  ]: 0.4,
  [
    37845
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR */
  ]: 0.4,
  [
    37814
    /* COMPRESSED_RGBA_ASTC_8x6_KHR */
  ]: 0.33375,
  [
    37846
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR */
  ]: 0.33375,
  [
    37815
    /* COMPRESSED_RGBA_ASTC_8x8_KHR */
  ]: 0.25,
  [
    37847
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR */
  ]: 0.25,
  [
    37816
    /* COMPRESSED_RGBA_ASTC_10x5_KHR */
  ]: 0.32,
  [
    37848
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR */
  ]: 0.32,
  [
    37817
    /* COMPRESSED_RGBA_ASTC_10x6_KHR */
  ]: 0.26625,
  [
    37849
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR */
  ]: 0.26625,
  [
    37818
    /* COMPRESSED_RGBA_ASTC_10x8_KHR */
  ]: 0.2,
  [
    37850
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR */
  ]: 0.2,
  [
    37819
    /* COMPRESSED_RGBA_ASTC_10x10_KHR */
  ]: 0.16,
  [
    37851
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR */
  ]: 0.16,
  [
    37820
    /* COMPRESSED_RGBA_ASTC_12x10_KHR */
  ]: 0.13375,
  [
    37852
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR */
  ]: 0.13375,
  [
    37821
    /* COMPRESSED_RGBA_ASTC_12x12_KHR */
  ]: 0.11125,
  [
    37853
    /* COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR */
  ]: 0.11125,
  [
    36492
    /* COMPRESSED_RGBA_BPTC_UNORM_EXT */
  ]: 1,
  [
    36493
    /* COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT */
  ]: 1,
  [
    36494
    /* COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT */
  ]: 1,
  [
    36495
    /* COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT */
  ]: 1
};
var KTX = {
  FILE_HEADER_SIZE,
  FILE_IDENTIFIER,
  FORMATS_TO_COMPONENTS,
  INTERNAL_FORMAT_TO_BYTES_PER_PIXEL,
  INTERNAL_FORMAT_TO_TEXTURE_FORMATS,
  FIELDS,
  TYPES_TO_BYTES_PER_COMPONENT,
  TYPES_TO_BYTES_PER_PIXEL,
  ENDIANNESS
};

// node_modules/pixi.js/lib/compressed-textures/ktx/parseKTX.mjs
function parseKTX(arrayBuffer, supportedFormats) {
  const dataView = new DataView(arrayBuffer);
  if (!validate(dataView)) {
    throw new Error("Invalid KTX identifier in header");
  }
  const {
    littleEndian,
    glType,
    glFormat,
    glInternalFormat,
    pixelWidth,
    pixelHeight,
    numberOfMipmapLevels,
    offset
  } = parseKTXHeader(dataView);
  const textureFormat = KTX.INTERNAL_FORMAT_TO_TEXTURE_FORMATS[glInternalFormat];
  if (!textureFormat) {
    throw new Error(`Unknown texture format ${glInternalFormat}`);
  }
  if (!supportedFormats.includes(textureFormat)) {
    throw new Error(`Unsupported texture format: ${textureFormat}, supportedFormats: ${supportedFormats}`);
  }
  const imagePixelByteSize = getImagePixelByteSize(glType, glFormat, glInternalFormat);
  const imageBuffers = getImageBuffers(
    dataView,
    glType,
    imagePixelByteSize,
    pixelWidth,
    pixelHeight,
    offset,
    numberOfMipmapLevels,
    littleEndian
  );
  return {
    format: textureFormat,
    width: pixelWidth,
    height: pixelHeight,
    resource: imageBuffers,
    alphaMode: "no-premultiply-alpha"
  };
}
function getImageBuffers(dataView, glType, imagePixelByteSize, pixelWidth, pixelHeight, offset, numberOfMipmapLevels, littleEndian) {
  const alignedWidth = pixelWidth + 3 & ~3;
  const alignedHeight = pixelHeight + 3 & ~3;
  let imagePixels = pixelWidth * pixelHeight;
  if (glType === 0) {
    imagePixels = alignedWidth * alignedHeight;
  }
  let mipByteSize = imagePixels * imagePixelByteSize;
  let mipWidth = pixelWidth;
  let mipHeight = pixelHeight;
  let alignedMipWidth = alignedWidth;
  let alignedMipHeight = alignedHeight;
  let imageOffset = offset;
  const imageBuffers = new Array(numberOfMipmapLevels);
  for (let mipmapLevel = 0; mipmapLevel < numberOfMipmapLevels; mipmapLevel++) {
    const imageSize = dataView.getUint32(imageOffset, littleEndian);
    let elementOffset = imageOffset + 4;
    imageBuffers[mipmapLevel] = new Uint8Array(dataView.buffer, elementOffset, mipByteSize);
    elementOffset += mipByteSize;
    imageOffset += imageSize + 4;
    imageOffset = imageOffset % 4 !== 0 ? imageOffset + 4 - imageOffset % 4 : imageOffset;
    mipWidth = mipWidth >> 1 || 1;
    mipHeight = mipHeight >> 1 || 1;
    alignedMipWidth = mipWidth + 4 - 1 & ~(4 - 1);
    alignedMipHeight = mipHeight + 4 - 1 & ~(4 - 1);
    mipByteSize = alignedMipWidth * alignedMipHeight * imagePixelByteSize;
  }
  return imageBuffers;
}
function getImagePixelByteSize(glType, glFormat, glInternalFormat) {
  let imagePixelByteSize = KTX.INTERNAL_FORMAT_TO_BYTES_PER_PIXEL[glInternalFormat];
  if (glType !== 0) {
    if (KTX.TYPES_TO_BYTES_PER_COMPONENT[glType]) {
      imagePixelByteSize = KTX.TYPES_TO_BYTES_PER_COMPONENT[glType] * KTX.FORMATS_TO_COMPONENTS[glFormat];
    } else {
      imagePixelByteSize = KTX.TYPES_TO_BYTES_PER_PIXEL[glType];
    }
  }
  if (imagePixelByteSize === void 0) {
    throw new Error("Unable to resolve the pixel format stored in the *.ktx file!");
  }
  return imagePixelByteSize;
}
function parseKTXHeader(dataView) {
  const littleEndian = dataView.getUint32(KTX.FIELDS.ENDIANNESS, true) === KTX.ENDIANNESS;
  const glType = dataView.getUint32(KTX.FIELDS.GL_TYPE, littleEndian);
  const glFormat = dataView.getUint32(KTX.FIELDS.GL_FORMAT, littleEndian);
  const glInternalFormat = dataView.getUint32(KTX.FIELDS.GL_INTERNAL_FORMAT, littleEndian);
  const pixelWidth = dataView.getUint32(KTX.FIELDS.PIXEL_WIDTH, littleEndian);
  const pixelHeight = dataView.getUint32(KTX.FIELDS.PIXEL_HEIGHT, littleEndian) || 1;
  const pixelDepth = dataView.getUint32(KTX.FIELDS.PIXEL_DEPTH, littleEndian) || 1;
  const numberOfArrayElements = dataView.getUint32(KTX.FIELDS.NUMBER_OF_ARRAY_ELEMENTS, littleEndian) || 1;
  const numberOfFaces = dataView.getUint32(KTX.FIELDS.NUMBER_OF_FACES, littleEndian);
  const numberOfMipmapLevels = dataView.getUint32(KTX.FIELDS.NUMBER_OF_MIPMAP_LEVELS, littleEndian);
  const bytesOfKeyValueData = dataView.getUint32(KTX.FIELDS.BYTES_OF_KEY_VALUE_DATA, littleEndian);
  if (pixelHeight === 0 || pixelDepth !== 1) {
    throw new Error("Only 2D textures are supported");
  }
  if (numberOfFaces !== 1) {
    throw new Error("CubeTextures are not supported by KTXLoader yet!");
  }
  if (numberOfArrayElements !== 1) {
    throw new Error("WebGL does not support array textures");
  }
  return {
    littleEndian,
    glType,
    glFormat,
    glInternalFormat,
    pixelWidth,
    pixelHeight,
    numberOfMipmapLevels,
    offset: KTX.FILE_HEADER_SIZE + bytesOfKeyValueData
  };
}
function validate(dataView) {
  for (let i = 0; i < KTX.FILE_IDENTIFIER.length; i++) {
    if (dataView.getUint8(i) !== KTX.FILE_IDENTIFIER[i]) {
      return false;
    }
  }
  return true;
}

// node_modules/pixi.js/lib/compressed-textures/ktx/loadKTX.mjs
var loadKTX = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.High,
    name: "loadKTX"
  },
  /** used for deprecation purposes */
  name: "loadKTX",
  id: "ktx",
  test(url) {
    return checkExtension(url, ".ktx");
  },
  load(url, asset, loader) {
    return __async(this, null, function* () {
      const supportedTextures = yield getSupportedTextureFormats();
      const ktxResponse = yield fetch(url);
      const ktxArrayBuffer = yield ktxResponse.arrayBuffer();
      const textureOptions = parseKTX(ktxArrayBuffer, supportedTextures);
      const compressedTextureSource = new CompressedSource(__spreadProps(__spreadValues({}, textureOptions), {
        resolution: asset.data?.resolution || getResolutionOfUrl(url)
      }));
      return createTexture(compressedTextureSource, loader, url);
    });
  },
  unload(texture) {
    if (Array.isArray(texture)) {
      texture.forEach((t) => t.destroy(true));
    } else {
      texture.destroy(true);
    }
  }
};

// node_modules/pixi.js/lib/_virtual/ktx.worker.mjs
var WORKER_CODE4 = '(function () {\n    \'use strict\';\n\n    const converters = {\n      rgb8unorm: {\n        convertedFormat: "rgba8unorm",\n        convertFunction: convertRGBtoRGBA\n      },\n      "rgb8unorm-srgb": {\n        convertedFormat: "rgba8unorm-srgb",\n        convertFunction: convertRGBtoRGBA\n      }\n    };\n    function convertFormatIfRequired(textureOptions) {\n      const format = textureOptions.format;\n      if (converters[format]) {\n        const convertFunction = converters[format].convertFunction;\n        const levelBuffers = textureOptions.resource;\n        for (let i = 0; i < levelBuffers.length; i++) {\n          levelBuffers[i] = convertFunction(levelBuffers[i]);\n        }\n        textureOptions.format = converters[format].convertedFormat;\n      }\n    }\n    function convertRGBtoRGBA(levelBuffer) {\n      const pixelCount = levelBuffer.byteLength / 3;\n      const levelBufferWithAlpha = new Uint32Array(pixelCount);\n      for (let i = 0; i < pixelCount; ++i) {\n        levelBufferWithAlpha[i] = levelBuffer[i * 3] + (levelBuffer[i * 3 + 1] << 8) + (levelBuffer[i * 3 + 2] << 16) + 4278190080;\n      }\n      return new Uint8Array(levelBufferWithAlpha.buffer);\n    }\n\n    function createLevelBuffersFromKTX(ktxTexture) {\n      const levelBuffers = [];\n      for (let i = 0; i < ktxTexture.numLevels; i++) {\n        const imageData = ktxTexture.getImageData(i, 0, 0);\n        const levelBuffer = new Uint8Array(imageData.byteLength);\n        levelBuffer.set(imageData);\n        levelBuffers.push(levelBuffer);\n      }\n      return levelBuffers;\n    }\n\n    const glFormatToGPUFormatMap = {\n      6408: "rgba8unorm",\n      32856: "bgra8unorm",\n      //\n      32857: "rgb10a2unorm",\n      33189: "depth16unorm",\n      33190: "depth24plus",\n      33321: "r8unorm",\n      33323: "rg8unorm",\n      33325: "r16float",\n      33326: "r32float",\n      33327: "rg16float",\n      33328: "rg32float",\n      33329: "r8sint",\n      33330: "r8uint",\n      33331: "r16sint",\n      33332: "r16uint",\n      33333: "r32sint",\n      33334: "r32uint",\n      33335: "rg8sint",\n      33336: "rg8uint",\n      33337: "rg16sint",\n      33338: "rg16uint",\n      33339: "rg32sint",\n      33340: "rg32uint",\n      33778: "bc2-rgba-unorm",\n      33779: "bc3-rgba-unorm",\n      34836: "rgba32float",\n      34842: "rgba16float",\n      35056: "depth24plus-stencil8",\n      35898: "rg11b10ufloat",\n      35901: "rgb9e5ufloat",\n      35907: "rgba8unorm-srgb",\n      // bgra8unorm-srgb\n      36012: "depth32float",\n      36013: "depth32float-stencil8",\n      36168: "stencil8",\n      36208: "rgba32uint",\n      36214: "rgba16uint",\n      36220: "rgba8uint",\n      36226: "rgba32sint",\n      36232: "rgba16sint",\n      36238: "rgba8sint",\n      36492: "bc7-rgba-unorm",\n      36756: "r8snorm",\n      36757: "rg8snorm",\n      36759: "rgba8snorm",\n      37496: "etc2-rgba8unorm",\n      37808: "astc-4x4-unorm"\n    };\n    function glFormatToGPUFormat(glInternalFormat) {\n      const format = glFormatToGPUFormatMap[glInternalFormat];\n      if (format) {\n        return format;\n      }\n      throw new Error(`Unsupported glInternalFormat: ${glInternalFormat}`);\n    }\n\n    const vkFormatToGPUFormatMap = {\n      23: "rgb8unorm",\n      // VK_FORMAT_R8G8B8_UNORM\n      37: "rgba8unorm",\n      // VK_FORMAT_R8G8B8A8_UNORM\n      43: "rgba8unorm-srgb"\n      // VK_FORMAT_R8G8B8A8_SRGB\n      // TODO add more!\n    };\n    function vkFormatToGPUFormat(vkFormat) {\n      const format = vkFormatToGPUFormatMap[vkFormat];\n      if (format) {\n        return format;\n      }\n      throw new Error(`Unsupported VkFormat: ${vkFormat}`);\n    }\n\n    function getTextureFormatFromKTXTexture(ktxTexture) {\n      if (ktxTexture.classId === 2) {\n        return vkFormatToGPUFormat(ktxTexture.vkFormat);\n      }\n      return glFormatToGPUFormat(ktxTexture.glInternalformat);\n    }\n\n    const gpuFormatToBasisTranscoderFormatMap = {\n      "bc3-rgba-unorm": "BC3_RGBA",\n      "bc7-rgba-unorm": "BC7_M5_RGBA",\n      "etc2-rgba8unorm": "ETC2_RGBA",\n      "astc-4x4-unorm": "ASTC_4x4_RGBA",\n      // Uncompressed\n      rgba8unorm: "RGBA32",\n      rg11b10ufloat: "R11F_G11F_B10F"\n    };\n    function gpuFormatToKTXBasisTranscoderFormat(transcoderFormat) {\n      const format = gpuFormatToBasisTranscoderFormatMap[transcoderFormat];\n      if (format) {\n        return format;\n      }\n      throw new Error(`Unsupported transcoderFormat: ${transcoderFormat}`);\n    }\n\n    const settings = {\n      jsUrl: "",\n      wasmUrl: ""\n    };\n    let basisTranscoderFormat;\n    let basisTranscodedTextureFormat;\n    let ktxPromise;\n    async function getKTX() {\n      if (!ktxPromise) {\n        const absoluteJsUrl = new URL(settings.jsUrl, location.origin).href;\n        const absoluteWasmUrl = new URL(settings.wasmUrl, location.origin).href;\n        importScripts(absoluteJsUrl);\n        ktxPromise = new Promise((resolve) => {\n          LIBKTX({\n            locateFile: (_file) => absoluteWasmUrl\n          }).then((libktx) => {\n            resolve(libktx);\n          });\n        });\n      }\n      return ktxPromise;\n    }\n    async function fetchKTXTexture(url, ktx) {\n      const ktx2Response = await fetch(url);\n      if (ktx2Response.ok) {\n        const ktx2ArrayBuffer = await ktx2Response.arrayBuffer();\n        return new ktx.ktxTexture(new Uint8Array(ktx2ArrayBuffer));\n      }\n      throw new Error(`Failed to load KTX(2) texture: ${url}`);\n    }\n    const preferredTranscodedFormat = [\n      "bc7-rgba-unorm",\n      "astc-4x4-unorm",\n      "etc2-rgba8unorm",\n      "bc3-rgba-unorm",\n      "rgba8unorm"\n    ];\n    async function load(url) {\n      const ktx = await getKTX();\n      const ktxTexture = await fetchKTXTexture(url, ktx);\n      let format;\n      if (ktxTexture.needsTranscoding) {\n        format = basisTranscodedTextureFormat;\n        const transcodeFormat = ktx.TranscodeTarget[basisTranscoderFormat];\n        const result = ktxTexture.transcodeBasis(transcodeFormat, 0);\n        if (result !== ktx.ErrorCode.SUCCESS) {\n          throw new Error("Unable to transcode basis texture.");\n        }\n      } else {\n        format = getTextureFormatFromKTXTexture(ktxTexture);\n      }\n      const levelBuffers = createLevelBuffersFromKTX(ktxTexture);\n      const textureOptions = {\n        width: ktxTexture.baseWidth,\n        height: ktxTexture.baseHeight,\n        format,\n        mipLevelCount: ktxTexture.numLevels,\n        resource: levelBuffers,\n        alphaMode: "no-premultiply-alpha"\n      };\n      convertFormatIfRequired(textureOptions);\n      return textureOptions;\n    }\n    async function init(jsUrl, wasmUrl, supportedTextures) {\n      if (jsUrl) settings.jsUrl = jsUrl;\n      if (wasmUrl) settings.wasmUrl = wasmUrl;\n      basisTranscodedTextureFormat = preferredTranscodedFormat.filter((format) => supportedTextures.includes(format))[0];\n      basisTranscoderFormat = gpuFormatToKTXBasisTranscoderFormat(basisTranscodedTextureFormat);\n      await getKTX();\n    }\n    const messageHandlers = {\n      init: async (data) => {\n        const { jsUrl, wasmUrl, supportedTextures } = data;\n        await init(jsUrl, wasmUrl, supportedTextures);\n      },\n      load: async (data) => {\n        try {\n          const textureOptions = await load(data.url);\n          return {\n            type: "load",\n            url: data.url,\n            success: true,\n            textureOptions,\n            transferables: textureOptions.resource?.map((arr) => arr.buffer)\n          };\n        } catch (e) {\n          throw e;\n        }\n      }\n    };\n    self.onmessage = (async (messageEvent) => {\n      const message = messageEvent.data;\n      try {\n        const response = await messageHandlers[message.type]?.(message);\n        if (response) {\n          self.postMessage(response, response.transferables);\n        }\n      } catch (err) {\n        self.postMessage({\n          type: "error",\n          err,\n          url: message.url\n        });\n      }\n    });\n\n})();\n';
var WORKER_URL4 = null;
var WorkerInstance4 = class {
  constructor() {
    if (!WORKER_URL4) {
      WORKER_URL4 = URL.createObjectURL(new Blob([WORKER_CODE4], { type: "application/javascript" }));
    }
    this.worker = new Worker(WORKER_URL4);
  }
};
WorkerInstance4.revokeObjectURL = function revokeObjectURL4() {
  if (WORKER_URL4) {
    URL.revokeObjectURL(WORKER_URL4);
    WORKER_URL4 = null;
  }
};

// node_modules/pixi.js/lib/compressed-textures/ktx2/utils/setKTXTranscoderPath.mjs
var ktxTranscoderUrls = {
  jsUrl: "https://cdn.jsdelivr.net/npm/pixi.js/transcoders/ktx/libktx.js",
  wasmUrl: "https://cdn.jsdelivr.net/npm/pixi.js/transcoders/ktx/libktx.wasm"
};
function setKTXTranscoderPath(config) {
  Object.assign(ktxTranscoderUrls, config);
}

// node_modules/pixi.js/lib/compressed-textures/ktx2/worker/loadKTX2onWorker.mjs
var ktxWorker;
var urlHash2 = {};
var errorHash = {};
function getKTX2Worker(supportedTextures) {
  if (!ktxWorker) {
    ktxWorker = new WorkerInstance4().worker;
    ktxWorker.onmessage = (messageEvent) => {
      const { err, success, url, textureOptions } = messageEvent.data;
      if (err) {
        errorHash[url](err);
        return;
      }
      if (!success) {
        console.warn("Failed to load KTX texture", url);
      }
      urlHash2[url](textureOptions);
    };
    ktxWorker.postMessage({
      type: "init",
      jsUrl: ktxTranscoderUrls.jsUrl,
      wasmUrl: ktxTranscoderUrls.wasmUrl,
      supportedTextures
    });
  }
  return ktxWorker;
}
function loadKTX2onWorker(url, supportedTextures) {
  const ktxWorker2 = getKTX2Worker(supportedTextures);
  return new Promise((resolve, reject) => {
    urlHash2[url] = resolve;
    errorHash[url] = reject;
    ktxWorker2.postMessage({ type: "load", url });
  });
}

// node_modules/pixi.js/lib/compressed-textures/ktx2/loadKTX2.mjs
var loadKTX2 = {
  extension: {
    type: ExtensionType.LoadParser,
    priority: LoaderParserPriority.High,
    name: "loadKTX2"
  },
  /** used for deprecation purposes */
  name: "loadKTX2",
  id: "ktx2",
  test(url) {
    return checkExtension(url, ".ktx2");
  },
  load(url, asset, loader) {
    return __async(this, null, function* () {
      const supportedTextures = yield getSupportedTextureFormats();
      const textureOptions = yield loadKTX2onWorker(url, supportedTextures);
      const compressedTextureSource = new CompressedSource(__spreadProps(__spreadValues({}, textureOptions), {
        resolution: asset.data?.resolution || getResolutionOfUrl(url)
      }));
      return createTexture(compressedTextureSource, loader, url);
    });
  },
  unload(texture) {
    return __async(this, null, function* () {
      if (Array.isArray(texture)) {
        texture.forEach((t) => t.destroy(true));
      } else {
        texture.destroy(true);
      }
    });
  }
};

// node_modules/pixi.js/lib/compressed-textures/ktx2/utils/convertFormatIfRequired.mjs
var converters = {
  rgb8unorm: {
    convertedFormat: "rgba8unorm",
    convertFunction: convertRGBtoRGBA
  },
  "rgb8unorm-srgb": {
    convertedFormat: "rgba8unorm-srgb",
    convertFunction: convertRGBtoRGBA
  }
};
function convertFormatIfRequired(textureOptions) {
  const format = textureOptions.format;
  if (converters[format]) {
    const convertFunction = converters[format].convertFunction;
    const levelBuffers = textureOptions.resource;
    for (let i = 0; i < levelBuffers.length; i++) {
      levelBuffers[i] = convertFunction(levelBuffers[i]);
    }
    textureOptions.format = converters[format].convertedFormat;
  }
}
function convertRGBtoRGBA(levelBuffer) {
  const pixelCount = levelBuffer.byteLength / 3;
  const levelBufferWithAlpha = new Uint32Array(pixelCount);
  for (let i = 0; i < pixelCount; ++i) {
    levelBufferWithAlpha[i] = levelBuffer[i * 3] + (levelBuffer[i * 3 + 1] << 8) + (levelBuffer[i * 3 + 2] << 16) + 4278190080;
  }
  return new Uint8Array(levelBufferWithAlpha.buffer);
}

// node_modules/pixi.js/lib/compressed-textures/ktx2/utils/createLevelBuffersFromKTX.mjs
function createLevelBuffersFromKTX(ktxTexture) {
  const levelBuffers = [];
  for (let i = 0; i < ktxTexture.numLevels; i++) {
    const imageData = ktxTexture.getImageData(i, 0, 0);
    const levelBuffer = new Uint8Array(imageData.byteLength);
    levelBuffer.set(imageData);
    levelBuffers.push(levelBuffer);
  }
  return levelBuffers;
}

// node_modules/pixi.js/lib/compressed-textures/ktx2/utils/glFormatToGPUFormat.mjs
var glFormatToGPUFormatMap = {
  6408: "rgba8unorm",
  32856: "bgra8unorm",
  //
  32857: "rgb10a2unorm",
  33189: "depth16unorm",
  33190: "depth24plus",
  33321: "r8unorm",
  33323: "rg8unorm",
  33325: "r16float",
  33326: "r32float",
  33327: "rg16float",
  33328: "rg32float",
  33329: "r8sint",
  33330: "r8uint",
  33331: "r16sint",
  33332: "r16uint",
  33333: "r32sint",
  33334: "r32uint",
  33335: "rg8sint",
  33336: "rg8uint",
  33337: "rg16sint",
  33338: "rg16uint",
  33339: "rg32sint",
  33340: "rg32uint",
  33778: "bc2-rgba-unorm",
  33779: "bc3-rgba-unorm",
  34836: "rgba32float",
  34842: "rgba16float",
  35056: "depth24plus-stencil8",
  35898: "rg11b10ufloat",
  35901: "rgb9e5ufloat",
  35907: "rgba8unorm-srgb",
  // bgra8unorm-srgb
  36012: "depth32float",
  36013: "depth32float-stencil8",
  36168: "stencil8",
  36208: "rgba32uint",
  36214: "rgba16uint",
  36220: "rgba8uint",
  36226: "rgba32sint",
  36232: "rgba16sint",
  36238: "rgba8sint",
  36492: "bc7-rgba-unorm",
  36756: "r8snorm",
  36757: "rg8snorm",
  36759: "rgba8snorm",
  37496: "etc2-rgba8unorm",
  37808: "astc-4x4-unorm"
};
function glFormatToGPUFormat(glInternalFormat) {
  const format = glFormatToGPUFormatMap[glInternalFormat];
  if (format) {
    return format;
  }
  throw new Error(`Unsupported glInternalFormat: ${glInternalFormat}`);
}

// node_modules/pixi.js/lib/compressed-textures/ktx2/utils/vkFormatToGPUFormat.mjs
var vkFormatToGPUFormatMap = {
  23: "rgb8unorm",
  // VK_FORMAT_R8G8B8_UNORM
  37: "rgba8unorm",
  // VK_FORMAT_R8G8B8A8_UNORM
  43: "rgba8unorm-srgb"
  // VK_FORMAT_R8G8B8A8_SRGB
  // TODO add more!
};
function vkFormatToGPUFormat(vkFormat) {
  const format = vkFormatToGPUFormatMap[vkFormat];
  if (format) {
    return format;
  }
  throw new Error(`Unsupported VkFormat: ${vkFormat}`);
}

// node_modules/pixi.js/lib/compressed-textures/ktx2/utils/getTextureFormatFromKTXTexture.mjs
function getTextureFormatFromKTXTexture(ktxTexture) {
  if (ktxTexture.classId === 2) {
    return vkFormatToGPUFormat(ktxTexture.vkFormat);
  }
  return glFormatToGPUFormat(ktxTexture.glInternalformat);
}

// node_modules/pixi.js/lib/compressed-textures/ktx2/utils/gpuFormatToKTXBasisTranscoderFormat.mjs
var gpuFormatToBasisTranscoderFormatMap2 = {
  "bc3-rgba-unorm": "BC3_RGBA",
  "bc7-rgba-unorm": "BC7_M5_RGBA",
  "etc2-rgba8unorm": "ETC2_RGBA",
  "astc-4x4-unorm": "ASTC_4x4_RGBA",
  // Uncompressed
  rgba8unorm: "RGBA32",
  rg11b10ufloat: "R11F_G11F_B10F"
};
function gpuFormatToKTXBasisTranscoderFormat(transcoderFormat) {
  const format = gpuFormatToBasisTranscoderFormatMap2[transcoderFormat];
  if (format) {
    return format;
  }
  throw new Error(`Unsupported transcoderFormat: ${transcoderFormat}`);
}

// node_modules/pixi.js/lib/compressed-textures/shared/resolveCompressedTextureUrl.mjs
var validFormats = ["basis", "bc7", "bc6h", "astc", "etc2", "bc5", "bc4", "bc3", "bc2", "bc1", "eac"];
var resolveCompressedTextureUrl = {
  extension: ExtensionType.ResolveParser,
  test: (value) => checkExtension(value, [".ktx", ".ktx2", ".dds"]),
  parse: (value) => {
    let format;
    const splitValue = value.split(".");
    if (splitValue.length > 2) {
      const newFormat = splitValue[splitValue.length - 2];
      if (validFormats.includes(newFormat)) {
        format = newFormat;
      }
    } else {
      format = splitValue[splitValue.length - 1];
    }
    return {
      resolution: parseFloat(Resolver.RETINA_PREFIX.exec(value)?.[1] ?? "1"),
      format,
      src: value
    };
  }
};

// node_modules/pixi.js/lib/compressed-textures/shared/detectCompressed.mjs
var compressedTextureExtensions;
var detectCompressed = {
  extension: {
    type: ExtensionType.DetectionParser,
    priority: 2
  },
  test: () => __async(null, null, function* () {
    if (yield isWebGPUSupported()) return true;
    if (isWebGLSupported()) return true;
    return false;
  }),
  add: (formats) => __async(null, null, function* () {
    const supportedCompressedTextureFormats2 = yield getSupportedCompressedTextureFormats();
    compressedTextureExtensions = extractExtensionsForCompressedTextureFormats(supportedCompressedTextureFormats2);
    return [...compressedTextureExtensions, ...formats];
  }),
  remove: (formats) => __async(null, null, function* () {
    if (compressedTextureExtensions) {
      return formats.filter((f) => !(f in compressedTextureExtensions));
    }
    return formats;
  })
};
function extractExtensionsForCompressedTextureFormats(formats) {
  const extensions2 = ["basis"];
  const dupeMap = {};
  formats.forEach((format) => {
    const extension = format.split("-")[0];
    if (extension && !dupeMap[extension]) {
      dupeMap[extension] = true;
      extensions2.push(extension);
    }
  });
  extensions2.sort((a, b) => {
    const aIndex = validFormats.indexOf(a);
    const bIndex = validFormats.indexOf(b);
    if (aIndex === -1) {
      return 1;
    }
    if (bIndex === -1) {
      return -1;
    }
    return aIndex - bIndex;
  });
  return extensions2;
}

// node_modules/pixi.js/lib/culling/Culler.mjs
var tempBounds = new Bounds();
var tempMatrix = new Matrix();
var tempRectangle = new Rectangle();
var _Culler = class _Culler2 {
  /**
   * Culls the children of a specific container based on the given view rectangle.
   * This determines which objects should be rendered and which can be skipped.
   * @param container - The container to cull. Must be a Container instance.
   * @param view - The view rectangle that defines the visible area
   * @param skipUpdateTransform - Whether to skip updating transforms for better performance
   * @example
   * ```ts
   * // Basic culling with view bounds
   * const culler = new Culler();
   * culler.cull(stage, {
   *     x: 0,
   *     y: 0,
   *     width: 800,
   *     height: 600
   * });
   *
   * // Culling to renderer screen
   * culler.cull(stage, renderer.screen, false);
   * ```
   * @remarks
   * - Recursively processes all cullable children
   * - Uses cullArea if defined, otherwise calculates bounds
   * - Performance depends on scene complexity
   * @see {@link CullingMixinConstructor.cullable} For enabling culling on objects
   * @see {@link CullingMixinConstructor.cullArea} For custom culling boundaries
   */
  cull(container, view, skipUpdateTransform = true) {
    this._cullRecursive(container, view, skipUpdateTransform);
  }
  _cullRecursive(container, view, skipUpdateTransform = true) {
    if (container.cullable && container.measurable && container.includeInBuild) {
      if (container.cullArea) {
        tempRectangle.x = view.x;
        tempRectangle.y = view.y;
        tempRectangle.width = view.width;
        tempRectangle.height = view.height;
        const transform2 = skipUpdateTransform ? container.worldTransform : container.getGlobalTransform(tempMatrix, skipUpdateTransform);
        container.culled = !tempRectangle.intersects(
          container.cullArea,
          transform2
        );
      } else {
        const bounds = getGlobalBounds(container, skipUpdateTransform, tempBounds);
        container.culled = bounds.x >= view.x + view.width || bounds.y >= view.y + view.height || bounds.x + bounds.width <= view.x || bounds.y + bounds.height <= view.y;
      }
    } else {
      container.culled = false;
    }
    if (!container.cullableChildren || container.culled || !container.renderable || !container.measurable || !container.includeInBuild) return;
    for (let i = 0; i < container.children.length; i++) {
      this._cullRecursive(container.children[i], view, skipUpdateTransform);
    }
  }
};
_Culler.shared = new _Culler();
var Culler = _Culler;

// node_modules/pixi.js/lib/culling/CullerPlugin.mjs
var CullerPlugin = class {
  /**
   * Initialize the plugin with scope of application instance
   * @private
   * @param {object} [options] - See application options
   */
  static init(options) {
    this._renderRef = this.render.bind(this);
    this.render = () => {
      const updateTransform = options?.culler?.updateTransform !== true;
      Culler.shared.cull(this.stage, this.renderer.screen, updateTransform);
      this.renderer.render({ container: this.stage });
    };
  }
  /** @internal */
  static destroy() {
    this.render = this._renderRef;
  }
};
CullerPlugin.extension = {
  priority: 10,
  type: ExtensionType.Application,
  name: "culler"
};

// node_modules/pixi.js/lib/environment-webworker/WebWorkerAdapter.mjs
var import_xmldom = __toESM(require_lib(), 1);
var WebWorkerAdapter = {
  createCanvas: (width, height) => new OffscreenCanvas(width ?? 0, height ?? 0),
  createImage: () => new Image(),
  getCanvasRenderingContext2D: () => OffscreenCanvasRenderingContext2D,
  getWebGLRenderingContext: () => WebGLRenderingContext,
  getNavigator: () => navigator,
  getBaseUrl: () => globalThis.location.href,
  getFontFaceSet: () => globalThis.fonts,
  fetch: (url, options) => fetch(url, options),
  parseXML: (xml) => {
    const parser = new import_xmldom.DOMParser();
    return parser.parseFromString(xml, "text/xml");
  }
};

// node_modules/pixi.js/lib/filters/defaults/alpha/alpha.frag.mjs
var fragment3 = "\nin vec2 vTextureCoord;\n\nout vec4 finalColor;\n\nuniform float uAlpha;\nuniform sampler2D uTexture;\n\nvoid main()\n{\n    finalColor =  texture(uTexture, vTextureCoord) * uAlpha;\n}\n";

// node_modules/pixi.js/lib/filters/defaults/alpha/alpha.wgsl.mjs
var source3 = "struct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct AlphaUniforms {\n  uAlpha:f32,\n};\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n\n@group(1) @binding(0) var<uniform> alphaUniforms : AlphaUniforms;\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>\n  };\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);  \n}\n\nfn getSize() -> vec2<f32>\n{\n  return gfu.uGlobalFrame.zw;\n}\n  \n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>, \n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition)\n  );\n}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n  @builtin(position) position: vec4<f32>\n) -> @location(0) vec4<f32> {\n \n    var sample = textureSample(uTexture, uSampler, uv);\n    \n    return sample * alphaUniforms.uAlpha;\n}";

// node_modules/pixi.js/lib/filters/defaults/alpha/AlphaFilter.mjs
var _AlphaFilter = class _AlphaFilter2 extends Filter {
  constructor(options) {
    options = __spreadValues(__spreadValues({}, _AlphaFilter2.defaultOptions), options);
    const gpuProgram3 = GpuProgram.from({
      vertex: {
        source: source3,
        entryPoint: "mainVertex"
      },
      fragment: {
        source: source3,
        entryPoint: "mainFragment"
      }
    });
    const glProgram3 = GlProgram.from({
      vertex,
      fragment: fragment3,
      name: "alpha-filter"
    });
    const _a = options, { alpha } = _a, rest = __objRest(_a, ["alpha"]);
    const alphaUniforms = new UniformGroup({
      uAlpha: { value: alpha, type: "f32" }
    });
    super(__spreadProps(__spreadValues({}, rest), {
      gpuProgram: gpuProgram3,
      glProgram: glProgram3,
      resources: {
        alphaUniforms
      }
    }));
  }
  /**
   * The alpha value of the filter.
   * Controls the transparency of the filtered display object.
   * @example
   * ```ts
   * // Create filter with initial alpha
   * const filter = new AlphaFilter({ alpha: 0.5 });
   *
   * // Update alpha value dynamically
   * filter.alpha = 0.8;
   * ```
   * @default 1
   * @remarks
   * - 0 = fully transparent
   * - 1 = fully opaque
   * - Values are clamped between 0 and 1
   */
  get alpha() {
    return this.resources.alphaUniforms.uniforms.uAlpha;
  }
  set alpha(value) {
    this.resources.alphaUniforms.uniforms.uAlpha = value;
  }
};
_AlphaFilter.defaultOptions = {
  /**
   * Amount of alpha transparency to apply.
   * - 0 = fully transparent
   * - 1 = fully opaque (default)
   * @default 1
   */
  alpha: 1
};
var AlphaFilter = _AlphaFilter;

// node_modules/pixi.js/lib/filters/defaults/blur/const.mjs
var GAUSSIAN_VALUES = {
  5: [0.153388, 0.221461, 0.250301],
  7: [0.071303, 0.131514, 0.189879, 0.214607],
  9: [0.028532, 0.067234, 0.124009, 0.179044, 0.20236],
  11: [93e-4, 0.028002, 0.065984, 0.121703, 0.175713, 0.198596],
  13: [2406e-6, 9255e-6, 0.027867, 0.065666, 0.121117, 0.174868, 0.197641],
  15: [489e-6, 2403e-6, 9246e-6, 0.02784, 0.065602, 0.120999, 0.174697, 0.197448]
};

// node_modules/pixi.js/lib/filters/defaults/blur/gl/generateBlurFragSource.mjs
var fragTemplate = [
  "in vec2 vBlurTexCoords[%size%];",
  "uniform sampler2D uTexture;",
  "uniform vec4 uInputClamp;",
  "out vec4 finalColor;",
  "void main(void)",
  "{",
  "    %blur%",
  "}"
].join("\n");
function generateBlurFragSource(kernelSize) {
  const kernel = GAUSSIAN_VALUES[kernelSize];
  const halfLength = kernel.length;
  let blurLoop = "";
  const prefixFirst = "finalColor = ";
  const prefixRest = "    + ";
  const template = "texture(uTexture, clamp(vBlurTexCoords[%index%], uInputClamp.xy, uInputClamp.zw)) * %value%";
  for (let i = 0; i < kernelSize; i++) {
    const prefix = i === 0 ? prefixFirst : prefixRest;
    const value = i < halfLength ? i : kernelSize - i - 1;
    const blur = template.replace("%index%", i.toString()).replace("%value%", kernel[value].toString());
    blurLoop += `${prefix}${blur}
`;
  }
  return fragTemplate.replace("%blur%", `${blurLoop};`).replace("%size%", kernelSize.toString());
}

// node_modules/pixi.js/lib/filters/defaults/blur/gl/generateBlurVertSource.mjs
var vertTemplate = `
    in vec2 aPosition;

    uniform float uStrength;

    out vec2 vBlurTexCoords[%size%];

    uniform vec4 uInputSize;
    uniform vec4 uOutputFrame;
    uniform vec4 uOutputTexture;

    vec4 filterVertexPosition( void )
{
    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;

    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;
    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;

    return vec4(position, 0.0, 1.0);
}

    vec2 filterTextureCoord( void )
    {
        return aPosition * (uOutputFrame.zw * uInputSize.zw);
    }

    void main(void)
    {
        gl_Position = filterVertexPosition();

        float pixelStrength = uInputSize.%dimension% * uStrength;

        vec2 textureCoord = filterTextureCoord();
        %blur%
    }`;
function generateBlurVertSource(kernelSize, x) {
  const halfLength = Math.ceil(kernelSize / 2);
  let vertSource = vertTemplate;
  let blurLoop = "";
  let template;
  if (x) {
    template = "vBlurTexCoords[%index%] =  textureCoord + vec2(%sampleIndex% * pixelStrength, 0.0);";
  } else {
    template = "vBlurTexCoords[%index%] =  textureCoord + vec2(0.0, %sampleIndex% * pixelStrength);";
  }
  for (let i = 0; i < kernelSize; i++) {
    let blur = template.replace("%index%", i.toString());
    blur = blur.replace("%sampleIndex%", `${i - (halfLength - 1)}.0`);
    blurLoop += blur;
    blurLoop += "\n";
  }
  vertSource = vertSource.replace("%blur%", blurLoop);
  vertSource = vertSource.replace("%size%", kernelSize.toString());
  vertSource = vertSource.replace("%dimension%", x ? "z" : "w");
  return vertSource;
}

// node_modules/pixi.js/lib/filters/defaults/blur/gl/generateBlurGlProgram.mjs
function generateBlurGlProgram(horizontal, kernelSize) {
  const vertex5 = generateBlurVertSource(kernelSize, horizontal);
  const fragment8 = generateBlurFragSource(kernelSize);
  return GlProgram.from({
    vertex: vertex5,
    fragment: fragment8,
    name: `blur-${horizontal ? "horizontal" : "vertical"}-pass-filter`
  });
}

// node_modules/pixi.js/lib/filters/defaults/blur/gpu/blur-template.wgsl.mjs
var source4 = "\n\nstruct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct BlurUniforms {\n  uStrength:f32,\n};\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n\n@group(1) @binding(0) var<uniform> blurUniforms : BlurUniforms;\n\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    %blur-struct%\n  };\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);\n}\n\nfn getSize() -> vec2<f32>\n{\n  return gfu.uGlobalFrame.zw;\n}\n\n\n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>,\n) -> VSOutput {\n\n  let filteredCord = filterTextureCoord(aPosition);\n\n  let pixelStrength = gfu.uInputSize.%dimension% * blurUniforms.uStrength;\n\n  return VSOutput(\n   filterVertexPosition(aPosition),\n    %blur-vertex-out%\n  );\n}\n\n@fragment\nfn mainFragment(\n  @builtin(position) position: vec4<f32>,\n  %blur-fragment-in%\n) -> @location(0) vec4<f32> {\n\n    var   finalColor = vec4(0.0);\n\n    %blur-sampling%\n\n    return finalColor;\n}\n";

// node_modules/pixi.js/lib/filters/defaults/blur/gpu/generateBlurProgram.mjs
function generateBlurProgram(horizontal, kernelSize) {
  const kernel = GAUSSIAN_VALUES[kernelSize];
  const halfLength = kernel.length;
  const blurStructSource = [];
  const blurOutSource = [];
  const blurSamplingSource = [];
  for (let i = 0; i < kernelSize; i++) {
    blurStructSource[i] = `@location(${i}) offset${i}: vec2<f32>,`;
    if (horizontal) {
      blurOutSource[i] = `filteredCord + vec2(${i - halfLength + 1} * pixelStrength, 0.0),`;
    } else {
      blurOutSource[i] = `filteredCord + vec2(0.0, ${i - halfLength + 1} * pixelStrength),`;
    }
    const kernelIndex = i < halfLength ? i : kernelSize - i - 1;
    const kernelValue = kernel[kernelIndex].toString();
    blurSamplingSource[i] = `finalColor += textureSample(uTexture, uSampler,
            clamp(offset${i}, gfu.uInputClamp.xy, gfu.uInputClamp.zw)) * ${kernelValue};`;
  }
  const blurStruct = blurStructSource.join("\n");
  const blurOut = blurOutSource.join("\n");
  const blurSampling = blurSamplingSource.join("\n");
  const finalSource = source4.replace("%blur-struct%", blurStruct).replace("%blur-vertex-out%", blurOut).replace("%blur-fragment-in%", blurStruct).replace("%blur-sampling%", blurSampling).replace("%dimension%", horizontal ? "z" : "w");
  return GpuProgram.from({
    vertex: {
      source: finalSource,
      entryPoint: "mainVertex"
    },
    fragment: {
      source: finalSource,
      entryPoint: "mainFragment"
    }
  });
}

// node_modules/pixi.js/lib/filters/defaults/blur/BlurFilterPass.mjs
var _BlurFilterPass = class _BlurFilterPass2 extends Filter {
  /**
   * @param options
   * @param options.horizontal - Do pass along the x-axis (`true`) or y-axis (`false`).
   * @param options.strength - The strength of the blur filter.
   * @param options.quality - The quality of the blur filter.
   * @param options.kernelSize - The kernelSize of the blur filter.Options: 5, 7, 9, 11, 13, 15.
   */
  constructor(options) {
    options = __spreadValues(__spreadValues({}, _BlurFilterPass2.defaultOptions), options);
    const glProgram3 = generateBlurGlProgram(options.horizontal, options.kernelSize);
    const gpuProgram3 = generateBlurProgram(options.horizontal, options.kernelSize);
    super(__spreadValues({
      glProgram: glProgram3,
      gpuProgram: gpuProgram3,
      resources: {
        blurUniforms: {
          uStrength: { value: 0, type: "f32" }
        }
      }
    }, options));
    this.horizontal = options.horizontal;
    this.legacy = options.legacy ?? false;
    this._quality = 0;
    this.quality = options.quality;
    this.blur = options.strength;
    this._blurUniforms = this.resources.blurUniforms;
    this._uniforms = this._blurUniforms.uniforms;
  }
  /**
   * Applies the filter.
   * @param filterManager - The manager.
   * @param input - The input target.
   * @param output - The output target.
   * @param clearMode - How to clear
   */
  apply(filterManager, input, output, clearMode) {
    if (this.legacy) {
      this._applyLegacy(filterManager, input, output, clearMode);
    } else {
      this._applyOptimized(filterManager, input, output, clearMode);
    }
  }
  _applyLegacy(filterManager, input, output, clearMode) {
    this._uniforms.uStrength = this.strength / this.passes;
    if (this.passes === 1) {
      filterManager.applyFilter(this, input, output, clearMode);
    } else {
      const tempTexture = TexturePool.getSameSizeTexture(input);
      let flip = input;
      let flop = tempTexture;
      this._state.blend = false;
      const shouldClear = filterManager.renderer.type === RendererType.WEBGPU;
      for (let i = 0; i < this.passes - 1; i++) {
        filterManager.applyFilter(this, flip, flop, i === 0 ? true : shouldClear);
        const temp = flop;
        flop = flip;
        flip = temp;
      }
      this._state.blend = true;
      filterManager.applyFilter(this, flip, output, clearMode);
      TexturePool.returnTexture(tempTexture);
    }
  }
  _applyOptimized(filterManager, input, output, clearMode) {
    this._uniforms.uStrength = this._calculateInitialStrength();
    if (this.passes === 1) {
      filterManager.applyFilter(this, input, output, clearMode);
    } else {
      const tempTexture = TexturePool.getSameSizeTexture(input);
      let flip = input;
      let flop = tempTexture;
      this._state.blend = false;
      const renderer = filterManager.renderer;
      const isWebGPU = renderer.type === RendererType.WEBGPU;
      const uboBatcher = isWebGPU ? renderer.renderPipes.uniformBatch : null;
      for (let i = 0; i < this.passes - 1; i++) {
        if (uboBatcher) {
          this.groups[1].setResource(uboBatcher.getUboResource(this._blurUniforms), 0);
        }
        filterManager.applyFilter(this, flip, flop, isWebGPU);
        const temp = flop;
        flop = flip;
        flip = temp;
        this._uniforms.uStrength *= 0.5;
      }
      if (uboBatcher) {
        this.groups[1].setResource(uboBatcher.getUboResource(this._blurUniforms), 0);
      }
      this._state.blend = true;
      filterManager.applyFilter(this, flip, output, clearMode);
      TexturePool.returnTexture(tempTexture);
    }
  }
  /**
   * Calculates the initial strength for the first blur pass so that the combined
   * effect of all passes matches the filter's target strength.
   *
   * Uses variance addition property: for Gaussian blurs, σ_combined² = Σσᵢ²
   * With halving scheme (s, s/2, s/4, ...), sum of squared coefficients = 4/3
   */
  _calculateInitialStrength() {
    let sumOfSquares = 1;
    let coefficient = 0.5;
    for (let i = 1; i < this.passes; i++) {
      sumOfSquares += coefficient * coefficient;
      coefficient *= 0.5;
    }
    return this.strength / Math.sqrt(sumOfSquares);
  }
  /**
   * Sets the strength of both the blur.
   * @default 16
   */
  get blur() {
    return this.strength;
  }
  set blur(value) {
    this.padding = 1 + Math.abs(value) * 2;
    this.strength = value;
  }
  /**
   * Sets the quality of the blur by modifying the number of passes. More passes means higher
   * quality blurring but the lower the performance.
   * @default 4
   */
  get quality() {
    return this._quality;
  }
  set quality(value) {
    this._quality = value;
    this.passes = value;
  }
};
_BlurFilterPass.defaultOptions = {
  /** The strength of the blur filter. */
  strength: 8,
  /** The quality of the blur filter. */
  quality: 4,
  /** The kernelSize of the blur filter.Options: 5, 7, 9, 11, 13, 15. */
  kernelSize: 5,
  /** Whether to use legacy blur pass behavior. */
  legacy: false
};
var BlurFilterPass = _BlurFilterPass;

// node_modules/pixi.js/lib/filters/defaults/blur/BlurFilter.mjs
var BlurFilter = class extends Filter {
  constructor(...args) {
    let options = args[0] ?? {};
    if (typeof options === "number") {
      deprecation(v8_0_0, "BlurFilter constructor params are now options object. See params: { strength, quality, resolution, kernelSize }");
      options = { strength: options };
      if (args[1] !== void 0) options.quality = args[1];
      if (args[2] !== void 0) options.resolution = args[2] || "inherit";
      if (args[3] !== void 0) options.kernelSize = args[3];
    }
    options = __spreadValues(__spreadValues({}, BlurFilterPass.defaultOptions), options);
    const _a = options, { strength, strengthX, strengthY, quality } = _a, rest = __objRest(_a, ["strength", "strengthX", "strengthY", "quality"]);
    super(__spreadProps(__spreadValues({}, rest), {
      compatibleRenderers: RendererType.BOTH,
      resources: {}
    }));
    this._repeatEdgePixels = false;
    this.blurXFilter = new BlurFilterPass(__spreadValues({ horizontal: true }, options));
    this.blurYFilter = new BlurFilterPass(__spreadValues({ horizontal: false }, options));
    this.quality = quality;
    this.strengthX = strengthX ?? strength;
    this.strengthY = strengthY ?? strength;
    this.repeatEdgePixels = false;
  }
  /**
   * Applies the filter.
   * @param filterManager - The manager.
   * @param input - The input target.
   * @param output - The output target.
   * @param clearMode - How to clear
   * @advanced
   */
  apply(filterManager, input, output, clearMode) {
    const xStrength = Math.abs(this.blurXFilter.strength);
    const yStrength = Math.abs(this.blurYFilter.strength);
    if (xStrength && yStrength) {
      const tempTexture = TexturePool.getSameSizeTexture(input);
      this.blurXFilter.blendMode = "normal";
      this.blurXFilter.apply(filterManager, input, tempTexture, true);
      this.blurYFilter.blendMode = this.blendMode;
      this.blurYFilter.apply(filterManager, tempTexture, output, clearMode);
      TexturePool.returnTexture(tempTexture);
    } else if (yStrength) {
      this.blurYFilter.blendMode = this.blendMode;
      this.blurYFilter.apply(filterManager, input, output, clearMode);
    } else {
      this.blurXFilter.blendMode = this.blendMode;
      this.blurXFilter.apply(filterManager, input, output, clearMode);
    }
  }
  updatePadding() {
    if (this._repeatEdgePixels) {
      this.padding = 0;
    } else {
      this.padding = Math.max(Math.abs(this.blurXFilter.blur), Math.abs(this.blurYFilter.blur)) * 2;
    }
  }
  /**
   * Sets the strength of both the blurX and blurY properties simultaneously.
   * Controls the overall intensity of the Gaussian blur effect.
   * @example
   * ```ts
   * // Set equal blur strength for both axes
   * filter.strength = 8;
   *
   * // Will throw error if X and Y are different
   * filter.strengthX = 4;
   * filter.strengthY = 8;
   * filter.strength; // Error: BlurFilter's strengthX and strengthY are different
   * ```
   * @default 8
   * @throws {Error} If strengthX and strengthY are different values
   */
  get strength() {
    if (this.strengthX !== this.strengthY) {
      throw new Error("BlurFilter's strengthX and strengthY are different");
    }
    return this.strengthX;
  }
  set strength(value) {
    this.blurXFilter.blur = this.blurYFilter.blur = value;
    this.updatePadding();
  }
  /**
   * Sets the number of passes for blur. More passes means higher quality blurring.
   * Controls the precision and smoothness of the blur effect at the cost of performance.
   * @example
   * ```ts
   * // High quality blur (slower)
   * filter.quality = 8;
   *
   * // Low quality blur (faster)
   * filter.quality = 2;
   * ```
   * @default 4
   * @remarks Higher values produce better quality but impact performance
   */
  get quality() {
    return this.blurXFilter.quality;
  }
  set quality(value) {
    this.blurXFilter.quality = this.blurYFilter.quality = value;
  }
  /**
   * Sets the strength of horizontal blur.
   * Controls the blur intensity along the x-axis independently.
   * @example
   * ```ts
   * // Apply horizontal-only blur
   * filter.strengthX = 8;
   * filter.strengthY = 0;
   *
   * // Create motion blur effect
   * filter.strengthX = 16;
   * filter.strengthY = 2;
   * ```
   * @default 8
   */
  get strengthX() {
    return this.blurXFilter.blur;
  }
  set strengthX(value) {
    this.blurXFilter.blur = value;
    this.updatePadding();
  }
  /**
   * Sets the strength of the vertical blur.
   * Controls the blur intensity along the y-axis independently.
   * @example
   * ```ts
   * // Apply vertical-only blur
   * filter.strengthX = 0;
   * filter.strengthY = 8;
   *
   * // Create radial blur effect
   * filter.strengthX = 8;
   * filter.strengthY = 8;
   * ```
   * @default 8
   */
  get strengthY() {
    return this.blurYFilter.blur;
  }
  set strengthY(value) {
    this.blurYFilter.blur = value;
    this.updatePadding();
  }
  /**
   * Sets the strength of both the blurX and blurY properties simultaneously
   * @default 2
   * @deprecated since 8.3.0
   * @see BlurFilter.strength
   */
  get blur() {
    deprecation("8.3.0", "BlurFilter.blur is deprecated, please use BlurFilter.strength instead.");
    return this.strength;
  }
  set blur(value) {
    deprecation("8.3.0", "BlurFilter.blur is deprecated, please use BlurFilter.strength instead.");
    this.strength = value;
  }
  /**
   * Sets the strength of the blurX property
   * @default 2
   * @deprecated since 8.3.0
   * @see BlurFilter.strengthX
   */
  get blurX() {
    deprecation("8.3.0", "BlurFilter.blurX is deprecated, please use BlurFilter.strengthX instead.");
    return this.strengthX;
  }
  set blurX(value) {
    deprecation("8.3.0", "BlurFilter.blurX is deprecated, please use BlurFilter.strengthX instead.");
    this.strengthX = value;
  }
  /**
   * Sets the strength of the blurY property
   * @default 2
   * @deprecated since 8.3.0
   * @see BlurFilter.strengthY
   */
  get blurY() {
    deprecation("8.3.0", "BlurFilter.blurY is deprecated, please use BlurFilter.strengthY instead.");
    return this.strengthY;
  }
  set blurY(value) {
    deprecation("8.3.0", "BlurFilter.blurY is deprecated, please use BlurFilter.strengthY instead.");
    this.strengthY = value;
  }
  /**
   * If set to true the edge of the target will be clamped
   * @default false
   */
  get repeatEdgePixels() {
    return this._repeatEdgePixels;
  }
  set repeatEdgePixels(value) {
    this._repeatEdgePixels = value;
    this.updatePadding();
  }
};
BlurFilter.defaultOptions = {
  /** The strength of the blur filter. */
  strength: 8,
  /** The quality of the blur filter. */
  quality: 4,
  /** The kernelSize of the blur filter.Options: 5, 7, 9, 11, 13, 15. */
  kernelSize: 5,
  /** Whether to use legacy blur pass behavior. */
  legacy: false
};

// node_modules/pixi.js/lib/filters/defaults/color-matrix/colorMatrixFilter.frag.mjs
var fragment4 = "\nin vec2 vTextureCoord;\nin vec4 vColor;\n\nout vec4 finalColor;\n\nuniform float uColorMatrix[20];\nuniform float uAlpha;\n\nuniform sampler2D uTexture;\n\nfloat rand(vec2 co)\n{\n    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);\n}\n\nvoid main()\n{\n    vec4 color = texture(uTexture, vTextureCoord);\n    float randomValue = rand(gl_FragCoord.xy * 0.2);\n    float diff = (randomValue - 0.5) *  0.5;\n\n    if (uAlpha == 0.0) {\n        finalColor = color;\n        return;\n    }\n\n    if (color.a > 0.0) {\n        color.rgb /= color.a;\n    }\n\n    vec4 result;\n\n    result.r = (uColorMatrix[0] * color.r);\n        result.r += (uColorMatrix[1] * color.g);\n        result.r += (uColorMatrix[2] * color.b);\n        result.r += (uColorMatrix[3] * color.a);\n        result.r += uColorMatrix[4];\n\n    result.g = (uColorMatrix[5] * color.r);\n        result.g += (uColorMatrix[6] * color.g);\n        result.g += (uColorMatrix[7] * color.b);\n        result.g += (uColorMatrix[8] * color.a);\n        result.g += uColorMatrix[9];\n\n    result.b = (uColorMatrix[10] * color.r);\n       result.b += (uColorMatrix[11] * color.g);\n       result.b += (uColorMatrix[12] * color.b);\n       result.b += (uColorMatrix[13] * color.a);\n       result.b += uColorMatrix[14];\n\n    result.a = (uColorMatrix[15] * color.r);\n       result.a += (uColorMatrix[16] * color.g);\n       result.a += (uColorMatrix[17] * color.b);\n       result.a += (uColorMatrix[18] * color.a);\n       result.a += uColorMatrix[19];\n\n    vec3 rgb = mix(color.rgb, result.rgb, uAlpha);\n\n    // Premultiply alpha again.\n    rgb *= result.a;\n\n    finalColor = vec4(rgb, result.a);\n}\n";

// node_modules/pixi.js/lib/filters/defaults/color-matrix/colorMatrixFilter.wgsl.mjs
var source5 = "struct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct ColorMatrixUniforms {\n  uColorMatrix:array<vec4<f32>, 5>,\n  uAlpha:f32,\n};\n\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n@group(1) @binding(0) var<uniform> colorMatrixUniforms : ColorMatrixUniforms;\n\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>,\n  };\n  \nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>, \n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition),\n  );\n}\n\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n) -> @location(0) vec4<f32> {\n\n\n  var c = textureSample(uTexture, uSampler, uv);\n  \n  if (colorMatrixUniforms.uAlpha == 0.0) {\n    return c;\n  }\n\n \n    // Un-premultiply alpha before applying the color matrix. See issue #3539.\n    if (c.a > 0.0) {\n      c.r /= c.a;\n      c.g /= c.a;\n      c.b /= c.a;\n    }\n\n    var cm = colorMatrixUniforms.uColorMatrix;\n\n\n    var result = vec4<f32>(0.);\n\n    result.r = (cm[0][0] * c.r);\n    result.r += (cm[0][1] * c.g);\n    result.r += (cm[0][2] * c.b);\n    result.r += (cm[0][3] * c.a);\n    result.r += cm[1][0];\n\n    result.g = (cm[1][1] * c.r);\n    result.g += (cm[1][2] * c.g);\n    result.g += (cm[1][3] * c.b);\n    result.g += (cm[2][0] * c.a);\n    result.g += cm[2][1];\n\n    result.b = (cm[2][2] * c.r);\n    result.b += (cm[2][3] * c.g);\n    result.b += (cm[3][0] * c.b);\n    result.b += (cm[3][1] * c.a);\n    result.b += cm[3][2];\n\n    result.a = (cm[3][3] * c.r);\n    result.a += (cm[4][0] * c.g);\n    result.a += (cm[4][1] * c.b);\n    result.a += (cm[4][2] * c.a);\n    result.a += cm[4][3];\n\n    var rgb = mix(c.rgb, result.rgb, colorMatrixUniforms.uAlpha);\n\n    rgb.r *= result.a;\n    rgb.g *= result.a;\n    rgb.b *= result.a;\n\n    return vec4(rgb, result.a);\n}";

// node_modules/pixi.js/lib/filters/defaults/color-matrix/ColorMatrixFilter.mjs
var ColorMatrixFilter = class extends Filter {
  constructor(options = {}) {
    const colorMatrixUniforms = new UniformGroup({
      uColorMatrix: {
        value: [
          1,
          0,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          0,
          1,
          0
        ],
        type: "f32",
        size: 20
      },
      uAlpha: {
        value: 1,
        type: "f32"
      }
    });
    const gpuProgram3 = GpuProgram.from({
      vertex: {
        source: source5,
        entryPoint: "mainVertex"
      },
      fragment: {
        source: source5,
        entryPoint: "mainFragment"
      }
    });
    const glProgram3 = GlProgram.from({
      vertex,
      fragment: fragment4,
      name: "color-matrix-filter"
    });
    super(__spreadProps(__spreadValues({}, options), {
      gpuProgram: gpuProgram3,
      glProgram: glProgram3,
      resources: {
        colorMatrixUniforms
      }
    }));
    this.alpha = 1;
  }
  /**
   * Transforms current matrix and set the new one
   * @param {number[]} matrix - 5x4 matrix
   * @param multiply - if true, current matrix and matrix are multiplied. If false,
   *  just set the current matrix with matrix
   */
  _loadMatrix(matrix, multiply = false) {
    if (multiply) {
      const newMatrix = [...matrix];
      this._multiply(newMatrix, this.matrix, matrix);
      this.resources.colorMatrixUniforms.uniforms.uColorMatrix = newMatrix;
    } else {
      this.resources.colorMatrixUniforms.uniforms.uColorMatrix = matrix;
    }
    this.resources.colorMatrixUniforms.update();
  }
  /**
   * Multiplies two mat5's
   * @private
   * @param out - 5x4 matrix the receiving matrix
   * @param a - 5x4 matrix the first operand
   * @param b - 5x4 matrix the second operand
   * @returns {number[]} 5x4 matrix
   */
  _multiply(out, a, b) {
    out[0] = a[0] * b[0] + a[1] * b[5] + a[2] * b[10] + a[3] * b[15];
    out[1] = a[0] * b[1] + a[1] * b[6] + a[2] * b[11] + a[3] * b[16];
    out[2] = a[0] * b[2] + a[1] * b[7] + a[2] * b[12] + a[3] * b[17];
    out[3] = a[0] * b[3] + a[1] * b[8] + a[2] * b[13] + a[3] * b[18];
    out[4] = a[0] * b[4] + a[1] * b[9] + a[2] * b[14] + a[3] * b[19] + a[4];
    out[5] = a[5] * b[0] + a[6] * b[5] + a[7] * b[10] + a[8] * b[15];
    out[6] = a[5] * b[1] + a[6] * b[6] + a[7] * b[11] + a[8] * b[16];
    out[7] = a[5] * b[2] + a[6] * b[7] + a[7] * b[12] + a[8] * b[17];
    out[8] = a[5] * b[3] + a[6] * b[8] + a[7] * b[13] + a[8] * b[18];
    out[9] = a[5] * b[4] + a[6] * b[9] + a[7] * b[14] + a[8] * b[19] + a[9];
    out[10] = a[10] * b[0] + a[11] * b[5] + a[12] * b[10] + a[13] * b[15];
    out[11] = a[10] * b[1] + a[11] * b[6] + a[12] * b[11] + a[13] * b[16];
    out[12] = a[10] * b[2] + a[11] * b[7] + a[12] * b[12] + a[13] * b[17];
    out[13] = a[10] * b[3] + a[11] * b[8] + a[12] * b[13] + a[13] * b[18];
    out[14] = a[10] * b[4] + a[11] * b[9] + a[12] * b[14] + a[13] * b[19] + a[14];
    out[15] = a[15] * b[0] + a[16] * b[5] + a[17] * b[10] + a[18] * b[15];
    out[16] = a[15] * b[1] + a[16] * b[6] + a[17] * b[11] + a[18] * b[16];
    out[17] = a[15] * b[2] + a[16] * b[7] + a[17] * b[12] + a[18] * b[17];
    out[18] = a[15] * b[3] + a[16] * b[8] + a[17] * b[13] + a[18] * b[18];
    out[19] = a[15] * b[4] + a[16] * b[9] + a[17] * b[14] + a[18] * b[19] + a[19];
    return out;
  }
  /**
   * Adjusts the brightness of a display object.
   *
   * The brightness adjustment works by multiplying the RGB channels by a scalar value while keeping
   * the alpha channel unchanged. Values below 1 darken the image, while values above 1 brighten it.
   * @param b - The brightness multiplier to apply. Values between 0-1 darken the image (0 being black),
   *           while values > 1 brighten it (2.0 would make it twice as bright)
   * @param multiply - When true, the new matrix is multiplied with the current one instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * // Create a new color matrix filter
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Darken the image to 50% brightness
   * colorMatrix.brightness(0.5, false);
   *
   * // Chain with other effects by using multiply
   * colorMatrix
   *     .brightness(1.2, true)  // Brighten by 20%
   *     .saturate(1.1, true);   // Increase saturation by 10%
   * ```
   */
  brightness(b, multiply) {
    const matrix = [
      b,
      0,
      0,
      0,
      0,
      0,
      b,
      0,
      0,
      0,
      0,
      0,
      b,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Sets each channel on the diagonal of the color matrix to apply a color tint.
   *
   * This method provides a way to tint display objects using the color matrix filter, similar to
   * the tint property available on Sprites and other display objects. The tint is applied by
   * scaling the RGB channels of each pixel.
   * @param color - The color to use for tinting, this can be any valid color source.
   * @param multiply - When true, the new tint matrix is multiplied with the current matrix instead
   *                  of replacing it. This allows for combining tints with other color effects.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply a red tint
   * colorMatrix.tint(0xff0000);
   *
   * // Layer a green tint on top of existing effects
   * colorMatrix.tint('green', true);
   *
   * // Chain with other color adjustments
   * colorMatrix
   *     .tint('blue')       // Blue tint
   *     .brightness(1.2, true) // Increase brightness
   * ```
   */
  tint(color, multiply) {
    const [r, g, b] = Color.shared.setValue(color).toArray();
    const matrix = [
      r,
      0,
      0,
      0,
      0,
      0,
      g,
      0,
      0,
      0,
      0,
      0,
      b,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Converts the display object to greyscale by applying a weighted matrix transformation.
   *
   * The greyscale effect works by setting equal RGB values for each pixel based on the scale parameter,
   * effectively removing color information while preserving luminance.
   * @param scale - The intensity of the greyscale effect. Value between 0-1, where:
   *               - 0 produces black
   *               - 0.5 produces 50% grey
   *               - 1 produces white
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Convert to 50% grey
   * colorMatrix.greyscale(0.5, false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .greyscale(0.6, true)    // Add grey tint
   *     .brightness(1.2, true);   // Brighten the result
   * ```
   */
  greyscale(scale, multiply) {
    const matrix = [
      scale,
      scale,
      scale,
      0,
      0,
      scale,
      scale,
      scale,
      0,
      0,
      scale,
      scale,
      scale,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Converts the display object to grayscale by applying a weighted matrix transformation.
   *
   * The grayscale effect works by setting equal RGB values for each pixel based on the scale parameter,
   * effectively removing color information while preserving luminance.
   * @param scale - The intensity of the grayscale effect. Value between 0-1, where:
   *               - 0 produces black
   *               - 0.5 produces 50% grey
   *               - 1 produces white
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Convert to 50% grey
   * colorMatrix.grayscale(0.5, false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .grayscale(0.6, true)    // Add grey tint
   *     .brightness(1.2, true);   // Brighten the result
   * ```
   */
  grayscale(scale, multiply) {
    this.greyscale(scale, multiply);
  }
  /**
   * Converts the display object to pure black and white using a luminance-based threshold.
   *
   * This method applies a matrix transformation that removes all color information and reduces
   * the image to just black and white values based on the luminance of each pixel. The transformation
   * uses standard luminance weightings: 30% red, 60% green, and 10% blue.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Convert to black and white
   * colorMatrix.blackAndWhite(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .blackAndWhite(true)     // Apply B&W effect
   *     .brightness(1.2, true);   // Then increase brightness
   * ```
   */
  blackAndWhite(multiply) {
    const matrix = [
      0.3,
      0.6,
      0.1,
      0,
      0,
      0.3,
      0.6,
      0.1,
      0,
      0,
      0.3,
      0.6,
      0.1,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Adjusts the hue of the display object by rotating the color values around the color wheel.
   *
   * This method uses an optimized matrix transformation that accurately rotates the RGB color space
   * around its luminance axis. The implementation is based on RGB cube rotation in 3D space, providing
   * better results than traditional matrices with magic luminance constants.
   * @param rotation - The angle of rotation in degrees around the color wheel:
   *                  - 0 = no change
   *                  - 90 = rotate colors 90° clockwise
   *                  - 180 = invert all colors
   *                  - 270 = rotate colors 90° counter-clockwise
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Rotate hue by 90 degrees
   * colorMatrix.hue(90, false);
   *
   * // Chain multiple color adjustments
   * colorMatrix
   *     .hue(45, true)          // Rotate colors by 45°
   *     .saturate(1.2, true)    // Increase saturation
   *     .brightness(1.1, true); // Slightly brighten
   * ```
   */
  hue(rotation, multiply) {
    rotation = (rotation || 0) / 180 * Math.PI;
    const cosR = Math.cos(rotation);
    const sinR = Math.sin(rotation);
    const sqrt = Math.sqrt;
    const w = 1 / 3;
    const sqrW = sqrt(w);
    const a00 = cosR + (1 - cosR) * w;
    const a01 = w * (1 - cosR) - sqrW * sinR;
    const a02 = w * (1 - cosR) + sqrW * sinR;
    const a10 = w * (1 - cosR) + sqrW * sinR;
    const a11 = cosR + w * (1 - cosR);
    const a12 = w * (1 - cosR) - sqrW * sinR;
    const a20 = w * (1 - cosR) - sqrW * sinR;
    const a21 = w * (1 - cosR) + sqrW * sinR;
    const a22 = cosR + w * (1 - cosR);
    const matrix = [
      a00,
      a01,
      a02,
      0,
      0,
      a10,
      a11,
      a12,
      0,
      0,
      a20,
      a21,
      a22,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Adjusts the contrast of the display object by modifying the separation between dark and bright values.
   *
   * This method applies a matrix transformation that affects the difference between dark and light areas
   * in the image. Increasing contrast makes shadows darker and highlights brighter, while decreasing
   * contrast brings shadows up and highlights down, reducing the overall dynamic range.
   * @param amount - The contrast adjustment value. Range is 0 to 1, where:
   *                - 0 represents minimum contrast (flat gray)
   *                - 0.5 represents normal contrast
   *                - 1 represents maximum contrast
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Increase contrast by 50%
   * colorMatrix.contrast(0.75, false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .contrast(0.6, true)     // Boost contrast
   *     .brightness(1.1, true)   // Slightly brighten
   *     .saturate(1.2, true);    // Increase color intensity
   * ```
   */
  contrast(amount, multiply) {
    const v = (amount || 0) + 1;
    const o = -0.5 * (v - 1);
    const matrix = [
      v,
      0,
      0,
      0,
      o,
      0,
      v,
      0,
      0,
      o,
      0,
      0,
      v,
      0,
      o,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Adjusts the saturation of the display object by modifying color separation.
   *
   * This method applies a matrix transformation that affects the intensity of colors.
   * Increasing saturation makes colors more vivid and intense, while decreasing saturation
   * moves colors toward grayscale.
   * @param amount - The saturation adjustment value. Range is -1 to 1, where:
   *                - -1 produces grayscale
   *                - 0 represents no change
   *                - 1 produces maximum saturation
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Double the saturation
   * colorMatrix.saturate(1, false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .saturate(0.5, true)     // Increase saturation by 50%
   *     .brightness(1.1, true)    // Slightly brighten
   *     .contrast(0.8, true);     // Reduce contrast
   * ```
   */
  saturate(amount = 0, multiply) {
    const x = amount * 2 / 3 + 1;
    const y = (x - 1) * -0.5;
    const matrix = [
      x,
      y,
      y,
      0,
      0,
      y,
      x,
      y,
      0,
      0,
      y,
      y,
      x,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Completely removes color information from the display object, creating a grayscale version.
   *
   * This is a convenience method that calls `saturate(-1)` internally. The transformation preserves
   * the luminance of the original image while removing all color information.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Convert image to grayscale
   * colorMatrix.desaturate();
   *
   * // Can be chained with other effects
   * colorMatrix
   *     .desaturate()         // Remove all color
   *     .brightness(1.2);     // Then increase brightness
   * ```
   */
  desaturate() {
    this.saturate(-1);
  }
  /**
   * Creates a negative effect by inverting all colors in the display object.
   *
   * This method applies a matrix transformation that inverts the RGB values of each pixel
   * while preserving the alpha channel. The result is similar to a photographic negative.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Create negative effect
   * colorMatrix.negative(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .negative(true)       // Apply negative effect
   *     .brightness(1.2, true) // Increase brightness
   *     .contrast(0.8, true);  // Reduce contrast
   * ```
   */
  negative(multiply) {
    const matrix = [
      -1,
      0,
      0,
      1,
      0,
      0,
      -1,
      0,
      1,
      0,
      0,
      0,
      -1,
      1,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a sepia tone effect to the display object, creating a warm brown tint reminiscent of vintage photographs.
   *
   * This method applies a matrix transformation that converts colors to various shades of brown while
   * preserving the original luminance values.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply sepia effect
   * colorMatrix.sepia(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .sepia(true)           // Add sepia tone
   *     .brightness(1.1, true)  // Slightly brighten
   *     .contrast(0.9, true);   // Reduce contrast
   * ```
   */
  sepia(multiply) {
    const matrix = [
      0.393,
      0.7689999,
      0.18899999,
      0,
      0,
      0.349,
      0.6859999,
      0.16799999,
      0,
      0,
      0.272,
      0.5339999,
      0.13099999,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a Technicolor-style effect that simulates the early color motion picture process.
   *
   * This method applies a matrix transformation that recreates the distinctive look of the
   * Technicolor process. The effect produces highly
   * saturated colors with a particular emphasis on reds, greens, and blues.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply Technicolor effect
   * colorMatrix.technicolor(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .technicolor(true)      // Add Technicolor effect
   *     .contrast(1.1, true)    // Boost contrast
   *     .brightness(0.9, true); // Slightly darken
   * ```
   */
  technicolor(multiply) {
    const matrix = [
      1.9125277891456083,
      -0.8545344976951645,
      -0.09155508482755585,
      0,
      0.046249425232852304,
      -0.3087833385928097,
      1.7658908555458428,
      -0.10601743074722245,
      0,
      -0.2758903984886823,
      -0.231103377548616,
      -0.7501899197440212,
      1.847597816108189,
      0,
      0.12137623870388682,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a vintage Polaroid camera effect to the display object.
   *
   * This method applies a matrix transformation that simulates the distinctive look of
   * Polaroid instant photographs, characterized by slightly enhanced contrast, subtle color shifts,
   * and a warm overall tone.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply Polaroid effect
   * colorMatrix.polaroid(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .polaroid(true)         // Add Polaroid effect
   *     .brightness(1.1, true)  // Slightly brighten
   *     .contrast(1.1, true);   // Boost contrast
   * ```
   */
  polaroid(multiply) {
    const matrix = [
      1.438,
      -0.062,
      -0.062,
      0,
      0,
      -0.122,
      1.378,
      -0.122,
      0,
      0,
      -0.016,
      -0.016,
      1.483,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Swaps the red and blue color channels in the display object.
   *
   * This method applies a matrix transformation that exchanges the red and blue color values
   * while keeping the green channel and alpha unchanged.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Swap red and blue channels
   * colorMatrix.toBGR(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .toBGR(true)           // Swap R and B channels
   *     .brightness(1.1, true)  // Slightly brighten
   *     .contrast(0.9, true);   // Reduce contrast
   * ```
   */
  toBGR(multiply) {
    const matrix = [
      0,
      0,
      1,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a Kodachrome color effect that simulates the iconic film stock.
   *
   * This method applies a matrix transformation that recreates the distinctive look of Kodachrome film,
   * known for its rich, vibrant colors and excellent image preservation qualities. The effect emphasizes
   * reds and blues while producing deep, true blacks.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply Kodachrome effect
   * colorMatrix.kodachrome(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .kodachrome(true)       // Add Kodachrome effect
   *     .contrast(1.1, true)    // Boost contrast
   *     .brightness(0.9, true); // Slightly darken
   * ```
   */
  kodachrome(multiply) {
    const matrix = [
      1.1285582396593525,
      -0.3967382283601348,
      -0.03992559172921793,
      0,
      0.24991995145868634,
      -0.16404339962244616,
      1.0835251566291304,
      -0.05498805115633132,
      0,
      0.09698983488904393,
      -0.16786010706155763,
      -0.5603416277695248,
      1.6014850761964943,
      0,
      0.13972481597886063,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a stylized brown-tinted effect to the display object.
   *
   * This method applies a matrix transformation that creates a rich, warm brown tone
   * with enhanced contrast and subtle color shifts.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply browni effect
   * colorMatrix.browni(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .browni(true)          // Add brown tint
   *     .brightness(1.1, true)  // Slightly brighten
   *     .contrast(1.2, true);   // Boost contrast
   * ```
   */
  browni(multiply) {
    const matrix = [
      0.5997023498159715,
      0.34553243048391263,
      -0.2708298674538042,
      0,
      0.1860075629647401,
      -0.037703249837783157,
      0.8609577587992641,
      0.15059552388459913,
      0,
      -0.14497417640467167,
      0.24113635128153335,
      -0.07441037908422492,
      0.44972182064877153,
      0,
      -0.029655197167024642,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a vintage photo effect that simulates old photography techniques.
   *
   * This method applies a matrix transformation that creates a nostalgic, aged look
   * with muted colors, enhanced warmth, and subtle vignetting.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply vintage effect
   * colorMatrix.vintage(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .vintage(true)          // Add vintage look
   *     .brightness(0.9, true)  // Slightly darken
   *     .contrast(1.1, true);   // Boost contrast
   * ```
   */
  vintage(multiply) {
    const matrix = [
      0.6279345635605994,
      0.3202183420819367,
      -0.03965408211312453,
      0,
      0.037848179746251466,
      0.02578397704808868,
      0.6441188644374771,
      0.03259127616149294,
      0,
      0.029265996770472907,
      0.0466055556782719,
      -0.0851232987247891,
      0.5241648018700465,
      0,
      0.020232119953863904,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * We don't know exactly what it does, kind of gradient map, but funny to play with!
   * @param desaturation - Tone values.
   * @param toned - Tone values.
   * @param lightColor - Tone values, example: `0xFFE580`
   * @param darkColor - Tone values, example: `0xFFE580`
   * @param multiply - if true, current matrix and matrix are multiplied. If false,
   *  just set the current matrix with matrix
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Create sepia-like effect with custom colors
   * colorMatrix.colorTone(
   *     0.3,        // Moderate desaturation
   *     0.2,        // Moderate toning
   *     0xFFE580,   // Warm highlight color
   *     0x338000,   // Dark green shadows
   *     false
   * );
   *
   * // Chain with other effects
   * colorMatrix
   *     .colorTone(0.2, 0.15, 0xFFE580, 0x338000, true)
   *     .brightness(1.1, true);  // Slightly brighten
   * ```
   */
  colorTone(desaturation, toned, lightColor, darkColor, multiply) {
    desaturation || (desaturation = 0.2);
    toned || (toned = 0.15);
    lightColor || (lightColor = 16770432);
    darkColor || (darkColor = 3375104);
    const temp = Color.shared;
    const [lR, lG, lB] = temp.setValue(lightColor).toArray();
    const [dR, dG, dB] = temp.setValue(darkColor).toArray();
    const matrix = [
      0.3,
      0.59,
      0.11,
      0,
      0,
      lR,
      lG,
      lB,
      desaturation,
      0,
      dR,
      dG,
      dB,
      toned,
      0,
      lR - dR,
      lG - dG,
      lB - dB,
      0,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a night vision effect to the display object.
   *
   * This method applies a matrix transformation that simulates night vision by enhancing
   * certain color channels while suppressing others, creating a green-tinted effect
   * similar to night vision goggles.
   * @param intensity - The intensity of the night effect (0-1):
   *                   - 0 produces no effect
   *                   - 0.1 produces a subtle night vision effect (default)
   *                   - 1 produces maximum night vision effect
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply night vision effect
   * colorMatrix.night(0.3, false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .night(0.2, true)        // Add night vision
   *     .brightness(1.1, true)    // Slightly brighten
   *     .contrast(1.2, true);     // Boost contrast
   * ```
   */
  night(intensity, multiply) {
    intensity || (intensity = 0.1);
    const matrix = [
      intensity * -2,
      -intensity,
      0,
      0,
      0,
      -intensity,
      0,
      intensity,
      0,
      0,
      0,
      intensity,
      intensity * 2,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Predator effect
   *
   * Erase the current matrix by setting a new independent one
   * @param amount - how much the predator feels his future victim
   * @param multiply - if true, current matrix and matrix are multiplied. If false,
   *  just set the current matrix with matrix
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply thermal vision effect
   * colorMatrix.predator(0.5, false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .predator(0.3, true)      // Add thermal effect
   *     .contrast(1.2, true)      // Boost contrast
   *     .brightness(1.1, true);   // Slightly brighten
   * ```
   */
  predator(amount, multiply) {
    const matrix = [
      // row 1
      11.224130630493164 * amount,
      -4.794486999511719 * amount,
      -2.8746118545532227 * amount,
      0 * amount,
      0.40342438220977783 * amount,
      // row 2
      -3.6330697536468506 * amount,
      9.193157196044922 * amount,
      -2.951810836791992 * amount,
      0 * amount,
      -1.316135048866272 * amount,
      // row 3
      -3.2184197902679443 * amount,
      -4.2375030517578125 * amount,
      7.476448059082031 * amount,
      0 * amount,
      0.8044459223747253 * amount,
      // row 4
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Applies a psychedelic color effect that creates dramatic color shifts.
   *
   * This method applies a matrix transformation that produces vibrant colors
   * through channel mixing and amplification. Creates an effect reminiscent of
   * color distortions in psychedelic art.
   * @param multiply - When true, the new matrix is multiplied with the current matrix instead of replacing it.
   *                  This allows for cumulative effects when calling multiple color adjustments.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply psychedelic effect
   * colorMatrix.lsd(false);
   *
   * // Chain with other effects
   * colorMatrix
   *     .lsd(true)             // Add color distortion
   *     .brightness(0.9, true)  // Slightly darken
   *     .contrast(1.2, true);   // Boost contrast
   * ```
   */
  lsd(multiply) {
    const matrix = [
      2,
      -0.4,
      0.5,
      0,
      0,
      -0.5,
      2,
      -0.4,
      0,
      0,
      -0.4,
      -0.5,
      3,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, multiply);
  }
  /**
   * Resets the color matrix filter to its default state.
   *
   * This method resets all color transformations by setting the matrix back to its identity state.
   * The identity matrix leaves colors unchanged, effectively removing all previously applied effects.
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply some effects
   * colorMatrix
   *     .sepia(true)
   *     .brightness(1.2, true);
   *
   * // Reset back to original colors
   * colorMatrix.reset();
   * ```
   */
  reset() {
    const matrix = [
      1,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      1,
      0
    ];
    this._loadMatrix(matrix, false);
  }
  /**
   * The current color transformation matrix of the filter.
   *
   * This 5x4 matrix transforms RGBA color and alpha values of each pixel. The matrix is stored
   * as a 20-element array in row-major order.
   * @type {ColorMatrix}
   * @default [
   *     1, 0, 0, 0, 0,  // Red channel
   *     0, 1, 0, 0, 0,  // Green channel
   *     0, 0, 1, 0, 0,  // Blue channel
   *     0, 0, 0, 1, 0   // Alpha channel
   * ]
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   * // Get the current color matrix
   * const currentMatrix = colorMatrix.matrix;
   * // Modify the matrix
   * colorMatrix.matrix = [
   *     1, 0, 0, 0, 0,
   *     0, 1, 0, 0, 0,
   *     0, 0, 1, 0, 0,
   *     0, 0, 0, 1, 0
   * ];
   */
  get matrix() {
    return this.resources.colorMatrixUniforms.uniforms.uColorMatrix;
  }
  set matrix(value) {
    this.resources.colorMatrixUniforms.uniforms.uColorMatrix = value;
  }
  /**
   * The opacity value used to blend between the original and transformed colors.
   *
   * This value controls how much of the color transformation is applied:
   * - 0 = Original color only (no effect)
   * - 0.5 = 50% blend of original and transformed colors
   * - 1 = Fully transformed color (default)
   * @default 1
   * @example
   * ```ts
   * const colorMatrix = new ColorMatrixFilter();
   *
   * // Apply sepia at 50% strength
   * colorMatrix.sepia(false);
   * colorMatrix.alpha = 0.5;
   *
   * // Fade between effects
   * colorMatrix
   *     .saturate(1.5)      // Increase saturation
   *     .contrast(1.2);     // Boost contrast
   * colorMatrix.alpha = 0.7; // Apply at 70% strength
   * ```
   */
  get alpha() {
    return this.resources.colorMatrixUniforms.uniforms.uAlpha;
  }
  set alpha(value) {
    this.resources.colorMatrixUniforms.uniforms.uAlpha = value;
  }
};

// node_modules/pixi.js/lib/filters/defaults/displacement/displacement.frag.mjs
var fragment5 = "\nin vec2 vTextureCoord;\nin vec2 vFilterUv;\n\nout vec4 finalColor;\n\nuniform sampler2D uTexture;\nuniform sampler2D uMapTexture;\n\nuniform vec4 uInputClamp;\nuniform highp vec4 uInputSize;\nuniform mat2 uRotation;\nuniform vec2 uScale;\n\nvoid main()\n{\n    vec4 map = texture(uMapTexture, vFilterUv);\n    \n    vec2 offset = uInputSize.zw * (uRotation * (map.xy - 0.5)) * uScale; \n\n    finalColor = texture(uTexture, clamp(vTextureCoord + offset, uInputClamp.xy, uInputClamp.zw));\n}\n";

// node_modules/pixi.js/lib/filters/defaults/displacement/displacement.vert.mjs
var vertex3 = "in vec2 aPosition;\nout vec2 vTextureCoord;\nout vec2 vFilterUv;\n\n\nuniform vec4 uInputSize;\nuniform vec4 uOutputFrame;\nuniform vec4 uOutputTexture;\n\nuniform mat3 uFilterMatrix;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;\n    \n    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aPosition * (uOutputFrame.zw * uInputSize.zw);\n}\n\nvec2 getFilterCoord( void )\n{\n  return ( uFilterMatrix * vec3( filterTextureCoord(), 1.0)  ).xy;\n}\n\n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition();\n    vTextureCoord = filterTextureCoord();\n    vFilterUv = getFilterCoord();\n}\n";

// node_modules/pixi.js/lib/filters/defaults/displacement/displacement.wgsl.mjs
var source6 = "\nstruct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct DisplacementUniforms {\n  uFilterMatrix:mat3x3<f32>,\n  uScale:vec2<f32>,\n  uRotation:mat2x2<f32>\n};\n\n\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n\n@group(1) @binding(0) var<uniform> filterUniforms : DisplacementUniforms;\n@group(1) @binding(1) var uMapTexture: texture_2d<f32>;\n@group(1) @binding(2) var uMapSampler : sampler;\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>,\n    @location(1) filterUv : vec2<f32>,\n  };\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);  \n}\n\nfn getFilterCoord(aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return ( filterUniforms.uFilterMatrix * vec3( filterTextureCoord(aPosition), 1.0)  ).xy;\n}\n\nfn getSize() -> vec2<f32>\n{\n\n  \n  return gfu.uGlobalFrame.zw;\n}\n  \n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>, \n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition),\n   getFilterCoord(aPosition)\n  );\n}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n  @location(1) filterUv: vec2<f32>,\n  @builtin(position) position: vec4<f32>\n) -> @location(0) vec4<f32> {\n\n    var map = textureSample(uMapTexture, uMapSampler, filterUv);\n\n    var offset =  gfu.uInputSize.zw * (filterUniforms.uRotation * (map.xy - 0.5)) * filterUniforms.uScale; \n   \n    return textureSample(uTexture, uSampler, clamp(uv + offset, gfu.uInputClamp.xy, gfu.uInputClamp.zw));\n}";

// node_modules/pixi.js/lib/filters/defaults/displacement/DisplacementFilter.mjs
var DisplacementFilter = class extends Filter {
  constructor(...args) {
    let options = args[0];
    if (options instanceof Sprite) {
      if (args[1]) {
        deprecation(v8_0_0, "DisplacementFilter now uses options object instead of params. {sprite, scale}");
      }
      options = { sprite: options, scale: args[1] };
    }
    const _a = options, { sprite, scale: scaleOption } = _a, rest = __objRest(_a, ["sprite", "scale"]);
    let scale = scaleOption ?? 20;
    if (typeof scale === "number") {
      scale = new Point(scale, scale);
    }
    const filterUniforms = new UniformGroup({
      uFilterMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      uScale: { value: scale, type: "vec2<f32>" },
      uRotation: { value: new Float32Array([0, 0, 0, 0]), type: "mat2x2<f32>" }
    });
    const glProgram3 = GlProgram.from({
      vertex: vertex3,
      fragment: fragment5,
      name: "displacement-filter"
    });
    const gpuProgram3 = GpuProgram.from({
      vertex: {
        source: source6,
        entryPoint: "mainVertex"
      },
      fragment: {
        source: source6,
        entryPoint: "mainFragment"
      }
    });
    const textureSource = sprite.texture.source;
    super(__spreadProps(__spreadValues({}, rest), {
      gpuProgram: gpuProgram3,
      glProgram: glProgram3,
      resources: {
        filterUniforms,
        uMapTexture: textureSource,
        uMapSampler: textureSource.style
      }
    }));
    this._sprite = options.sprite;
    this._sprite.renderable = false;
  }
  /**
   * Applies the filter.
   * @param filterManager - The manager.
   * @param input - The input target.
   * @param output - The output target.
   * @param clearMode - clearMode.
   * @advanced
   */
  apply(filterManager, input, output, clearMode) {
    const uniforms = this.resources.filterUniforms.uniforms;
    filterManager.calculateSpriteMatrix(
      uniforms.uFilterMatrix,
      this._sprite
    );
    const wt = this._sprite.worldTransform;
    const lenX = Math.sqrt(wt.a * wt.a + wt.b * wt.b);
    const lenY = Math.sqrt(wt.c * wt.c + wt.d * wt.d);
    if (lenX !== 0 && lenY !== 0) {
      uniforms.uRotation[0] = wt.a / lenX;
      uniforms.uRotation[1] = wt.b / lenX;
      uniforms.uRotation[2] = wt.c / lenY;
      uniforms.uRotation[3] = wt.d / lenY;
    }
    this.resources.uMapTexture = this._sprite.texture.source;
    filterManager.applyFilter(this, input, output, clearMode);
  }
  /**
   * The scale of the displacement effect.
   *
   * Gets the current x and y scaling values used for the displacement mapping.
   * - x: Horizontal displacement scale
   * - y: Vertical displacement scale
   * @returns {Point} The current scale as a Point object
   * @example
   * ```ts
   * const filter = new DisplacementFilter({ sprite });
   *
   * // Get current scale
   * console.log(filter.scale.x, filter.scale.y);
   *
   * // Update scale
   * filter.scale.x = 100;
   * filter.scale.y = 50;
   * ```
   */
  get scale() {
    return this.resources.filterUniforms.uniforms.uScale;
  }
};

// node_modules/pixi.js/lib/filters/defaults/noise/noise.frag.mjs
var fragment6 = "\nin vec2 vTextureCoord;\nin vec4 vColor;\n\nout vec4 finalColor;\n\nuniform float uNoise;\nuniform float uSeed;\nuniform sampler2D uTexture;\n\nfloat rand(vec2 co)\n{\n    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);\n}\n\nvoid main()\n{\n    vec4 color = texture(uTexture, vTextureCoord);\n    float randomValue = rand(gl_FragCoord.xy * uSeed);\n    float diff = (randomValue - 0.5) *  uNoise;\n\n    // Un-premultiply alpha before applying the color matrix. See issue #3539.\n    if (color.a > 0.0) {\n        color.rgb /= color.a;\n    }\n\n    color.r += diff;\n    color.g += diff;\n    color.b += diff;\n\n    // Premultiply alpha again.\n    color.rgb *= color.a;\n\n    finalColor = color;\n}\n";

// node_modules/pixi.js/lib/filters/defaults/noise/noise.wgsl.mjs
var source7 = "\n\nstruct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct NoiseUniforms {\n  uNoise:f32,\n  uSeed:f32,\n};\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n\n@group(1) @binding(0) var<uniform> noiseUniforms : NoiseUniforms;\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>\n  };\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);  \n}\n\nfn getSize() -> vec2<f32>\n{\n  return gfu.uGlobalFrame.zw;\n}\n  \n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>, \n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition)\n  );\n}\n\nfn rand(co:vec2<f32>) -> f32\n{\n  return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);\n}\n\n\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n  @builtin(position) position: vec4<f32>\n) -> @location(0) vec4<f32> {\n\n    var pixelPosition =  globalTextureCoord(position.xy);// / (getSize());//-  gfu.uOutputFrame.xy);\n  \n    \n    var sample = textureSample(uTexture, uSampler, uv);\n    var randomValue =  rand(pixelPosition.xy * noiseUniforms.uSeed);\n    var diff = (randomValue - 0.5) * noiseUniforms.uNoise;\n  \n    // Un-premultiply alpha before applying the color matrix. See issue #3539.\n    if (sample.a > 0.0) {\n      sample.r /= sample.a;\n      sample.g /= sample.a;\n      sample.b /= sample.a;\n    }\n\n    sample.r += diff;\n    sample.g += diff;\n    sample.b += diff;\n\n    // Premultiply alpha again.\n    sample.r *= sample.a;\n    sample.g *= sample.a;\n    sample.b *= sample.a;\n    \n    return sample;\n}";

// node_modules/pixi.js/lib/filters/defaults/noise/NoiseFilter.mjs
var _NoiseFilter = class _NoiseFilter2 extends Filter {
  /**
   * @param options - The options of the noise filter.
   */
  constructor(options = {}) {
    options = __spreadValues(__spreadValues({}, _NoiseFilter2.defaultOptions), options);
    const gpuProgram3 = GpuProgram.from({
      vertex: {
        source: source7,
        entryPoint: "mainVertex"
      },
      fragment: {
        source: source7,
        entryPoint: "mainFragment"
      }
    });
    const glProgram3 = GlProgram.from({
      vertex,
      fragment: fragment6,
      name: "noise-filter"
    });
    const _a = options, { noise, seed } = _a, rest = __objRest(_a, ["noise", "seed"]);
    super(__spreadProps(__spreadValues({}, rest), {
      gpuProgram: gpuProgram3,
      glProgram: glProgram3,
      resources: {
        noiseUniforms: new UniformGroup({
          uNoise: { value: 1, type: "f32" },
          uSeed: { value: 1, type: "f32" }
        })
      }
    }));
    this.noise = noise;
    this.seed = seed ?? Math.random();
  }
  /**
   * The amount of noise to apply to the filtered content.
   *
   * This value controls the intensity of the random noise effect:
   * - Values close to 0 produce subtle noise
   * - Values around 0.5 produce moderate noise
   * - Values close to 1 produce strong noise
   * @default 0.5
   * @example
   * ```ts
   * const noiseFilter = new NoiseFilter();
   *
   * // Set to subtle noise
   * noiseFilter.noise = 0.2;
   *
   * // Set to maximum noise
   * noiseFilter.noise = 1.0;
   * ```
   */
  get noise() {
    return this.resources.noiseUniforms.uniforms.uNoise;
  }
  set noise(value) {
    this.resources.noiseUniforms.uniforms.uNoise = value;
  }
  /**
   * The seed value used for random noise generation.
   *
   * This value determines the noise pattern:
   * - Using the same seed will generate identical noise patterns
   * - Different seeds produce different but consistent patterns
   * - `Math.random()` can be used for random patterns
   * @default Math.random()
   * @example
   * ```ts
   * const noiseFilter = new NoiseFilter();
   *
   * // Use a fixed seed for consistent noise
   * noiseFilter.seed = 12345;
   *
   * // Generate new random pattern
   * noiseFilter.seed = Math.random();
   * ```
   */
  get seed() {
    return this.resources.noiseUniforms.uniforms.uSeed;
  }
  set seed(value) {
    this.resources.noiseUniforms.uniforms.uSeed = value;
  }
};
_NoiseFilter.defaultOptions = {
  noise: 0.5
};
var NoiseFilter = _NoiseFilter;

// node_modules/pixi.js/lib/filters/blend-modes/hsl.wgsl.mjs
var hsl = "fn getLuminosity(c: vec3<f32>) -> f32 {\n  return 0.3 * c.r + 0.59 * c.g + 0.11 * c.b;\n}\n\nfn setLuminosity(c: vec3<f32>, lum: f32) -> vec3<f32> {\n  let d: f32 = lum - getLuminosity(c);\n  let newColor: vec3<f32> = c.rgb + vec3<f32>(d, d, d);\n\n  // clip back into legal range\n  let newLum: f32 = getLuminosity(newColor);\n  let cMin: f32 = min(newColor.r, min(newColor.g, newColor.b));\n  let cMax: f32 = max(newColor.r, max(newColor.g, newColor.b));\n\n  let t1: f32 = newLum / (newLum - cMin);\n  let t2: f32 = (1.0 - newLum) / (cMax - newLum);\n\n  let finalColor = mix(vec3<f32>(newLum, newLum, newLum), newColor, select(select(1.0, t2, cMax > 1.0), t1, cMin < 0.0));\n\n  return finalColor;\n}\n\nfn getSaturation(c: vec3<f32>) -> f32 {\n  return max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));\n}\n\n// Set saturation if color components are sorted in ascending order.\nfn setSaturationMinMidMax(cSorted: vec3<f32>, s: f32) -> vec3<f32> {\n  var result: vec3<f32>;\n  if (cSorted.z > cSorted.x) {\n    let newY = (((cSorted.y - cSorted.x) * s) / (cSorted.z - cSorted.x));\n    result = vec3<f32>(0.0, newY, s);\n  } else {\n    result = vec3<f32>(0.0, 0.0, 0.0);\n  }\n  return vec3<f32>(result.x, result.y, result.z);\n}\n\nfn setSaturation(c: vec3<f32>, s: f32) -> vec3<f32> {\n    var result: vec3<f32> = c;\n\n    if (c.r <= c.g && c.r <= c.b) {\n        if (c.g <= c.b) {\n            result = setSaturationMinMidMax(result, s);\n        } else {\n            var temp: vec3<f32> = vec3<f32>(result.r, result.b, result.g);\n            temp = setSaturationMinMidMax(temp, s);\n            result = vec3<f32>(temp.r, temp.b, temp.g);\n        }\n    } else if (c.g <= c.r && c.g <= c.b) {\n        if (c.r <= c.b) {\n            var temp: vec3<f32> = vec3<f32>(result.g, result.r, result.b);\n            temp = setSaturationMinMidMax(temp, s);\n            result = vec3<f32>(temp.g, temp.r, temp.b);\n        } else {\n            var temp: vec3<f32> = vec3<f32>(result.g, result.b, result.r);\n            temp = setSaturationMinMidMax(temp, s);\n            result = vec3<f32>(temp.g, temp.b, temp.r);\n        }\n    } else {\n        if (c.r <= c.g) {\n            var temp: vec3<f32> = vec3<f32>(result.b, result.r, result.g);\n            temp = setSaturationMinMidMax(temp, s);\n            result = vec3<f32>(temp.b, temp.r, temp.g);\n        } else {\n            var temp: vec3<f32> = vec3<f32>(result.b, result.g, result.r);\n            temp = setSaturationMinMidMax(temp, s);\n            result = vec3<f32>(temp.b, temp.g, temp.r);\n        }\n    }\n\n    return result;\n}";

// node_modules/pixi.js/lib/prepare/PrepareBase.mjs
var _PrepareBase = class _PrepareBase2 {
  /**
   * @param {Renderer} renderer - A reference to the current renderer
   */
  constructor(renderer) {
    this._tick = () => {
      if (this._destroyed) return;
      this.timeout = setTimeout(this._processQueue, 0);
    };
    this._processQueue = () => {
      if (this._destroyed) return;
      const { queue } = this;
      let itemsProcessed = 0;
      while (queue.length && itemsProcessed < _PrepareBase2.uploadsPerFrame) {
        const queueItem = queue.shift();
        this.uploadQueueItem(queueItem);
        itemsProcessed++;
      }
      if (queue.length) {
        Ticker.system.addOnce(this._tick, this, UPDATE_PRIORITY.UTILITY);
      } else {
        this._resolve();
      }
    };
    this.renderer = renderer;
    this.queue = [];
    this.resolves = [];
  }
  /**
   * Return a copy of the queue
   * @returns {PrepareQueueItem[]} The queue
   */
  getQueue() {
    return [...this.queue];
  }
  /**
   * Add a textures or graphics resource to the queue
   * @param {PrepareSourceItem | PrepareSourceItem[]} resource
   */
  add(resource) {
    const resourceArray = Array.isArray(resource) ? resource : [resource];
    for (const resourceItem of resourceArray) {
      if (resourceItem instanceof Container) {
        this._addContainer(resourceItem);
      } else {
        this.resolveQueueItem(resourceItem, this.queue);
      }
    }
    return this;
  }
  /**
   * Recursively add a container and its children to the queue
   * @param {Container} container - The container to add to the queue
   */
  _addContainer(container) {
    this.resolveQueueItem(container, this.queue);
    for (const child of container.children) {
      this._addContainer(child);
    }
  }
  /**
   * Upload all the textures and graphics to the GPU (optionally add more resources to the queue first)
   * @param {PrepareSourceItem | PrepareSourceItem[] | undefined} resource
   */
  upload(resource) {
    if (resource) {
      this.add(resource);
    }
    return new Promise((resolve) => {
      if (this.queue.length) {
        this.resolves.push(resolve);
        this.dedupeQueue();
        Ticker.system.addOnce(this._tick, this, UPDATE_PRIORITY.UTILITY);
      } else {
        resolve();
      }
    });
  }
  /** eliminate duplicates before processing */
  dedupeQueue() {
    const hash = /* @__PURE__ */ Object.create(null);
    let nextUnique = 0;
    for (let i = 0; i < this.queue.length; i++) {
      const current = this.queue[i];
      if (!hash[current.uid]) {
        hash[current.uid] = true;
        this.queue[nextUnique++] = current;
      }
    }
    this.queue.length = nextUnique;
  }
  destroy() {
    this._destroyed = true;
    clearTimeout(this.timeout);
  }
  /** Call all the resolve callbacks */
  _resolve() {
    const { resolves } = this;
    const array = resolves.slice(0);
    resolves.length = 0;
    for (const resolve of array) {
      resolve();
    }
  }
};
_PrepareBase.uploadsPerFrame = 4;
var PrepareBase = _PrepareBase;

// node_modules/pixi.js/lib/scene/mesh/shared/MeshGeometry.mjs
var _MeshGeometry = class _MeshGeometry2 extends Geometry {
  constructor(...args) {
    let options = args[0] ?? {};
    if (options instanceof Float32Array) {
      deprecation(v8_0_0, "use new MeshGeometry({ positions, uvs, indices }) instead");
      options = {
        positions: options,
        uvs: args[1],
        indices: args[2]
      };
    }
    options = __spreadValues(__spreadValues({}, _MeshGeometry2.defaultOptions), options);
    const positions = options.positions || new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]);
    let uvs = options.uvs;
    if (!uvs) {
      if (options.positions) {
        uvs = new Float32Array(positions.length);
      } else {
        uvs = new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]);
      }
    }
    const indices = options.indices || new Uint32Array([0, 1, 2, 0, 2, 3]);
    const shrinkToFit = options.shrinkBuffersToFit;
    const positionBuffer = new Buffer({
      data: positions,
      label: "attribute-mesh-positions",
      shrinkToFit,
      usage: BufferUsage.VERTEX | BufferUsage.COPY_DST
    });
    const uvBuffer = new Buffer({
      data: uvs,
      label: "attribute-mesh-uvs",
      shrinkToFit,
      usage: BufferUsage.VERTEX | BufferUsage.COPY_DST
    });
    const indexBuffer = new Buffer({
      data: indices,
      label: "index-mesh-buffer",
      shrinkToFit,
      usage: BufferUsage.INDEX | BufferUsage.COPY_DST
    });
    super({
      attributes: {
        aPosition: {
          buffer: positionBuffer,
          format: "float32x2",
          stride: 2 * 4,
          offset: 0
        },
        aUV: {
          buffer: uvBuffer,
          format: "float32x2",
          stride: 2 * 4,
          offset: 0
        }
      },
      indexBuffer,
      topology: options.topology
    });
    this.batchMode = "auto";
  }
  /** The positions of the mesh. */
  get positions() {
    return this.attributes.aPosition.buffer.data;
  }
  /**
   * Set the positions of the mesh.
   * When setting the positions, its important that the uvs array is at least as long as the positions array.
   * otherwise the geometry will not be valid.
   * @param {Float32Array} value - The positions of the mesh.
   */
  set positions(value) {
    this.attributes.aPosition.buffer.data = value;
  }
  /** The UVs of the mesh. */
  get uvs() {
    return this.attributes.aUV.buffer.data;
  }
  /**
   * Set the UVs of the mesh.
   * Its important that the uvs array you set is at least as long as the positions array.
   * otherwise the geometry will not be valid.
   * @param {Float32Array} value - The UVs of the mesh.
   */
  set uvs(value) {
    this.attributes.aUV.buffer.data = value;
  }
  /** The indices of the mesh. */
  get indices() {
    return this.indexBuffer.data;
  }
  set indices(value) {
    this.indexBuffer.data = value;
  }
};
_MeshGeometry.defaultOptions = {
  topology: "triangle-list",
  shrinkBuffersToFit: false
};
var MeshGeometry = _MeshGeometry;

// node_modules/pixi.js/lib/scene/mesh/shared/BatchableMesh.mjs
var BatchableMesh = class {
  constructor() {
    this.batcherName = "default";
    this.packAsQuad = false;
    this.indexOffset = 0;
    this.attributeOffset = 0;
    this.roundPixels = 0;
    this._batcher = null;
    this._batch = null;
    this._textureMatrixUpdateId = -1;
    this._uvUpdateId = -1;
  }
  get blendMode() {
    return this.renderable.groupBlendMode;
  }
  get topology() {
    return this._topology || this.geometry.topology;
  }
  set topology(value) {
    this._topology = value;
  }
  reset() {
    this.renderable = null;
    this.texture = null;
    this._batcher = null;
    this._batch = null;
    this.geometry = null;
    this._uvUpdateId = -1;
    this._textureMatrixUpdateId = -1;
  }
  /**
   * Sets the texture for the batchable mesh.
   * As it does so, it resets the texture matrix update ID.
   * this is to ensure that the texture matrix is recalculated when the uvs are referenced
   * @param value - The texture to set.
   */
  setTexture(value) {
    if (this.texture === value) return;
    this.texture = value;
    this._textureMatrixUpdateId = -1;
  }
  get uvs() {
    const geometry = this.geometry;
    const uvBuffer = geometry.getBuffer("aUV");
    const uvs = uvBuffer.data;
    let transformedUvs = uvs;
    const textureMatrix = this.texture.textureMatrix;
    if (!textureMatrix.isSimple) {
      transformedUvs = this._transformedUvs;
      if (this._textureMatrixUpdateId !== textureMatrix._updateID || this._uvUpdateId !== uvBuffer._updateID) {
        if (!transformedUvs || transformedUvs.length < uvs.length) {
          transformedUvs = this._transformedUvs = new Float32Array(uvs.length);
        }
        this._textureMatrixUpdateId = textureMatrix._updateID;
        this._uvUpdateId = uvBuffer._updateID;
        textureMatrix.multiplyUvs(uvs, transformedUvs);
      }
    }
    return transformedUvs;
  }
  get positions() {
    return this.geometry.positions;
  }
  get indices() {
    return this.geometry.indices;
  }
  get color() {
    return this.renderable.groupColorAlpha;
  }
  get groupTransform() {
    return this.renderable.groupTransform;
  }
  get attributeSize() {
    return this.geometry.positions.length / 2;
  }
  get indexSize() {
    return this.geometry.indices.length;
  }
};

// node_modules/pixi.js/lib/scene/mesh/shared/MeshPipe.mjs
var MeshGpuData = class {
  destroy() {
  }
};
var MeshPipe = class {
  constructor(renderer, adaptor) {
    this.localUniforms = new UniformGroup({
      uTransformMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      uColor: { value: new Float32Array([1, 1, 1, 1]), type: "vec4<f32>" },
      uRound: { value: 0, type: "f32" }
    });
    this.localUniformsBindGroup = new BindGroup({
      0: this.localUniforms
    });
    this.renderer = renderer;
    this._adaptor = adaptor;
    this._adaptor.init();
  }
  validateRenderable(mesh) {
    const meshData = this._getMeshData(mesh);
    const wasBatched = meshData.batched;
    const isBatched = mesh.batched;
    meshData.batched = isBatched;
    if (wasBatched !== isBatched) {
      return true;
    } else if (isBatched) {
      const geometry = mesh._geometry;
      if (geometry.indices.length !== meshData.indexSize || geometry.positions.length !== meshData.vertexSize) {
        meshData.indexSize = geometry.indices.length;
        meshData.vertexSize = geometry.positions.length;
        return true;
      }
      const batchableMesh = this._getBatchableMesh(mesh);
      if (batchableMesh.texture.uid !== mesh._texture.uid) {
        batchableMesh._textureMatrixUpdateId = -1;
      }
      return !batchableMesh._batcher.checkAndUpdateTexture(
        batchableMesh,
        mesh._texture
      );
    }
    return false;
  }
  addRenderable(mesh, instructionSet) {
    const batcher = this.renderer.renderPipes.batch;
    const meshData = this._getMeshData(mesh);
    if (mesh.didViewUpdate) {
      meshData.indexSize = mesh._geometry.indices?.length;
      meshData.vertexSize = mesh._geometry.positions?.length;
    }
    if (meshData.batched) {
      const gpuBatchableMesh = this._getBatchableMesh(mesh);
      gpuBatchableMesh.setTexture(mesh._texture);
      gpuBatchableMesh.geometry = mesh._geometry;
      batcher.addToBatch(gpuBatchableMesh, instructionSet);
    } else {
      batcher.break(instructionSet);
      instructionSet.add(mesh);
    }
  }
  updateRenderable(mesh) {
    if (mesh.batched) {
      const gpuBatchableMesh = this._getBatchableMesh(mesh);
      gpuBatchableMesh.setTexture(mesh._texture);
      gpuBatchableMesh.geometry = mesh._geometry;
      gpuBatchableMesh._batcher.updateElement(gpuBatchableMesh);
    }
  }
  execute(mesh) {
    if (!mesh.isRenderable) return;
    if (mesh.state.blend) {
      mesh.state.blendMode = getAdjustedBlendModeBlend(mesh.groupBlendMode, mesh.texture._source);
    }
    const localUniforms = this.localUniforms;
    localUniforms.uniforms.uTransformMatrix = mesh.groupTransform;
    localUniforms.uniforms.uRound = this.renderer._roundPixels | mesh._roundPixels;
    localUniforms.update();
    color32BitToUniform(
      mesh.groupColorAlpha,
      localUniforms.uniforms.uColor,
      0
    );
    this._adaptor.execute(this, mesh);
  }
  _getMeshData(mesh) {
    var _a, _b;
    (_a = mesh._gpuData)[_b = this.renderer.uid] || (_a[_b] = new MeshGpuData());
    return mesh._gpuData[this.renderer.uid].meshData || this._initMeshData(mesh);
  }
  _initMeshData(mesh) {
    mesh._gpuData[this.renderer.uid].meshData = {
      batched: mesh.batched,
      indexSize: 0,
      vertexSize: 0
    };
    return mesh._gpuData[this.renderer.uid].meshData;
  }
  _getBatchableMesh(mesh) {
    var _a, _b;
    (_a = mesh._gpuData)[_b = this.renderer.uid] || (_a[_b] = new MeshGpuData());
    return mesh._gpuData[this.renderer.uid].batchableMesh || this._initBatchableMesh(mesh);
  }
  _initBatchableMesh(mesh) {
    const gpuMesh = new BatchableMesh();
    gpuMesh.renderable = mesh;
    gpuMesh.setTexture(mesh._texture);
    gpuMesh.transform = mesh.groupTransform;
    gpuMesh.roundPixels = this.renderer._roundPixels | mesh._roundPixels;
    mesh._gpuData[this.renderer.uid].batchableMesh = gpuMesh;
    return gpuMesh;
  }
  destroy() {
    this.localUniforms = null;
    this.localUniformsBindGroup = null;
    this._adaptor.destroy();
    this._adaptor = null;
    this.renderer = null;
  }
};
MeshPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes
  ],
  name: "mesh"
};

// node_modules/pixi.js/lib/scene/mesh/init.mjs
extensions.add(MeshPipe);

// node_modules/pixi.js/lib/scene/mesh/shared/Mesh.mjs
var Mesh = class extends ViewContainer {
  constructor(...args) {
    let options = args[0];
    if (options instanceof Geometry) {
      deprecation(v8_0_0, "Mesh: use new Mesh({ geometry, shader }) instead");
      options = {
        geometry: options,
        shader: args[1]
      };
      if (args[3]) {
        deprecation(v8_0_0, "Mesh: drawMode argument has been removed, use geometry.topology instead");
        options.geometry.topology = args[3];
      }
    }
    const _a = options, { geometry, shader, texture, roundPixels, state } = _a, rest = __objRest(_a, ["geometry", "shader", "texture", "roundPixels", "state"]);
    super(__spreadValues({
      label: "Mesh"
    }, rest));
    this.renderPipeId = "mesh";
    this._shader = null;
    this.allowChildren = false;
    this.shader = shader ?? null;
    this.texture = texture ?? shader?.texture ?? Texture.WHITE;
    this.state = state ?? State.for2d();
    this._geometry = geometry;
    this._geometry.on("update", this.onViewUpdate, this);
    this.roundPixels = roundPixels ?? false;
  }
  /** Alias for {@link Mesh#shader}. */
  get material() {
    deprecation(v8_0_0, "mesh.material property has been removed, use mesh.shader instead");
    return this._shader;
  }
  /**
   * Represents the vertex and fragment shaders that processes the geometry and runs on the GPU.
   * Can be shared between multiple Mesh objects.
   */
  set shader(value) {
    if (this._shader === value) return;
    this._shader = value;
    this.onViewUpdate();
  }
  get shader() {
    return this._shader;
  }
  /**
   * Includes vertex positions, face indices, colors, UVs, and
   * custom attributes within buffers, reducing the cost of passing all
   * this data to the GPU. Can be shared between multiple Mesh objects.
   */
  set geometry(value) {
    if (this._geometry === value) return;
    this._geometry?.off("update", this.onViewUpdate, this);
    value.on("update", this.onViewUpdate, this);
    this._geometry = value;
    this.onViewUpdate();
  }
  get geometry() {
    return this._geometry;
  }
  /** The texture that the Mesh uses. Null for non-MeshMaterial shaders */
  set texture(value) {
    value || (value = Texture.EMPTY);
    const currentTexture = this._texture;
    if (currentTexture === value) return;
    if (currentTexture && currentTexture.dynamic) currentTexture.off("update", this.onViewUpdate, this);
    if (value.dynamic) value.on("update", this.onViewUpdate, this);
    if (this.shader) {
      this.shader.texture = value;
    }
    this._texture = value;
    this.onViewUpdate();
  }
  get texture() {
    return this._texture;
  }
  get batched() {
    if (this._shader) return false;
    if ((this.state.data & 12) !== 0) return false;
    if (this._geometry instanceof MeshGeometry) {
      if (this._geometry.batchMode === "auto") {
        return this._geometry.positions.length / 2 <= 100;
      }
      return this._geometry.batchMode === "batch";
    }
    return false;
  }
  /**
   * The local bounds of the mesh.
   * @type {Bounds}
   */
  get bounds() {
    return this._geometry.bounds;
  }
  /**
   * Update local bounds of the mesh.
   * @private
   */
  updateBounds() {
    this._bounds = this._geometry.bounds;
  }
  /**
   * Checks if the object contains the given point.
   * @param point - The point to check
   */
  containsPoint(point) {
    const { x, y } = point;
    if (!this.bounds.containsPoint(x, y)) return false;
    const vertices = this.geometry.getBuffer("aPosition").data;
    const step = this.geometry.topology === "triangle-strip" ? 3 : 1;
    if (this.geometry.getIndex()) {
      const indices = this.geometry.getIndex().data;
      const len = indices.length;
      for (let i = 0; i + 2 < len; i += step) {
        const ind0 = indices[i] * 2;
        const ind1 = indices[i + 1] * 2;
        const ind2 = indices[i + 2] * 2;
        if (pointInTriangle(
          x,
          y,
          vertices[ind0],
          vertices[ind0 + 1],
          vertices[ind1],
          vertices[ind1 + 1],
          vertices[ind2],
          vertices[ind2 + 1]
        )) {
          return true;
        }
      }
    } else {
      const len = vertices.length / 2;
      for (let i = 0; i + 2 < len; i += step) {
        const ind0 = i * 2;
        const ind1 = (i + 1) * 2;
        const ind2 = (i + 2) * 2;
        if (pointInTriangle(
          x,
          y,
          vertices[ind0],
          vertices[ind0 + 1],
          vertices[ind1],
          vertices[ind1 + 1],
          vertices[ind2],
          vertices[ind2 + 1]
        )) {
          return true;
        }
      }
    }
    return false;
  }
  /**
   * Destroys this sprite renderable and optionally its texture.
   * @param options - Options parameter. A boolean will act as if all options
   *  have been set to that value
   * @example
   * mesh.destroy();
   * mesh.destroy(true);
   * mesh.destroy({ texture: true, textureSource: true });
   */
  destroy(options) {
    super.destroy(options);
    const destroyTexture = typeof options === "boolean" ? options : options?.texture;
    if (destroyTexture) {
      const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
      this._texture.destroy(destroyTextureSource);
    }
    this._geometry?.off("update", this.onViewUpdate, this);
    this._texture = null;
    this._geometry = null;
    this._shader = null;
  }
};

// node_modules/pixi.js/lib/scene/sprite-animated/AnimatedSprite.mjs
var AnimatedSprite = class _AnimatedSprite extends Sprite {
  constructor(...args) {
    let options = args[0];
    if (Array.isArray(args[0])) {
      options = {
        textures: args[0],
        autoUpdate: args[1]
      };
    }
    const _a = options, {
      animationSpeed = 1,
      autoPlay = false,
      autoUpdate = true,
      loop = true,
      onComplete = null,
      onFrameChange = null,
      onLoop = null,
      textures,
      updateAnchor = false
    } = _a, rest = __objRest(_a, [
      "animationSpeed",
      "autoPlay",
      "autoUpdate",
      "loop",
      "onComplete",
      "onFrameChange",
      "onLoop",
      "textures",
      "updateAnchor"
    ]);
    const [firstFrame] = textures;
    super(__spreadProps(__spreadValues({}, rest), {
      texture: firstFrame instanceof Texture ? firstFrame : firstFrame.texture
    }));
    this._textures = null;
    this._durations = null;
    this._autoUpdate = autoUpdate;
    this._isConnectedToTicker = false;
    this.animationSpeed = animationSpeed;
    this.loop = loop;
    this.updateAnchor = updateAnchor;
    this.onComplete = onComplete;
    this.onFrameChange = onFrameChange;
    this.onLoop = onLoop;
    this._currentTime = 0;
    this._playing = false;
    this._previousFrame = null;
    this.textures = textures;
    if (autoPlay) {
      this.play();
    }
  }
  /**
   * Stops the animation playback and freezes the current frame.
   * Does not reset the current frame or animation progress.
   * @example
   * ```ts
   * // Create an animated sprite
   * const sprite = new AnimatedSprite({
   *     textures: [
   *         Texture.from('walk1.png'),
   *         Texture.from('walk2.png'),
   *         Texture.from('walk3.png')
   *     ],
   *     autoPlay: true
   * });
   *
   * // Stop at current frame
   * sprite.stop();
   *
   * // Stop at specific frame
   * sprite.gotoAndStop(1); // Stops at second frame
   *
   * // Stop and reset
   * sprite.stop();
   * sprite.currentFrame = 0;
   *
   * // Stop with completion check
   * if (sprite.playing) {
   *     sprite.stop();
   *     sprite.onComplete?.();
   * }
   * ```
   * @see {@link AnimatedSprite#play} For starting playback
   * @see {@link AnimatedSprite#gotoAndStop} For stopping at a specific frame
   * @see {@link AnimatedSprite#playing} For checking play state
   */
  stop() {
    if (!this._playing) {
      return;
    }
    this._playing = false;
    if (this._autoUpdate && this._isConnectedToTicker) {
      Ticker.shared.remove(this.update, this);
      this._isConnectedToTicker = false;
    }
  }
  /**
   * Starts or resumes the animation playback.
   * If the animation was previously stopped, it will continue from where it left off.
   * @example
   * ```ts
   * // Basic playback
   * const sprite = new AnimatedSprite({
   *     textures: [
   *         Texture.from('walk1.png'),
   *         Texture.from('walk2.png'),
   *     ],
   *     autoPlay: false
   * });
   * sprite.play();
   *
   * // Play after stopping
   * sprite.stop();
   * sprite.currentFrame = 0; // Reset to start
   * sprite.play(); // Play from beginning
   *
   * // Play with auto-update disabled
   * sprite.autoUpdate = false;
   * sprite.play();
   * app.ticker.add(() => {
   *     sprite.update(app.ticker); // Manual updates
   * });
   * ```
   * @see {@link AnimatedSprite#stop} For stopping playback
   * @see {@link AnimatedSprite#gotoAndPlay} For playing from a specific frame
   * @see {@link AnimatedSprite#playing} For checking play state
   */
  play() {
    if (this._playing) {
      return;
    }
    this._playing = true;
    if (this._autoUpdate && !this._isConnectedToTicker) {
      Ticker.shared.add(this.update, this, UPDATE_PRIORITY.HIGH);
      this._isConnectedToTicker = true;
    }
  }
  /**
   * Stops the AnimatedSprite and sets it to a specific frame.
   * @example
   * ```ts
   * // Create an animated sprite
   * const sprite = new AnimatedSprite({
   *     textures: [
   *         Texture.from('walk1.png'),
   *         Texture.from('walk2.png'),
   *         Texture.from('walk3.png'),
   *     ]
   * });
   *
   * // Go to specific frames
   * sprite.gotoAndStop(0);  // First frame
   * sprite.gotoAndStop(2);  // Third frame
   *
   * // Jump to last frame
   * sprite.gotoAndStop(sprite.totalFrames - 1);
   * ```
   * @param frameNumber - Frame index to stop at (0-based)
   * @throws {Error} If frameNumber is out of bounds
   * @see {@link AnimatedSprite#gotoAndPlay} For going to a frame and playing
   * @see {@link AnimatedSprite#currentFrame} For getting/setting current frame
   * @see {@link AnimatedSprite#totalFrames} For total number of frames
   */
  gotoAndStop(frameNumber) {
    this.stop();
    this.currentFrame = frameNumber;
  }
  /**
   * Goes to a specific frame and begins playing the AnimatedSprite from that point.
   * Combines frame navigation and playback start in one operation.
   * @example
   * ```ts
   * // Start from specific frame
   * sprite.gotoAndPlay(1); // Starts playing from second frame
   * ```
   * @param frameNumber - Frame index to start playing from (0-based)
   * @throws {Error} If frameNumber is out of bounds
   * @see {@link AnimatedSprite#gotoAndStop} For going to a frame without playing
   * @see {@link AnimatedSprite#play} For playing from current frame
   * @see {@link AnimatedSprite#currentFrame} For getting/setting current frame
   */
  gotoAndPlay(frameNumber) {
    this.currentFrame = frameNumber;
    this.play();
  }
  /**
   * Updates the object transform for rendering. This method handles animation timing, frame updates,
   * and manages looping behavior.
   * @example
   * ```ts
   * // Create an animated sprite with manual updates
   * const sprite = new AnimatedSprite({
   *     textures: [
   *         Texture.from('frame1.png'),
   *         Texture.from('frame2.png'),
   *         Texture.from('frame3.png')
   *     ],
   *     autoUpdate: false // Disable automatic updates
   * });
   *
   * // Manual update with app ticker
   * app.ticker.add((ticker) => {
   *     sprite.update(ticker);
   * });
   * ```
   * @param ticker - The ticker to use for updating the animation timing
   * @see {@link AnimatedSprite#autoUpdate} For controlling automatic updates
   * @see {@link AnimatedSprite#animationSpeed} For controlling animation speed
   * @see {@link Ticker} For timing system details
   */
  update(ticker) {
    if (!this._playing) {
      return;
    }
    const deltaTime = ticker.deltaTime;
    const elapsed = this.animationSpeed * deltaTime;
    const previousFrame = this.currentFrame;
    if (this._durations !== null) {
      let lag = this._currentTime % 1 * this._durations[this.currentFrame];
      lag += elapsed / 60 * 1e3;
      while (lag < 0) {
        this._currentTime--;
        lag += this._durations[this.currentFrame];
      }
      const sign = Math.sign(this.animationSpeed * deltaTime);
      this._currentTime = Math.floor(this._currentTime);
      while (lag >= this._durations[this.currentFrame]) {
        lag -= this._durations[this.currentFrame] * sign;
        this._currentTime += sign;
      }
      this._currentTime += lag / this._durations[this.currentFrame];
    } else {
      this._currentTime += elapsed;
    }
    if (this._currentTime < 0 && !this.loop) {
      this.gotoAndStop(0);
      if (this.onComplete) {
        this.onComplete();
      }
    } else if (this._currentTime >= this._textures.length && !this.loop) {
      this.gotoAndStop(this._textures.length - 1);
      if (this.onComplete) {
        this.onComplete();
      }
    } else if (previousFrame !== this.currentFrame) {
      if (this.loop && this.onLoop) {
        if (this.animationSpeed > 0 && this.currentFrame < previousFrame || this.animationSpeed < 0 && this.currentFrame > previousFrame) {
          this.onLoop();
        }
      }
      this._updateTexture();
    }
  }
  /** Updates the displayed texture to match the current frame index. */
  _updateTexture() {
    const currentFrame = this.currentFrame;
    if (this._previousFrame === currentFrame) {
      return;
    }
    this._previousFrame = currentFrame;
    this.texture = this._textures[currentFrame];
    if (this.updateAnchor && this.texture.defaultAnchor) {
      this.anchor.copyFrom(this.texture.defaultAnchor);
    }
    if (this.onFrameChange) {
      this.onFrameChange(this.currentFrame);
    }
  }
  /**
   * Stops the AnimatedSprite and destroys it.
   * This method stops the animation playback, removes it from the ticker,
   * and cleans up any resources associated with the sprite.
   * @param options - Options for destroying the sprite, such as whether to remove from parent
   * @example
   * ```ts
   * // Destroy the sprite when done
   * sprite.destroy();
   * // Or with options
   * sprite.destroy({ children: true, texture: true, textureSource: true });
   * ```
   */
  destroy(options = false) {
    const destroyTexture = typeof options === "boolean" ? options : options?.texture;
    if (destroyTexture) {
      const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
      this._textures.forEach((texture) => {
        if (this.texture !== texture) {
          texture.destroy(destroyTextureSource);
        }
      });
    }
    this._textures = [];
    this._durations = null;
    this.stop();
    super.destroy(options);
    this.onComplete = null;
    this.onFrameChange = null;
    this.onLoop = null;
  }
  /**
   * A short hand way of creating an AnimatedSprite from an array of frame ids.
   * Uses texture frames from the cache to create an animation sequence.
   * @example
   * ```ts
   * // Create from frame IDs
   * const frameIds = [
   *     'walk_001.png',
   *     'walk_002.png',
   *     'walk_003.png'
   * ];
   *
   * const walkingAnimation = AnimatedSprite.fromFrames(frameIds);
   * walkingAnimation.play();
   * ```
   * @param frames - The array of frame ids to use for the animation
   * @returns A new animated sprite using the frames
   * @see {@link Texture.from} For texture creation from frames
   * @see {@link Spritesheet} For loading spritesheets
   */
  static fromFrames(frames) {
    const textures = [];
    for (let i = 0; i < frames.length; ++i) {
      textures.push(Texture.from(frames[i]));
    }
    return new _AnimatedSprite(textures);
  }
  /**
   * A short hand way of creating an AnimatedSprite from an array of image urls.
   * Each image will be used as a frame in the animation.
   * @example
   * ```ts
   * // Create from image URLs
   * const images = [
   *     'assets/walk1.png',
   *     'assets/walk2.png',
   *     'assets/walk3.png'
   * ];
   *
   * const walkingSprite = AnimatedSprite.fromImages(images);
   * walkingSprite.play();
   * ```
   * @param images - The array of image urls to use as frames
   * @returns A new animated sprite using the images as frames
   * @see {@link Assets} For asset loading and management
   * @see {@link Texture.from} For texture creation from images
   */
  static fromImages(images) {
    const textures = [];
    for (let i = 0; i < images.length; ++i) {
      textures.push(Texture.from(images[i]));
    }
    return new _AnimatedSprite(textures);
  }
  /**
   * The total number of frames in the AnimatedSprite. This is the same as number of textures
   * assigned to the AnimatedSprite.
   * @example
   * ```ts
   * // Create an animated sprite
   * const sprite = new AnimatedSprite({
   *     textures: [
   *         Texture.from('frame1.png'),
   *         Texture.from('frame2.png'),
   *         Texture.from('frame3.png')
   *     ]
   * });
   *
   * // Get total frames
   * console.log(sprite.totalFrames); // Outputs: 3
   *
   * // Use with frame navigation
   * sprite.gotoAndStop(sprite.totalFrames - 1); // Go to last frame
   * ```
   * @readonly
   * @see {@link AnimatedSprite#currentFrame} For the current frame index
   * @see {@link AnimatedSprite#textures} For the array of textures
   * @returns {number} The total number of frames
   */
  get totalFrames() {
    return this._textures.length;
  }
  /**
   * The array of textures or frame objects used for the animation sequence.
   * Can be set to either an array of Textures or an array of FrameObjects with custom timing.
   * @example
   * ```ts
   * // Update textures at runtime
   * sprite.textures = [
   *     Texture.from('run1.png'),
   *     Texture.from('run2.png')
   * ];
   *
   * // Use custom frame timing
   * sprite.textures = [
   *     { texture: Texture.from('explosion1.png'), time: 100 },
   *     { texture: Texture.from('explosion2.png'), time: 200 },
   *     { texture: Texture.from('explosion3.png'), time: 300 }
   * ];
   *
   * // Use with spritesheet
   * const sheet = await Assets.load('animations.json');
   * sprite.textures = sheet.animations['walk'];
   * ```
   * @type {AnimatedSpriteFrames}
   * @see {@link FrameObject} For frame timing options
   * @see {@link Spritesheet} For loading from spritesheets
   */
  get textures() {
    return this._textures;
  }
  set textures(value) {
    if (value[0] instanceof Texture) {
      this._textures = value;
      this._durations = null;
    } else {
      this._textures = [];
      this._durations = [];
      for (let i = 0; i < value.length; i++) {
        this._textures.push(value[i].texture);
        this._durations.push(value[i].time);
      }
    }
    this._previousFrame = null;
    this.gotoAndStop(0);
    this._updateTexture();
  }
  /**
   * Gets or sets the current frame index of the animation.
   * When setting, the value will be clamped between 0 and totalFrames - 1.
   * @example
   * ```ts
   * // Create an animated sprite
   * const sprite = new AnimatedSprite({
   *     textures: [
   *         Texture.from('walk1.png'),
   *         Texture.from('walk2.png'),
   *         Texture.from('walk3.png')
   *     ]
   * });
   *
   * // Get current frame
   * console.log(sprite.currentFrame); // 0
   *
   * // Set specific frame
   * sprite.currentFrame = 1; // Show second frame
   *
   * // Use with frame callbacks
   * sprite.onFrameChange = (frame) => {
   *     console.log(`Now showing frame: ${frame}`);
   * };
   * sprite.currentFrame = 2;
   * ```
   * @throws {Error} If attempting to set a frame index out of bounds
   * @see {@link AnimatedSprite#totalFrames} For the total number of frames
   * @see {@link AnimatedSprite#gotoAndPlay} For playing from a specific frame
   * @see {@link AnimatedSprite#gotoAndStop} For stopping at a specific frame
   */
  get currentFrame() {
    let currentFrame = Math.floor(this._currentTime) % this._textures.length;
    if (currentFrame < 0) {
      currentFrame += this._textures.length;
    }
    return currentFrame;
  }
  set currentFrame(value) {
    if (value < 0 || value > this.totalFrames - 1) {
      throw new Error(`[AnimatedSprite]: Invalid frame index value ${value}, expected to be between 0 and totalFrames ${this.totalFrames}.`);
    }
    const previousFrame = this.currentFrame;
    this._currentTime = value;
    if (previousFrame !== this.currentFrame) {
      this._updateTexture();
    }
  }
  /**
   * Indicates if the AnimatedSprite is currently playing.
   * This is a read-only property that reflects the current playback state.
   * @example
   * ```ts
   * // Check if animation is playing
   * console.log('Playing:', sprite.playing); // true
   *
   * // Use with play control
   * if (!sprite.playing) {
   *     sprite.play();
   * }
   * ```
   * @readonly
   * @returns {boolean} True if the animation is currently playing
   * @see {@link AnimatedSprite#play} For starting playback
   * @see {@link AnimatedSprite#stop} For stopping playback
   * @see {@link AnimatedSprite#loop} For controlling looping behavior
   */
  get playing() {
    return this._playing;
  }
  /**
   * Controls whether the animation automatically updates using the shared ticker.
   * When enabled, the animation will update on each frame. When disabled, you must
   * manually call update() to advance the animation.
   * @example
   * ```ts
   * // Create sprite with auto-update disabled
   * const sprite = new AnimatedSprite({
   *     textures: [],
   *     autoUpdate: false
   * });
   *
   * // Manual update with app ticker
   * app.ticker.add((ticker) => {
   *     sprite.update(ticker);
   * });
   *
   * // Enable auto-update later
   * sprite.autoUpdate = true;
   * ```
   * @default true
   * @see {@link AnimatedSprite#update} For manual animation updates
   * @see {@link Ticker} For the timing system
   */
  get autoUpdate() {
    return this._autoUpdate;
  }
  set autoUpdate(value) {
    if (value !== this._autoUpdate) {
      this._autoUpdate = value;
      if (!this._autoUpdate && this._isConnectedToTicker) {
        Ticker.shared.remove(this.update, this);
        this._isConnectedToTicker = false;
      } else if (this._autoUpdate && !this._isConnectedToTicker && this._playing) {
        Ticker.shared.add(this.update, this);
        this._isConnectedToTicker = true;
      }
    }
  }
};

// node_modules/pixi.js/lib/utils/misc/Transform.mjs
var Transform = class {
  /**
   * @param options - Options for the transform.
   * @param options.matrix - The matrix to use.
   * @param options.observer - The observer to use.
   */
  constructor({ matrix, observer } = {}) {
    this.dirty = true;
    this._matrix = matrix ?? new Matrix();
    this.observer = observer;
    this.position = new ObservablePoint(this, 0, 0);
    this.scale = new ObservablePoint(this, 1, 1);
    this.pivot = new ObservablePoint(this, 0, 0);
    this.skew = new ObservablePoint(this, 0, 0);
    this._rotation = 0;
    this._cx = 1;
    this._sx = 0;
    this._cy = 0;
    this._sy = 1;
  }
  /**
   * The transformation matrix computed from the transform's properties.
   * Combines position, scale, rotation, skew, and pivot into a single matrix.
   * @example
   * ```ts
   * // Get current matrix
   * const matrix = transform.matrix;
   * console.log(matrix.toString());
   * ```
   * @readonly
   * @see {@link Matrix} For matrix operations
   * @see {@link Transform.setFromMatrix} For setting transform from matrix
   */
  get matrix() {
    const lt = this._matrix;
    if (!this.dirty) return lt;
    lt.a = this._cx * this.scale.x;
    lt.b = this._sx * this.scale.x;
    lt.c = this._cy * this.scale.y;
    lt.d = this._sy * this.scale.y;
    lt.tx = this.position.x - (this.pivot.x * lt.a + this.pivot.y * lt.c);
    lt.ty = this.position.y - (this.pivot.x * lt.b + this.pivot.y * lt.d);
    this.dirty = false;
    return lt;
  }
  /**
   * Called when a value changes.
   * @param point
   * @internal
   */
  _onUpdate(point) {
    this.dirty = true;
    if (point === this.skew) {
      this.updateSkew();
    }
    this.observer?._onUpdate(this);
  }
  /** Called when the skew or the rotation changes. */
  updateSkew() {
    this._cx = Math.cos(this._rotation + this.skew.y);
    this._sx = Math.sin(this._rotation + this.skew.y);
    this._cy = -Math.sin(this._rotation - this.skew.x);
    this._sy = Math.cos(this._rotation - this.skew.x);
    this.dirty = true;
  }
  toString() {
    return `[pixi.js/math:Transform position=(${this.position.x}, ${this.position.y}) rotation=${this.rotation} scale=(${this.scale.x}, ${this.scale.y}) skew=(${this.skew.x}, ${this.skew.y}) ]`;
  }
  /**
   * Decomposes a matrix and sets the transforms properties based on it.
   * @example
   * ```ts
   * // Basic matrix decomposition
   * const transform = new Transform();
   * const matrix = new Matrix()
   *     .translate(100, 100)
   *     .rotate(Math.PI / 4)
   *     .scale(2, 2);
   *
   * transform.setFromMatrix(matrix);
   * console.log(transform.position.x); // 100
   * console.log(transform.rotation); // ~0.785 (π/4)
   * ```
   * @param matrix - The matrix to decompose
   * @see {@link Matrix#decompose} For the decomposition logic
   * @see {@link Transform#matrix} For getting the current matrix
   */
  setFromMatrix(matrix) {
    matrix.decompose(this);
    this.dirty = true;
  }
  /**
   * The rotation of the object in radians.
   * @example
   * ```ts
   * // Basic rotation
   * transform.rotation = Math.PI / 4; // 45 degrees
   *
   * // Rotate around pivot point
   * transform.pivot.set(50, 50);
   * transform.rotation = Math.PI; // 180 degrees around pivot
   *
   * // Animate rotation
   * app.ticker.add(() => {
   *     transform.rotation += 0.1;
   * });
   * ```
   * @see {@link Transform#pivot} For rotation point
   * @see {@link Transform#skew} For skew effects
   */
  get rotation() {
    return this._rotation;
  }
  set rotation(value) {
    if (this._rotation !== value) {
      this._rotation = value;
      this._onUpdate(this.skew);
    }
  }
};

// node_modules/pixi.js/lib/scene/sprite-tiling/canvas/CanvasTilingSpritePipe.mjs
var worldMatrix = new Matrix();
var patternMatrix = new Matrix();
var patternRect = [new Point(), new Point(), new Point(), new Point()];
var CanvasTilingSpritePipe = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  validateRenderable(_renderable) {
    return false;
  }
  addRenderable(tilingSprite, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add(tilingSprite);
  }
  updateRenderable(_tilingSprite) {
  }
  execute(tilingSprite) {
    const renderer = this._renderer;
    const contextSystem = renderer.canvasContext;
    const context = contextSystem.activeContext;
    context.save();
    contextSystem.setBlendMode(tilingSprite.groupBlendMode);
    const globalColor = renderer.globalUniforms.globalUniformData?.worldColor ?? 4294967295;
    const groupColorAlpha = tilingSprite.groupColorAlpha;
    const globalAlpha = (globalColor >>> 24 & 255) / 255;
    const groupAlphaValue = (groupColorAlpha >>> 24 & 255) / 255;
    const filterAlpha = renderer.filter?.alphaMultiplier ?? 1;
    const alpha = globalAlpha * groupAlphaValue * filterAlpha;
    if (alpha <= 0) {
      context.restore();
      return;
    }
    context.globalAlpha = alpha;
    const globalTint = globalColor & 16777215;
    const groupTintBGR = groupColorAlpha & 16777215;
    const tint = bgr2rgb(multiplyHexColors(groupTintBGR, globalTint));
    const texture = tilingSprite.texture;
    const pattern = canvasUtils.getTintedPattern(texture, tint);
    const width = tilingSprite.width;
    const height = tilingSprite.height;
    const transform2 = tilingSprite.groupTransform;
    const resolution = texture.source._resolution ?? texture.source.resolution ?? 1;
    patternMatrix.copyFrom(tilingSprite._tileTransform.matrix);
    if (!tilingSprite.applyAnchorToTexture) {
      patternMatrix.translate(-tilingSprite.anchor.x * width, -tilingSprite.anchor.y * height);
    }
    const savedTx = patternMatrix.tx;
    const savedTy = patternMatrix.ty;
    patternMatrix.scale(1 / resolution, 1 / resolution);
    patternMatrix.tx = savedTx;
    patternMatrix.ty = savedTy;
    worldMatrix.identity();
    worldMatrix.prepend(patternMatrix);
    worldMatrix.prepend(transform2);
    const roundPixels = renderer._roundPixels | tilingSprite._roundPixels;
    contextSystem.setContextTransform(worldMatrix, roundPixels === 1);
    context.fillStyle = pattern;
    const lx = tilingSprite.anchor.x * -width;
    const ly = tilingSprite.anchor.y * -height;
    patternRect[0].set(lx, ly);
    patternRect[1].set(lx + width, ly);
    patternRect[2].set(lx + width, ly + height);
    patternRect[3].set(lx, ly + height);
    for (let i = 0; i < 4; i++) {
      patternMatrix.applyInverse(patternRect[i], patternRect[i]);
    }
    context.beginPath();
    context.moveTo(patternRect[0].x, patternRect[0].y);
    for (let i = 1; i < 4; i++) {
      context.lineTo(patternRect[i].x, patternRect[i].y);
    }
    context.closePath();
    context.fill();
    context.restore();
  }
  destroy() {
    this._renderer = null;
  }
};
CanvasTilingSpritePipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "tilingSprite"
};

// node_modules/pixi.js/lib/scene/sprite-tiling/shader/tilingBit.mjs
var tilingBit = {
  name: "tiling-bit",
  vertex: {
    header: (
      /* wgsl */
      `
            struct TilingUniforms {
                uMapCoord:mat3x3<f32>,
                uClampFrame:vec4<f32>,
                uClampOffset:vec2<f32>,
                uTextureTransform:mat3x3<f32>,
                uSizeAnchor:vec4<f32>
            };

            @group(2) @binding(0) var<uniform> tilingUniforms: TilingUniforms;
            @group(2) @binding(1) var uTexture: texture_2d<f32>;
            @group(2) @binding(2) var uSampler: sampler;
        `
    ),
    main: (
      /* wgsl */
      `
            uv = (tilingUniforms.uTextureTransform * vec3(uv, 1.0)).xy;

            position = (position - tilingUniforms.uSizeAnchor.zw) * tilingUniforms.uSizeAnchor.xy;
        `
    )
  },
  fragment: {
    header: (
      /* wgsl */
      `
            struct TilingUniforms {
                uMapCoord:mat3x3<f32>,
                uClampFrame:vec4<f32>,
                uClampOffset:vec2<f32>,
                uTextureTransform:mat3x3<f32>,
                uSizeAnchor:vec4<f32>
            };

            @group(2) @binding(0) var<uniform> tilingUniforms: TilingUniforms;
            @group(2) @binding(1) var uTexture: texture_2d<f32>;
            @group(2) @binding(2) var uSampler: sampler;
        `
    ),
    main: (
      /* wgsl */
      `

            var coord = vUV + ceil(tilingUniforms.uClampOffset - vUV);
            coord = (tilingUniforms.uMapCoord * vec3(coord, 1.0)).xy;
            var unclamped = coord;
            coord = clamp(coord, tilingUniforms.uClampFrame.xy, tilingUniforms.uClampFrame.zw);

            var bias = 0.;

            if(unclamped.x == coord.x && unclamped.y == coord.y)
            {
                bias = -32.;
            }

            outColor = textureSampleBias(uTexture, uSampler, coord, bias);
        `
    )
  }
};
var tilingBitGl = {
  name: "tiling-bit",
  vertex: {
    header: (
      /* glsl */
      `
            uniform mat3 uTextureTransform;
            uniform vec4 uSizeAnchor;

        `
    ),
    main: (
      /* glsl */
      `
            uv = (uTextureTransform * vec3(aUV, 1.0)).xy;

            position = (position - uSizeAnchor.zw) * uSizeAnchor.xy;
        `
    )
  },
  fragment: {
    header: (
      /* glsl */
      `
            uniform sampler2D uTexture;
            uniform mat3 uMapCoord;
            uniform vec4 uClampFrame;
            uniform vec2 uClampOffset;
        `
    ),
    main: (
      /* glsl */
      `

        vec2 coord = vUV + ceil(uClampOffset - vUV);
        coord = (uMapCoord * vec3(coord, 1.0)).xy;
        vec2 unclamped = coord;
        coord = clamp(coord, uClampFrame.xy, uClampFrame.zw);

        outColor = texture(uTexture, coord, unclamped == coord ? 0.0 : -32.0);// lod-bias very negative to force lod 0

        `
    )
  }
};

// node_modules/pixi.js/lib/scene/sprite-tiling/shader/TilingSpriteShader.mjs
var gpuProgram;
var glProgram;
var TilingSpriteShader = class extends Shader {
  constructor() {
    gpuProgram ?? (gpuProgram = compileHighShaderGpuProgram({
      name: "tiling-sprite-shader",
      bits: [
        localUniformBit,
        tilingBit,
        roundPixelsBit
      ]
    }));
    glProgram ?? (glProgram = compileHighShaderGlProgram({
      name: "tiling-sprite-shader",
      bits: [
        localUniformBitGl,
        tilingBitGl,
        roundPixelsBitGl
      ]
    }));
    const tilingUniforms = new UniformGroup({
      uMapCoord: { value: new Matrix(), type: "mat3x3<f32>" },
      uClampFrame: { value: new Float32Array([0, 0, 1, 1]), type: "vec4<f32>" },
      uClampOffset: { value: new Float32Array([0, 0]), type: "vec2<f32>" },
      uTextureTransform: { value: new Matrix(), type: "mat3x3<f32>" },
      uSizeAnchor: { value: new Float32Array([100, 100, 0.5, 0.5]), type: "vec4<f32>" }
    });
    super({
      glProgram,
      gpuProgram,
      resources: {
        localUniforms: new UniformGroup({
          uTransformMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
          uColor: { value: new Float32Array([1, 1, 1, 1]), type: "vec4<f32>" },
          uRound: { value: 0, type: "f32" }
        }),
        tilingUniforms,
        uTexture: Texture.EMPTY.source,
        uSampler: Texture.EMPTY.source.style
      }
    });
  }
  updateUniforms(width, height, matrix, anchorX, anchorY, texture) {
    const tilingUniforms = this.resources.tilingUniforms;
    const textureWidth = texture.width;
    const textureHeight = texture.height;
    const textureMatrix = texture.textureMatrix;
    const uTextureTransform = tilingUniforms.uniforms.uTextureTransform;
    uTextureTransform.set(
      matrix.a * textureWidth / width,
      matrix.b * textureWidth / height,
      matrix.c * textureHeight / width,
      matrix.d * textureHeight / height,
      matrix.tx / width,
      matrix.ty / height
    );
    uTextureTransform.invert();
    tilingUniforms.uniforms.uMapCoord = textureMatrix.mapCoord;
    tilingUniforms.uniforms.uClampFrame = textureMatrix.uClampFrame;
    tilingUniforms.uniforms.uClampOffset = textureMatrix.uClampOffset;
    tilingUniforms.uniforms.uTextureTransform = uTextureTransform;
    tilingUniforms.uniforms.uSizeAnchor[0] = width;
    tilingUniforms.uniforms.uSizeAnchor[1] = height;
    tilingUniforms.uniforms.uSizeAnchor[2] = anchorX;
    tilingUniforms.uniforms.uSizeAnchor[3] = anchorY;
    if (texture) {
      this.resources.uTexture = texture.source;
      this.resources.uSampler = texture.source.style;
    }
  }
};

// node_modules/pixi.js/lib/scene/sprite-tiling/utils/QuadGeometry.mjs
var QuadGeometry = class extends MeshGeometry {
  constructor() {
    super({
      positions: new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]),
      uvs: new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]),
      indices: new Uint32Array([0, 1, 2, 0, 2, 3])
    });
  }
};

// node_modules/pixi.js/lib/scene/sprite-tiling/utils/setPositions.mjs
function setPositions(tilingSprite, positions) {
  const anchorX = tilingSprite.anchor.x;
  const anchorY = tilingSprite.anchor.y;
  positions[0] = -anchorX * tilingSprite.width;
  positions[1] = -anchorY * tilingSprite.height;
  positions[2] = (1 - anchorX) * tilingSprite.width;
  positions[3] = -anchorY * tilingSprite.height;
  positions[4] = (1 - anchorX) * tilingSprite.width;
  positions[5] = (1 - anchorY) * tilingSprite.height;
  positions[6] = -anchorX * tilingSprite.width;
  positions[7] = (1 - anchorY) * tilingSprite.height;
}

// node_modules/pixi.js/lib/scene/sprite-tiling/utils/applyMatrix.mjs
function applyMatrix(array, stride, offset, matrix) {
  let index = 0;
  const size = array.length / (stride || 2);
  const a = matrix.a;
  const b = matrix.b;
  const c = matrix.c;
  const d = matrix.d;
  const tx = matrix.tx;
  const ty = matrix.ty;
  offset *= stride;
  while (index < size) {
    const x = array[offset];
    const y = array[offset + 1];
    array[offset] = a * x + c * y + tx;
    array[offset + 1] = b * x + d * y + ty;
    offset += stride;
    index++;
  }
}

// node_modules/pixi.js/lib/scene/sprite-tiling/utils/setUvs.mjs
function setUvs(tilingSprite, uvs) {
  const texture = tilingSprite.texture;
  const width = texture.frame.width;
  const height = texture.frame.height;
  let anchorX = 0;
  let anchorY = 0;
  if (tilingSprite.applyAnchorToTexture) {
    anchorX = tilingSprite.anchor.x;
    anchorY = tilingSprite.anchor.y;
  }
  uvs[0] = uvs[6] = -anchorX;
  uvs[2] = uvs[4] = 1 - anchorX;
  uvs[1] = uvs[3] = -anchorY;
  uvs[5] = uvs[7] = 1 - anchorY;
  const tileMatrix = tilingSprite._tileTransform.matrix;
  const textureMatrix = Matrix.shared;
  textureMatrix.set(
    tileMatrix.a * width / tilingSprite.width,
    tileMatrix.b * width / tilingSprite.height,
    tileMatrix.c * height / tilingSprite.width,
    tileMatrix.d * height / tilingSprite.height,
    tileMatrix.tx / tilingSprite.width,
    tileMatrix.ty / tilingSprite.height
  );
  textureMatrix.invert();
  applyMatrix(uvs, 2, 0, textureMatrix);
}

// node_modules/pixi.js/lib/scene/sprite-tiling/TilingSpritePipe.mjs
var sharedQuad = new QuadGeometry();
var TilingSpriteGpuData = class {
  constructor() {
    this.canBatch = true;
    this.geometry = new MeshGeometry({
      indices: sharedQuad.indices.slice(),
      positions: sharedQuad.positions.slice(),
      uvs: sharedQuad.uvs.slice()
    });
  }
  destroy() {
    this.geometry.destroy();
    this.shader?.destroy();
  }
};
var TilingSpritePipe = class {
  constructor(renderer) {
    this._state = State.default2d;
    this._renderer = renderer;
    this._managedTilingSprites = new GCManagedHash({ renderer, type: "renderable", name: "tilingSprite" });
  }
  validateRenderable(renderable) {
    const tilingSpriteData = this._getTilingSpriteData(renderable);
    const couldBatch = tilingSpriteData.canBatch;
    this._updateCanBatch(renderable);
    const canBatch = tilingSpriteData.canBatch;
    if (canBatch && canBatch === couldBatch) {
      const { batchableMesh } = tilingSpriteData;
      return !batchableMesh._batcher.checkAndUpdateTexture(
        batchableMesh,
        renderable.texture
      );
    }
    return couldBatch !== canBatch;
  }
  addRenderable(tilingSprite, instructionSet) {
    const batcher = this._renderer.renderPipes.batch;
    this._updateCanBatch(tilingSprite);
    const tilingSpriteData = this._getTilingSpriteData(tilingSprite);
    const { geometry, canBatch } = tilingSpriteData;
    if (canBatch) {
      tilingSpriteData.batchableMesh || (tilingSpriteData.batchableMesh = new BatchableMesh());
      const batchableMesh = tilingSpriteData.batchableMesh;
      if (tilingSprite.didViewUpdate) {
        this._updateBatchableMesh(tilingSprite);
        batchableMesh.geometry = geometry;
        batchableMesh.renderable = tilingSprite;
        batchableMesh.transform = tilingSprite.groupTransform;
        batchableMesh.setTexture(tilingSprite._texture);
      }
      batchableMesh.roundPixels = this._renderer._roundPixels | tilingSprite._roundPixels;
      batcher.addToBatch(batchableMesh, instructionSet);
    } else {
      batcher.break(instructionSet);
      tilingSpriteData.shader || (tilingSpriteData.shader = new TilingSpriteShader());
      this.updateRenderable(tilingSprite);
      instructionSet.add(tilingSprite);
    }
  }
  execute(tilingSprite) {
    const renderer = this._renderer;
    const { shader } = this._getTilingSpriteData(tilingSprite);
    shader.groups[0] = renderer.globalUniforms.bindGroup;
    const localUniforms = shader.resources.localUniforms.uniforms;
    localUniforms.uTransformMatrix = tilingSprite.groupTransform;
    localUniforms.uRound = renderer._roundPixels | tilingSprite._roundPixels;
    color32BitToUniform(
      tilingSprite.groupColorAlpha,
      localUniforms.uColor,
      0
    );
    this._state.blendMode = getAdjustedBlendModeBlend(tilingSprite.groupBlendMode, tilingSprite.texture._source);
    renderer.encoder.draw({
      geometry: sharedQuad,
      shader,
      state: this._state
    });
  }
  updateRenderable(tilingSprite) {
    const tilingSpriteData = this._getTilingSpriteData(tilingSprite);
    const { canBatch } = tilingSpriteData;
    if (canBatch) {
      const { batchableMesh } = tilingSpriteData;
      if (tilingSprite.didViewUpdate) this._updateBatchableMesh(tilingSprite);
      batchableMesh._batcher.updateElement(batchableMesh);
    } else if (tilingSprite.didViewUpdate) {
      const { shader } = tilingSpriteData;
      shader.updateUniforms(
        tilingSprite.width,
        tilingSprite.height,
        tilingSprite._tileTransform.matrix,
        tilingSprite.anchor.x,
        tilingSprite.anchor.y,
        tilingSprite.texture
      );
    }
  }
  _getTilingSpriteData(renderable) {
    return renderable._gpuData[this._renderer.uid] || this._initTilingSpriteData(renderable);
  }
  _initTilingSpriteData(tilingSprite) {
    const gpuData = new TilingSpriteGpuData();
    gpuData.renderable = tilingSprite;
    tilingSprite._gpuData[this._renderer.uid] = gpuData;
    this._managedTilingSprites.add(tilingSprite);
    return gpuData;
  }
  _updateBatchableMesh(tilingSprite) {
    const renderableData = this._getTilingSpriteData(tilingSprite);
    const { geometry } = renderableData;
    const style = tilingSprite.texture.source.style;
    if (style.addressMode !== "repeat") {
      style.addressMode = "repeat";
      style.update();
    }
    setUvs(tilingSprite, geometry.uvs);
    setPositions(tilingSprite, geometry.positions);
  }
  destroy() {
    this._managedTilingSprites.destroy();
    this._renderer = null;
  }
  _updateCanBatch(tilingSprite) {
    const renderableData = this._getTilingSpriteData(tilingSprite);
    const texture = tilingSprite.texture;
    let _nonPowOf2wrapping = true;
    if (this._renderer.type === RendererType.WEBGL) {
      _nonPowOf2wrapping = this._renderer.context.supports.nonPowOf2wrapping;
    }
    renderableData.canBatch = texture.textureMatrix.isSimple && (_nonPowOf2wrapping || texture.source.isPowerOfTwo);
    return renderableData.canBatch;
  }
};
TilingSpritePipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes
  ],
  name: "tilingSprite"
};

// node_modules/pixi.js/lib/scene/sprite-tiling/init.mjs
extensions.add(CanvasTilingSpritePipe);
extensions.add(TilingSpritePipe);

// node_modules/pixi.js/lib/scene/sprite-tiling/TilingSprite.mjs
var _TilingSprite = class _TilingSprite2 extends ViewContainer {
  constructor(...args) {
    let options = args[0] || {};
    if (options instanceof Texture) {
      options = { texture: options };
    }
    if (args.length > 1) {
      deprecation(v8_0_0, "use new TilingSprite({ texture, width:100, height:100 }) instead");
      options.width = args[1];
      options.height = args[2];
    }
    options = __spreadValues(__spreadValues({}, _TilingSprite2.defaultOptions), options);
    const _a = options ?? {}, {
      texture,
      anchor,
      tilePosition,
      tileScale,
      tileRotation,
      width,
      height,
      applyAnchorToTexture,
      roundPixels
    } = _a, rest = __objRest(_a, [
      "texture",
      "anchor",
      "tilePosition",
      "tileScale",
      "tileRotation",
      "width",
      "height",
      "applyAnchorToTexture",
      "roundPixels"
    ]);
    super(__spreadValues({
      label: "TilingSprite"
    }, rest));
    this.renderPipeId = "tilingSprite";
    this.batched = true;
    this.allowChildren = false;
    this._anchor = new ObservablePoint(
      {
        _onUpdate: () => {
          this.onViewUpdate();
        }
      }
    );
    this.applyAnchorToTexture = applyAnchorToTexture;
    this.texture = texture;
    this._width = width ?? texture.width;
    this._height = height ?? texture.height;
    this._tileTransform = new Transform({
      observer: {
        _onUpdate: () => this.onViewUpdate()
      }
    });
    if (anchor) this.anchor = anchor;
    this.tilePosition = tilePosition;
    this.tileScale = tileScale;
    this.tileRotation = tileRotation;
    this.roundPixels = roundPixels ?? false;
  }
  /**
   * Creates a new tiling sprite based on a source texture or image path.
   * This is a convenience method that automatically creates and manages textures.
   * @example
   * ```ts
   * // Create a new tiling sprite from an image path
   * const pattern = TilingSprite.from('pattern.png');
   * pattern.width = 300; // Set the width of the tiling area
   * pattern.height = 200; // Set the height of the tiling area
   *
   * // Create from options
   * const texture = Texture.from('pattern.png');
   * const pattern = TilingSprite.from(texture, {
   *     width: 300,
   *     height: 200,
   *     tileScale: { x: 0.5, y: 0.5 }
   * });
   * ```
   * @param source - The source to create the sprite from. Can be a path to an image or a texture
   * @param options - Additional options for the tiling sprite
   * @returns A new tiling sprite based on the source
   * @see {@link Texture.from} For texture creation details
   * @see {@link Assets} For asset loading and management
   */
  static from(source8, options = {}) {
    if (typeof source8 === "string") {
      return new _TilingSprite2(__spreadValues({
        texture: Cache.get(source8)
      }, options));
    }
    return new _TilingSprite2(__spreadValues({
      texture: source8
    }, options));
  }
  /**
   * @see {@link TilingSpriteOptions.applyAnchorToTexture}
   * @deprecated since 8.0.0
   * @advanced
   */
  get uvRespectAnchor() {
    deprecation(v8_0_0, "uvRespectAnchor is deprecated, please use applyAnchorToTexture instead");
    return this.applyAnchorToTexture;
  }
  /** @advanced */
  set uvRespectAnchor(value) {
    deprecation(v8_0_0, "uvRespectAnchor is deprecated, please use applyAnchorToTexture instead");
    this.applyAnchorToTexture = value;
  }
  /**
   * Changes frame clamping in corresponding textureMatrix
   * Change to -0.5 to add a pixel to the edge, recommended for transparent trimmed textures in atlas
   * @default 0.5
   * @type {number}
   * @advanced
   */
  get clampMargin() {
    return this._texture.textureMatrix.clampMargin;
  }
  /** @advanced */
  set clampMargin(value) {
    this._texture.textureMatrix.clampMargin = value;
  }
  /**
   * The anchor sets the origin point of the sprite. The default value is taken from the {@link Texture}
   * and passed to the constructor.
   *
   * - The default is `(0,0)`, this means the sprite's origin is the top left.
   * - Setting the anchor to `(0.5,0.5)` means the sprite's origin is centered.
   * - Setting the anchor to `(1,1)` would mean the sprite's origin point will be the bottom right corner.
   *
   * If you pass only single parameter, it will set both x and y to the same value as shown in the example below.
   * @example
   * ```ts
   * // Center the anchor point
   * sprite.anchor = 0.5; // Sets both x and y to 0.5
   * sprite.position.set(400, 300); // Sprite will be centered at this position
   *
   * // Set specific x/y anchor points
   * sprite.anchor = {
   *     x: 1, // Right edge
   *     y: 0  // Top edge
   * };
   *
   * // Using individual coordinates
   * sprite.anchor.set(0.5, 1); // Center-bottom
   *
   * // For rotation around center
   * sprite.anchor.set(0.5);
   * sprite.rotation = Math.PI / 4; // 45 degrees around center
   *
   * // For scaling from center
   * sprite.anchor.set(0.5);
   * sprite.scale.set(2); // Scales from center point
   * ```
   */
  get anchor() {
    return this._anchor;
  }
  set anchor(value) {
    typeof value === "number" ? this._anchor.set(value) : this._anchor.copyFrom(value);
  }
  /**
   * The offset of the tiling texture.
   * Used to scroll or position the repeated pattern.
   * @example
   * ```ts
   * // Offset the tiling pattern by 100 pixels in both x and y directions
   * tilingSprite.tilePosition = { x: 100, y: 100 };
   * ```
   * @default {x: 0, y: 0}
   */
  get tilePosition() {
    return this._tileTransform.position;
  }
  set tilePosition(value) {
    this._tileTransform.position.copyFrom(value);
  }
  /**
   * Scale of the tiling texture.
   * Affects the size of each repeated instance of the texture.
   * @example
   * ```ts
   * // Scale the texture by 1.5 in both x and y directions
   * tilingSprite.tileScale = { x: 1.5, y: 1.5 };
   * ```
   * @default {x: 1, y: 1}
   */
  get tileScale() {
    return this._tileTransform.scale;
  }
  set tileScale(value) {
    typeof value === "number" ? this._tileTransform.scale.set(value) : this._tileTransform.scale.copyFrom(value);
  }
  set tileRotation(value) {
    this._tileTransform.rotation = value;
  }
  /**
   * Rotation of the tiling texture in radians.
   * This controls the rotation applied to the texture before tiling.
   * @example
   * ```ts
   * // Rotate the texture by 45 degrees (in radians)
   * tilingSprite.tileRotation = Math.PI / 4; // 45 degrees
   * ```
   * @default 0
   */
  get tileRotation() {
    return this._tileTransform.rotation;
  }
  /**
   * The transform object that controls the tiling texture's position, scale, and rotation.
   * This transform is independent of the sprite's own transform properties.
   * @example
   * ```ts
   * // Access transform properties directly
   * sprite.tileTransform.position.set(100, 50);
   * sprite.tileTransform.scale.set(2);
   * sprite.tileTransform.rotation = Math.PI / 4;
   *
   * // Create smooth scrolling animation
   * app.ticker.add(() => {
   *     sprite.tileTransform.position.x += 1;
   *     sprite.tileTransform.rotation += 0.01;
   * });
   *
   * // Reset transform
   * sprite.tileTransform.position.set(0);
   * sprite.tileTransform.scale.set(1);
   * sprite.tileTransform.rotation = 0;
   * ```
   * @returns {Transform} The transform object for the tiling texture
   * @see {@link Transform} For transform operations
   * @see {@link TilingSprite#tilePosition} For position control
   * @see {@link TilingSprite#tileScale} For scale control
   * @see {@link TilingSprite#tileRotation} For rotation control
   * @advanced
   */
  get tileTransform() {
    return this._tileTransform;
  }
  set texture(value) {
    value || (value = Texture.EMPTY);
    const currentTexture = this._texture;
    if (currentTexture === value) return;
    if (currentTexture && currentTexture.dynamic) currentTexture.off("update", this.onViewUpdate, this);
    if (value.dynamic) value.on("update", this.onViewUpdate, this);
    this._texture = value;
    this.onViewUpdate();
  }
  /**
   * The texture to use for tiling.
   * This is the image that will be repeated across the sprite.
   * @example
   * ```ts
   * // Use a texture from the asset cache
   * tilingSprite.texture = Texture.from('assets/pattern.png');
   * ```
   * @default Texture.EMPTY
   */
  get texture() {
    return this._texture;
  }
  /**
   * The width of the tiling area. This defines how wide the area is that the texture will be tiled across.
   * @example
   * ```ts
   * // Create a tiling sprite
   * const sprite = new TilingSprite({
   *     texture: Texture.from('pattern.png'),
   *     width: 500,
   *     height: 300
   * });
   *
   * // Adjust width dynamically
   * sprite.width = 800; // Expands tiling area
   *
   * // Update on resize
   * window.addEventListener('resize', () => {
   *     sprite.width = app.screen.width;
   * });
   * ```
   * @see {@link TilingSprite#setSize} For setting both width and height efficiently
   * @see {@link TilingSprite#height} For setting height
   */
  set width(value) {
    this._width = value;
    this.onViewUpdate();
  }
  get width() {
    return this._width;
  }
  set height(value) {
    this._height = value;
    this.onViewUpdate();
  }
  /**
   * The height of the tiling area. This defines how tall the area is that the texture will be tiled across.
   * @example
   * ```ts
   * // Create a tiling sprite
   * const sprite = new TilingSprite({
   *     texture: Texture.from('pattern.png'),
   *     width: 500,
   *     height: 300
   * });
   *
   * // Adjust width dynamically
   * sprite.height = 800; // Expands tiling area
   *
   * // Update on resize
   * window.addEventListener('resize', () => {
   *     sprite.height = app.screen.height;
   * });
   * ```
   * @see {@link TilingSprite#setSize} For setting both width and height efficiently
   * @see {@link TilingSprite#width} For setting width
   */
  get height() {
    return this._height;
  }
  /**
   * Sets the size of the TilingSprite to the specified width and height.
   * This is faster than setting width and height separately as it only triggers one update.
   * @example
   * ```ts
   * // Set specific dimensions
   * sprite.setSize(300, 200); // Width: 300, Height: 200
   *
   * // Set uniform size (square)
   * sprite.setSize(400); // Width: 400, Height: 400
   *
   * // Set size using object
   * sprite.setSize({
   *     width: 500,
   *     height: 300
   * });
   * ```
   * @param value - This can be either a number for uniform sizing or a Size object with width/height properties
   * @param height - The height to set. Defaults to the value of `width` if not provided
   * @see {@link TilingSprite#width} For setting width only
   * @see {@link TilingSprite#height} For setting height only
   */
  setSize(value, height) {
    if (typeof value === "object") {
      height = value.height ?? value.width;
      value = value.width;
    }
    this._width = value;
    this._height = height ?? value;
    this.onViewUpdate();
  }
  /**
   * Retrieves the size of the TilingSprite as a {@link Size} object.
   * This method is more efficient than getting width and height separately as it only allocates one object.
   * @example
   * ```ts
   * // Get basic size
   * const size = sprite.getSize();
   * console.log(`Size: ${size.width}x${size.height}`);
   *
   * // Reuse existing size object
   * const reuseSize = { width: 0, height: 0 };
   * sprite.getSize(reuseSize);
   * ```
   * @param out - Optional object to store the size in, to avoid allocating a new object
   * @returns The size of the TilingSprite
   * @see {@link TilingSprite#width} For getting just the width
   * @see {@link TilingSprite#height} For getting just the height
   * @see {@link TilingSprite#setSize} For setting both width and height efficiently
   */
  getSize(out) {
    out || (out = {});
    out.width = this._width;
    out.height = this._height;
    return out;
  }
  /** @private */
  updateBounds() {
    const bounds = this._bounds;
    const anchor = this._anchor;
    const width = this._width;
    const height = this._height;
    bounds.minX = -anchor._x * width;
    bounds.maxX = bounds.minX + width;
    bounds.minY = -anchor._y * height;
    bounds.maxY = bounds.minY + height;
  }
  /**
   * Checks if the object contains the given point in local coordinates.
   * Takes into account the anchor offset when determining boundaries.
   * @example
   * ```ts
   * // Create a tiling sprite
   * const sprite = new TilingSprite({
   *     texture: Texture.from('pattern.png'),
   *     width: 200,
   *     height: 100,
   *     anchor: 0.5 // Center anchor
   * });
   *
   * // Basic point check
   * const contains = sprite.containsPoint({ x: 50, y: 25 });
   * console.log('Point is inside:', contains);
   *
   * // Check with different anchors
   * sprite.anchor.set(0); // Top-left anchor
   * console.log('Contains point:', sprite.containsPoint({ x: 150, y: 75 }));
   * ```
   * @param point - The point to check in local coordinates
   * @returns True if the point is within the sprite's bounds
   * @see {@link TilingSprite#toLocal} For converting global coordinates to local
   * @see {@link TilingSprite#anchor} For understanding boundary calculations
   */
  containsPoint(point) {
    const width = this._width;
    const height = this._height;
    const x1 = -width * this._anchor._x;
    let y1 = 0;
    if (point.x >= x1 && point.x <= x1 + width) {
      y1 = -height * this._anchor._y;
      if (point.y >= y1 && point.y <= y1 + height) return true;
    }
    return false;
  }
  /**
   * Destroys this sprite renderable and optionally its texture.
   * @param options - Options parameter. A boolean will act as if all options
   *  have been set to that value
   * @example
   * tilingSprite.destroy();
   * tilingSprite.destroy(true);
   * tilingSprite.destroy({ texture: true, textureSource: true });
   */
  destroy(options = false) {
    super.destroy(options);
    this._anchor = null;
    this._tileTransform = null;
    this._bounds = null;
    const destroyTexture = typeof options === "boolean" ? options : options?.texture;
    if (destroyTexture) {
      const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
      this._texture.destroy(destroyTextureSource);
    }
    this._texture = null;
  }
};
_TilingSprite.defaultOptions = {
  /** The texture to use for the sprite. */
  texture: Texture.EMPTY,
  /** The anchor point of the sprite */
  anchor: { x: 0, y: 0 },
  /** The offset of the image that is being tiled. */
  tilePosition: { x: 0, y: 0 },
  /** Scaling of the image that is being tiled. */
  tileScale: { x: 1, y: 1 },
  /** The rotation of the image that is being tiled. */
  tileRotation: 0,
  /**
   * Flags whether the tiling pattern should originate from the origin instead of the top-left corner in
   * local space.
   *
   * This will make the texture coordinates assigned to each vertex dependent on the value of the anchor. Without
   * this, the top-left corner always gets the (0, 0) texture coordinate.
   * @default false
   */
  applyAnchorToTexture: false
};
var TilingSprite = _TilingSprite;

// node_modules/pixi.js/lib/scene/text/AbstractText.mjs
var AbstractText = class extends ViewContainer {
  constructor(options, styleClass) {
    const _a = options, { text, resolution, style, anchor, width, height, roundPixels } = _a, rest = __objRest(_a, ["text", "resolution", "style", "anchor", "width", "height", "roundPixels"]);
    super(__spreadValues({}, rest));
    this.batched = true;
    this._resolution = null;
    this._autoResolution = true;
    this._didTextUpdate = true;
    this._styleClass = styleClass;
    this.text = text ?? "";
    this.style = style;
    this.resolution = resolution ?? null;
    this.allowChildren = false;
    this._anchor = new ObservablePoint(
      {
        _onUpdate: () => {
          this.onViewUpdate();
        }
      }
    );
    if (anchor) this.anchor = anchor;
    this.roundPixels = roundPixels ?? false;
    if (width !== void 0) this.width = width;
    if (height !== void 0) this.height = height;
  }
  /**
   * The anchor point of the text that controls the origin point for positioning and rotation.
   * Can be a number (same value for x/y) or a PointData object.
   * - (0,0) is top-left
   * - (0.5,0.5) is center
   * - (1,1) is bottom-right
   * ```ts
   * // Set anchor to center
   * const text = new Text({
   *     text: 'Hello Pixi!',
   *     anchor: 0.5 // Same as { x: 0.5, y: 0.5 }
   * });
   * // Set anchor to top-left
   * const text2 = new Text({
   *     text: 'Hello Pixi!',
   *     anchor: { x: 0, y: 0 } // Top-left corner
   * });
   * // Set anchor to bottom-right
   * const text3 = new Text({
   *     text: 'Hello Pixi!',
   *     anchor: { x: 1, y: 1 } // Bottom-right corner
   * });
   * ```
   * @default { x: 0, y: 0 }
   */
  get anchor() {
    return this._anchor;
  }
  set anchor(value) {
    typeof value === "number" ? this._anchor.set(value) : this._anchor.copyFrom(value);
  }
  /**
   * The text content to display. Use '\n' for line breaks.
   * Accepts strings, numbers, or objects with toString() method.
   * @example
   * ```ts
   * const text = new Text({
   *     text: 'Hello Pixi!',
   * });
   * const multilineText = new Text({
   *     text: 'Line 1\nLine 2\nLine 3',
   * });
   * const numberText = new Text({
   *     text: 12345, // Will be converted to '12345'
   * });
   * const objectText = new Text({
   *     text: { toString: () => 'Object Text' }, // Custom toString
   * });
   *
   * // Update text dynamically
   * text.text = 'Updated Text'; // Re-renders with new text
   * text.text = 67890; // Updates to '67890'
   * text.text = { toString: () => 'Dynamic Text' }; // Uses custom toString method
   * // Clear text
   * text.text = ''; // Clears the text
   * ```
   * @default ''
   */
  set text(value) {
    value = value.toString();
    if (this._text === value) return;
    this._text = value;
    this.onViewUpdate();
  }
  get text() {
    return this._text;
  }
  /**
   * The resolution/device pixel ratio for rendering.
   * Higher values result in sharper text at the cost of performance.
   * Set to null for auto-resolution based on device.
   * @example
   * ```ts
   * const text = new Text({
   *     text: 'Hello Pixi!',
   *     resolution: 2 // High DPI for sharper text
   * });
   * const autoResText = new Text({
   *     text: 'Auto Resolution',
   *     resolution: null // Use device's pixel ratio
   * });
   * ```
   * @default null
   */
  set resolution(value) {
    this._autoResolution = value === null;
    this._resolution = value;
    this.onViewUpdate();
  }
  get resolution() {
    return this._resolution;
  }
  get style() {
    return this._style;
  }
  /**
   * The style configuration for the text.
   * Can be a TextStyle instance or a configuration object.
   * Supports canvas text styles, HTML text styles, and bitmap text styles.
   * @example
   * ```ts
   * const text = new Text({
   *     text: 'Styled Text',
   *     style: {
   *         fontSize: 24,
   *         fill: 0xff1010, // Red color
   *         fontFamily: 'Arial',
   *         align: 'center', // Center alignment
   *         stroke: { color: '#4a1850', width: 5 }, // Purple stroke
   *         dropShadow: {
   *             color: '#000000', // Black shadow
   *             blur: 4, // Shadow blur
   *             distance: 6 // Shadow distance
   *         }
   *     }
   * });
   * const htmlText = new HTMLText({
   *     text: 'HTML Styled Text',
   *     style: {
   *         fontSize: '20px',
   *         fill: 'blue',
   *         fontFamily: 'Verdana',
   *     }
   * });
   * const bitmapText = new BitmapText({
   *     text: 'Bitmap Styled Text',
   *     style: {
   *         fontName: 'Arial',
   *         fontSize: 32,
   *     }
   * })
   *
   * // Update style dynamically
   * text.style = {
   *     fontSize: 30, // Change font size
   *     fill: 0x00ff00, // Change color to green
   *     align: 'right', // Change alignment to right
   *     stroke: { color: '#000000', width: 2 }, // Add black stroke
   * }
   */
  set style(style) {
    style || (style = {});
    this._style?.off("update", this.onViewUpdate, this);
    if (style instanceof this._styleClass) {
      this._style = style;
    } else {
      this._style = new this._styleClass(style);
    }
    this._style.on("update", this.onViewUpdate, this);
    this.onViewUpdate();
  }
  /**
   * The width of the sprite, setting this will actually modify the scale to achieve the value set.
   * @example
   * ```ts
   * // Set width directly
   * texture.width = 200;
   * console.log(texture.scale.x); // Scale adjusted to match width
   *
   * // For better performance when setting both width and height
   * texture.setSize(300, 400); // Avoids recalculating bounds twice
   * ```
   */
  get width() {
    return Math.abs(this.scale.x) * this.bounds.width;
  }
  set width(value) {
    this._setWidth(value, this.bounds.width);
  }
  /**
   * The height of the sprite, setting this will actually modify the scale to achieve the value set.
   * @example
   * ```ts
   * // Set height directly
   * texture.height = 200;
   * console.log(texture.scale.y); // Scale adjusted to match height
   *
   * // For better performance when setting both width and height
   * texture.setSize(300, 400); // Avoids recalculating bounds twice
   * ```
   */
  get height() {
    return Math.abs(this.scale.y) * this.bounds.height;
  }
  set height(value) {
    this._setHeight(value, this.bounds.height);
  }
  /**
   * Retrieves the size of the Text as a [Size]{@link Size} object based on the texture dimensions and scale.
   * This is faster than getting width and height separately as it only calculates the bounds once.
   * @example
   * ```ts
   * // Basic size retrieval
   * const text = new Text({
   *     text: 'Hello Pixi!',
   *     style: { fontSize: 24 }
   * });
   * const size = text.getSize();
   * console.log(`Size: ${size.width}x${size.height}`);
   *
   * // Reuse existing size object
   * const reuseSize = { width: 0, height: 0 };
   * text.getSize(reuseSize);
   * ```
   * @param out - Optional object to store the size in, to avoid allocating a new object
   * @returns The size of the Sprite
   * @see {@link Text#width} For getting just the width
   * @see {@link Text#height} For getting just the height
   * @see {@link Text#setSize} For setting both width and height
   */
  getSize(out) {
    out || (out = {});
    out.width = Math.abs(this.scale.x) * this.bounds.width;
    out.height = Math.abs(this.scale.y) * this.bounds.height;
    return out;
  }
  /**
   * Sets the size of the Text to the specified width and height.
   * This is faster than setting width and height separately as it only recalculates bounds once.
   * @example
   * ```ts
   * // Basic size setting
   * const text = new Text({
   *    text: 'Hello Pixi!',
   *    style: { fontSize: 24 }
   * });
   * text.setSize(100, 200); // Width: 100, Height: 200
   *
   * // Set uniform size
   * text.setSize(100); // Sets both width and height to 100
   *
   * // Set size with object
   * text.setSize({
   *     width: 200,
   *     height: 300
   * });
   * ```
   * @param value - This can be either a number or a {@link Size} object
   * @param height - The height to set. Defaults to the value of `width` if not provided
   * @see {@link Text#width} For setting width only
   * @see {@link Text#height} For setting height only
   */
  setSize(value, height) {
    if (typeof value === "object") {
      height = value.height ?? value.width;
      value = value.width;
    } else {
      height ?? (height = value);
    }
    value !== void 0 && this._setWidth(value, this.bounds.width);
    height !== void 0 && this._setHeight(height, this.bounds.height);
  }
  /**
   * Checks if the object contains the given point in local coordinates.
   * Uses the text's bounds for hit testing.
   * @example
   * ```ts
   * // Basic point check
   * const localPoint = { x: 50, y: 25 };
   * const contains = text.containsPoint(localPoint);
   * console.log('Point is inside:', contains);
   * ```
   * @param point - The point to check in local coordinates
   * @returns True if the point is within the text's bounds
   * @see {@link Container#toLocal} For converting global coordinates to local
   */
  containsPoint(point) {
    const width = this.bounds.width;
    const height = this.bounds.height;
    const x1 = -width * this.anchor.x;
    let y1 = 0;
    if (point.x >= x1 && point.x <= x1 + width) {
      y1 = -height * this.anchor.y;
      if (point.y >= y1 && point.y <= y1 + height) return true;
    }
    return false;
  }
  /** @internal */
  onViewUpdate() {
    if (!this.didViewUpdate) this._didTextUpdate = true;
    super.onViewUpdate();
  }
  /**
   * Destroys this text renderable and optionally its style texture.
   * @param options - Options parameter. A boolean will act as if all options
   *  have been set to that value
   * @example
   * // Destroys the text and its style
   * text.destroy({ style: true, texture: true, textureSource: true });
   * text.destroy(true);
   * text.destroy() // Destroys the text, but not its style
   */
  destroy(options = false) {
    this._style?.off("update", this.onViewUpdate, this);
    super.destroy(options);
    this.owner = null;
    this._bounds = null;
    this._anchor = null;
    if (typeof options === "boolean" ? options : options?.style) {
      this._style.destroy(options);
    }
    this._style = null;
    this._text = null;
  }
  /**
   * Returns a unique key for this instance.
   * This key is used for caching.
   * @returns {string} Unique key for the instance
   */
  get styleKey() {
    return `${this._text}:${this._style.styleKey}:${this._resolution}`;
  }
};
function ensureTextOptions(args, name) {
  let options = args[0] ?? {};
  if (typeof options === "string" || args[1]) {
    deprecation(v8_0_0, `use new ${name}({ text: "hi!", style }) instead`);
    options = {
      text: options,
      style: args[1]
    };
  }
  return options;
}

// node_modules/pixi.js/lib/utils/canvas/getCanvasBoundingBox.mjs
var _internalCanvas = null;
var _internalContext = null;
function ensureInternalCanvas(width, height) {
  if (!_internalCanvas) {
    _internalCanvas = DOMAdapter.get().createCanvas(256, 128);
    _internalContext = _internalCanvas.getContext("2d", { willReadFrequently: true });
    _internalContext.globalCompositeOperation = "copy";
    _internalContext.globalAlpha = 1;
  }
  if (_internalCanvas.width < width || _internalCanvas.height < height) {
    _internalCanvas.width = nextPow2(width);
    _internalCanvas.height = nextPow2(height);
  }
}
function checkRow(data, width, y) {
  for (let x = 0, index = 4 * y * width; x < width; ++x, index += 4) {
    if (data[index + 3] !== 0) return false;
  }
  return true;
}
function checkColumn(data, width, x, top, bottom) {
  const stride = 4 * width;
  for (let y = top, index = top * stride + 4 * x; y <= bottom; ++y, index += stride) {
    if (data[index + 3] !== 0) return false;
  }
  return true;
}
function getCanvasBoundingBox(...args) {
  let options = args[0];
  if (!options.canvas) {
    options = { canvas: args[0], resolution: args[1] };
  }
  const { canvas } = options;
  const resolution = Math.min(options.resolution ?? 1, 1);
  const width = options.width ?? canvas.width;
  const height = options.height ?? canvas.height;
  let output = options.output;
  ensureInternalCanvas(width, height);
  if (!_internalContext) {
    throw new TypeError("Failed to get canvas 2D context");
  }
  _internalContext.drawImage(
    canvas,
    0,
    0,
    width,
    height,
    0,
    0,
    width * resolution,
    height * resolution
  );
  const imageData = _internalContext.getImageData(0, 0, width, height);
  const data = imageData.data;
  let left = 0;
  let top = 0;
  let right = width - 1;
  let bottom = height - 1;
  while (top < height && checkRow(data, width, top)) ++top;
  if (top === height) return Rectangle.EMPTY;
  while (checkRow(data, width, bottom)) --bottom;
  while (checkColumn(data, width, left, top, bottom)) ++left;
  while (checkColumn(data, width, right, top, bottom)) --right;
  ++right;
  ++bottom;
  _internalContext.globalCompositeOperation = "source-over";
  _internalContext.strokeRect(left, top, right - left, bottom - top);
  _internalContext.globalCompositeOperation = "copy";
  output ?? (output = new Rectangle());
  output.set(left / resolution, top / resolution, (right - left) / resolution, (bottom - top) / resolution);
  return output;
}

// node_modules/pixi.js/lib/scene/text/canvas/CanvasTextGenerator.mjs
var tempRect = new Rectangle();
function countSpaces(text) {
  let count = 0;
  for (let i = 0; i < text.length; i++) {
    if (text.charCodeAt(i) === 32) count++;
  }
  return count;
}
var CanvasTextGeneratorClass = class {
  /**
   * Creates a canvas with the specified text rendered to it.
   *
   * Generates a canvas of appropriate size, renders the text with the provided style,
   * and returns both the canvas/context and a Rectangle representing the text bounds.
   *
   * When trim is enabled in the style, the frame will represent the bounds of the
   * non-transparent pixels, which can be smaller than the full canvas.
   * @param options - The options for generating the text canvas
   * @param options.text - The text to render
   * @param options.style - The style to apply to the text
   * @param options.resolution - The resolution of the canvas (defaults to 1)
   * @param options.padding
   * @returns An object containing the canvas/context and the frame (bounds) of the text
   */
  getCanvasAndContext(options) {
    const { text, style, resolution = 1 } = options;
    const padding = style._getFinalPadding();
    const measured = CanvasTextMetrics.measureText(text || " ", style);
    const width = Math.ceil(Math.ceil(Math.max(1, measured.width) + padding * 2) * resolution);
    const height = Math.ceil(Math.ceil(Math.max(1, measured.height) + padding * 2) * resolution);
    const canvasAndContext = CanvasPool.getOptimalCanvasAndContext(width, height);
    this._renderTextToCanvas(style, padding, resolution, canvasAndContext, measured);
    const frame = style.trim ? getCanvasBoundingBox({ canvas: canvasAndContext.canvas, width, height, resolution: 1, output: tempRect }) : tempRect.set(0, 0, width, height);
    return {
      canvasAndContext,
      frame
    };
  }
  /**
   * Returns a canvas and context to the pool.
   *
   * This should be called when you're done with the canvas to allow reuse
   * and prevent memory leaks.
   * @param canvasAndContext - The canvas and context to return to the pool
   */
  returnCanvasAndContext(canvasAndContext) {
    CanvasPool.returnCanvasAndContext(canvasAndContext);
  }
  /**
   * Renders text to its canvas, and updates its texture.
   * @param style - The style of the text
   * @param padding - The padding of the text
   * @param resolution - The resolution of the text
   * @param canvasAndContext - The canvas and context to render the text to
   * @param measured - Pre-measured text metrics to avoid duplicate measurement
   */
  _renderTextToCanvas(style, padding, resolution, canvasAndContext, measured) {
    if (measured.runsByLine && measured.runsByLine.length > 0) {
      this._renderTaggedTextToCanvas(measured, style, padding, resolution, canvasAndContext);
      return;
    }
    const { canvas, context } = canvasAndContext;
    const font = fontStringFromTextStyle(style);
    const lines = measured.lines;
    const lineHeight = measured.lineHeight;
    const lineWidths = measured.lineWidths;
    const maxLineWidth = measured.maxLineWidth;
    const fontProperties = measured.fontProperties;
    const height = canvas.height;
    context.resetTransform();
    context.scale(resolution, resolution);
    context.textBaseline = style.textBaseline;
    if (style._stroke?.width) {
      const strokeStyle = style._stroke;
      context.lineWidth = strokeStyle.width;
      context.miterLimit = strokeStyle.miterLimit;
      context.lineJoin = strokeStyle.join;
      context.lineCap = strokeStyle.cap;
    }
    context.font = font;
    let linePositionX;
    let linePositionY;
    const passesCount = style.dropShadow ? 2 : 1;
    const strokeWidth = style._stroke?.width ?? 0;
    const halfStroke = strokeWidth / 2;
    let linePositionYShift = (lineHeight - fontProperties.fontSize) / 2;
    if (lineHeight - fontProperties.fontSize < 0) {
      linePositionYShift = 0;
    }
    for (let i = 0; i < passesCount; ++i) {
      const isShadowPass = style.dropShadow && i === 0;
      const dsOffsetText = isShadowPass ? Math.ceil(Math.max(1, height) + padding * 2) : 0;
      const dsOffsetShadow = dsOffsetText * resolution;
      if (isShadowPass) {
        this._setupDropShadow(context, style, resolution, dsOffsetShadow);
      } else {
        const gradientBounds = style._gradientBounds;
        const gradientOffset = style._gradientOffset;
        if (gradientBounds) {
          const gradientMetrics = {
            width: gradientBounds.width,
            height: gradientBounds.height,
            lineHeight: gradientBounds.height,
            lines: measured.lines
          };
          this._setFillAndStrokeStyles(
            context,
            style,
            gradientMetrics,
            padding,
            halfStroke,
            gradientOffset?.x ?? 0,
            gradientOffset?.y ?? 0
          );
        } else if (gradientOffset) {
          this._setFillAndStrokeStyles(
            context,
            style,
            measured,
            padding,
            halfStroke,
            gradientOffset.x,
            gradientOffset.y
          );
        } else {
          this._setFillAndStrokeStyles(context, style, measured, padding, halfStroke);
        }
        context.shadowColor = "rgba(0,0,0,0)";
      }
      for (let j = 0; j < lines.length; j++) {
        linePositionX = halfStroke;
        linePositionY = halfStroke + j * lineHeight + fontProperties.ascent + linePositionYShift;
        linePositionX += this._getAlignmentOffset(lineWidths[j], maxLineWidth, style.align);
        let wordSpacing = 0;
        if (style.align === "justify" && style.wordWrap && j < lines.length - 1) {
          const spaces = countSpaces(lines[j]);
          if (spaces > 0) {
            wordSpacing = (maxLineWidth - lineWidths[j]) / spaces;
          }
        }
        if (style._stroke?.width) {
          this._drawLetterSpacing(
            lines[j],
            style,
            canvasAndContext,
            linePositionX + padding,
            linePositionY + padding - dsOffsetText,
            true,
            wordSpacing
          );
        }
        if (style._fill !== void 0) {
          this._drawLetterSpacing(
            lines[j],
            style,
            canvasAndContext,
            linePositionX + padding,
            linePositionY + padding - dsOffsetText,
            false,
            wordSpacing
          );
        }
      }
    }
  }
  /**
   * Renders tagged text (with per-run styles) to canvas.
   * @param measured - The measured text metrics containing runsByLine
   * @param style - The base text style
   * @param padding - The padding of the text
   * @param resolution - The resolution of the text
   * @param canvasAndContext - The canvas and context to render to
   */
  _renderTaggedTextToCanvas(measured, style, padding, resolution, canvasAndContext) {
    const { canvas, context } = canvasAndContext;
    const { runsByLine, lineWidths, maxLineWidth, lineAscents, lineHeights, hasDropShadow } = measured;
    const height = canvas.height;
    context.resetTransform();
    context.scale(resolution, resolution);
    context.textBaseline = style.textBaseline;
    const passesCount = hasDropShadow ? 2 : 1;
    let maxStrokeWidth = style._stroke?.width ?? 0;
    for (const lineRuns of runsByLine) {
      for (const run of lineRuns) {
        const w = run.style._stroke?.width ?? 0;
        if (w > maxStrokeWidth) maxStrokeWidth = w;
      }
    }
    const halfStroke = maxStrokeWidth / 2;
    const runDataByLine = [];
    for (let lineIndex = 0; lineIndex < runsByLine.length; lineIndex++) {
      const lineRuns = runsByLine[lineIndex];
      const runData = [];
      for (const run of lineRuns) {
        const font = fontStringFromTextStyle(run.style);
        context.font = font;
        runData.push({
          width: CanvasTextMetrics._measureText(run.text, run.style.letterSpacing, context),
          font
        });
      }
      runDataByLine.push(runData);
    }
    for (let pass = 0; pass < passesCount; ++pass) {
      const isShadowPass = hasDropShadow && pass === 0;
      const dsOffsetText = isShadowPass ? Math.ceil(Math.max(1, height) + padding * 2) : 0;
      const dsOffsetShadow = dsOffsetText * resolution;
      if (!isShadowPass) {
        context.shadowColor = "rgba(0,0,0,0)";
      }
      let currentY = halfStroke;
      for (let lineIndex = 0; lineIndex < runsByLine.length; lineIndex++) {
        const lineRuns = runsByLine[lineIndex];
        const lineWidth = lineWidths[lineIndex];
        const lineAscent = lineAscents[lineIndex];
        const currentLineHeight = lineHeights[lineIndex];
        const lineRunData = runDataByLine[lineIndex];
        let linePositionX = halfStroke;
        linePositionX += this._getAlignmentOffset(lineWidth, maxLineWidth, style.align);
        let wordSpacing = 0;
        if (style.align === "justify" && style.wordWrap && lineIndex < runsByLine.length - 1) {
          let totalSpaces = 0;
          for (const run of lineRuns) {
            totalSpaces += countSpaces(run.text);
          }
          if (totalSpaces > 0) {
            wordSpacing = (maxLineWidth - lineWidth) / totalSpaces;
          }
        }
        const linePositionY = currentY + lineAscent;
        let runX = linePositionX + padding;
        for (let runIndex = 0; runIndex < lineRuns.length; runIndex++) {
          const run = lineRuns[runIndex];
          const { width: runWidth, font: runFont } = lineRunData[runIndex];
          context.font = runFont;
          context.textBaseline = run.style.textBaseline;
          if (run.style._stroke?.width) {
            const runStroke = run.style._stroke;
            context.lineWidth = runStroke.width;
            context.miterLimit = runStroke.miterLimit;
            context.lineJoin = runStroke.join;
            context.lineCap = runStroke.cap;
            if (isShadowPass) {
              if (run.style.dropShadow) {
                this._setupDropShadow(
                  context,
                  run.style,
                  resolution,
                  dsOffsetShadow
                );
              } else {
                const spacesSkipped = countSpaces(run.text);
                runX += runWidth + spacesSkipped * wordSpacing;
                continue;
              }
            } else {
              const runFontProps = CanvasTextMetrics.measureFont(runFont);
              const runHeight = run.style.lineHeight || runFontProps.fontSize;
              const runMetrics = {
                width: runWidth,
                height: runHeight,
                lineHeight: runHeight,
                lines: [run.text]
              };
              context.strokeStyle = getCanvasFillStyle(
                runStroke,
                context,
                runMetrics,
                padding * 2,
                runX - padding,
                currentY
              );
            }
            this._drawLetterSpacing(
              run.text,
              run.style,
              canvasAndContext,
              runX,
              linePositionY + padding - dsOffsetText,
              true,
              wordSpacing
            );
          }
          const spacesInRun = countSpaces(run.text);
          runX += runWidth + spacesInRun * wordSpacing;
        }
        runX = linePositionX + padding;
        for (let runIndex = 0; runIndex < lineRuns.length; runIndex++) {
          const run = lineRuns[runIndex];
          const { width: runWidth, font: runFont } = lineRunData[runIndex];
          context.font = runFont;
          context.textBaseline = run.style.textBaseline;
          if (run.style._fill !== void 0) {
            if (isShadowPass) {
              if (run.style.dropShadow) {
                this._setupDropShadow(
                  context,
                  run.style,
                  resolution,
                  dsOffsetShadow
                );
              } else {
                const spacesSkipped = countSpaces(run.text);
                runX += runWidth + spacesSkipped * wordSpacing;
                continue;
              }
            } else {
              const runFontProps = CanvasTextMetrics.measureFont(runFont);
              const runHeight = run.style.lineHeight || runFontProps.fontSize;
              const runMetrics = {
                width: runWidth,
                height: runHeight,
                lineHeight: runHeight,
                lines: [run.text]
              };
              context.fillStyle = getCanvasFillStyle(
                run.style._fill,
                context,
                runMetrics,
                padding * 2,
                runX - padding,
                currentY
              );
            }
            this._drawLetterSpacing(
              run.text,
              run.style,
              canvasAndContext,
              runX,
              linePositionY + padding - dsOffsetText,
              false,
              wordSpacing
            );
          }
          const spacesInFillRun = countSpaces(run.text);
          runX += runWidth + spacesInFillRun * wordSpacing;
        }
        currentY += currentLineHeight;
      }
    }
  }
  /**
   * Sets fill and stroke styles on the canvas context for text rendering.
   * @param context - The canvas context
   * @param style - The text style
   * @param metrics - The text metrics for gradient calculation
   * @param padding - The padding value
   * @param halfStroke - Half the stroke width
   * @param offsetX - X offset for gradient positioning
   * @param offsetY - Y offset for gradient positioning
   */
  _setFillAndStrokeStyles(context, style, metrics, padding, halfStroke, offsetX = 0, offsetY = 0) {
    context.fillStyle = style._fill ? getCanvasFillStyle(style._fill, context, metrics, padding * 2, offsetX, offsetY) : null;
    if (style._stroke?.width) {
      const strokePadding = halfStroke + padding * 2;
      context.strokeStyle = getCanvasFillStyle(
        style._stroke,
        context,
        metrics,
        strokePadding,
        offsetX,
        offsetY
      );
    }
  }
  /**
   * Sets up the canvas context for drop shadow rendering.
   * @param context - The canvas context
   * @param style - The text style containing drop shadow options
   * @param resolution - The resolution multiplier
   * @param dsOffsetShadow - The shadow Y offset
   */
  _setupDropShadow(context, style, resolution, dsOffsetShadow) {
    context.fillStyle = "black";
    context.strokeStyle = "black";
    const shadowOptions = style.dropShadow;
    const dropShadowColor = shadowOptions.color;
    const dropShadowAlpha = shadowOptions.alpha;
    context.shadowColor = Color.shared.setValue(dropShadowColor).setAlpha(dropShadowAlpha).toRgbaString();
    const dropShadowBlur = shadowOptions.blur * resolution;
    const dropShadowDistance = shadowOptions.distance * resolution;
    context.shadowBlur = dropShadowBlur;
    context.shadowOffsetX = Math.cos(shadowOptions.angle) * dropShadowDistance;
    context.shadowOffsetY = Math.sin(shadowOptions.angle) * dropShadowDistance + dsOffsetShadow;
  }
  /**
   * Calculates the X offset for text alignment.
   * @param lineWidth - The width of the current line
   * @param alignWidth - The width to align against
   * @param align - The text alignment
   * @returns The X offset for this line
   */
  _getAlignmentOffset(lineWidth, alignWidth, align) {
    if (align === "right") {
      return alignWidth - lineWidth;
    } else if (align === "center") {
      return (alignWidth - lineWidth) / 2;
    }
    return 0;
  }
  /**
   * Render the text with letter-spacing.
   *
   * This method handles rendering text with the correct letter spacing, using either:
   * 1. Native letter spacing if supported by the browser
   * 2. Manual letter spacing calculation if not natively supported
   *
   * For manual letter spacing, it calculates the position of each character
   * based on its width and the desired spacing.
   * @param text - The text to draw
   * @param style - The text style to apply
   * @param canvasAndContext - The canvas and context to draw to
   * @param x - Horizontal position to draw the text
   * @param y - Vertical position to draw the text
   * @param isStroke - Whether to render the stroke (true) or fill (false)
   * @param wordSpacing - Extra spacing to add between words (for justify alignment)
   * @private
   */
  _drawLetterSpacing(text, style, canvasAndContext, x, y, isStroke = false, wordSpacing = 0) {
    const { context } = canvasAndContext;
    const letterSpacing = style.letterSpacing;
    let useExperimentalLetterSpacing = false;
    if (CanvasTextMetrics.experimentalLetterSpacingSupported) {
      if (CanvasTextMetrics.experimentalLetterSpacing) {
        context.letterSpacing = `${letterSpacing}px`;
        context.textLetterSpacing = `${letterSpacing}px`;
        useExperimentalLetterSpacing = true;
      } else {
        context.letterSpacing = "0px";
        context.textLetterSpacing = "0px";
      }
    }
    if ((letterSpacing === 0 || useExperimentalLetterSpacing) && wordSpacing === 0) {
      if (isStroke) {
        context.strokeText(text, x, y);
      } else {
        context.fillText(text, x, y);
      }
      return;
    }
    if (wordSpacing !== 0 && (letterSpacing === 0 || useExperimentalLetterSpacing)) {
      const words = text.split(" ");
      let currentPosition2 = x;
      const spaceWidth = context.measureText(" ").width;
      for (let i = 0; i < words.length; i++) {
        if (isStroke) {
          context.strokeText(words[i], currentPosition2, y);
        } else {
          context.fillText(words[i], currentPosition2, y);
        }
        currentPosition2 += context.measureText(words[i]).width + spaceWidth + wordSpacing;
      }
      return;
    }
    let currentPosition = x;
    const stringArray = CanvasTextMetrics.graphemeSegmenter(text);
    let previousWidth = context.measureText(text).width;
    let currentWidth = 0;
    for (let i = 0; i < stringArray.length; ++i) {
      const currentChar = stringArray[i];
      if (isStroke) {
        context.strokeText(currentChar, currentPosition, y);
      } else {
        context.fillText(currentChar, currentPosition, y);
      }
      let textStr = "";
      for (let j = i + 1; j < stringArray.length; ++j) {
        textStr += stringArray[j];
      }
      currentWidth = context.measureText(textStr).width;
      currentPosition += previousWidth - currentWidth + letterSpacing;
      if (currentChar === " ") currentPosition += wordSpacing;
      previousWidth = currentWidth;
    }
  }
};
var CanvasTextGenerator = new CanvasTextGeneratorClass();

// node_modules/pixi.js/lib/scene/text/utils/warnIgnoredTextureStyle.mjs
var warned = false;
function warnIgnoredTextureStyle(textureStyle) {
  if (warned) return;
  const scaleModeOnly = new TextureStyle({ scaleMode: textureStyle.scaleMode });
  if (textureStyle._resourceId === scaleModeOnly._resourceId) return;
  warned = true;
  warn("Text textureStyle: only scaleMode is applied to a text texture, the other fields are ignored");
}

// node_modules/pixi.js/lib/scene/text/utils/updateTextBounds.mjs
function updateTextBounds(batchableSprite, text) {
  const { texture, bounds } = batchableSprite;
  const padding = text._style._getFinalPadding();
  updateQuadBounds(bounds, text._anchor, texture);
  const paddingOffset = text._anchor._x * padding * 2;
  const paddingOffsetY = text._anchor._y * padding * 2;
  bounds.minX -= padding - paddingOffset;
  bounds.minY -= padding - paddingOffsetY;
  bounds.maxX -= padding - paddingOffset;
  bounds.maxY -= padding - paddingOffsetY;
}

// node_modules/pixi.js/lib/scene/text/canvas/BatchableText.mjs
var BatchableText = class extends BatchableSprite {
};

// node_modules/pixi.js/lib/scene/text/canvas/CanvasTextPipe.mjs
var CanvasTextPipe = class {
  constructor(renderer) {
    this._renderer = renderer;
    renderer.runners.resolutionChange.add(this);
    renderer.runners.contextChange.add(this);
    this._managedTexts = new GCManagedHash({
      renderer,
      type: "renderable",
      onUnload: this.onTextUnload.bind(this),
      name: "canvasText"
    });
  }
  resolutionChange() {
    for (const key in this._managedTexts.items) {
      const text = this._managedTexts.items[key];
      if (text?._autoResolution) text.onViewUpdate();
    }
  }
  /**
   * Text textures are uploaded from pooled canvases that are cleared and reused straight after upload,
   * so they cannot be re-uploaded after a context loss. Unload them and regenerate on the next render.
   */
  contextChange() {
    for (const key in this._managedTexts.items) {
      this._managedTexts.items[key]?.unload();
    }
  }
  validateRenderable(text) {
    const gpuText = this._getGpuText(text);
    const newKey = text.styleKey;
    if (gpuText.currentKey !== newKey) return true;
    return text._didTextUpdate;
  }
  addRenderable(text, instructionSet) {
    const batchableText = this._getGpuText(text);
    if (text._didTextUpdate || batchableText.currentKey !== text.styleKey) {
      const resolution = text._autoResolution ? this._renderer.resolution : text.resolution;
      if (batchableText.currentKey !== text.styleKey || text._resolution !== resolution) {
        this._updateGpuText(text);
      }
      text._didTextUpdate = false;
      updateTextBounds(batchableText, text);
    }
    this._renderer.renderPipes.batch.addToBatch(batchableText, instructionSet);
  }
  updateRenderable(text) {
    const batchableText = this._getGpuText(text);
    batchableText._batcher.updateElement(batchableText);
  }
  _updateGpuText(text) {
    const batchableText = this._getGpuText(text);
    if (batchableText.texture) {
      this._renderer.canvasText.decreaseReferenceCount(batchableText.currentKey);
    }
    text._resolution = text._autoResolution ? this._renderer.resolution : text.resolution;
    batchableText.texture = this._renderer.canvasText.getManagedTexture(text);
    batchableText.currentKey = text.styleKey;
  }
  _getGpuText(text) {
    return text._gpuData[this._renderer.uid] || this.initGpuText(text);
  }
  initGpuText(text) {
    const batchableText = new BatchableText();
    batchableText.currentKey = "--";
    batchableText.renderable = text;
    batchableText.transform = text.groupTransform;
    batchableText.bounds = { minX: 0, maxX: 1, minY: 0, maxY: 0 };
    batchableText.roundPixels = this._renderer._roundPixels | text._roundPixels;
    text._gpuData[this._renderer.uid] = batchableText;
    this._managedTexts.add(text);
    return batchableText;
  }
  onTextUnload(text) {
    const gpuData = text._gpuData[this._renderer.uid];
    if (!gpuData) return;
    const { canvasText } = this._renderer;
    const refCount = canvasText.getReferenceCount(gpuData.currentKey);
    if (refCount > 0) {
      canvasText.decreaseReferenceCount(gpuData.currentKey);
    } else if (gpuData.texture) {
      canvasText.returnTexture(gpuData.texture);
    }
  }
  destroy() {
    this._managedTexts.destroy();
    this._renderer = null;
  }
};
CanvasTextPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "text"
};

// node_modules/pixi.js/lib/scene/text/shared/AbstractTextSystem.mjs
var AbstractTextSystem = class {
  constructor(renderer, retainCanvasContext) {
    this._activeTextures = {};
    this._renderer = renderer;
    this._retainCanvasContext = retainCanvasContext;
  }
  getTexture(options, _resolution, _style, _textKey) {
    if (typeof options === "string") {
      deprecation("8.0.0", "CanvasTextSystem.getTexture: Use object TextOptions instead of separate arguments");
      options = {
        text: options,
        style: _style,
        resolution: _resolution
      };
    }
    if (!(options.style instanceof TextStyle)) {
      options.style = new TextStyle(options.style);
    }
    if (typeof options.text !== "string") {
      options.text = options.text.toString();
    }
    const { text, style, textureStyle, autoGenerateMipmaps } = options;
    const resolution = options.resolution ?? this._renderer.resolution;
    const { frame, canvasAndContext } = CanvasTextGenerator.getCanvasAndContext({
      text,
      style,
      resolution
    });
    const texture = getPo2TextureFromSource(
      canvasAndContext.canvas,
      frame.width,
      frame.height,
      resolution,
      autoGenerateMipmaps,
      textureStyle?.scaleMode
    );
    if (style.trim) {
      frame.pad(style.padding);
      texture.frame.copyFrom(frame);
      texture.frame.scale(1 / resolution);
      texture.updateUvs();
    }
    if (style.filters) {
      const filteredTexture = this._applyFilters(texture, style.filters);
      this.returnTexture(texture);
      CanvasTextGenerator.returnCanvasAndContext(canvasAndContext);
      return filteredTexture;
    }
    this._renderer.texture.initSource(texture._source);
    if (!this._retainCanvasContext) {
      CanvasTextGenerator.returnCanvasAndContext(canvasAndContext);
    }
    return texture;
  }
  /**
   * Returns a texture that was created wit the above `getTexture` function.
   * Handy if you are done with a texture and want to return it to the pool.
   * @param texture - The texture to be returned.
   */
  returnTexture(texture) {
    const source8 = texture.source;
    const resource = source8.resource;
    if (this._retainCanvasContext && resource?.getContext) {
      const context = resource.getContext("2d");
      if (context) {
        CanvasTextGenerator.returnCanvasAndContext({ canvas: resource, context });
      }
    }
    source8.resource = null;
    source8.uploadMethodId = "unknown";
    source8.alphaMode = "no-premultiply-alpha";
    TexturePool.returnTexture(texture);
  }
  /**
   * Renders text to its canvas, and updates its texture.
   * @deprecated since 8.10.0
   */
  renderTextToCanvas() {
    deprecation(
      "8.10.0",
      "CanvasTextSystem.renderTextToCanvas: no longer supported, use CanvasTextSystem.getTexture instead"
    );
  }
  /**
   * Gets or creates a managed texture for a Text object. This method handles texture reuse and reference counting.
   * @param text - The Text object that needs a texture
   * @returns A Texture instance that represents the rendered text
   * @remarks
   * This method performs the following:
   * 1. Sets the appropriate resolution based on auto-resolution settings
   * 2. Checks if a texture already exists for the text's style
   * 3. Creates a new texture if needed or returns an existing one
   * 4. Manages reference counting for texture reuse
   */
  getManagedTexture(text) {
    text._resolution = text._autoResolution ? this._renderer.resolution : text.resolution;
    const textKey = text.styleKey;
    if (this._activeTextures[textKey]) {
      this._increaseReferenceCount(textKey);
      return this._activeTextures[textKey].texture;
    }
    const texture = this.getTexture({
      text: text.text,
      style: text.style,
      resolution: text._resolution,
      textureStyle: text.textureStyle,
      autoGenerateMipmaps: text.autoGenerateMipmaps
    });
    this._activeTextures[textKey] = {
      texture,
      usageCount: 1
    };
    return texture;
  }
  /**
   * Decreases the reference count for a texture associated with a text key.
   * When the reference count reaches zero, the texture is returned to the pool.
   * @param textKey - The unique key identifying the text style configuration
   * @remarks
   * This method is crucial for memory management, ensuring textures are properly
   * cleaned up when they are no longer needed by any Text instances.
   */
  decreaseReferenceCount(textKey) {
    const activeTexture = this._activeTextures[textKey];
    if (!activeTexture) return;
    activeTexture.usageCount--;
    if (activeTexture.usageCount === 0) {
      this.returnTexture(activeTexture.texture);
      this._activeTextures[textKey] = null;
    }
  }
  /**
   * Gets the current reference count for a texture associated with a text key.
   * @param textKey - The unique key identifying the text style configuration
   * @returns The number of Text instances currently using this texture
   */
  getReferenceCount(textKey) {
    return this._activeTextures[textKey]?.usageCount ?? 0;
  }
  _increaseReferenceCount(textKey) {
    this._activeTextures[textKey].usageCount++;
  }
  /**
   * Applies the specified filters to the given texture.
   *
   * This method takes a texture and a list of filters, applies the filters to the texture,
   * and returns the resulting texture. It also ensures that the alpha mode of the resulting
   * texture is set to 'premultiplied-alpha'.
   * @param {Texture} texture - The texture to which the filters will be applied.
   * @param {Filter[]} filters - The filters to apply to the texture.
   * @returns {Texture} The resulting texture after all filters have been applied.
   */
  _applyFilters(texture, filters) {
    const currentRenderTarget = this._renderer.renderTarget.renderTarget;
    const resultTexture = this._renderer.filter.generateFilteredTexture({
      texture,
      filters
    });
    this._renderer.renderTarget.bind({ target: currentRenderTarget, clear: false });
    return resultTexture;
  }
  destroy() {
    this._renderer = null;
    for (const key in this._activeTextures) {
      if (this._activeTextures[key]) this.returnTexture(this._activeTextures[key].texture);
    }
    this._activeTextures = null;
  }
};

// node_modules/pixi.js/lib/scene/text/canvas/CanvasTextSystem.mjs
var CanvasRendererTextSystem = class extends AbstractTextSystem {
  constructor(renderer) {
    super(renderer, true);
  }
};
CanvasRendererTextSystem.extension = {
  type: [
    ExtensionType.CanvasSystem
  ],
  name: "canvasText"
};

// node_modules/pixi.js/lib/scene/text/shared/GpuTextSystem.mjs
var CanvasTextSystem = class extends AbstractTextSystem {
  constructor(renderer) {
    super(renderer, false);
  }
};
CanvasTextSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem
  ],
  name: "canvasText"
};

// node_modules/pixi.js/lib/scene/text/init.mjs
extensions.add(CanvasRendererTextSystem);
extensions.add(CanvasTextSystem);
extensions.add(CanvasTextPipe);

// node_modules/pixi.js/lib/scene/text/Text.mjs
var Text = class extends AbstractText {
  constructor(...args) {
    const options = ensureTextOptions(args, "Text");
    super(options, TextStyle);
    this.renderPipeId = "text";
    if (options.textureStyle) {
      this.textureStyle = options.textureStyle instanceof TextureStyle ? options.textureStyle : new TextureStyle(options.textureStyle);
      warnIgnoredTextureStyle(this.textureStyle);
    }
    this.autoGenerateMipmaps = options.autoGenerateMipmaps ?? TextureSource.defaultOptions.autoGenerateMipmaps;
  }
  /** @private */
  updateBounds() {
    const bounds = this._bounds;
    const anchor = this._anchor;
    let width = 0;
    let height = 0;
    if (this._style.trim) {
      const { frame, canvasAndContext } = CanvasTextGenerator.getCanvasAndContext({
        text: this.text,
        style: this._style,
        resolution: 1
      });
      CanvasTextGenerator.returnCanvasAndContext(canvasAndContext);
      width = frame.width;
      height = frame.height;
    } else {
      const canvasMeasurement = CanvasTextMetrics.measureText(
        this._text,
        this._style
      );
      width = canvasMeasurement.width;
      height = canvasMeasurement.height;
    }
    bounds.minX = -anchor._x * width;
    bounds.maxX = bounds.minX + width;
    bounds.minY = -anchor._y * height;
    bounds.maxY = bounds.minY + height;
  }
};

// node_modules/pixi.js/lib/prepare/PrepareQueue.mjs
var PrepareQueue = class extends PrepareBase {
  /**
   * Resolve the given resource type and return an item for the queue
   * @param source
   * @param queue
   */
  resolveQueueItem(source8, queue) {
    if (source8 instanceof Container) {
      this.resolveContainerQueueItem(source8, queue);
    } else if (source8 instanceof TextureSource || source8 instanceof Texture) {
      queue.push(source8.source);
    } else if (source8 instanceof GraphicsContext) {
      queue.push(source8);
    }
    return null;
  }
  /**
   * Resolve the given container and return an item for the queue
   * @param container
   * @param queue
   */
  resolveContainerQueueItem(container, queue) {
    if (container instanceof Sprite || container instanceof TilingSprite || container instanceof Mesh) {
      queue.push(container.texture.source);
    } else if (container instanceof Text) {
      queue.push(container);
    } else if (container instanceof Graphics) {
      queue.push(container.context);
    } else if (container instanceof AnimatedSprite) {
      container.textures.forEach((textureOrFrame) => {
        if (textureOrFrame.source) {
          queue.push(textureOrFrame.source);
        } else {
          queue.push(textureOrFrame.texture.source);
        }
      });
    }
  }
  /**
   * Resolve the given graphics context and return an item for the queue
   * @param graphicsContext
   */
  resolveGraphicsContextQueueItem(graphicsContext) {
    this.renderer.graphicsContext.getGpuContext(graphicsContext);
    const { instructions } = graphicsContext;
    for (const instruction of instructions) {
      if (instruction.action === "texture") {
        const { image } = instruction.data;
        return image.source;
      } else if (instruction.action === "fill") {
        const { texture } = instruction.data.style;
        return texture.source;
      }
    }
    return null;
  }
};

// node_modules/pixi.js/lib/scene/text-bitmap/AbstractBitmapTextPipe.mjs
var BitmapTextGraphics = class extends Graphics {
  destroy() {
    if (this.context.customShader) {
      this.context.customShader.destroy();
    }
    super.destroy();
  }
};
var AbstractBitmapTextPipe = class {
  constructor(renderer) {
    this._renderer = renderer;
    this._managedBitmapTexts = new GCManagedHash({ renderer, type: "renderable", priority: -2, name: "bitmapText" });
  }
  validateRenderable(bitmapText) {
    const graphicsRenderable = this._getGpuBitmapText(bitmapText);
    return this._renderer.renderPipes.graphics.validateRenderable(graphicsRenderable);
  }
  addRenderable(bitmapText, instructionSet) {
    const graphicsRenderable = this._getGpuBitmapText(bitmapText);
    syncWithProxy(bitmapText, graphicsRenderable);
    if (bitmapText._didTextUpdate) {
      bitmapText._didTextUpdate = false;
      this._updateContext(bitmapText, graphicsRenderable);
    }
    this._renderer.renderPipes.graphics.addRenderable(graphicsRenderable, instructionSet);
    if (graphicsRenderable.context.customShader) {
      this._updateDistanceField(bitmapText);
    }
  }
  updateRenderable(bitmapText) {
    const graphicsRenderable = this._getGpuBitmapText(bitmapText);
    syncWithProxy(bitmapText, graphicsRenderable);
    this._renderer.renderPipes.graphics.updateRenderable(graphicsRenderable);
    if (graphicsRenderable.context.customShader) {
      this._updateDistanceField(bitmapText);
    }
  }
  _updateContext(bitmapText, proxyGraphics) {
    const { context } = proxyGraphics;
    const bitmapFont = BitmapFontManager.getFont(bitmapText.text, bitmapText._style);
    context.clear();
    if (bitmapFont.distanceField.type !== "none") {
      const sdfShader = this.getSdfShader();
      if (sdfShader) {
        if (!context.customShader) {
          context.customShader = sdfShader;
        }
      }
    }
    const chars = CanvasTextMetrics.graphemeSegmenter(bitmapText.text);
    const style = bitmapText._style;
    let currentY = bitmapFont.baseLineOffset;
    const bitmapTextLayout = getBitmapTextLayout(chars, style, bitmapFont, true);
    const padding = style.padding;
    const scale = bitmapTextLayout.scale;
    let tx = bitmapTextLayout.width;
    let ty = bitmapTextLayout.height + bitmapTextLayout.offsetY;
    if (style._stroke) {
      tx += style._stroke.width / scale;
      ty += style._stroke.width / scale;
    }
    context.translate(-bitmapText._anchor._x * tx - padding, -bitmapText._anchor._y * ty - padding).scale(scale, scale);
    const tint = bitmapFont.applyFillAsTint ? style._fill.color : 16777215;
    let fontSize = bitmapFont.fontMetrics.fontSize;
    let lineHeight = bitmapFont.lineHeight;
    if (style.lineHeight) {
      fontSize = style.fontSize / scale;
      lineHeight = style.lineHeight / scale;
    }
    let linePositionYShift = (lineHeight - fontSize) / 2;
    if (linePositionYShift - bitmapFont.baseLineOffset < 0) {
      linePositionYShift = 0;
    }
    for (let i = 0; i < bitmapTextLayout.lines.length; i++) {
      const line = bitmapTextLayout.lines[i];
      for (let j = 0; j < line.charPositions.length; j++) {
        const char = line.chars[j];
        const charData = bitmapFont.chars[char];
        if (charData?.texture) {
          const texture = charData.texture;
          context.texture(
            texture,
            tint,
            Math.round(line.charPositions[j] + charData.xOffset),
            Math.round(currentY + charData.yOffset + linePositionYShift),
            texture.orig.width,
            texture.orig.height
          );
        }
      }
      currentY += lineHeight;
    }
  }
  _getGpuBitmapText(bitmapText) {
    return bitmapText._gpuData[this._renderer.uid] || this.initGpuText(bitmapText);
  }
  initGpuText(bitmapText) {
    const proxyRenderable = new BitmapTextGraphics();
    bitmapText._gpuData[this._renderer.uid] = proxyRenderable;
    this._updateContext(bitmapText, proxyRenderable);
    this._managedBitmapTexts.add(bitmapText);
    return proxyRenderable;
  }
  _updateDistanceField(bitmapText) {
    const context = this._getGpuBitmapText(bitmapText).context;
    const fontFamily = bitmapText._style.fontFamily;
    const dynamicFont = Cache.get(`${fontFamily}-bitmap`);
    const { a, b, c, d } = bitmapText.groupTransform;
    const dx = Math.sqrt(a * a + b * b);
    const dy = Math.sqrt(c * c + d * d);
    const worldScale = (Math.abs(dx) + Math.abs(dy)) / 2;
    const fontScale = dynamicFont.baseRenderedFontSize / bitmapText._style.fontSize;
    const distance = worldScale * dynamicFont.distanceField.range * (1 / fontScale);
    context.customShader.resources.localUniforms.uniforms.uDistance = distance;
  }
  destroy() {
    this._managedBitmapTexts.destroy();
    this._renderer = null;
    this._managedBitmapTexts = null;
  }
};
function syncWithProxy(container, proxy) {
  proxy.groupTransform = container.groupTransform;
  proxy.groupColorAlpha = container.groupColorAlpha;
  proxy.groupColor = container.groupColor;
  proxy.groupBlendMode = container.groupBlendMode;
  proxy.globalDisplayStatus = container.globalDisplayStatus;
  proxy.groupTransform = container.groupTransform;
  proxy.localDisplayStatus = container.localDisplayStatus;
  proxy.groupAlpha = container.groupAlpha;
  proxy._roundPixels = container._roundPixels;
}

// node_modules/pixi.js/lib/scene/text-bitmap/CanvasBitmapTextPipe.mjs
var CanvasBitmapTextPipe = class extends AbstractBitmapTextPipe {
  getSdfShader() {
    return null;
  }
};
CanvasBitmapTextPipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "bitmapText"
};

// node_modules/pixi.js/lib/scene/text/sdfShader/shader-bits/localUniformMSDFBit.mjs
var localUniformMSDFBit = {
  name: "local-uniform-msdf-bit",
  vertex: {
    header: (
      /* wgsl */
      `
            struct LocalUniforms {
                uColor:vec4<f32>,
                uTransformMatrix:mat3x3<f32>,
                uDistance: f32,
                uRound:f32,
            }

            @group(2) @binding(0) var<uniform> localUniforms : LocalUniforms;
        `
    ),
    main: (
      /* wgsl */
      `
            vColor *= localUniforms.uColor;
            modelMatrix *= localUniforms.uTransformMatrix;
        `
    ),
    end: (
      /* wgsl */
      `
            if(localUniforms.uRound == 1)
            {
                vPosition = vec4(roundPixels(vPosition.xy, globalUniforms.uResolution), vPosition.zw);
            }
        `
    )
  },
  fragment: {
    header: (
      /* wgsl */
      `
            struct LocalUniforms {
                uColor:vec4<f32>,
                uTransformMatrix:mat3x3<f32>,
                uDistance: f32
            }

            @group(2) @binding(0) var<uniform> localUniforms : LocalUniforms;
         `
    ),
    main: (
      /* wgsl */
      `
            outColor = vec4<f32>(calculateMSDFAlpha(outColor, vColor, localUniforms.uDistance));
        `
    )
  }
};
var localUniformMSDFBitGl = {
  name: "local-uniform-msdf-bit",
  vertex: {
    header: (
      /* glsl */
      `
            uniform mat3 uTransformMatrix;
            uniform vec4 uColor;
            uniform float uRound;
        `
    ),
    main: (
      /* glsl */
      `
            vColor *= uColor;
            modelMatrix *= uTransformMatrix;
        `
    ),
    end: (
      /* glsl */
      `
            if(uRound == 1.)
            {
                gl_Position.xy = roundPixels(gl_Position.xy, uResolution);
            }
        `
    )
  },
  fragment: {
    header: (
      /* glsl */
      `
            uniform float uDistance;
         `
    ),
    main: (
      /* glsl */
      `
            outColor = vec4(calculateMSDFAlpha(outColor, vColor, uDistance));
        `
    )
  }
};

// node_modules/pixi.js/lib/scene/text/sdfShader/shader-bits/mSDFBit.mjs
var mSDFBit = {
  name: "msdf-bit",
  fragment: {
    header: (
      /* wgsl */
      `
            fn calculateMSDFAlpha(msdfColor:vec4<f32>, shapeColor:vec4<f32>, distance:f32) -> f32 {

                // MSDF
                var median = msdfColor.r + msdfColor.g + msdfColor.b -
                    min(msdfColor.r, min(msdfColor.g, msdfColor.b)) -
                    max(msdfColor.r, max(msdfColor.g, msdfColor.b));

                // SDF
                median = min(median, msdfColor.a);

                var screenPxDistance = distance * (median - 0.5);
                var alpha = clamp(screenPxDistance + 0.5, 0.0, 1.0);
                if (median < 0.01) {
                    alpha = 0.0;
                } else if (median > 0.99) {
                    alpha = 1.0;
                }

                // Gamma correction for coverage-like alpha
                var luma: f32 = dot(shapeColor.rgb, vec3<f32>(0.299, 0.587, 0.114));
                var gamma: f32 = mix(1.0, 1.0 / 2.2, luma);
                var coverage: f32 = pow(shapeColor.a * alpha, gamma);

                return coverage;

            }
        `
    )
  }
};
var mSDFBitGl = {
  name: "msdf-bit",
  fragment: {
    header: (
      /* glsl */
      `
            float calculateMSDFAlpha(vec4 msdfColor, vec4 shapeColor, float distance) {

                // MSDF
                float median = msdfColor.r + msdfColor.g + msdfColor.b -
                                min(msdfColor.r, min(msdfColor.g, msdfColor.b)) -
                                max(msdfColor.r, max(msdfColor.g, msdfColor.b));

                // SDF
                median = min(median, msdfColor.a);

                float screenPxDistance = distance * (median - 0.5);
                float alpha = clamp(screenPxDistance + 0.5, 0.0, 1.0);

                if (median < 0.01) {
                    alpha = 0.0;
                } else if (median > 0.99) {
                    alpha = 1.0;
                }

                // Gamma correction for coverage-like alpha
                float luma = dot(shapeColor.rgb, vec3(0.299, 0.587, 0.114));
                float gamma = mix(1.0, 1.0 / 2.2, luma);
                float coverage = pow(shapeColor.a * alpha, gamma);

                return coverage;
            }
        `
    )
  }
};

// node_modules/pixi.js/lib/scene/text/sdfShader/SdfShader.mjs
var gpuProgram2;
var glProgram2;
var SdfShader = class extends Shader {
  constructor(maxTextures) {
    const uniforms = new UniformGroup({
      uColor: { value: new Float32Array([1, 1, 1, 1]), type: "vec4<f32>" },
      uTransformMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      uDistance: { value: 4, type: "f32" },
      uRound: { value: 0, type: "f32" }
    });
    gpuProgram2 ?? (gpuProgram2 = compileHighShaderGpuProgram({
      name: "sdf-shader",
      bits: [
        colorBit,
        generateTextureBatchBit(maxTextures),
        localUniformMSDFBit,
        mSDFBit,
        roundPixelsBit
      ]
    }));
    glProgram2 ?? (glProgram2 = compileHighShaderGlProgram({
      name: "sdf-shader",
      bits: [
        colorBitGl,
        generateTextureBatchBitGl(maxTextures),
        localUniformMSDFBitGl,
        mSDFBitGl,
        roundPixelsBitGl
      ]
    }));
    super({
      glProgram: glProgram2,
      gpuProgram: gpuProgram2,
      resources: {
        localUniforms: uniforms,
        batchSamplers: getBatchSamplersUniformGroup(maxTextures)
      }
    });
  }
};

// node_modules/pixi.js/lib/scene/text-bitmap/GpuBitmapTextPipe.mjs
var BitmapTextPipe = class extends AbstractBitmapTextPipe {
  getSdfShader() {
    return new SdfShader(this._renderer.limits.maxBatchableTextures);
  }
};
BitmapTextPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes
  ],
  name: "bitmapText"
};

// node_modules/pixi.js/lib/scene/text-bitmap/init.mjs
extensions.add(CanvasBitmapTextPipe);
extensions.add(BitmapTextPipe);

// node_modules/pixi.js/lib/scene/text-bitmap/BitmapText.mjs
var BitmapText = class extends AbstractText {
  constructor(...args) {
    var _a;
    const options = ensureTextOptions(args, "BitmapText");
    options.style ?? (options.style = options.style || {});
    (_a = options.style).fill ?? (_a.fill = 16777215);
    super(options, TextStyle);
    this.renderPipeId = "bitmapText";
  }
  /**
   * @param now - The current time in milliseconds.
   * @internal
   */
  _onTouch(now) {
    this._gcLastUsed = now;
    for (const key in this._gpuData) {
      this._gpuData[key]?._onTouch(now);
    }
  }
  /** @private */
  updateBounds() {
    const bounds = this._bounds;
    const anchor = this._anchor;
    const bitmapMeasurement = BitmapFontManager.measureText(this.text, this._style);
    const scale = bitmapMeasurement.scale;
    const offset = bitmapMeasurement.offsetY * scale;
    let width = bitmapMeasurement.width * scale;
    let height = bitmapMeasurement.height * scale;
    const stroke = this._style._stroke;
    if (stroke) {
      width += stroke.width;
      height += stroke.width;
    }
    bounds.minX = -anchor._x * width;
    bounds.maxX = bounds.minX + width;
    bounds.minY = -anchor._y * (height + offset);
    bounds.maxY = bounds.minY + height;
  }
  /**
   * The resolution / device pixel ratio for text rendering.
   * Unlike other text types, BitmapText resolution is managed by the BitmapFont.
   * Individual resolution changes are not supported.
   * @example
   * ```ts
   * // ❌ Incorrect: Setting resolution directly (will trigger warning)
   * const text = new BitmapText({
   *     text: 'Hello',
   *     resolution: 2 // This will be ignored
   * });
   *
   * // ✅ Correct: Set resolution when installing the font
   * BitmapFont.install({
   *     name: 'MyFont',
   *     style: {
   *         fontFamily: 'Arial',
   *     },
   *     resolution: 2 // Resolution is set here
   * });
   *
   * const text = new BitmapText({
   *     text: 'Hello',
   *     style: {
   *         fontFamily: 'MyFont' // Uses font's resolution
   *     }
   * });
   * ```
   * @default 1
   * @see {@link BitmapFont.install} For setting font resolution
   * @throws {Warning} When attempting to change resolution directly
   * @readonly
   */
  set resolution(value) {
    if (value !== null) {
      warn(
        // eslint-disable-next-line max-len
        "[BitmapText] dynamically updating the resolution is not supported. Resolution should be managed by the BitmapFont."
      );
    }
  }
  get resolution() {
    return this._resolution;
  }
};

// node_modules/pixi.js/lib/scene/text-html/utils/textStyleToCSS.mjs
function textStyleToCSS(style) {
  const stroke = style._stroke;
  const fill = style._fill;
  const color = Color.shared.setValue(fill.color).setAlpha(fill.alpha ?? 1).toHexa();
  const cssStyleString = [
    `color: ${color}`,
    `font-size: ${style.fontSize}px`,
    `font-family: ${style.fontFamily}`,
    `font-weight: ${style.fontWeight}`,
    `font-style: ${style.fontStyle}`,
    `font-variant: ${style.fontVariant}`,
    `letter-spacing: ${style.letterSpacing}px`,
    `text-align: ${style.align}`,
    `padding: ${style.padding}px`,
    `white-space: ${style.whiteSpace === "pre" && style.wordWrap ? "pre-wrap" : style.whiteSpace}`,
    ...style.lineHeight ? [`line-height: ${style.lineHeight}px`] : [],
    ...style.wordWrap ? [
      `word-break: ${style.breakWords ? "break-word" : "normal"}`,
      `max-width: ${style.wordWrapWidth}px`
    ] : [],
    ...stroke ? [strokeToCSS(stroke)] : [],
    ...style.dropShadow ? [dropShadowToCSS(style.dropShadow)] : [],
    ...style.cssOverrides
  ].join(";");
  const cssStyles = [`div { ${cssStyleString} }`];
  tagStyleToCSS(style.tagStyles, cssStyles);
  return cssStyles.join(" ");
}
function dropShadowToCSS(dropShadowStyle) {
  const dropshadowStyle = __spreadValues({}, dropShadowStyle);
  const color = Color.shared.setValue(dropshadowStyle.color).setAlpha(dropshadowStyle.alpha ?? 1).toHexa();
  const x = Math.round(Math.cos(dropshadowStyle.angle) * dropshadowStyle.distance);
  const y = Math.round(Math.sin(dropshadowStyle.angle) * dropshadowStyle.distance);
  const position = `${x}px ${y}px`;
  if (dropshadowStyle.blur > 0) {
    return `text-shadow: ${position} ${dropshadowStyle.blur}px ${color}`;
  }
  return `text-shadow: ${position} ${color}`;
}
function strokeToCSS(stroke) {
  const color = Color.shared.setValue(stroke.color).setAlpha(stroke.alpha ?? 1).toHexa();
  return [
    `-webkit-text-stroke-width: ${stroke.width}px`,
    `-webkit-text-stroke-color: ${color}`,
    `text-stroke-width: ${stroke.width}px`,
    `text-stroke-color: ${color}`,
    "paint-order: stroke"
  ].join(";");
}
var templates = {
  fontSize: `font-size: {{VALUE}}px`,
  fontFamily: `font-family: {{VALUE}}`,
  fontWeight: `font-weight: {{VALUE}}`,
  fontStyle: `font-style: {{VALUE}}`,
  fontVariant: `font-variant: {{VALUE}}`,
  letterSpacing: `letter-spacing: {{VALUE}}px`,
  align: `text-align: {{VALUE}}`,
  padding: `padding: {{VALUE}}px`,
  whiteSpace: `white-space: {{VALUE}}`,
  lineHeight: `line-height: {{VALUE}}px`,
  wordWrapWidth: `max-width: {{VALUE}}px`
};
var transform = {
  fill: (value) => `color: ${Color.shared.setValue(value).toHexa()}`,
  breakWords: (value) => `word-break: ${value ? "break-all" : "normal"}`,
  stroke: strokeToCSS,
  dropShadow: (value) => {
    if (value === true) {
      return dropShadowToCSS(TextStyle.defaultDropShadow);
    }
    if (value && typeof value === "object") {
      return dropShadowToCSS(__spreadValues(__spreadValues({}, TextStyle.defaultDropShadow), value));
    }
    return "";
  }
};
function tagStyleToCSS(tagStyles, out) {
  for (const i in tagStyles) {
    const tagStyle = tagStyles[i];
    const cssTagStyle = [];
    for (const j in tagStyle) {
      if (transform[j]) {
        cssTagStyle.push(transform[j](tagStyle[j]));
      } else if (templates[j]) {
        cssTagStyle.push(templates[j].replace("{{VALUE}}", tagStyle[j]));
      }
    }
    out.push(`${i} { ${cssTagStyle.join(";")} }`);
  }
}

// node_modules/pixi.js/lib/scene/text-html/HTMLTextStyle.mjs
var HTMLTextStyle = class _HTMLTextStyle extends TextStyle {
  constructor(options = {}) {
    super(options);
    this._cssOverrides = [];
    this.cssOverrides = options.cssOverrides ?? [];
    this.tagStyles = options.tagStyles ?? {};
  }
  /**
   * Custom styles to apply to specific HTML tags.
   * Allows for consistent styling of custom elements without CSS overrides.
   * @example
   * ```ts
   * const text = new HTMLText({
   *     text: '<red>Red</red>, <blue>Blue</blue>, <green>Green</green>',
   *     style: {
   *         tagStyles: {
   *             red: { fill: 'red' },
   *             blue: { fill: 'blue' },
   *             green: { fill: 'green' },
   *         }
   *     }
   * });
   * ```
   * @standard
   */
  get tagStyles() {
    return this._tagStyles;
  }
  /** @standard */
  set tagStyles(value) {
    if (this._tagStyles === value) return;
    this._tagStyles = value ?? {};
    this.update();
  }
  /**
   * List of CSS style overrides to apply to the HTML text.
   * These styles are added after the built-in styles and can override any default styling.
   * @advanced
   */
  set cssOverrides(value) {
    this._cssOverrides = value instanceof Array ? value : [value];
    this.update();
  }
  /** @advanced */
  get cssOverrides() {
    return this._cssOverrides;
  }
  /**
   * Updates the text style and triggers a refresh of the CSS style cache.
   * This method is called automatically when style properties are changed.
   * @example
   * ```ts
   * // Update after multiple changes
   * const text = new HTMLText({
   *     text: 'Hello World',
   *     style
   * });
   *
   * style.fontSize = 32;
   * style.fill = '#00ff00';
   * style.fontFamily = 'Arial';
   * style.update(); // Apply all changes at once
   * ```
   * @advanced
   * @see {@link HTMLTextStyle#cssStyle} For accessing the generated CSS
   * @see {@link HTMLTextStyle#cssOverrides} For managing CSS overrides
   */
  update() {
    this._cssStyle = null;
    super.update();
  }
  /**
   * Creates a new HTMLTextStyle object with the same values as this one.
   * This creates a deep copy of all style properties, including dropShadow and tag styles.
   * @example
   * ```ts
   * // Create original style
   * const originalStyle = new HTMLTextStyle({
   *     fontSize: 24,
   *     fill: '#ff0000',
   *     tagStyles: {
   *         header: { fontSize: 32, fill: '#00ff00' }
   *     }
   * });
   *
   * // Clone the style
   * const clonedStyle = originalStyle.clone();
   *
   * // Modify cloned style independently
   * clonedStyle.fontSize = 36;
   * clonedStyle.fill = '#0000ff';
   *
   * // Original style remains unchanged
   * console.log(originalStyle.fontSize); // Still 24
   * console.log(originalStyle.fill); // Still '#ff0000'
   * ```
   *
   * Properties that are cloned:
   * - Basic text properties (fontSize, fontFamily, etc.)
   * - Fill and stroke styles
   * - Drop shadow configuration
   * - CSS overrides
   * - Tag styles (deep copied)
   * - Word wrap settings
   * - Alignment and spacing
   * @returns {HTMLTextStyle} A new HTMLTextStyle instance with the same properties
   * @see {@link HTMLTextStyle} For available style properties
   * @see {@link HTMLTextStyle#cssOverrides} For CSS override handling
   * @see {@link HTMLTextStyle#tagStyles} For tag style configuration
   * @standard
   */
  clone() {
    return new _HTMLTextStyle({
      align: this.align,
      breakWords: this.breakWords,
      dropShadow: this.dropShadow ? __spreadValues({}, this.dropShadow) : null,
      fill: this._fill,
      fontFamily: this.fontFamily,
      fontSize: this.fontSize,
      fontStyle: this.fontStyle,
      fontVariant: this.fontVariant,
      fontWeight: this.fontWeight,
      letterSpacing: this.letterSpacing,
      lineHeight: this.lineHeight,
      padding: this.padding,
      stroke: this._stroke,
      whiteSpace: this.whiteSpace,
      wordWrap: this.wordWrap,
      wordWrapWidth: this.wordWrapWidth,
      cssOverrides: this.cssOverrides,
      tagStyles: __spreadValues({}, this.tagStyles)
    });
  }
  /**
   * The CSS style string that will be applied to the HTML text.
   * @advanced
   */
  get cssStyle() {
    if (!this._cssStyle) {
      this._cssStyle = textStyleToCSS(this);
    }
    return this._cssStyle;
  }
  /**
   * Add a style override, this can be any CSS property
   * it will override any built-in style. This is the
   * property and the value as a string (e.g., `color: red`).
   * This will override any other internal style.
   * @param {string} value - CSS style(s) to add.
   * @example
   * style.addOverride('background-color: red');
   * @advanced
   */
  addOverride(...value) {
    const toAdd = value.filter((v) => !this.cssOverrides.includes(v));
    if (toAdd.length > 0) {
      this.cssOverrides.push(...toAdd);
      this.update();
    }
  }
  /**
   * Remove any overrides that match the value.
   * @param {string} value - CSS style to remove.
   * @example
   * style.removeOverride('background-color: red');
   * @advanced
   */
  removeOverride(...value) {
    const toRemove = value.filter((v) => this.cssOverrides.includes(v));
    if (toRemove.length > 0) {
      this.cssOverrides = this.cssOverrides.filter((v) => !toRemove.includes(v));
      this.update();
    }
  }
  /**
   * Sets the fill style for the text. HTML text only supports color fills (string or number values).
   * Texture fills are not supported and will trigger a warning in debug mode.
   * @example
   * ```ts
   * // Using hex colors
   * const text = new HTMLText({
   *     text: 'Colored Text',
   *     style: {
   *         fill: 0xff0000 // Red color
   *     }
   * });
   *
   * // Using CSS color strings
   * text.style.fill = '#00ff00';     // Hex string (Green)
   * text.style.fill = 'blue';        // Named color
   * text.style.fill = 'rgb(255,0,0)' // RGB
   * text.style.fill = '#f0f';        // Short hex
   *
   * // Invalid usage (will trigger warning in debug)
   * text.style.fill = {
   *     type: 'pattern',
   *     texture: Texture.from('pattern.png')
   * }; // Not supported, falls back to default
   * ```
   * @param value - The fill color to use. Must be a string or number.
   * @throws {Warning} In debug mode when attempting to use unsupported fill types
   * @see {@link TextStyle#fill} For full fill options in canvas text
   * @standard
   */
  set fill(value) {
    if (typeof value !== "string" && typeof value !== "number") {
      warn("[HTMLTextStyle] only color fill is not supported by HTMLText");
    }
    super.fill = value;
  }
  /**
   * Sets the stroke style for the text. HTML text only supports color strokes (string or number values).
   * Texture strokes are not supported and will trigger a warning in debug mode.
   * @example
   * ```ts
   * // Using hex colors
   * const text = new HTMLText({
   *     text: 'Outlined Text',
   *     style: {
   *         stroke: 0xff0000 // Red outline
   *     }
   * });
   *
   * // Using CSS color strings
   * text.style.stroke = '#00ff00';     // Hex string (Green)
   * text.style.stroke = 'blue';        // Named color
   * text.style.stroke = 'rgb(255,0,0)' // RGB
   * text.style.stroke = '#f0f';        // Short hex
   *
   * // Using stroke width
   * text.style = {
   *     stroke: {
   *         color: '#ff0000',
   *         width: 2
   *     }
   * };
   *
   * // Remove stroke
   * text.style.stroke = null;
   *
   * // Invalid usage (will trigger warning in debug)
   * text.style.stroke = {
   *     type: 'pattern',
   *     texture: Texture.from('pattern.png')
   * }; // Not supported, falls back to default
   * ```
   * @param value - The stroke style to use. Must be a string, number, or stroke configuration object
   * @throws {Warning} In debug mode when attempting to use unsupported stroke types
   * @see {@link TextStyle#stroke} For full stroke options in canvas text
   * @standard
   */
  set stroke(value) {
    if (value && typeof value !== "string" && typeof value !== "number") {
      warn("[HTMLTextStyle] only color stroke is not supported by HTMLText");
    }
    super.stroke = value;
  }
};

// node_modules/pixi.js/lib/scene/text-html/HTMLTextRenderData.mjs
var nssvg = "http://www.w3.org/2000/svg";
var nsxhtml = "http://www.w3.org/1999/xhtml";
var HTMLTextRenderData = class {
  constructor() {
    this.svgRoot = document.createElementNS(nssvg, "svg");
    this.foreignObject = document.createElementNS(nssvg, "foreignObject");
    this.domElement = document.createElementNS(nsxhtml, "div");
    this.styleElement = document.createElementNS(nsxhtml, "style");
    const { foreignObject, svgRoot, styleElement, domElement } = this;
    foreignObject.setAttribute("width", "10000");
    foreignObject.setAttribute("height", "10000");
    foreignObject.style.overflow = "hidden";
    svgRoot.appendChild(foreignObject);
    foreignObject.appendChild(styleElement);
    foreignObject.appendChild(domElement);
    this.image = DOMAdapter.get().createImage();
  }
  destroy() {
    this.svgRoot.remove();
    this.foreignObject.remove();
    this.styleElement.remove();
    this.domElement.remove();
    this.image.src = "";
    this.image.remove();
    this.svgRoot = null;
    this.foreignObject = null;
    this.styleElement = null;
    this.domElement = null;
    this.image = null;
    this.canvasAndContext = null;
  }
};

// node_modules/pixi.js/lib/scene/text-html/utils/measureHtmlText.mjs
var tempHTMLTextRenderData;
function measureHtmlText(text, style, fontStyleCSS, htmlTextRenderData) {
  htmlTextRenderData || (htmlTextRenderData = tempHTMLTextRenderData || (tempHTMLTextRenderData = new HTMLTextRenderData()));
  const { domElement, styleElement, svgRoot } = htmlTextRenderData;
  domElement.innerHTML = `<style>${style.cssStyle};</style><div style='padding:0'>${text}</div>`;
  domElement.setAttribute("style", "transform-origin: top left; display: inline-block");
  if (fontStyleCSS) {
    styleElement.textContent = fontStyleCSS;
  }
  document.body.appendChild(svgRoot);
  let contentWidth = domElement.scrollWidth;
  let contentHeight = domElement.scrollHeight;
  svgRoot.remove();
  if (style.dropShadow) {
    const { distance, angle, blur } = style.dropShadow;
    const shadowOffsetX = Math.abs(Math.round(Math.cos(angle) * distance));
    const shadowOffsetY = Math.abs(Math.round(Math.sin(angle) * distance));
    contentWidth += shadowOffsetX + blur;
    contentHeight += shadowOffsetY + blur;
  }
  const doublePadding = style.padding * 2;
  return {
    width: contentWidth - doublePadding,
    height: contentHeight - doublePadding
  };
}

// node_modules/pixi.js/lib/scene/text-html/BatchableHTMLText.mjs
var BatchableHTMLText = class extends BatchableSprite {
  constructor() {
    super(...arguments);
    this.generatingTexture = false;
    this.currentKey = "--";
  }
  /** Destroys the BatchableHTMLText instance. Returns the texture promise to the renderer and cleans up references. */
  destroy() {
    this.texturePromise = null;
    this.generatingTexture = false;
    this.currentKey = "--";
    super.destroy();
  }
};

// node_modules/pixi.js/lib/scene/text-html/HTMLTextPipe.mjs
var HTMLTextPipe = class {
  constructor(renderer) {
    this._renderer = renderer;
    renderer.runners.resolutionChange.add(this);
    renderer.runners.contextChange.add(this);
    this._managedTexts = new GCManagedHash({
      renderer,
      type: "renderable",
      onUnload: this.onTextUnload.bind(this),
      name: "htmlText"
    });
  }
  resolutionChange() {
    for (const key in this._managedTexts.items) {
      const text = this._managedTexts.items[key];
      if (text?._autoResolution) {
        text.onViewUpdate();
      }
    }
  }
  /**
   * HTMLText textures are uploaded from pooled images that are reused for the next text,
   * so they cannot be re-uploaded after a context loss. Unload them and regenerate on the next render.
   */
  contextChange() {
    for (const key in this._managedTexts.items) {
      this._managedTexts.items[key]?.unload();
    }
  }
  validateRenderable(htmlText) {
    const gpuText = this._getGpuText(htmlText);
    const newKey = htmlText.styleKey;
    if (gpuText.currentKey !== newKey) {
      return true;
    }
    return false;
  }
  addRenderable(htmlText, instructionSet) {
    const batchableHTMLText = this._getGpuText(htmlText);
    if (htmlText._didTextUpdate || batchableHTMLText.currentKey !== htmlText.styleKey) {
      const resolution = htmlText._autoResolution ? this._renderer.resolution : htmlText.resolution;
      if (batchableHTMLText.currentKey !== htmlText.styleKey || htmlText.resolution !== resolution) {
        this._updateGpuText(htmlText).catch((e) => {
          console.error(e);
        });
      }
      htmlText._didTextUpdate = false;
      updateTextBounds(batchableHTMLText, htmlText);
    }
    this._renderer.renderPipes.batch.addToBatch(batchableHTMLText, instructionSet);
  }
  updateRenderable(htmlText) {
    const batchableHTMLText = this._getGpuText(htmlText);
    batchableHTMLText._batcher.updateElement(batchableHTMLText);
  }
  _updateGpuText(htmlText) {
    return __async(this, null, function* () {
      htmlText._didTextUpdate = false;
      const batchableHTMLText = this._getGpuText(htmlText);
      if (batchableHTMLText.generatingTexture) return;
      const oldTexturePromise = batchableHTMLText.texturePromise;
      batchableHTMLText.texturePromise = null;
      batchableHTMLText.generatingTexture = true;
      htmlText._resolution = htmlText._autoResolution ? this._renderer.resolution : htmlText.resolution;
      let texturePromise = this._renderer.htmlText.getTexturePromise(htmlText);
      if (oldTexturePromise) {
        texturePromise = texturePromise.finally(() => {
          this._renderer.htmlText.decreaseReferenceCount(batchableHTMLText.currentKey);
          this._renderer.htmlText.returnTexturePromise(oldTexturePromise);
        });
      }
      batchableHTMLText.texturePromise = texturePromise;
      batchableHTMLText.currentKey = htmlText.styleKey;
      const texture = yield texturePromise;
      if (!batchableHTMLText.renderable) return;
      batchableHTMLText.texture = texture;
      const renderGroup = htmlText.renderGroup || htmlText.parentRenderGroup;
      if (renderGroup) {
        renderGroup.structureDidChange = true;
      }
      batchableHTMLText.generatingTexture = false;
      updateTextBounds(batchableHTMLText, htmlText);
    });
  }
  _getGpuText(htmlText) {
    return htmlText._gpuData[this._renderer.uid] || this.initGpuText(htmlText);
  }
  initGpuText(htmlText) {
    const batchableHTMLText = new BatchableHTMLText();
    batchableHTMLText.renderable = htmlText;
    batchableHTMLText.transform = htmlText.groupTransform;
    batchableHTMLText.texture = Texture.EMPTY;
    batchableHTMLText.bounds = { minX: 0, maxX: 1, minY: 0, maxY: 0 };
    batchableHTMLText.roundPixels = this._renderer._roundPixels | htmlText._roundPixels;
    htmlText._resolution = htmlText._autoResolution ? this._renderer.resolution : htmlText.resolution;
    htmlText._gpuData[this._renderer.uid] = batchableHTMLText;
    this._managedTexts.add(htmlText);
    return batchableHTMLText;
  }
  onTextUnload(text) {
    const gpuData = text._gpuData[this._renderer.uid];
    if (!gpuData?.texturePromise) return;
    const { htmlText } = this._renderer;
    htmlText.getReferenceCount(gpuData.currentKey) === null ? htmlText.returnTexturePromise(gpuData.texturePromise) : htmlText.decreaseReferenceCount(gpuData.currentKey);
  }
  destroy() {
    this._managedTexts.destroy();
    this._renderer = null;
  }
};
HTMLTextPipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes,
    ExtensionType.CanvasPipes
  ],
  name: "htmlText"
};

// node_modules/pixi.js/lib/scene/text-html/utils/extractFontFamilies.mjs
function extractFontFamilies(text, style) {
  const fontFamily = style.fontFamily;
  const fontFamilies = [];
  const dedupe = {};
  const regex = /font-family:([^;"\s]+)/g;
  const matches = text.match(regex);
  function addFontFamily(fontFamily2) {
    if (!dedupe[fontFamily2]) {
      fontFamilies.push(fontFamily2);
      dedupe[fontFamily2] = true;
    }
  }
  if (Array.isArray(fontFamily)) {
    for (let i = 0; i < fontFamily.length; i++) {
      addFontFamily(fontFamily[i]);
    }
  } else {
    addFontFamily(fontFamily);
  }
  if (matches) {
    matches.forEach((match) => {
      const fontFamily2 = match.split(":")[1].trim();
      addFontFamily(fontFamily2);
    });
  }
  for (const i in style.tagStyles) {
    const fontFamily2 = style.tagStyles[i].fontFamily;
    addFontFamily(fontFamily2);
  }
  return fontFamilies;
}

// node_modules/pixi.js/lib/scene/text-html/utils/loadFontAsBase64.mjs
function loadFontAsBase64(url) {
  return __async(this, null, function* () {
    const response = yield DOMAdapter.get().fetch(url);
    const blob = yield response.blob();
    const reader = new FileReader();
    const dataSrc = yield new Promise((resolve, reject) => {
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
    return dataSrc;
  });
}

// node_modules/pixi.js/lib/scene/text-html/utils/loadFontCSS.mjs
function loadFontCSS(style, url) {
  return __async(this, null, function* () {
    const dataSrc = yield loadFontAsBase64(url);
    return `@font-face {
        font-family: "${style.fontFamily}";
        font-weight: ${style.fontWeight};
        font-style: ${style.fontStyle};
        src: url('${dataSrc}');
    }`;
  });
}

// node_modules/pixi.js/lib/scene/text-html/utils/getFontCss.mjs
var FontStylePromiseCache = /* @__PURE__ */ new Map();
function getFontCss(fontFamilies) {
  return __async(this, null, function* () {
    const fontPromises = fontFamilies.filter((fontFamily) => Cache.has(`${fontFamily}-and-url`)).map((fontFamily) => {
      if (!FontStylePromiseCache.has(fontFamily)) {
        const { entries } = Cache.get(`${fontFamily}-and-url`);
        const promises = [];
        entries.forEach((entry) => {
          const url = entry.url;
          const faces = entry.faces;
          const out = faces.map((face) => ({ weight: face.weight, style: face.style }));
          promises.push(
            ...out.map(
              (style) => loadFontCSS(
                {
                  fontWeight: style.weight,
                  fontStyle: style.style,
                  fontFamily
                },
                url
              )
            )
          );
        });
        FontStylePromiseCache.set(
          fontFamily,
          Promise.all(promises).then((css) => css.join("\n"))
        );
      }
      return FontStylePromiseCache.get(fontFamily);
    });
    return (yield Promise.all(fontPromises)).join("\n");
  });
}

// node_modules/pixi.js/lib/scene/text-html/utils/getSVGUrl.mjs
function getSVGUrl(text, style, resolution, fontCSS, htmlTextData) {
  const { domElement, styleElement, svgRoot } = htmlTextData;
  domElement.innerHTML = `<style>${style.cssStyle}</style><div style='padding:0;'>${text}</div>`;
  domElement.setAttribute("style", `transform: scale(${resolution});transform-origin: top left; display: inline-block`);
  styleElement.textContent = fontCSS;
  const { width, height } = htmlTextData.image;
  svgRoot.setAttribute("width", width.toString());
  svgRoot.setAttribute("height", height.toString());
  return new XMLSerializer().serializeToString(svgRoot);
}

// node_modules/pixi.js/lib/scene/text-html/utils/getTemporaryCanvasFromImage.mjs
function getTemporaryCanvasFromImage(image, resolution) {
  const canvasAndContext = CanvasPool.getOptimalCanvasAndContext(
    image.width,
    image.height,
    resolution
  );
  const { context } = canvasAndContext;
  context.clearRect(0, 0, image.width, image.height);
  context.drawImage(image, 0, 0);
  return canvasAndContext;
}

// node_modules/pixi.js/lib/scene/text-html/utils/loadSVGImage.mjs
function loadSVGImage(image, url, delay) {
  return new Promise((resolve) => __async(null, null, function* () {
    if (delay) {
      yield new Promise((resolve2) => setTimeout(resolve2, 100));
    }
    image.onload = () => {
      resolve();
    };
    image.src = `data:image/svg+xml;charset=utf8,${encodeURIComponent(url)}`;
    image.crossOrigin = "anonymous";
  }));
}

// node_modules/pixi.js/lib/scene/text-html/HTMLTextSystem.mjs
var HTMLTextSystem = class {
  constructor(renderer) {
    this._activeTextures = {};
    this._renderer = renderer;
    this._createCanvas = renderer.type === RendererType.WEBGPU;
  }
  /**
   * @param options
   * @deprecated Use getTexturePromise instead
   */
  getTexture(options) {
    return this.getTexturePromise(options);
  }
  /**
   * Increases the reference count for a texture.
   * @param text - The HTMLText instance associated with the texture.
   */
  getManagedTexture(text) {
    const textKey = text.styleKey;
    if (this._activeTextures[textKey]) {
      this._increaseReferenceCount(textKey);
      return this._activeTextures[textKey].promise;
    }
    const promise = this._buildTexturePromise(text).then((texture) => {
      this._activeTextures[textKey].texture = texture;
      return texture;
    });
    this._activeTextures[textKey] = {
      texture: null,
      promise,
      usageCount: 1
    };
    return promise;
  }
  /**
   * Gets the current reference count for a texture associated with a text key.
   * @param textKey - The unique key identifying the text style configuration
   * @returns The number of Text instances currently using this texture
   */
  getReferenceCount(textKey) {
    return this._activeTextures[textKey]?.usageCount ?? null;
  }
  _increaseReferenceCount(textKey) {
    this._activeTextures[textKey].usageCount++;
  }
  /**
   * Decreases the reference count for a texture.
   * If the count reaches zero, the texture is cleaned up.
   * @param textKey - The key associated with the HTMLText instance.
   */
  decreaseReferenceCount(textKey) {
    const activeTexture = this._activeTextures[textKey];
    if (!activeTexture) return;
    activeTexture.usageCount--;
    if (activeTexture.usageCount === 0) {
      if (activeTexture.texture) {
        this._cleanUp(activeTexture.texture);
      } else {
        activeTexture.promise.then((texture) => {
          activeTexture.texture = texture;
          this._cleanUp(activeTexture.texture);
        }).catch(() => {
          warn("HTMLTextSystem: Failed to clean texture");
        });
      }
      this._activeTextures[textKey] = null;
    }
  }
  /**
   * Returns a promise that resolves to a texture for the given HTMLText options.
   * @param options - The options for the HTMLText.
   * @returns A promise that resolves to a Texture.
   */
  getTexturePromise(options) {
    return this._buildTexturePromise(options);
  }
  _buildTexturePromise(options) {
    return __async(this, null, function* () {
      const { text, style, resolution, textureStyle, autoGenerateMipmaps } = options;
      const htmlTextData = BigPool.get(HTMLTextRenderData);
      const fontFamilies = extractFontFamilies(text, style);
      const fontCSS = yield getFontCss(fontFamilies);
      const measured = measureHtmlText(text, style, fontCSS, htmlTextData);
      const width = Math.ceil(Math.ceil(Math.max(1, measured.width) + style.padding * 2) * resolution);
      const height = Math.ceil(Math.ceil(Math.max(1, measured.height) + style.padding * 2) * resolution);
      const image = htmlTextData.image;
      const uvSafeOffset = 2;
      image.width = (width | 0) + uvSafeOffset;
      image.height = (height | 0) + uvSafeOffset;
      const svgURL = getSVGUrl(text, style, resolution, fontCSS, htmlTextData);
      yield loadSVGImage(image, svgURL, isSafari() && fontFamilies.length > 0);
      const resource = image;
      let canvasAndContext;
      if (this._createCanvas) {
        canvasAndContext = getTemporaryCanvasFromImage(image, resolution);
      }
      const texture = getPo2TextureFromSource(
        canvasAndContext ? canvasAndContext.canvas : resource,
        image.width - uvSafeOffset,
        image.height - uvSafeOffset,
        resolution,
        autoGenerateMipmaps,
        textureStyle?.scaleMode
      );
      this._renderer?.texture.initSource(texture.source);
      if (this._createCanvas) {
        CanvasPool.returnCanvasAndContext(canvasAndContext);
      }
      BigPool.return(htmlTextData);
      return texture;
    });
  }
  returnTexturePromise(texturePromise) {
    texturePromise.then((texture) => {
      this._cleanUp(texture);
    }).catch(() => {
      warn("HTMLTextSystem: Failed to clean texture");
    });
  }
  _cleanUp(texture) {
    const source8 = texture.source;
    TexturePool.returnTexture(texture);
    source8.resource = null;
    source8.uploadMethodId = "unknown";
  }
  destroy() {
    this._renderer = null;
    for (const key in this._activeTextures) {
      if (this._activeTextures[key]) this.returnTexturePromise(this._activeTextures[key].promise);
    }
    this._activeTextures = null;
  }
};
HTMLTextSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem,
    ExtensionType.CanvasSystem
  ],
  name: "htmlText"
};

// node_modules/pixi.js/lib/scene/text-html/init.mjs
extensions.add(HTMLTextSystem);
extensions.add(HTMLTextPipe);

// node_modules/pixi.js/lib/scene/text-html/HTMLText.mjs
var HTMLText = class extends AbstractText {
  constructor(...args) {
    const options = ensureTextOptions(args, "HtmlText");
    super(options, HTMLTextStyle);
    this.renderPipeId = "htmlText";
    if (options.textureStyle) {
      this.textureStyle = options.textureStyle instanceof TextureStyle ? options.textureStyle : new TextureStyle(options.textureStyle);
      warnIgnoredTextureStyle(this.textureStyle);
    }
    this.autoGenerateMipmaps = options.autoGenerateMipmaps ?? TextureSource.defaultOptions.autoGenerateMipmaps;
  }
  /** @private */
  updateBounds() {
    const bounds = this._bounds;
    const anchor = this._anchor;
    const htmlMeasurement = measureHtmlText(this.text, this._style);
    const { width, height } = htmlMeasurement;
    bounds.minX = -anchor._x * width;
    bounds.maxX = bounds.minX + width;
    bounds.minY = -anchor._y * height;
    bounds.maxY = bounds.minY + height;
  }
  get text() {
    return this._text;
  }
  /**
   * The text content to display. Use '\n' for line breaks.
   * Accepts strings, numbers, or objects with toString() method.
   * @example
   * ```ts
   * const text = new HTMLText({
   *     text: 'Hello Pixi!',
   * });
   * const multilineText = new HTMLText({
   *     text: 'Line 1\nLine 2\nLine 3',
   * });
   * const numberText = new HTMLText({
   *     text: 12345, // Will be converted to '12345'
   * });
   * const objectText = new HTMLText({
   *     text: { toString: () => 'Object Text' }, // Custom toString
   * });
   *
   * // Update text dynamically
   * text.text = 'Updated Text'; // Re-renders with new text
   * text.text = 67890; // Updates to '67890'
   * text.text = { toString: () => 'Dynamic Text' }; // Uses custom toString method
   * // Clear text
   * text.text = ''; // Clears the text
   * ```
   * @default ''
   */
  set text(text) {
    const sanitisedText = this._sanitiseText(text.toString());
    super.text = sanitisedText;
  }
  /**
   * Sanitise text - replace `<br>` with `<br/>`, `&nbsp;` with `&#160;`
   * @param text
   * @see https://www.sitepoint.com/community/t/xhtml-1-0-transitional-xml-parsing-error-entity-nbsp-not-defined/3392/3
   */
  _sanitiseText(text) {
    return this._removeInvalidHtmlTags(text.replace(/<br>/gi, "<br/>").replace(/<hr>/gi, "<hr/>").replace(/&nbsp;/gi, "&#160;"));
  }
  _removeInvalidHtmlTags(input) {
    const brokenTagPattern = /<[^>]*?(?=<|$)/g;
    return input.replace(brokenTagPattern, "");
  }
};

// node_modules/pixi.js/lib/prepare/PrepareUpload.mjs
var PrepareUpload = class extends PrepareQueue {
  /**
   * Upload the given queue item
   * @param item
   */
  uploadQueueItem(item) {
    if (item instanceof TextureSource) {
      this.uploadTextureSource(item);
    } else if (item instanceof Text) {
      this.uploadText(item);
    } else if (item instanceof HTMLText) {
      this.uploadHTMLText(item);
    } else if (item instanceof BitmapText) {
      this.uploadBitmapText(item);
    } else if (item instanceof GraphicsContext) {
      this.uploadGraphicsContext(item);
    }
  }
  uploadTextureSource(textureSource) {
    this.renderer.texture.initSource(textureSource);
  }
  uploadText(_text) {
    this.renderer.renderPipes.text.initGpuText(_text);
  }
  uploadBitmapText(_text) {
    this.renderer.renderPipes.bitmapText.initGpuText(_text);
  }
  uploadHTMLText(_text) {
    this.renderer.renderPipes.htmlText.initGpuText(_text);
  }
  /**
   * Resolve the given graphics context and return an item for the queue
   * @param graphicsContext
   */
  uploadGraphicsContext(graphicsContext) {
    this.renderer.graphicsContext.getGpuContext(graphicsContext);
    const { instructions } = graphicsContext;
    for (const instruction of instructions) {
      if (instruction.action === "texture") {
        const { image } = instruction.data;
        this.uploadTextureSource(image.source);
      } else if (instruction.action === "fill") {
        const { texture } = instruction.data.style;
        this.uploadTextureSource(texture.source);
      }
    }
    return null;
  }
};

// node_modules/pixi.js/lib/prepare/PrepareSystem.mjs
var PrepareSystem = class extends PrepareUpload {
  /** Destroys the plugin, don't use after this. */
  destroy() {
    super.destroy();
    clearTimeout(this.timeout);
    this.renderer = null;
    this.queue = null;
    this.resolves = null;
  }
};
PrepareSystem.extension = {
  type: [
    ExtensionType.WebGLSystem,
    ExtensionType.WebGPUSystem
  ],
  name: "prepare"
};

// node_modules/pixi.js/lib/rendering/batcher/gpu/generateGPULayout.mjs
function generateGPULayout(maxTextures) {
  const gpuLayout = [];
  let bindIndex = 0;
  for (let i = 0; i < maxTextures; i++) {
    gpuLayout[bindIndex] = {
      texture: {
        sampleType: "float",
        viewDimension: "2d",
        multisampled: false
      },
      binding: bindIndex,
      visibility: GPUShaderStage.FRAGMENT
    };
    bindIndex++;
    gpuLayout[bindIndex] = {
      sampler: {
        type: "filtering"
      },
      binding: bindIndex,
      visibility: GPUShaderStage.FRAGMENT
    };
    bindIndex++;
  }
  return gpuLayout;
}

// node_modules/pixi.js/lib/rendering/batcher/gpu/generateLayout.mjs
function generateLayout(maxTextures) {
  const layout = {};
  let bindIndex = 0;
  for (let i = 0; i < maxTextures; i++) {
    layout[`textureSource${i + 1}`] = bindIndex++;
    layout[`textureSampler${i + 1}`] = bindIndex++;
  }
  return layout;
}

// node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/formatShader.mjs
function formatShader(shader) {
  const spl = shader.split(/([\n{}])/g).map((a) => a.trim()).filter((a) => a.length);
  let indent = "";
  const formatted = spl.map((a) => {
    let indentedLine = indent + a;
    if (a === "{") {
      indent += "    ";
    } else if (a === "}") {
      indent = indent.substr(0, indent.length - 4);
      indentedLine = indent + a;
    }
    return indentedLine;
  }).join("\n");
  return formatted;
}

// node_modules/pixi.js/lib/rendering/mask/scissor/ScissorMask.mjs
var ScissorMask = class {
  constructor(mask) {
    this.priority = 0;
    this.pipe = "scissorMask";
    this.mask = mask;
    this.mask.renderable = false;
    this.mask.measurable = false;
  }
  addBounds(bounds, skipUpdateTransform) {
    addMaskBounds(this.mask, bounds, skipUpdateTransform);
  }
  addLocalBounds(bounds, localRoot) {
    addMaskLocalBounds(this.mask, bounds, localRoot);
  }
  containsPoint(point, hitTestFn) {
    const mask = this.mask;
    return hitTestFn(mask, point);
  }
  reset() {
    if (this.mask === null) return;
    this.mask.measurable = true;
    this.mask = null;
  }
  destroy() {
    this.reset();
  }
};

// node_modules/pixi.js/lib/rendering/renderers/gl/shader/migrateFragmentFromV7toV8.mjs
function migrateFragmentFromV7toV8(fragmentShader) {
  fragmentShader = fragmentShader.replaceAll("texture2D", "texture").replaceAll("gl_FragColor", "finalColor").replaceAll("varying", "in");
  fragmentShader = `
        out vec4 finalColor;
    ${fragmentShader}
    `;
  return fragmentShader;
}

// node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/mapSize.mjs
var GLSL_TO_SIZE = {
  float: 1,
  vec2: 2,
  vec3: 3,
  vec4: 4,
  int: 1,
  ivec2: 2,
  ivec3: 3,
  ivec4: 4,
  uint: 1,
  uvec2: 2,
  uvec3: 3,
  uvec4: 4,
  bool: 1,
  bvec2: 2,
  bvec3: 3,
  bvec4: 4,
  mat2: 4,
  mat3: 9,
  mat4: 16,
  sampler2D: 1
};
function mapSize(type) {
  return GLSL_TO_SIZE[type];
}

// node_modules/pixi.js/lib/rendering/renderers/shared/geometry/const.mjs
var DEPRECATED_DRAW_MODES = {
  POINTS: "point-list",
  LINES: "line-list",
  LINE_STRIP: "line-strip",
  TRIANGLES: "triangle-list",
  TRIANGLE_STRIP: "triangle-strip"
};
var DRAW_MODES = new Proxy(DEPRECATED_DRAW_MODES, {
  get(target, prop) {
    deprecation(v8_0_0, `DRAW_MODES.${prop} is deprecated, use '${DEPRECATED_DRAW_MODES[prop]}' instead`);
    return target[prop];
  }
});

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/const.mjs
var DEPRECATED_WRAP_MODES = ((DEPRECATED_WRAP_MODES2) => {
  DEPRECATED_WRAP_MODES2["CLAMP"] = "clamp-to-edge";
  DEPRECATED_WRAP_MODES2["REPEAT"] = "repeat";
  DEPRECATED_WRAP_MODES2["MIRRORED_REPEAT"] = "mirror-repeat";
  return DEPRECATED_WRAP_MODES2;
})(DEPRECATED_WRAP_MODES || {});
var WRAP_MODES = new Proxy(DEPRECATED_WRAP_MODES, {
  get(target, prop) {
    deprecation(v8_0_0, `DRAW_MODES.${prop} is deprecated, use '${DEPRECATED_WRAP_MODES[prop]}' instead`);
    return target[prop];
  }
});
var DEPRECATED_SCALE_MODES = ((DEPRECATED_SCALE_MODES2) => {
  DEPRECATED_SCALE_MODES2["NEAREST"] = "nearest";
  DEPRECATED_SCALE_MODES2["LINEAR"] = "linear";
  return DEPRECATED_SCALE_MODES2;
})(DEPRECATED_SCALE_MODES || {});
var SCALE_MODES = new Proxy(DEPRECATED_SCALE_MODES, {
  get(target, prop) {
    deprecation(v8_0_0, `DRAW_MODES.${prop} is deprecated, use '${DEPRECATED_SCALE_MODES[prop]}' instead`);
    return target[prop];
  }
});

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/CubeTextureSource.mjs
var CubeTextureSource = class _CubeTextureSource extends TextureSource {
  constructor(options) {
    const _a = options, { faces } = _a, rest = __objRest(_a, ["faces"]);
    _CubeTextureSource._validateFaces(faces);
    const first = faces.right;
    const derivedResolution = first.resolution;
    const derivedFormat = first.format;
    const derivedAlphaMode = first.alphaMode;
    const ignoredKeys = [
      "resolution",
      "format",
      "alphaMode",
      "dimensions",
      "viewDimension"
    ].filter((key) => rest[key] !== void 0);
    if (ignoredKeys.length) {
      warn(
        `[CubeTextureSource] Ignoring option(s) [${ignoredKeys.join(", ")}]; these are derived from face sources.`
      );
    }
    super(__spreadProps(__spreadValues({}, rest), {
      resource: faces,
      // Keep these aligned with the face sources so any code that reads width/height works.
      width: first.width,
      height: first.height,
      viewDimension: "cube",
      arrayLayerCount: 6,
      resolution: derivedResolution,
      format: derivedFormat,
      alphaMode: derivedAlphaMode
    }));
    this.uploadMethodId = "cube";
    this.faces = faces;
    for (const key of Object.keys(faces)) {
      const face = faces[key];
      face.on("update", this._onFaceUpdate, this);
      face.on("resize", this._onFaceResize, this);
      face.on("unload", this._onFaceUpdate, this);
    }
  }
  destroy() {
    const faces = this.faces;
    if (faces) {
      for (const key of Object.keys(faces)) {
        const face = faces[key];
        face.off("update", this._onFaceUpdate, this);
        face.off("resize", this._onFaceResize, this);
        face.off("unload", this._onFaceUpdate, this);
      }
    }
    super.destroy();
  }
  _onFaceUpdate() {
    this.emit("update", this);
  }
  _onFaceResize(face) {
    _CubeTextureSource._validateFaces(this.faces);
    this.resize(face.width, face.height, face.resolution);
  }
  static _validateFaces(faces) {
    if (!faces.right || !faces.left || !faces.top || !faces.bottom || !faces.front || !faces.back) {
      throw new Error("[CubeTextureSource] Requires { left, right, top, bottom, front, back } faces.");
    }
    const first = faces.right;
    const expectedPixelWidth = first.pixelWidth;
    const expectedPixelHeight = first.pixelHeight;
    const expectedFormat = first.format;
    const expectedAlphaMode = first.alphaMode;
    const expectedResolution = first.resolution;
    for (const key of Object.keys(faces)) {
      const face = faces[key];
      if (face.pixelWidth !== expectedPixelWidth || face.pixelHeight !== expectedPixelHeight) {
        throw new Error(`[CubeTextureSource] Face '${String(key)}' has a different size. All faces must match.`);
      }
      if (face.format !== expectedFormat) {
        throw new Error(`[CubeTextureSource] Face '${String(key)}' has a different format. All faces must match.`);
      }
      if (face.alphaMode !== expectedAlphaMode) {
        throw new Error(
          `[CubeTextureSource] Face '${String(key)}' has a different alphaMode. All faces must match.`
        );
      }
      if (face.resolution !== expectedResolution) {
        throw new Error(
          `[CubeTextureSource] Face '${String(key)}' has a different resolution. All faces must match.`
        );
      }
    }
  }
};

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/CubeTexture.mjs
var faceKeys = ["left", "right", "top", "bottom", "front", "back"];
function getCubeCacheKey(faceIds, options) {
  const opts = options ? __spreadValues({}, options) : {};
  delete opts.label;
  const optKeys = Object.keys(opts).sort();
  const optPart = optKeys.length ? `|${optKeys.map((k) => `${k}=${String(opts[k])}`).join("&")}` : "";
  const facesPart = faceKeys.map((k) => faceIds[k]).join(",");
  return `cube:${facesPart}${optPart}`;
}
var CubeTexture = class _CubeTexture extends eventemitter3_default {
  constructor(options) {
    super();
    this.uid = uid("cubeTexture");
    this.destroyed = false;
    const { label, source: source8 } = options;
    this.label = label;
    this.source = source8;
    this.source.label = this.label ?? this.source.label;
  }
  static from(options, skipCache = false) {
    if (options instanceof CubeTextureSource) {
      return new _CubeTexture({ source: options });
    }
    const _a = options, { faces } = _a, sourceOptions = __objRest(_a, ["faces"]);
    let cacheKey = null;
    const isFaceIds = faceKeys.every((key) => typeof faces[key] === "string");
    if (!skipCache && isFaceIds) {
      cacheKey = getCubeCacheKey(faces, sourceOptions);
      if (Cache.has(cacheKey)) {
        return Cache.get(cacheKey);
      }
    }
    const toTexture = (input) => {
      if (input.isTexture) return input;
      return Texture.from(input);
    };
    const faceSources = {};
    for (const key of faceKeys) {
      faceSources[key] = toTexture(faces[key]).source;
    }
    const cubeTexture = new _CubeTexture({
      source: new CubeTextureSource(__spreadProps(__spreadValues({}, sourceOptions), {
        faces: faceSources
      })),
      label: sourceOptions.label
    });
    if (cacheKey) {
      Cache.set(cacheKey, cubeTexture);
      cubeTexture.once("destroy", () => {
        if (Cache.has(cacheKey)) {
          Cache.remove(cacheKey);
        }
      });
    }
    return cubeTexture;
  }
  /**
   * Destroy this CubeTexture.
   * @param destroySource - If true, destroys the underlying {@link CubeTextureSource}.
   */
  destroy(destroySource = false) {
    if (this.destroyed) return;
    this.destroyed = true;
    if (destroySource) {
      this.source.destroy();
    }
    this.emit("destroy", this);
    this.removeAllListeners();
  }
};

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/ExternalSource.mjs
var placeholderGl = /* @__PURE__ */ Object.create(null);
var placeholderGpu = /* @__PURE__ */ Object.create(null);
function getPlaceholder(renderer) {
  var _a;
  if (renderer.type === RendererType.WEBGPU) {
    placeholderGpu[_a = renderer.uid] || (placeholderGpu[_a] = renderer.gpu.device.createTexture({
      label: "ExternalSource placeholder",
      size: { width: 1, height: 1 },
      format: "rgba8unorm",
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
    }));
    return placeholderGpu[renderer.uid];
  }
  if (!placeholderGl[renderer.uid]) {
    const gl = renderer.gl;
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    placeholderGl[renderer.uid] = texture;
  }
  return placeholderGl[renderer.uid];
}
var ExternalSource = class extends TextureSource {
  constructor({ resource, renderer, label, width, height }) {
    resource || (resource = getPlaceholder(renderer));
    width || (width = width ?? resource?.width ?? 1);
    height || (height = height ?? resource?.height ?? 1);
    super({
      resource,
      width,
      height,
      label,
      // External textures shouldn't be garbage collected - the external library owns them
      autoGarbageCollect: false
    });
    this._renderer = renderer;
    this._initGpuData(resource);
  }
  /**
   * Test if a resource is a valid external GPU texture.
   * @param resource - The resource to test
   * @returns True if the resource is a GPUTexture or WebGLTexture
   */
  static test(resource) {
    return globalThis.GPUTexture && resource instanceof GPUTexture || globalThis.WebGLTexture && resource instanceof WebGLTexture;
  }
  _validateTexture(resource) {
    const renderer = this._renderer;
    const isWebGPU = !!renderer.gpu;
    const isGPUTexture = globalThis.GPUTexture && resource instanceof GPUTexture;
    const isWebGLTexture = globalThis.WebGLTexture && resource instanceof WebGLTexture;
    if (isWebGPU && isWebGLTexture) {
      throw new Error("Cannot use WebGLTexture with a WebGPU renderer");
    }
    if (!isWebGPU && isGPUTexture) {
      throw new Error("Cannot use GPUTexture with a WebGL renderer");
    }
    if (!isWebGPU) {
      const gl = renderer.gl;
      if (gl && !gl.isTexture(resource)) {
        throw new Error("WebGLTexture does not belong to this renderer's WebGL context");
      }
    }
  }
  _initGpuData(resource) {
    const renderer = this._renderer;
    this._validateTexture(resource);
    if (renderer.gpu) {
      this._gpuData[renderer.uid] = new GPUTextureGpuData(resource);
    } else {
      this._gpuData[renderer.uid] = new GlTexture(resource);
    }
  }
  /**
   * Update the external GPU texture reference.
   * Call this when the external library provides a new texture.
   * @param gpuTexture - The new GPU texture
   * @param width - New width (required for WebGLTexture, auto-detected for GPUTexture)
   * @param height - New height (required for WebGLTexture, auto-detected for GPUTexture)
   */
  updateGPUTexture(gpuTexture, width, height) {
    const renderer = this._renderer;
    const gpuData = this._gpuData[renderer.uid];
    this.resource = gpuTexture;
    if (renderer.gpu) {
      this._validateTexture(gpuTexture);
      const data = gpuData;
      if (data.gpuTexture !== gpuTexture) {
        data.gpuTexture = gpuTexture;
        data.textureView = null;
        data.textureViews = /* @__PURE__ */ Object.create(null);
        this._resourceId = uid("resource");
        this.emit("change", this);
      }
      const newWidth = width ?? gpuTexture.width;
      const newHeight = height ?? gpuTexture.height;
      this.resize(newWidth, newHeight);
    } else {
      this._validateTexture(gpuTexture);
      const data = gpuData;
      data.texture = gpuTexture;
      if (width !== void 0 && height !== void 0) {
        this.resize(width, height);
      }
    }
    this.emit("update", this);
  }
  destroy() {
    const renderer = this._renderer;
    delete this._gpuData[renderer.uid];
    super.destroy();
  }
};

// node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureUvs.mjs
var TextureUvs = class {
  constructor() {
    this.x0 = 0;
    this.y0 = 0;
    this.x1 = 1;
    this.y1 = 0;
    this.x2 = 1;
    this.y2 = 1;
    this.x3 = 0;
    this.y3 = 1;
    this.uvsFloat32 = new Float32Array(8);
  }
  /**
   * Sets the texture Uvs based on the given frame information.
   * @protected
   * @param frame - The frame of the texture
   * @param baseFrame - The base frame of the texture
   * @param rotate - Rotation of frame, see {@link groupD8}
   */
  set(frame, baseFrame, rotate) {
    const tw = baseFrame.width;
    const th = baseFrame.height;
    if (rotate) {
      const w2 = frame.width / 2 / tw;
      const h2 = frame.height / 2 / th;
      const cX = frame.x / tw + w2;
      const cY = frame.y / th + h2;
      rotate = groupD8.add(rotate, groupD8.NW);
      this.x0 = cX + w2 * groupD8.uX(rotate);
      this.y0 = cY + h2 * groupD8.uY(rotate);
      rotate = groupD8.add(rotate, 2);
      this.x1 = cX + w2 * groupD8.uX(rotate);
      this.y1 = cY + h2 * groupD8.uY(rotate);
      rotate = groupD8.add(rotate, 2);
      this.x2 = cX + w2 * groupD8.uX(rotate);
      this.y2 = cY + h2 * groupD8.uY(rotate);
      rotate = groupD8.add(rotate, 2);
      this.x3 = cX + w2 * groupD8.uX(rotate);
      this.y3 = cY + h2 * groupD8.uY(rotate);
    } else {
      this.x0 = frame.x / tw;
      this.y0 = frame.y / th;
      this.x1 = (frame.x + frame.width) / tw;
      this.y1 = frame.y / th;
      this.x2 = (frame.x + frame.width) / tw;
      this.y2 = (frame.y + frame.height) / th;
      this.x3 = frame.x / tw;
      this.y3 = (frame.y + frame.height) / th;
    }
    this.uvsFloat32[0] = this.x0;
    this.uvsFloat32[1] = this.y0;
    this.uvsFloat32[2] = this.x1;
    this.uvsFloat32[3] = this.y1;
    this.uvsFloat32[4] = this.x2;
    this.uvsFloat32[5] = this.y2;
    this.uvsFloat32[6] = this.x3;
    this.uvsFloat32[7] = this.y3;
  }
  toString() {
    return `[pixi.js/core:TextureUvs x0=${this.x0} y0=${this.y0} x1=${this.x1} y1=${this.y1} x2=${this.x2} y2=${this.y2} x3=${this.x3} y3=${this.y3}]`;
  }
};

// node_modules/pixi.js/lib/rendering/renderers/shared/utils/parseFunctionBody.mjs
function parseFunctionBody(fn) {
  const fnStr = fn.toString();
  const bodyStart = fnStr.indexOf("{");
  const bodyEnd = fnStr.lastIndexOf("}");
  if (bodyStart === -1 || bodyEnd === -1) {
    throw new Error("getFunctionBody: No body found in function definition");
  }
  return fnStr.slice(bodyStart + 1, bodyEnd).trim();
}

// node_modules/pixi.js/lib/scene/container/bounds/getFastGlobalBounds.mjs
function getFastGlobalBounds(target, bounds) {
  deprecation("8.7.0", "Use container.getFastGlobalBounds() instead");
  return target.getFastGlobalBounds(true, bounds);
}

// node_modules/pixi.js/lib/scene/container/RenderContainer.mjs
var RenderContainer = class extends ViewContainer {
  /**
   * @param options - The options for the container.
   */
  constructor(options) {
    if (typeof options === "function") {
      options = { render: options };
    }
    const _a = options, { render } = _a, rest = __objRest(_a, ["render"]);
    super(__spreadValues({
      label: "RenderContainer"
    }, rest));
    this.renderPipeId = "customRender";
    this.batched = false;
    if (render) this.render = render;
    this.containsPoint = options.containsPoint ?? (() => false);
    this.addBounds = options.addBounds ?? (() => false);
  }
  /** @private */
  updateBounds() {
    this._bounds.clear();
    this.addBounds(this._bounds);
  }
  /**
   * An overridable function that can be used to render the object using the current renderer.
   * @param _renderer - The current renderer
   */
  render(_renderer) {
  }
};

// node_modules/pixi.js/lib/scene/container/utils/collectAllRenderables.mjs
function collectAllRenderables(container, instructionSet, rendererOrPipes) {
  deprecation("8.7.0", "Please use container.collectRenderables instead.");
  const renderer = rendererOrPipes.renderPipes ? rendererOrPipes : rendererOrPipes.batch.renderer;
  return container.collectRenderables(instructionSet, renderer, null);
}

// node_modules/pixi.js/lib/scene/container/utils/updateLocalTransform.mjs
function updateLocalTransform(lt, container) {
  const scale = container._scale;
  const pivot = container._pivot;
  const position = container._position;
  const sx = scale._x;
  const sy = scale._y;
  const px = pivot._x;
  const py = pivot._y;
  lt.a = container._cx * sx;
  lt.b = container._sx * sx;
  lt.c = container._cy * sy;
  lt.d = container._sy * sy;
  lt.tx = position._x - (px * lt.a + py * lt.c);
  lt.ty = position._y - (px * lt.b + py * lt.d);
}

// node_modules/pixi.js/lib/scene/container/utils/updateWorldTransform.mjs
function updateWorldTransform(local, parent, world) {
  const lta = local.a;
  const ltb = local.b;
  const ltc = local.c;
  const ltd = local.d;
  const lttx = local.tx;
  const ltty = local.ty;
  const pta = parent.a;
  const ptb = parent.b;
  const ptc = parent.c;
  const ptd = parent.d;
  world.a = lta * pta + ltb * ptc;
  world.b = lta * ptb + ltb * ptd;
  world.c = ltc * pta + ltd * ptc;
  world.d = ltc * ptb + ltd * ptd;
  world.tx = lttx * pta + ltty * ptc + parent.tx;
  world.ty = lttx * ptb + ltty * ptd + parent.ty;
}

// node_modules/pixi.js/lib/scene/graphics/shared/svg/buildSVGDefinitions.mjs
var SVGDefsCollector = class {
  constructor() {
    this._gradients = [];
    this._nextId = 0;
  }
  /**
   * Registers a gradient from a fill/stroke style and returns a `url(#id)` reference.
   * If the style has no gradient, returns `null`.
   * @param style
   */
  addStyle(style) {
    if (!(style.fill instanceof FillGradient)) return null;
    const id = `pixi-grad-${this._nextId++}`;
    this._gradients.push({
      id,
      gradient: style.fill,
      textureSpace: style.textureSpace ?? "local"
    });
    return `url(#${id})`;
  }
  /** Renders the collected definitions as an SVG `<defs>` string. */
  build() {
    if (this._gradients.length === 0) return "";
    const parts = ["<defs>"];
    for (const { id, gradient, textureSpace } of this._gradients) {
      const gradientUnits = textureSpace === "global" ? "userSpaceOnUse" : "objectBoundingBox";
      const stops = buildColorStops(gradient.colorStops);
      if (gradient.type === "radial") {
        const cx = gradient.outerCenter?.x ?? 0.5;
        const cy = gradient.outerCenter?.y ?? 0.5;
        const r = gradient.outerRadius ?? 0.5;
        const fx = gradient.center?.x ?? cx;
        const fy = gradient.center?.y ?? cy;
        parts.push(
          `<radialGradient id="${id}" gradientUnits="${gradientUnits}" cx="${cx}" cy="${cy}" r="${r}" fx="${fx}" fy="${fy}">`,
          stops,
          "</radialGradient>"
        );
      } else {
        const x1 = gradient.start?.x ?? 0;
        const y1 = gradient.start?.y ?? 0;
        const x2 = gradient.end?.x ?? 1;
        const y2 = gradient.end?.y ?? 0;
        parts.push(
          `<linearGradient id="${id}" gradientUnits="${gradientUnits}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}">`,
          stops,
          "</linearGradient>"
        );
      }
    }
    parts.push("</defs>");
    return parts.join("");
  }
};
function buildColorStops(colorStops) {
  return colorStops.map((stop) => {
    const hex = Color.shared.setValue(stop.color).toHex();
    return `<stop offset="${stop.offset}" stop-color="${hex}"/>`;
  }).join("");
}

// node_modules/pixi.js/lib/scene/graphics/shared/svg/buildSVGPath.mjs
var PI2 = Math.PI * 2;
var COMPLEX_ACTIONS = /* @__PURE__ */ new Set([
  "regularPoly",
  "roundPoly",
  "roundShape",
  "filletRect",
  "chamferRect",
  "arcTo"
]);
function buildSVGPath(path2, precision = 2, flatten = false) {
  if (path2.instructions.some((inst) => COMPLEX_ACTIONS.has(inst.action))) {
    return buildFromShapePrimitives(path2, precision, flatten);
  }
  const parts = [];
  let hasCurrent = false;
  for (let i = 0; i < path2.instructions.length; i++) {
    const inst = path2.instructions[i];
    const d = inst.data;
    switch (inst.action) {
      case "moveTo":
        parts.push(`M${pt(d[0], d[1], null, precision)}`);
        hasCurrent = true;
        break;
      case "lineTo":
        parts.push(`L${pt(d[0], d[1], null, precision)}`);
        hasCurrent = true;
        break;
      case "quadraticCurveTo":
        parts.push(
          `Q${pt(d[0], d[1], null, precision)} ${pt(d[2], d[3], null, precision)}`
        );
        hasCurrent = true;
        break;
      case "bezierCurveTo":
        parts.push(
          `C${pt(d[0], d[1], null, precision)} ${pt(d[2], d[3], null, precision)} ${pt(d[4], d[5], null, precision)}`
        );
        hasCurrent = true;
        break;
      case "arcToSvg":
        parts.push(
          `A${n(d[0], precision)} ${n(d[1], precision)} ${n(d[2], precision)} ${d[3]} ${d[4]} ${pt(d[5], d[6], null, precision)}`
        );
        hasCurrent = true;
        break;
      case "closePath":
        parts.push("Z");
        hasCurrent = false;
        break;
      case "arc":
        parts.push(buildArc2(d[0], d[1], d[2], d[3], d[4], !!d[5], hasCurrent, precision, flatten));
        hasCurrent = !isFullCircle(d[3], d[4], !!d[5]);
        break;
      case "rect":
        parts.push(buildRect(d[0], d[1], d[2], d[3], d[4], precision));
        hasCurrent = false;
        break;
      case "circle":
        parts.push(buildEllipseArc(d[0], d[1], d[2], d[2], d[3], precision, flatten));
        hasCurrent = false;
        break;
      case "ellipse":
        parts.push(buildEllipseArc(d[0], d[1], d[2], d[3], d[4], precision, flatten));
        hasCurrent = false;
        break;
      case "roundRect":
        parts.push(buildRoundRect(d[0], d[1], d[2], d[3], d[4] ?? 0, d[5], precision, flatten));
        hasCurrent = false;
        break;
      case "poly":
        parts.push(buildPoly(d[0], d[1] ?? true, d[2], precision));
        hasCurrent = !(d[1] ?? true);
        break;
      case "addPath":
        parts.push(buildAddPath(d[0], d[1], precision, flatten));
        hasCurrent = true;
        break;
    }
  }
  return parts.join("");
}
function isFullCircle(startAngle, endAngle, ccw) {
  let sweep = endAngle - startAngle;
  if (ccw) {
    if (sweep > 0) sweep -= PI2;
  } else if (sweep < 0) {
    sweep += PI2;
  }
  return Math.abs(sweep) >= PI2 - 1e-6;
}
function n(value, precision) {
  return parseFloat(value.toFixed(precision)).toString();
}
function pt(x, y, matrix, precision) {
  if (matrix && !matrix.isIdentity()) {
    const tx = matrix.a * x + matrix.c * y + matrix.tx;
    const ty = matrix.b * x + matrix.d * y + matrix.ty;
    return `${n(tx, precision)} ${n(ty, precision)}`;
  }
  return `${n(x, precision)} ${n(y, precision)}`;
}
function buildArc2(cx, cy, radius, startAngle, endAngle, ccw, hasCurrent, precision, flatten = false) {
  let sweep = endAngle - startAngle;
  if (ccw) {
    if (sweep > 0) sweep -= PI2;
  } else if (sweep < 0) {
    sweep += PI2;
  }
  if (Math.abs(sweep) >= PI2 - 1e-6) {
    return buildEllipseArc(cx, cy, radius, radius, null, precision, flatten);
  }
  if (flatten) {
    const segments = 32;
    const parts = [];
    for (let i = 0; i <= segments; i++) {
      const a = startAngle + i / segments * sweep;
      const px = cx + radius * Math.cos(a);
      const py = cy + radius * Math.sin(a);
      const cmd = i === 0 ? hasCurrent ? "L" : "M" : "L";
      parts.push(`${cmd}${n(px, precision)} ${n(py, precision)}`);
    }
    return parts.join("");
  }
  const sx = cx + radius * Math.cos(startAngle);
  const sy = cy + radius * Math.sin(startAngle);
  const ex = cx + radius * Math.cos(endAngle);
  const ey = cy + radius * Math.sin(endAngle);
  const largeArc = Math.abs(sweep) > Math.PI ? 1 : 0;
  const sweepFlag = ccw ? 0 : 1;
  const start = hasCurrent ? "L" : "M";
  return `${start}${n(sx, precision)} ${n(sy, precision)}A${n(radius, precision)} ${n(radius, precision)} 0 ${largeArc} ${sweepFlag} ${n(ex, precision)} ${n(ey, precision)}`;
}
function buildEllipseArc(cx, cy, rx, ry, matrixArg, precision, flatten = false) {
  const matrix = matrixArg && !matrixArg.isIdentity() ? matrixArg : null;
  if (!matrix && !flatten) {
    return `M${n(cx - rx, precision)} ${n(cy, precision)}A${n(rx, precision)} ${n(ry, precision)} 0 1 1 ${n(cx + rx, precision)} ${n(cy, precision)}A${n(rx, precision)} ${n(ry, precision)} 0 1 1 ${n(cx - rx, precision)} ${n(cy, precision)}Z`;
  }
  const segments = 64;
  const parts = [];
  for (let i = 0; i < segments; i++) {
    const a = i / segments * PI2;
    const x = cx + rx * Math.cos(a);
    const y = cy + ry * Math.sin(a);
    parts.push(`${i === 0 ? "M" : "L"}${pt(x, y, matrix, precision)}`);
  }
  parts.push("Z");
  return parts.join("");
}
function buildRect(x, y, w, h, matrix, precision) {
  return `M${pt(x, y, matrix, precision)}L${pt(x + w, y, matrix, precision)}L${pt(x + w, y + h, matrix, precision)}L${pt(x, y + h, matrix, precision)}Z`;
}
function buildRoundRect(x, y, w, h, r, matrixArg, precision, flatten = false) {
  const matrix = matrixArg && !matrixArg.isIdentity() ? matrixArg : null;
  if (r <= 0) return buildRect(x, y, w, h, matrix, precision);
  r = Math.min(r, Math.min(w, h) / 2);
  if (matrix || flatten) {
    const parts = [];
    const cornerSegments = 8;
    const corners = [
      [x + w - r, y + r, -Math.PI / 2],
      [x + w - r, y + h - r, 0],
      [x + r, y + h - r, Math.PI / 2],
      [x + r, y + r, Math.PI]
    ];
    let first = true;
    for (let c = 0; c < corners.length; c++) {
      const [cx, cy, start] = corners[c];
      for (let i = 0; i <= cornerSegments; i++) {
        const a = start + i / cornerSegments * (Math.PI / 2);
        const px = cx + r * Math.cos(a);
        const py = cy + r * Math.sin(a);
        parts.push(`${first ? "M" : "L"}${pt(px, py, matrix, precision)}`);
        first = false;
      }
    }
    parts.push("Z");
    return parts.join("");
  }
  return `M${n(x + r, precision)} ${n(y, precision)}L${n(x + w - r, precision)} ${n(y, precision)}A${n(r, precision)} ${n(r, precision)} 0 0 1 ${n(x + w, precision)} ${n(y + r, precision)}L${n(x + w, precision)} ${n(y + h - r, precision)}A${n(r, precision)} ${n(r, precision)} 0 0 1 ${n(x + w - r, precision)} ${n(y + h, precision)}L${n(x + r, precision)} ${n(y + h, precision)}A${n(r, precision)} ${n(r, precision)} 0 0 1 ${n(x, precision)} ${n(y + h - r, precision)}L${n(x, precision)} ${n(y + r, precision)}A${n(r, precision)} ${n(r, precision)} 0 0 1 ${n(x + r, precision)} ${n(y, precision)}Z`;
}
function buildPoly(points, close, matrix, precision) {
  if (points.length === 0) return "";
  const parts = [];
  const isFlat = typeof points[0] === "number";
  if (isFlat) {
    const pts = points;
    parts.push(`M${pt(pts[0], pts[1], matrix, precision)}`);
    for (let i = 2; i < pts.length; i += 2) {
      parts.push(`L${pt(pts[i], pts[i + 1], matrix, precision)}`);
    }
  } else {
    const pts = points;
    parts.push(`M${pt(pts[0].x, pts[0].y, matrix, precision)}`);
    for (let i = 1; i < pts.length; i++) {
      parts.push(`L${pt(pts[i].x, pts[i].y, matrix, precision)}`);
    }
  }
  if (close) parts.push("Z");
  return parts.join("");
}
function buildAddPath(inner, matrix, precision, flatten) {
  if (!matrix || matrix.isIdentity()) return buildSVGPath(inner, precision, flatten);
  return buildSVGPath(inner.clone(true).transform(matrix), precision, flatten);
}
function buildFromShapePrimitives(path2, precision, flatten) {
  const shapePrimitives = path2.shapePath.shapePrimitives;
  const parts = [];
  for (const primitive of shapePrimitives) {
    const shape = primitive.shape;
    const transform2 = primitive.transform;
    switch (shape.type) {
      case "polygon": {
        const poly = shape;
        parts.push(buildPoly(poly.points, poly.closePath, transform2, precision));
        break;
      }
      case "circle": {
        const c = shape;
        parts.push(buildEllipseArc(c.x, c.y, c.radius, c.radius, transform2, precision, flatten));
        break;
      }
      case "ellipse": {
        const e = shape;
        parts.push(buildEllipseArc(e.x, e.y, e.halfWidth, e.halfHeight, transform2, precision, flatten));
        break;
      }
      case "rectangle": {
        const r = shape;
        parts.push(buildRect(r.x, r.y, r.width, r.height, transform2, precision));
        break;
      }
      case "roundedRectangle": {
        const rr = shape;
        parts.push(buildRoundRect(rr.x, rr.y, rr.width, rr.height, rr.radius, transform2, precision, flatten));
        break;
      }
    }
  }
  return parts.join("");
}

// node_modules/pixi.js/lib/scene/graphics/shared/svg/buildSVGStyle.mjs
function buildSVGFillAttributes(style, defs) {
  const gradRef = defs.addStyle(style);
  const parts = [];
  if (gradRef) {
    parts.push(`fill="${gradRef}"`);
  } else {
    parts.push(`fill="${Color.shared.setValue(style.color).toHex()}"`);
  }
  if (style.alpha < 1) {
    parts.push(`fill-opacity="${style.alpha}"`);
  }
  return parts.join(" ");
}
function buildSVGStrokeAttributes(style, defs) {
  const gradRef = defs.addStyle(style);
  const parts = [];
  parts.push('fill="none"');
  if (gradRef) {
    parts.push(`stroke="${gradRef}"`);
  } else {
    parts.push(`stroke="${Color.shared.setValue(style.color).toHex()}"`);
  }
  parts.push(`stroke-width="${style.width}"`);
  if (style.cap !== "butt") {
    parts.push(`stroke-linecap="${style.cap}"`);
  }
  if (style.join !== "miter") {
    parts.push(`stroke-linejoin="${style.join}"`);
  } else if (style.miterLimit !== 10) {
    parts.push(`stroke-miterlimit="${style.miterLimit}"`);
  }
  if (style.alpha < 1) {
    parts.push(`stroke-opacity="${style.alpha}"`);
  }
  return parts.join(" ");
}

// node_modules/pixi.js/lib/scene/graphics/shared/svg/SVGExporter.mjs
function graphicsContextToSvg(source8, precision = 2) {
  const context = source8 instanceof GraphicsContext ? source8 : source8.context;
  const defs = new SVGDefsCollector();
  const elements = [];
  const instructions = context.instructions;
  let i = 0;
  while (i < instructions.length) {
    const inst = instructions[i];
    switch (inst.action) {
      case "fill": {
        const fillInst = inst;
        const hasHole = !!fillInst.data.hole;
        const d = hasHole ? buildSVGPath(fillInst.data.path, precision) + buildSVGPath(fillInst.data.hole, precision, true) : buildSVGPath(fillInst.data.path, precision);
        const fillAttrs = buildSVGFillAttributes(fillInst.data.style, defs);
        const rule = hasHole ? ' fill-rule="evenodd"' : "";
        elements.push(`<path d="${d}" ${fillAttrs}${rule}/>`);
        break;
      }
      case "stroke": {
        const strokeInst = inst;
        let pathD = buildSVGPath(strokeInst.data.path, precision);
        if (strokeInst.data.hole) {
          pathD += buildSVGPath(strokeInst.data.hole, precision, true);
        }
        const strokeAttrs = buildSVGStrokeAttributes(strokeInst.data.style, defs);
        elements.push(`<path d="${pathD}" ${strokeAttrs}/>`);
        break;
      }
      case "texture":
        break;
    }
    i++;
  }
  const bounds = context.bounds;
  const x = parseFloat(bounds.minX.toFixed(precision));
  const y = parseFloat(bounds.minY.toFixed(precision));
  const w = parseFloat((bounds.maxX - bounds.minX).toFixed(precision));
  const h = parseFloat((bounds.maxY - bounds.minY).toFixed(precision));
  const defsBlock = defs.build();
  const body = elements.join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="${x} ${y} ${w} ${h}">${defsBlock}${body}</svg>`;
}

// node_modules/pixi.js/lib/scene/graphics/shared/utils/buildGeometryFromPath.mjs
function buildGeometryFromPath(options) {
  if (options instanceof GraphicsPath) {
    options = {
      path: options,
      textureMatrix: null,
      out: null
    };
  }
  const vertices = [];
  const uvs = [];
  const indices = [];
  const shapePath = options.path.shapePath;
  const textureMatrix = options.textureMatrix;
  shapePath.shapePrimitives.forEach(({ shape, transform: matrix }) => {
    const indexOffset = indices.length;
    const vertOffset = vertices.length / 2;
    const points = [];
    const build = shapeBuilders[shape.type];
    build.build(shape, points);
    if (matrix) {
      transformVertices(points, matrix);
    }
    build.triangulate(points, vertices, 2, vertOffset, indices, indexOffset);
    const uvsOffset = uvs.length / 2;
    if (textureMatrix) {
      if (matrix) {
        textureMatrix.append(matrix.clone().invert());
      }
      buildUvs(vertices, 2, vertOffset, uvs, uvsOffset, 2, vertices.length / 2 - vertOffset, textureMatrix);
    } else {
      buildSimpleUvs(uvs, uvsOffset, 2, vertices.length / 2 - vertOffset);
    }
  });
  const out = options.out;
  if (out) {
    out.positions = new Float32Array(vertices);
    out.uvs = new Float32Array(uvs);
    out.indices = new Uint32Array(indices);
    return out;
  }
  const geometry = new MeshGeometry({
    positions: new Float32Array(vertices),
    uvs: new Float32Array(uvs),
    indices: new Uint32Array(indices)
  });
  return geometry;
}

// node_modules/pixi.js/lib/scene/layers/RenderLayer.mjs
var _RenderLayer = class _RenderLayer2 extends Container {
  /**
   * Creates a new RenderLayer instance
   * @param options - Configuration options for the RenderLayer
   * @param {boolean} [options.sortableChildren=false] - If true, layer children will be automatically sorted each render
   * @param {Function} [options.sortFunction] - Custom function to sort layer children. Default sorts by zIndex
   */
  constructor(options = {}) {
    options = __spreadValues(__spreadValues({}, _RenderLayer2.defaultOptions), options);
    super();
    this.renderLayerChildren = [];
    this.sortableChildren = options.sortableChildren;
    this.sortFunction = options.sortFunction;
  }
  /**
   * Adds one or more Containers to this render layer. The Containers will be rendered as part of this layer
   * while maintaining their original parent in the scene graph.
   *
   * If the Container already belongs to a layer, it will be removed from the old layer before being added to this one.
   * @example
   * ```ts
   * const layer = new RenderLayer();
   * const container = new Container();
   * const sprite1 = new Sprite(texture1);
   * const sprite2 = new Sprite(texture2);
   *
   * // Add sprites to scene graph for transforms
   * container.addChild(sprite1, sprite2);
   *
   * // Add sprites to layer for render order control
   * layer.attach(sprite1, sprite2);
   *
   * // Add single sprite with type checking
   * const typedSprite = layer.attach<Sprite>(new Sprite(texture3));
   * typedSprite.tint = 'red';
   *
   * // Automatically removes from previous layer if needed
   * const otherLayer = new RenderLayer();
   * otherLayer.attach(sprite1); // Removes from previous layer
   * ```
   * @param children - The Container(s) to add to this layer. Can be any Container or array of Containers.
   * @returns The first child that was added, for method chaining
   * @see {@link RenderLayer#detach} For removing objects from the layer
   * @see {@link RenderLayer#detachAll} For removing all objects from the layer
   * @see {@link Container#addChild} For adding to scene graph hierarchy
   */
  attach(...children) {
    for (let i = 0; i < children.length; i++) {
      const child = children[i];
      if (child.parentRenderLayer) {
        if (child.parentRenderLayer === this) continue;
        child.parentRenderLayer.detach(child);
      }
      this.renderLayerChildren.push(child);
      child.parentRenderLayer = this;
      const renderGroup = this.renderGroup || this.parentRenderGroup;
      if (renderGroup) {
        renderGroup.structureDidChange = true;
      }
    }
    return children[0];
  }
  /**
   * Removes one or more Containers from this render layer. The Containers will maintain their
   * original parent in the scene graph but will no longer be rendered as part of this layer.
   * @example
   * ```ts
   * const layer = new RenderLayer();
   * const container = new Container();
   * const sprite1 = new Sprite(texture1);
   * const sprite2 = new Sprite(texture2);
   *
   * // Add sprites to scene graph and layer
   * container.addChild(sprite1, sprite2);
   * layer.attach(sprite1, sprite2);
   *
   * // Remove single sprite from layer
   * layer.detach(sprite1);
   * // sprite1 is still child of container but not rendered in layer
   *
   * // Remove multiple sprites at once
   * const otherLayer = new RenderLayer();
   * otherLayer.attach(sprite3, sprite4);
   * otherLayer.detach(sprite3, sprite4);
   *
   * // Type-safe detachment
   * const typedSprite = layer.detach<Sprite>(spriteInLayer);
   * typedSprite.texture = newTexture; // TypeScript knows this is a Sprite
   * ```
   * @param children - The Container(s) to remove from this layer
   * @returns The first child that was removed, for method chaining
   * @see {@link RenderLayer#attach} For adding objects to the layer
   * @see {@link RenderLayer#detachAll} For removing all objects from the layer
   * @see {@link Container#removeChild} For removing from scene graph hierarchy
   */
  detach(...children) {
    for (let i = 0; i < children.length; i++) {
      const child = children[i];
      const index = this.renderLayerChildren.indexOf(child);
      if (index !== -1) {
        this.renderLayerChildren.splice(index, 1);
      }
      child.parentRenderLayer = null;
      const renderGroup = this.renderGroup || this.parentRenderGroup;
      if (renderGroup) {
        renderGroup.structureDidChange = true;
      }
    }
    return children[0];
  }
  /**
   * Removes all objects from this render layer. Objects will maintain their
   * original parent in the scene graph but will no longer be rendered as part of this layer.
   * @example
   * ```ts
   * const layer = new RenderLayer();
   * const container = new Container();
   *
   * // Add multiple sprites to scene graph and layer
   * const sprites = [
   *     new Sprite(texture1),
   *     new Sprite(texture2),
   *     new Sprite(texture3)
   * ];
   *
   * container.addChild(...sprites);  // Add to scene graph
   * layer.attach(...sprites);       // Add to render layer
   *
   * // Later, remove all sprites from layer at once
   * layer.detachAll();
   * console.log(layer.renderLayerChildren.length); // 0
   * console.log(container.children.length);        // 3 (still in scene graph)
   * ```
   * @returns The RenderLayer instance for method chaining
   * @see {@link RenderLayer#attach} For adding objects to the layer
   * @see {@link RenderLayer#detach} For removing individual objects
   * @see {@link Container#removeChildren} For removing from scene graph
   */
  detachAll() {
    const layerChildren = this.renderLayerChildren;
    for (let i = 0; i < layerChildren.length; i++) {
      layerChildren[i].parentRenderLayer = null;
    }
    this.renderLayerChildren.length = 0;
  }
  /**
   * Collects renderables for this layer and its children.
   * This method is called by the renderer to gather all objects that should be rendered in this layer.
   * @param instructionSet - The set of instructions to collect renderables into.
   * @param renderer - The renderer that is collecting renderables.
   * @param _currentLayer - The current render layer being processed.
   * @internal
   */
  collectRenderables(instructionSet, renderer, _currentLayer) {
    const layerChildren = this.renderLayerChildren;
    const length = layerChildren.length;
    if (this.sortableChildren) {
      this.sortRenderLayerChildren();
    }
    for (let i = 0; i < length; i++) {
      if (!layerChildren[i].parent) {
        warn(
          "Container must be added to both layer and scene graph. Layers only handle render order - the scene graph is required for transforms (addChild)",
          layerChildren[i]
        );
      }
      layerChildren[i].collectRenderables(instructionSet, renderer, this);
    }
  }
  /**
   * Sort the layer's children using the defined sort function. This method allows manual sorting
   * of layer children and is automatically called during rendering if sortableChildren is true.
   * @example
   * ```ts
   * const layer = new RenderLayer();
   *
   * // Add multiple sprites at different depths
   * const sprite1 = new Sprite(texture);
   * const sprite2 = new Sprite(texture);
   * const sprite3 = new Sprite(texture);
   *
   * sprite1.zIndex = 3;
   * sprite2.zIndex = 1;
   * sprite3.zIndex = 2;
   *
   * layer.attach(sprite1, sprite2, sprite3);
   *
   * // Manual sorting with default zIndex sort
   * layer.sortRenderLayerChildren();
   * // Order is now: sprite2 (1), sprite3 (2), sprite1 (3)
   *
   * // Custom sort by y position
   * layer.sortFunction = (a, b) => a.y - b.y;
   * layer.sortRenderLayerChildren();
   *
   * // Automatic sorting
   * layer.sortableChildren = true; // Will sort each render
   * ```
   * @returns The RenderLayer instance for method chaining
   * @see {@link RenderLayer#sortableChildren} For enabling automatic sorting
   * @see {@link RenderLayer#sortFunction} For customizing the sort logic
   */
  sortRenderLayerChildren() {
    this.renderLayerChildren.sort(this.sortFunction);
  }
  /**
   * Recursively calculates the global bounds of this RenderLayer and its children.
   * @param factorRenderLayers
   * @param bounds
   * @param _currentLayer
   * @internal
   */
  _getGlobalBoundsRecursive(factorRenderLayers, bounds, _currentLayer) {
    if (!factorRenderLayers) return;
    const children = this.renderLayerChildren;
    for (let i = 0; i < children.length; i++) {
      children[i]._getGlobalBoundsRecursive(true, bounds, this);
    }
  }
  /**
   * @inheritdoc
   * @internal
   */
  getFastGlobalBounds(factorRenderLayers, bounds) {
    return super.getFastGlobalBounds(factorRenderLayers, bounds);
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error. Please use `RenderLayer.attach()` instead.
   * @param {...any} _children
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  addChild(..._children) {
    throw new Error(
      "RenderLayer.addChild() is not available. Please use RenderLayer.attach()"
    );
  }
  /**
   * This method is not available in RenderLayer.
   * Calling this method will throw an error. Please use `RenderLayer.detach()` instead.
   * @param {...any} _children
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  removeChild(..._children) {
    throw new Error(
      "RenderLayer.removeChild() is not available. Please use RenderLayer.detach()"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error. Please use `RenderLayer.detach()` instead.
   * @param {number} [_beginIndex]
   * @param {number} [_endIndex]
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  removeChildren(_beginIndex, _endIndex) {
    throw new Error(
      "RenderLayer.removeChildren() is not available. Please use RenderLayer.detach()"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  removeChildAt(_index) {
    throw new Error(
      "RenderLayer.removeChildAt() is not available"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  getChildAt(_index) {
    throw new Error(
      "RenderLayer.getChildAt() is not available"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param {Container} _child
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  setChildIndex(_child, _index) {
    throw new Error(
      "RenderLayer.setChildIndex() is not available"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param {Container} _child
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  getChildIndex(_child) {
    throw new Error(
      "RenderLayer.getChildIndex() is not available"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param {Container} _child
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  addChildAt(_child, _index) {
    throw new Error(
      "RenderLayer.addChildAt() is not available"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param {Container} _child
   * @param {Container} _child2
   * @ignore
   */
  swapChildren(_child, _child2) {
    throw new Error(
      "RenderLayer.swapChildren() is not available"
    );
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param _child - The child to reparent
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  reparentChild(..._child) {
    throw new Error("RenderLayer.reparentChild() is not available with the render layer");
  }
  /**
   * This method is not available in RenderLayer.
   *
   * Calling this method will throw an error.
   * @param _child - The child to reparent
   * @param _index - The index to reparent the child to
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  reparentChildAt(_child, _index) {
    throw new Error("RenderLayer.reparentChildAt() is not available with the render layer");
  }
};
_RenderLayer.defaultOptions = {
  /** If true, layer children will be automatically sorted each render. Default is false. */
  sortableChildren: false,
  /**
   * Function used to sort layer children.
   * Default sorts by zIndex. Accepts two Container objects and returns
   * a number indicating their relative order.
   * @param a - First container to compare
   * @param b - Second container to compare
   * @returns Negative if a should render before b, positive if b should render before a
   */
  sortFunction: (a, b) => a.zIndex - b.zIndex
};
var RenderLayer = _RenderLayer;

// node_modules/pixi.js/lib/scene/mesh-plane/PlaneGeometry.mjs
var _PlaneGeometry = class _PlaneGeometry2 extends MeshGeometry {
  constructor(...args) {
    super({});
    let options = args[0] ?? {};
    if (typeof options === "number") {
      deprecation(v8_0_0, "PlaneGeometry constructor changed please use { width, height, verticesX, verticesY } instead");
      options = {
        width: options,
        height: args[1],
        verticesX: args[2],
        verticesY: args[3]
      };
    }
    this.build(options);
  }
  /**
   * Refreshes plane coordinates
   * @param options - Options to be applied to plane geometry
   */
  build(options) {
    options = __spreadValues(__spreadValues({}, _PlaneGeometry2.defaultOptions), options);
    this.verticesX = this.verticesX ?? options.verticesX;
    this.verticesY = this.verticesY ?? options.verticesY;
    this.width = this.width ?? options.width;
    this.height = this.height ?? options.height;
    const total = this.verticesX * this.verticesY;
    const verts = [];
    const uvs = [];
    const indices = [];
    const verticesX = this.verticesX - 1;
    const verticesY = this.verticesY - 1;
    const sizeX = this.width / verticesX;
    const sizeY = this.height / verticesY;
    for (let i = 0; i < total; i++) {
      const x = i % this.verticesX;
      const y = i / this.verticesX | 0;
      verts.push(x * sizeX, y * sizeY);
      uvs.push(x / verticesX, y / verticesY);
    }
    const totalSub = verticesX * verticesY;
    for (let i = 0; i < totalSub; i++) {
      const xpos = i % verticesX;
      const ypos = i / verticesX | 0;
      const value = ypos * this.verticesX + xpos;
      const value2 = ypos * this.verticesX + xpos + 1;
      const value3 = (ypos + 1) * this.verticesX + xpos;
      const value4 = (ypos + 1) * this.verticesX + xpos + 1;
      indices.push(
        value,
        value2,
        value3,
        value2,
        value4,
        value3
      );
    }
    this.buffers[0].data = new Float32Array(verts);
    this.buffers[1].data = new Float32Array(uvs);
    this.indexBuffer.data = new Uint32Array(indices);
    this.buffers[0].update();
    this.buffers[1].update();
    this.indexBuffer.update();
  }
};
_PlaneGeometry.defaultOptions = {
  width: 100,
  height: 100,
  verticesX: 10,
  verticesY: 10
};
var PlaneGeometry = _PlaneGeometry;

// node_modules/pixi.js/lib/scene/mesh-perspective/utils/applyProjectiveTransformationToPlane.mjs
function applyProjectiveTransformationToPlane(width, height, geometry, transformationMatrix) {
  const buffer = geometry.buffers[0];
  const vertices = buffer.data;
  const { verticesX, verticesY } = geometry;
  const sizeX = width / (verticesX - 1);
  const sizeY = height / (verticesY - 1);
  let index = 0;
  const a00 = transformationMatrix[0];
  const a01 = transformationMatrix[1];
  const a02 = transformationMatrix[2];
  const a10 = transformationMatrix[3];
  const a11 = transformationMatrix[4];
  const a12 = transformationMatrix[5];
  const a20 = transformationMatrix[6];
  const a21 = transformationMatrix[7];
  const a22 = transformationMatrix[8];
  for (let i = 0; i < vertices.length; i += 2) {
    const x = index % verticesX * sizeX;
    const y = (index / verticesX | 0) * sizeY;
    const newX = a00 * x + a01 * y + a02;
    const newY = a10 * x + a11 * y + a12;
    const w = a20 * x + a21 * y + a22;
    vertices[i] = newX / w;
    vertices[i + 1] = newY / w;
    index++;
  }
  buffer.update();
}

// node_modules/pixi.js/lib/scene/mesh-perspective/utils/compute2DProjections.mjs
function computeAdjugate(out, matrix) {
  const a00 = matrix[0];
  const a01 = matrix[1];
  const a02 = matrix[2];
  const a10 = matrix[3];
  const a11 = matrix[4];
  const a12 = matrix[5];
  const a20 = matrix[6];
  const a21 = matrix[7];
  const a22 = matrix[8];
  out[0] = a11 * a22 - a12 * a21;
  out[1] = a02 * a21 - a01 * a22;
  out[2] = a01 * a12 - a02 * a11;
  out[3] = a12 * a20 - a10 * a22;
  out[4] = a00 * a22 - a02 * a20;
  out[5] = a02 * a10 - a00 * a12;
  out[6] = a10 * a21 - a11 * a20;
  out[7] = a01 * a20 - a00 * a21;
  out[8] = a00 * a11 - a01 * a10;
  return out;
}
function multiplyMatrix3x3(out, a, b) {
  const a00 = a[0];
  const a01 = a[1];
  const a02 = a[2];
  const a10 = a[3];
  const a11 = a[4];
  const a12 = a[5];
  const a20 = a[6];
  const a21 = a[7];
  const a22 = a[8];
  const b00 = b[0];
  const b01 = b[1];
  const b02 = b[2];
  const b10 = b[3];
  const b11 = b[4];
  const b12 = b[5];
  const b20 = b[6];
  const b21 = b[7];
  const b22 = b[8];
  out[0] = b00 * a00 + b01 * a10 + b02 * a20;
  out[1] = b00 * a01 + b01 * a11 + b02 * a21;
  out[2] = b00 * a02 + b01 * a12 + b02 * a22;
  out[3] = b10 * a00 + b11 * a10 + b12 * a20;
  out[4] = b10 * a01 + b11 * a11 + b12 * a21;
  out[5] = b10 * a02 + b11 * a12 + b12 * a22;
  out[6] = b20 * a00 + b21 * a10 + b22 * a20;
  out[7] = b20 * a01 + b21 * a11 + b22 * a21;
  out[8] = b20 * a02 + b21 * a12 + b22 * a22;
  return out;
}
function multiplyMatrixAndVector(out, m, v) {
  const x = v[0];
  const y = v[1];
  const z = v[2];
  out[0] = m[0] * x + m[1] * y + m[2] * z;
  out[1] = m[3] * x + m[4] * y + m[5] * z;
  out[2] = m[6] * x + m[7] * y + m[8] * z;
  return out;
}
var tempMatrix2 = [0, 0, 0, 0, 0, 0, 0, 0, 0];
var tempVec = [0, 0, 0];
var tempVec2 = [0, 0, 0];
function generateBasisToPointsMatrix(out, x1, y1, x2, y2, x3, y3, x4, y4) {
  const m = tempMatrix2;
  m[0] = x1;
  m[1] = x2;
  m[2] = x3;
  m[3] = y1;
  m[4] = y2;
  m[5] = y3;
  m[6] = 1;
  m[7] = 1;
  m[8] = 1;
  const adjugateM = computeAdjugate(
    out,
    // reusing out as adjugateM is only used once
    m
  );
  tempVec2[0] = x4;
  tempVec2[1] = y4;
  tempVec2[2] = 1;
  const v = multiplyMatrixAndVector(
    tempVec,
    adjugateM,
    tempVec2
  );
  const diagonalMatrix = out;
  out[0] = v[0];
  out[1] = 0;
  out[2] = 0;
  out[3] = 0;
  out[4] = v[1];
  out[5] = 0;
  out[6] = 0;
  out[7] = 0;
  out[8] = v[2];
  return multiplyMatrix3x3(out, diagonalMatrix, m);
}
var tempSourceMatrix = [0, 0, 0, 0, 0, 0, 0, 0, 0];
var tempDestinationMatrix = [0, 0, 0, 0, 0, 0, 0, 0, 0];
function compute2DProjection(out, x1s, y1s, x1d, y1d, x2s, y2s, x2d, y2d, x3s, y3s, x3d, y3d, x4s, y4s, x4d, y4d) {
  const sourceMatrix = generateBasisToPointsMatrix(
    tempSourceMatrix,
    x1s,
    y1s,
    x2s,
    y2s,
    x3s,
    y3s,
    x4s,
    y4s
  );
  const destinationMatrix = generateBasisToPointsMatrix(
    tempDestinationMatrix,
    x1d,
    y1d,
    x2d,
    y2d,
    x3d,
    y3d,
    x4d,
    y4d
  );
  return multiplyMatrix3x3(
    out,
    computeAdjugate(sourceMatrix, sourceMatrix),
    destinationMatrix
  );
}

// node_modules/pixi.js/lib/scene/mesh-perspective/PerspectivePlaneGeometry.mjs
var PerspectivePlaneGeometry = class extends PlaneGeometry {
  /**
   * @param options - Options to be applied to MeshPlane
   * @param options.width - The width of the plane
   * @param options.height - The height of the plane
   * @param options.verticesX - The amount of vertices on the x axis
   * @param options.verticesY - The amount of vertices on the y axis
   */
  constructor(options) {
    super(options);
    this._projectionMatrix = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    const { width, height } = options;
    this.corners = [0, 0, width, 0, width, height, 0, height];
  }
  /**
   * Will set the corners of the quad to the given coordinates
   * Calculating the perspective so it looks correct!
   * @param x0 - x coordinate of the first corner
   * @param y0 - y coordinate of the first corner
   * @param x1 - x coordinate of the second corner
   * @param y1 - y coordinate of the second corner
   * @param x2 - x coordinate of the third corner
   * @param y2 - y coordinate of the third corner
   * @param x3 - x coordinate of the fourth corner
   * @param y3 - y coordinate of the fourth corner
   */
  setCorners(x0, y0, x1, y1, x2, y2, x3, y3) {
    const corners = this.corners;
    corners[0] = x0;
    corners[1] = y0;
    corners[2] = x1;
    corners[3] = y1;
    corners[4] = x2;
    corners[5] = y2;
    corners[6] = x3;
    corners[7] = y3;
    this.updateProjection();
  }
  /** Update the projection matrix based on the corners */
  updateProjection() {
    const { width, height } = this;
    const corners = this.corners;
    const projectionMatrix = compute2DProjection(
      this._projectionMatrix,
      0,
      0,
      // top-left source
      corners[0],
      corners[1],
      // top-left dest
      width,
      0,
      // top-right source
      corners[2],
      corners[3],
      // top-right dest
      width,
      height,
      // bottom-right source
      corners[4],
      corners[5],
      // bottom-right dest
      0,
      height,
      // bottom-left source
      corners[6],
      corners[7]
      // bottom-left dest
    );
    applyProjectiveTransformationToPlane(
      width,
      height,
      this,
      projectionMatrix
    );
  }
};

// node_modules/pixi.js/lib/scene/mesh-perspective/PerspectiveMesh.mjs
var _PerspectiveMesh = class _PerspectiveMesh2 extends Mesh {
  /**
   * @param options - Options to be applied to PerspectiveMesh
   */
  constructor(options) {
    options = __spreadValues(__spreadValues({}, _PerspectiveMesh2.defaultOptions), options);
    const _a = options, { texture, verticesX, verticesY } = _a, rest = __objRest(_a, ["texture", "verticesX", "verticesY"]);
    const planeGeometry = new PerspectivePlaneGeometry(definedProps({
      width: texture.width,
      height: texture.height,
      verticesX,
      verticesY
    }));
    super(definedProps(__spreadProps(__spreadValues({}, rest), { geometry: planeGeometry })));
    this._texture = texture;
    this.geometry.setCorners(
      options.x0,
      options.y0,
      options.x1,
      options.y1,
      options.x2,
      options.y2,
      options.x3,
      options.y3
    );
  }
  /** Update the geometry when the texture is updated */
  textureUpdated() {
    const geometry = this.geometry;
    if (!geometry) return;
    const { width, height } = this.texture;
    if (geometry.width !== width || geometry.height !== height) {
      geometry.width = width;
      geometry.height = height;
      geometry.updateProjection();
    }
  }
  set texture(value) {
    if (this._texture === value) return;
    super.texture = value;
    this.textureUpdated();
  }
  /**
   * The texture that the mesh uses for rendering. When changed, automatically updates
   * the geometry to match the new texture dimensions.
   * @example
   * ```ts
   * const mesh = new PerspectiveMesh({
   *     texture: Texture.from('initial.png'),
   * });
   *
   * // Update texture and maintain perspective
   * mesh.texture = Texture.from('newImage.png');
   * ```
   * @see {@link Texture} For texture creation and management
   * @see {@link PerspectiveMesh#setCorners} For adjusting the mesh perspective
   */
  get texture() {
    return this._texture;
  }
  /**
   * Sets the corners of the mesh to create a perspective transformation. The corners should be
   * specified in clockwise order starting from the top-left.
   *
   * The mesh automatically recalculates the UV coordinates to create the perspective effect.
   * @example
   * ```ts
   * const mesh = new PerspectiveMesh({
   *     texture: Texture.from('myImage.png'),
   * });
   *
   * // Create a basic perspective tilt
   * mesh.setCorners(
   *     0, 0,      // Top-left
   *     100, 20,   // Top-right (raised)
   *     100, 100,  // Bottom-right
   *     0, 80      // Bottom-left
   * );
   *
   * // Create a skewed billboard effect
   * mesh.setCorners(
   *     0, 30,     // Top-left (shifted down)
   *     128, 0,    // Top-right (raised)
   *     128, 128,  // Bottom-right
   *     0, 98      // Bottom-left (shifted up)
   * );
   *
   * // Animate perspective
   * app.ticker.add((delta) => {
   *     const time = performance.now() / 1000;
   *     const wave = Math.sin(time) * 20;
   *
   *     mesh.setCorners(
   *         0, wave,      // Top-left
   *         100, -wave,   // Top-right
   *         100, 100,     // Bottom-right
   *         0, 100        // Bottom-left
   *     );
   * });
   * ```
   * @param x0 - x-coordinate of the top-left corner
   * @param y0 - y-coordinate of the top-left corner
   * @param x1 - x-coordinate of the top-right corner
   * @param y1 - y-coordinate of the top-right corner
   * @param x2 - x-coordinate of the bottom-right corner
   * @param y2 - y-coordinate of the bottom-right corner
   * @param x3 - x-coordinate of the bottom-left corner
   * @param y3 - y-coordinate of the bottom-left corner
   * @returns The PerspectiveMesh instance for method chaining
   * @see {@link PerspectivePlaneGeometry} For the underlying geometry calculations
   */
  setCorners(x0, y0, x1, y1, x2, y2, x3, y3) {
    this.geometry.setCorners(x0, y0, x1, y1, x2, y2, x3, y3);
  }
};
_PerspectiveMesh.defaultOptions = {
  texture: Texture.WHITE,
  verticesX: 10,
  verticesY: 10,
  x0: 0,
  y0: 0,
  x1: 100,
  y1: 0,
  x2: 100,
  y2: 100,
  x3: 0,
  y3: 100
};
var PerspectiveMesh = _PerspectiveMesh;

// node_modules/pixi.js/lib/scene/mesh-plane/MeshPlane.mjs
var MeshPlane = class extends Mesh {
  /**
   * @param options - Options to be applied to MeshPlane
   */
  constructor(options) {
    const _a = options, { texture, verticesX, verticesY } = _a, rest = __objRest(_a, ["texture", "verticesX", "verticesY"]);
    const planeGeometry = new PlaneGeometry(definedProps({
      width: texture.width,
      height: texture.height,
      verticesX,
      verticesY
    }));
    super(definedProps(__spreadProps(__spreadValues({}, rest), { geometry: planeGeometry, texture })));
    this.texture = texture;
    this.autoResize = true;
  }
  /**
   * Method used for overrides, to do something in case texture frame was changed.
   * Meshes based on plane can override it and change more details based on texture.
   * @internal
   */
  textureUpdated() {
    const geometry = this.geometry;
    const { width, height } = this.texture;
    if (this.autoResize && (geometry.width !== width || geometry.height !== height)) {
      geometry.width = width;
      geometry.height = height;
      geometry.build({});
    }
  }
  set texture(value) {
    this._texture?.off("update", this.textureUpdated, this);
    super.texture = value;
    value.on("update", this.textureUpdated, this);
    this.textureUpdated();
  }
  /**
   * The texture that the mesh plane uses for rendering. When changed, automatically updates
   * geometry dimensions if autoResize is true and manages texture update event listeners.
   * @example
   * ```ts
   * const plane = new MeshPlane({
   *     texture: Assets.get('initial.png'),
   *     verticesX: 10,
   *     verticesY: 10
   * });
   *
   * // Update texture and auto-resize geometry
   * plane.texture = Assets.get('larger.png');
   * ```
   * @see {@link MeshPlane#autoResize} For controlling automatic geometry updates
   * @see {@link PlaneGeometry} For manual geometry updates
   * @see {@link Texture} For texture creation and management
   */
  get texture() {
    return this._texture;
  }
  /**
   * Destroys this sprite renderable and optionally its texture.
   * @param options - Options parameter. A boolean will act as if all options
   *  have been set to that value
   * @example
   * meshPlane.destroy();
   * meshPlane.destroy(true);
   * meshPlane.destroy({ texture: true, textureSource: true });
   */
  destroy(options) {
    this.texture.off("update", this.textureUpdated, this);
    super.destroy(options);
  }
};

// node_modules/pixi.js/lib/scene/mesh-simple/RopeGeometry.mjs
var _RopeGeometry = class _RopeGeometry2 extends MeshGeometry {
  /**
   * @param options - Options to be applied to rope geometry
   */
  constructor(options) {
    const { width, points, textureScale } = __spreadValues(__spreadValues({}, _RopeGeometry2.defaultOptions), options);
    super({
      positions: new Float32Array(points.length * 4),
      uvs: new Float32Array(points.length * 4),
      indices: new Uint32Array((points.length - 1) * 6)
    });
    this.points = points;
    this._width = width;
    this.textureScale = textureScale;
    this._build();
  }
  /**
   * The width (i.e., thickness) of the rope.
   * @readonly
   */
  get width() {
    return this._width;
  }
  /** Refreshes Rope indices and uvs */
  _build() {
    const points = this.points;
    if (!points) return;
    const vertexBuffer = this.getBuffer("aPosition");
    const uvBuffer = this.getBuffer("aUV");
    const indexBuffer = this.getIndex();
    if (points.length < 1) {
      return;
    }
    if (vertexBuffer.data.length / 4 !== points.length) {
      vertexBuffer.data = new Float32Array(points.length * 4);
      uvBuffer.data = new Float32Array(points.length * 4);
      indexBuffer.data = new Uint16Array((points.length - 1) * 6);
    }
    const uvs = uvBuffer.data;
    const indices = indexBuffer.data;
    uvs[0] = 0;
    uvs[1] = 0;
    uvs[2] = 0;
    uvs[3] = 1;
    let amount = 0;
    let prev = points[0];
    const textureWidth = this._width * this.textureScale;
    const total = points.length;
    for (let i = 0; i < total; i++) {
      const index = i * 4;
      if (this.textureScale > 0) {
        const dx = prev.x - points[i].x;
        const dy = prev.y - points[i].y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        prev = points[i];
        amount += distance / textureWidth;
      } else {
        amount = i / (total - 1);
      }
      uvs[index] = amount;
      uvs[index + 1] = 0;
      uvs[index + 2] = amount;
      uvs[index + 3] = 1;
    }
    let indexCount = 0;
    for (let i = 0; i < total - 1; i++) {
      const index = i * 2;
      indices[indexCount++] = index;
      indices[indexCount++] = index + 1;
      indices[indexCount++] = index + 2;
      indices[indexCount++] = index + 2;
      indices[indexCount++] = index + 1;
      indices[indexCount++] = index + 3;
    }
    uvBuffer.update();
    indexBuffer.update();
    this.updateVertices();
  }
  /** refreshes vertices of Rope mesh */
  updateVertices() {
    const points = this.points;
    if (points.length < 1) {
      return;
    }
    let lastPoint = points[0];
    let nextPoint;
    let perpX = 0;
    let perpY = 0;
    const vertices = this.buffers[0].data;
    const total = points.length;
    const halfWidth = this.textureScale > 0 ? this.textureScale * this._width / 2 : this._width / 2;
    for (let i = 0; i < total; i++) {
      const point = points[i];
      const index = i * 4;
      if (i < points.length - 1) {
        nextPoint = points[i + 1];
      } else {
        nextPoint = point;
      }
      perpY = -(nextPoint.x - lastPoint.x);
      perpX = nextPoint.y - lastPoint.y;
      let ratio = (1 - i / (total - 1)) * 10;
      if (ratio > 1) {
        ratio = 1;
      }
      const perpLength = Math.sqrt(perpX * perpX + perpY * perpY);
      if (perpLength < 1e-6) {
        perpX = 0;
        perpY = 0;
      } else {
        perpX /= perpLength;
        perpY /= perpLength;
        perpX *= halfWidth;
        perpY *= halfWidth;
      }
      vertices[index] = point.x + perpX;
      vertices[index + 1] = point.y + perpY;
      vertices[index + 2] = point.x - perpX;
      vertices[index + 3] = point.y - perpY;
      lastPoint = point;
    }
    this.buffers[0].update();
  }
  /** Refreshes Rope indices and uvs */
  update() {
    if (this.textureScale > 0) {
      this._build();
    } else {
      this.updateVertices();
    }
  }
};
_RopeGeometry.defaultOptions = {
  /** The width (i.e., thickness) of the rope. */
  width: 200,
  /** An array of points that determine the rope. */
  points: [],
  /** Rope texture scale, if zero then the rope texture is stretched. */
  textureScale: 0
};
var RopeGeometry = _RopeGeometry;

// node_modules/pixi.js/lib/scene/mesh-simple/MeshRope.mjs
var _MeshRope = class _MeshRope2 extends Mesh {
  /**
   * Note: The wrap mode of the texture is set to REPEAT if `textureScale` is positive.
   * @param options
   * @param options.texture - The texture to use on the rope.
   * @param options.points - An array of {@link math.Point} objects to construct this rope.
   * @param {number} options.textureScale - Optional. Positive values scale rope texture
   * keeping its aspect ratio. You can reduce alpha channel artifacts by providing a larger texture
   * and downsampling here. If set to zero, texture will be stretched instead.
   */
  constructor(options) {
    const _a = __spreadValues(__spreadValues({}, _MeshRope2.defaultOptions), options), { width, texture, points, textureScale } = _a, rest = __objRest(_a, ["width", "texture", "points", "textureScale"]);
    const ropeGeometry = new RopeGeometry(definedProps({ width: width ?? texture.height, points, textureScale }));
    if (textureScale > 0) {
      texture.source.style.addressMode = "repeat";
    }
    super(definedProps(__spreadProps(__spreadValues({}, rest), {
      texture,
      geometry: ropeGeometry
    })));
    this.autoUpdate = true;
    this.onRender = this._render;
  }
  _render() {
    const geometry = this.geometry;
    if (this.autoUpdate || geometry._width !== this.texture.height) {
      geometry._width = this.texture.height;
      geometry.update();
    }
  }
};
_MeshRope.defaultOptions = {
  textureScale: 0
};
var MeshRope = _MeshRope;

// node_modules/pixi.js/lib/scene/mesh-simple/MeshSimple.mjs
var MeshSimple = class extends Mesh {
  /**
   * @param options - Options to be used for construction
   */
  constructor(options) {
    const _a = options, { texture, vertices, uvs, indices, topology } = _a, rest = __objRest(_a, ["texture", "vertices", "uvs", "indices", "topology"]);
    const geometry = new MeshGeometry(definedProps({
      positions: vertices,
      uvs,
      indices,
      topology
    }));
    super(definedProps(__spreadProps(__spreadValues({}, rest), {
      texture,
      geometry
    })));
    this.autoUpdate = true;
    this.onRender = this._render;
  }
  /**
   * The vertex positions of the mesh as a TypedArray. Each vertex is represented by two
   * consecutive values (x, y) in the array. Changes to these values will update the mesh's shape.
   * @example
   * ```ts
   * // Read vertex positions
   * const vertices = mesh.vertices;
   * console.log('First vertex:', vertices[0], vertices[1]);
   *
   * // Modify vertices directly
   * vertices[0] += 10;  // Move first vertex right
   * vertices[1] -= 20;  // Move first vertex up
   *
   * // Animate vertices
   * app.ticker.add(() => {
   *     const time = performance.now() / 1000;
   *     const vertices = mesh.vertices;
   *
   *     // Wave motion
   *     for (let i = 0; i < vertices.length; i += 2) {
   *         vertices[i + 1] = Math.sin(time + i * 0.5) * 20;
   *     }
   * });
   * ```
   * @see {@link MeshSimple#autoUpdate} For controlling vertex buffer updates
   * @see {@link MeshGeometry#getBuffer} For direct buffer access
   */
  get vertices() {
    return this.geometry.getBuffer("aPosition").data;
  }
  set vertices(value) {
    this.geometry.getBuffer("aPosition").data = value;
  }
  _render() {
    if (this.autoUpdate) {
      this.geometry.getBuffer("aPosition").update();
    }
  }
};

// node_modules/pixi.js/lib/scene/mesh/shared/getTextureDefaultMatrix.mjs
function getTextureDefaultMatrix(texture, out) {
  const { width, height } = texture.frame;
  out.scale(1 / width, 1 / height);
  return out;
}

// node_modules/pixi.js/lib/scene/particle-container/canvas/CanvasParticleContainerAdaptor.mjs
var CanvasParticleContainerAdaptor = class {
  execute(particleContainerPipe, container) {
    const renderer = particleContainerPipe.renderer;
    const context = renderer.canvasContext.activeContext;
    const children = container.particleChildren;
    const texture = container.texture;
    context.save();
    renderer.canvasContext.setContextTransform(container.worldTransform, container.roundPixels);
    renderer.canvasContext.setBlendMode(container.groupBlendMode);
    const groupColorAlpha = container.groupColorAlpha;
    const filterAlpha = renderer.filter?.alphaMultiplier ?? 1;
    const groupAlpha = (groupColorAlpha >>> 24 & 255) / 255 * filterAlpha;
    for (let i = 0; i < children.length; i++) {
      const particle = children[i];
      const pTexture = particle.texture || texture;
      if (!pTexture?.source?.resource) continue;
      const color = particle.color;
      const alpha = (color >>> 24 & 255) / 255 * groupAlpha;
      if (alpha <= 0) continue;
      const bgr = color & 16777215;
      const tint = ((bgr & 255) << 16) + (bgr & 65280) + (bgr >> 16 & 255);
      let drawSource = pTexture.source.resource;
      if (tint !== 16777215) {
        drawSource = canvasUtils.getTintedCanvas({ texture: pTexture }, tint);
      }
      const frame = pTexture.frame;
      const resolution = pTexture.source.resolution;
      const sx = frame.x * resolution;
      const sy = frame.y * resolution;
      const sw = frame.width * resolution;
      const sh = frame.height * resolution;
      context.globalAlpha = alpha;
      const dx = -particle.anchorX * frame.width;
      const dy = -particle.anchorY * frame.height;
      if (particle.rotation !== 0 || particle.scaleX !== 1 || particle.scaleY !== 1) {
        context.save();
        context.translate(particle.x, particle.y);
        context.rotate(particle.rotation);
        context.scale(particle.scaleX, particle.scaleY);
        context.drawImage(drawSource, sx, sy, sw, sh, dx, dy, frame.width, frame.height);
        context.restore();
      } else {
        context.drawImage(drawSource, sx, sy, sw, sh, particle.x + dx, particle.y + dy, frame.width, frame.height);
      }
    }
    context.restore();
  }
};

// node_modules/pixi.js/lib/scene/particle-container/shared/utils/createIndicesForQuads.mjs
function createIndicesForQuads(size, outBuffer = null) {
  const totalIndices = size * 6;
  if (totalIndices > 65535) {
    outBuffer || (outBuffer = new Uint32Array(totalIndices));
  } else {
    outBuffer || (outBuffer = new Uint16Array(totalIndices));
  }
  if (outBuffer.length !== totalIndices) {
    throw new Error(`Out buffer length is incorrect, got ${outBuffer.length} and expected ${totalIndices}`);
  }
  for (let i = 0, j = 0; i < totalIndices; i += 6, j += 4) {
    outBuffer[i + 0] = j + 0;
    outBuffer[i + 1] = j + 1;
    outBuffer[i + 2] = j + 2;
    outBuffer[i + 3] = j + 0;
    outBuffer[i + 4] = j + 2;
    outBuffer[i + 5] = j + 3;
  }
  return outBuffer;
}

// node_modules/pixi.js/lib/scene/particle-container/shared/utils/generateParticleUpdateFunction.mjs
function generateParticleUpdateFunction(properties) {
  return {
    dynamicUpdate: generateUpdateFunction(properties, true),
    staticUpdate: generateUpdateFunction(properties, false)
  };
}
function generateUpdateFunction(properties, dynamic) {
  const funcFragments = [];
  funcFragments.push(`

        var index = 0;

        for (let i = 0; i < ps.length; ++i)
        {
            const p = ps[i];

            `);
  let offset = 0;
  for (const i in properties) {
    const property = properties[i];
    if (dynamic !== property.dynamic) continue;
    funcFragments.push(`offset = index + ${offset}`);
    funcFragments.push(property.code);
    const attributeInfo = getAttributeInfoFromFormat(property.format);
    offset += attributeInfo.stride / 4;
  }
  funcFragments.push(`
            index += stride * 4;
        }
    `);
  funcFragments.unshift(`
        var stride = ${offset};
    `);
  const functionSource = funcFragments.join("\n");
  return new Function("ps", "f32v", "u32v", functionSource);
}

// node_modules/pixi.js/lib/scene/particle-container/shared/ParticleBuffer.mjs
var ParticleBuffer = class {
  constructor(options) {
    this._size = 0;
    this._generateParticleUpdateCache = {};
    const size = this._size = options.size ?? 1e3;
    const properties = options.properties;
    let staticVertexSize = 0;
    let dynamicVertexSize = 0;
    for (const i in properties) {
      const property = properties[i];
      const attributeInfo = getAttributeInfoFromFormat(property.format);
      if (property.dynamic) {
        dynamicVertexSize += attributeInfo.stride;
      } else {
        staticVertexSize += attributeInfo.stride;
      }
    }
    this._dynamicStride = dynamicVertexSize / 4;
    this._staticStride = staticVertexSize / 4;
    this.staticAttributeBuffer = new ViewableBuffer(size * 4 * staticVertexSize);
    this.dynamicAttributeBuffer = new ViewableBuffer(size * 4 * dynamicVertexSize);
    this.indexBuffer = createIndicesForQuads(size);
    const geometry = new Geometry();
    let dynamicOffset = 0;
    let staticOffset = 0;
    this._staticBuffer = new Buffer({
      data: new Float32Array(1),
      label: "static-particle-buffer",
      shrinkToFit: false,
      usage: BufferUsage.VERTEX | BufferUsage.COPY_DST
    });
    this._dynamicBuffer = new Buffer({
      data: new Float32Array(1),
      label: "dynamic-particle-buffer",
      shrinkToFit: false,
      usage: BufferUsage.VERTEX | BufferUsage.COPY_DST
    });
    for (const i in properties) {
      const property = properties[i];
      const attributeInfo = getAttributeInfoFromFormat(property.format);
      if (property.dynamic) {
        geometry.addAttribute(property.attributeName, {
          buffer: this._dynamicBuffer,
          stride: this._dynamicStride * 4,
          offset: dynamicOffset * 4,
          format: property.format
        });
        dynamicOffset += attributeInfo.size;
      } else {
        geometry.addAttribute(property.attributeName, {
          buffer: this._staticBuffer,
          stride: this._staticStride * 4,
          offset: staticOffset * 4,
          format: property.format
        });
        staticOffset += attributeInfo.size;
      }
    }
    geometry.addIndex(this.indexBuffer);
    const uploadFunction = this.getParticleUpdate(properties);
    this._dynamicUpload = uploadFunction.dynamicUpdate;
    this._staticUpload = uploadFunction.staticUpdate;
    this.geometry = geometry;
  }
  getParticleUpdate(properties) {
    const key = getParticleSyncKey(properties);
    if (this._generateParticleUpdateCache[key]) {
      return this._generateParticleUpdateCache[key];
    }
    this._generateParticleUpdateCache[key] = this.generateParticleUpdate(properties);
    return this._generateParticleUpdateCache[key];
  }
  generateParticleUpdate(properties) {
    return generateParticleUpdateFunction(properties);
  }
  update(particles, uploadStatic) {
    if (particles.length > this._size) {
      uploadStatic = true;
      this._size = Math.max(particles.length, this._size * 1.5 | 0);
      this.staticAttributeBuffer = new ViewableBuffer(this._size * this._staticStride * 4 * 4);
      this.dynamicAttributeBuffer = new ViewableBuffer(this._size * this._dynamicStride * 4 * 4);
      this.indexBuffer = createIndicesForQuads(this._size);
      this.geometry.indexBuffer.setDataWithSize(
        this.indexBuffer,
        this.indexBuffer.byteLength,
        true
      );
    }
    const dynamicAttributeBuffer = this.dynamicAttributeBuffer;
    this._dynamicUpload(particles, dynamicAttributeBuffer.float32View, dynamicAttributeBuffer.uint32View);
    this._dynamicBuffer.setDataWithSize(
      this.dynamicAttributeBuffer.float32View,
      particles.length * this._dynamicStride * 4,
      true
    );
    if (uploadStatic) {
      const staticAttributeBuffer = this.staticAttributeBuffer;
      this._staticUpload(particles, staticAttributeBuffer.float32View, staticAttributeBuffer.uint32View);
      this._staticBuffer.setDataWithSize(
        staticAttributeBuffer.float32View,
        particles.length * this._staticStride * 4,
        true
      );
    }
  }
  destroy() {
    this._staticBuffer.destroy();
    this._dynamicBuffer.destroy();
    this.geometry.destroy();
  }
};
function getParticleSyncKey(properties) {
  const keyGen = [];
  for (const key in properties) {
    const property = properties[key];
    keyGen.push(key, property.code, property.dynamic ? "d" : "s");
  }
  return keyGen.join("_");
}

// node_modules/pixi.js/lib/scene/particle-container/shared/shader/particles.frag.mjs
var fragment7 = "varying vec2 vUV;\nvarying vec4 vColor;\n\nuniform sampler2D uTexture;\n\nvoid main(void){\n    vec4 color = texture2D(uTexture, vUV) * vColor;\n    gl_FragColor = color;\n}";

// node_modules/pixi.js/lib/scene/particle-container/shared/shader/particles.vert.mjs
var vertex4 = "attribute vec2 aVertex;\nattribute vec2 aUV;\nattribute vec4 aColor;\n\nattribute vec2 aPosition;\nattribute float aRotation;\n\nuniform mat3 uTranslationMatrix;\nuniform float uRound;\nuniform vec2 uResolution;\nuniform vec4 uColor;\n\nvarying vec2 vUV;\nvarying vec4 vColor;\n\nvec2 roundPixels(vec2 position, vec2 targetSize)\n{       \n    return (floor(((position * 0.5 + 0.5) * targetSize) + 0.5) / targetSize) * 2.0 - 1.0;\n}\n\nvoid main(void){\n    float cosRotation = cos(aRotation);\n    float sinRotation = sin(aRotation);\n    float x = aVertex.x * cosRotation - aVertex.y * sinRotation;\n    float y = aVertex.x * sinRotation + aVertex.y * cosRotation;\n\n    vec2 v = vec2(x, y);\n    v = v + aPosition;\n\n    gl_Position = vec4((uTranslationMatrix * vec3(v, 1.0)).xy, 0.0, 1.0);\n\n    if(uRound == 1.0)\n    {\n        gl_Position.xy = roundPixels(gl_Position.xy, uResolution);\n    }\n\n    vUV = aUV;\n    vColor = vec4(aColor.rgb * aColor.a, aColor.a) * uColor;\n}\n";

// node_modules/pixi.js/lib/scene/particle-container/shared/shader/particles.wgsl.mjs
var wgsl = "\nstruct ParticleUniforms {\n  uTranslationMatrix:mat3x3<f32>,\n  uColor:vec4<f32>,\n  uRound:f32,\n  uResolution:vec2<f32>,\n};\n\nfn roundPixels(position: vec2<f32>, targetSize: vec2<f32>) -> vec2<f32>\n{\n  return (floor(((position * 0.5 + 0.5) * targetSize) + 0.5) / targetSize) * 2.0 - 1.0;\n}\n\n@group(0) @binding(0) var<uniform> uniforms: ParticleUniforms;\n\n@group(1) @binding(0) var uTexture: texture_2d<f32>;\n@group(1) @binding(1) var uSampler : sampler;\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>,\n    @location(1) color : vec4<f32>,\n  };\n@vertex\nfn mainVertex(\n  @location(0) aVertex: vec2<f32>,\n  @location(1) aPosition: vec2<f32>,\n  @location(2) aUV: vec2<f32>,\n  @location(3) aColor: vec4<f32>,\n  @location(4) aRotation: f32,\n) -> VSOutput {\n  \n   let v = vec2(\n       aVertex.x * cos(aRotation) - aVertex.y * sin(aRotation),\n       aVertex.x * sin(aRotation) + aVertex.y * cos(aRotation)\n   ) + aPosition;\n\n   var position = vec4((uniforms.uTranslationMatrix * vec3(v, 1.0)).xy, 0.0, 1.0);\n\n   if(uniforms.uRound == 1.0) {\n       position = vec4(roundPixels(position.xy, uniforms.uResolution), position.zw);\n   }\n\n    let vColor = vec4(aColor.rgb * aColor.a, aColor.a) * uniforms.uColor;\n\n  return VSOutput(\n   position,\n   aUV,\n   vColor,\n  );\n}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n  @location(1) color: vec4<f32>,\n  @builtin(position) position: vec4<f32>,\n) -> @location(0) vec4<f32> {\n\n    var sample = textureSample(uTexture, uSampler, uv) * color;\n   \n    return sample;\n}";

// node_modules/pixi.js/lib/scene/particle-container/shared/shader/ParticleShader.mjs
var ParticleShader = class extends Shader {
  constructor() {
    const glProgram3 = GlProgram.from({
      vertex: vertex4,
      fragment: fragment7
    });
    const gpuProgram3 = GpuProgram.from({
      fragment: {
        source: wgsl,
        entryPoint: "mainFragment"
      },
      vertex: {
        source: wgsl,
        entryPoint: "mainVertex"
      }
    });
    super({
      glProgram: glProgram3,
      gpuProgram: gpuProgram3,
      resources: {
        // this will be replaced with the texture from the particle container
        uTexture: Texture.WHITE.source,
        // this will be replaced with the texture style from the particle container
        uSampler: new TextureStyle({}),
        // this will be replaced with the local uniforms from the particle container
        uniforms: {
          uTranslationMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
          uColor: { value: new Color(16777215), type: "vec4<f32>" },
          uRound: { value: 1, type: "f32" },
          uResolution: { value: [0, 0], type: "vec2<f32>" }
        }
      }
    });
  }
};

// node_modules/pixi.js/lib/scene/particle-container/shared/ParticleContainerPipe.mjs
var ParticleContainerPipe = class {
  /**
   * @param renderer - The renderer this sprite batch works for.
   * @param adaptor
   */
  constructor(renderer, adaptor) {
    this.state = State.for2d();
    this.localUniforms = new UniformGroup({
      uTranslationMatrix: { value: new Matrix(), type: "mat3x3<f32>" },
      uColor: { value: new Float32Array(4), type: "vec4<f32>" },
      uRound: { value: 1, type: "f32" },
      uResolution: { value: [0, 0], type: "vec2<f32>" }
    });
    this.renderer = renderer;
    this.adaptor = adaptor;
    this.defaultShader = new ParticleShader();
    this.state = State.for2d();
    this._managedContainers = new GCManagedHash({ renderer, type: "renderable", name: "particleContainer" });
  }
  validateRenderable(_renderable) {
    return false;
  }
  addRenderable(renderable, instructionSet) {
    this.renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add(renderable);
  }
  getBuffers(renderable) {
    return renderable._gpuData[this.renderer.uid] || this._initBuffer(renderable);
  }
  _initBuffer(renderable) {
    renderable._gpuData[this.renderer.uid] = new ParticleBuffer({
      size: renderable.particleChildren.length,
      properties: renderable._properties
    });
    this._managedContainers.add(renderable);
    return renderable._gpuData[this.renderer.uid];
  }
  updateRenderable(_renderable) {
  }
  execute(container) {
    const children = container.particleChildren;
    if (children.length === 0) {
      return;
    }
    const renderer = this.renderer;
    const buffer = this.getBuffers(container);
    container.texture || (container.texture = children[0].texture);
    const state = this.state;
    buffer.update(children, container._childrenDirty);
    container._childrenDirty = false;
    state.blendMode = getAdjustedBlendModeBlend(container.groupBlendMode, container.texture._source);
    const uniforms = this.localUniforms.uniforms;
    const transformationMatrix = uniforms.uTranslationMatrix;
    container.worldTransform.copyTo(transformationMatrix);
    const globalUniformData = renderer.globalUniforms.globalUniformData;
    transformationMatrix.tx -= globalUniformData.offset.x;
    transformationMatrix.ty -= globalUniformData.offset.y;
    transformationMatrix.prepend(globalUniformData.projectionMatrix);
    uniforms.uResolution = globalUniformData.resolution;
    uniforms.uRound = renderer._roundPixels | container._roundPixels;
    const groupColorAlpha = container.groupColorAlpha;
    const worldColorAlpha = globalUniformData.worldColor;
    const alpha = (groupColorAlpha >>> 24) * (worldColorAlpha >>> 24) / 255 | 0;
    const bgr = multiplyHexColors(groupColorAlpha & 16777215, worldColorAlpha & 16777215);
    color32BitToUniform(
      (alpha << 24 | bgr) >>> 0,
      uniforms.uColor,
      0
    );
    this.adaptor.execute(this, container);
  }
  /** Destroys the ParticleRenderer. */
  destroy() {
    this._managedContainers.destroy();
    this.renderer = null;
    if (this.defaultShader) {
      this.defaultShader.destroy();
      this.defaultShader = null;
    }
  }
};
ParticleContainerPipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "particle"
};

// node_modules/pixi.js/lib/scene/particle-container/canvas/CanvasParticleContainerPipe.mjs
var CanvasParticleContainerPipe = class extends ParticleContainerPipe {
  constructor(renderer) {
    super(renderer, new CanvasParticleContainerAdaptor());
  }
};
CanvasParticleContainerPipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "particle"
};

// node_modules/pixi.js/lib/scene/particle-container/gl/GlParticleContainerAdaptor.mjs
var GlParticleContainerAdaptor = class {
  execute(particleContainerPipe, container) {
    const state = particleContainerPipe.state;
    const renderer = particleContainerPipe.renderer;
    const shader = container.shader || particleContainerPipe.defaultShader;
    shader.resources.uTexture = container.texture._source;
    shader.resources.uniforms = particleContainerPipe.localUniforms;
    const gl = renderer.gl;
    const buffer = particleContainerPipe.getBuffers(container);
    renderer.shader.bind(shader);
    renderer.state.set(state);
    renderer.geometry.bind(buffer.geometry, shader.glProgram);
    const byteSize = buffer.geometry.indexBuffer.data.BYTES_PER_ELEMENT;
    const glType = byteSize === 2 ? gl.UNSIGNED_SHORT : gl.UNSIGNED_INT;
    gl.drawElements(gl.TRIANGLES, container.particleChildren.length * 6, glType, 0);
  }
};

// node_modules/pixi.js/lib/scene/particle-container/gl/GlParticleContainerPipe.mjs
var GlParticleContainerPipe = class extends ParticleContainerPipe {
  constructor(renderer) {
    super(renderer, new GlParticleContainerAdaptor());
  }
};
GlParticleContainerPipe.extension = {
  type: [
    ExtensionType.WebGLPipes
  ],
  name: "particle"
};

// node_modules/pixi.js/lib/scene/particle-container/gpu/GpuParticleContainerAdaptor.mjs
var GpuParticleContainerAdaptor = class {
  execute(particleContainerPipe, container) {
    const renderer = particleContainerPipe.renderer;
    const shader = container.shader || particleContainerPipe.defaultShader;
    shader.groups[0] = renderer.renderPipes.uniformBatch.getUniformBindGroup(particleContainerPipe.localUniforms, true);
    shader.groups[1] = renderer.texture.getTextureBindGroup(container.texture);
    const state = particleContainerPipe.state;
    const buffer = particleContainerPipe.getBuffers(container);
    renderer.encoder.draw({
      geometry: buffer.geometry,
      shader: container.shader || particleContainerPipe.defaultShader,
      state,
      size: container.particleChildren.length * 6
    });
  }
};

// node_modules/pixi.js/lib/scene/particle-container/gpu/GpuParticleContainerPipe.mjs
var GpuParticleContainerPipe = class extends ParticleContainerPipe {
  constructor(renderer) {
    super(renderer, new GpuParticleContainerAdaptor());
  }
};
GpuParticleContainerPipe.extension = {
  type: [
    ExtensionType.WebGPUPipes
  ],
  name: "particle"
};

// node_modules/pixi.js/lib/scene/particle-container/shared/Particle.mjs
var _Particle = class _Particle2 {
  constructor(options) {
    if (options instanceof Texture) {
      this.texture = options;
      assignWithIgnore(this, _Particle2.defaultOptions, {});
    } else {
      const combined = __spreadValues(__spreadValues({}, _Particle2.defaultOptions), options);
      assignWithIgnore(this, combined, {});
    }
  }
  /**
   * The transparency of the particle. Values range from 0 (fully transparent)
   * to 1 (fully opaque). Values outside this range are clamped.
   * @example
   * ```ts
   * // Create a semi-transparent particle
   * const particle = new Particle({
   *     texture: Texture.from('particle.png'),
   *     alpha: 0.5
   * });
   *
   * // Fade out
   * particle.alpha *= 0.9;
   *
   * // Fade in
   * particle.alpha = Math.min(particle.alpha + 0.1, 1);
   *
   * // Values are clamped to valid range
   * particle.alpha = 1.5; // Becomes 1.0
   * particle.alpha = -0.5; // Becomes 0.0
   *
   * // Animate transparency
   * app.ticker.add((delta) => {
   *     const time = performance.now() / 1000;
   *     particle.alpha = 0.5 + Math.sin(time) * 0.5; // Pulse between 0-1
   * });
   * ```
   * @default 1
   * @see {@link Particle#tint} For controlling particle color
   * @see {@link Particle#color} For the combined color and alpha value
   */
  get alpha() {
    return this._alpha;
  }
  set alpha(value) {
    this._alpha = Math.min(Math.max(value, 0), 1);
    this._updateColor();
  }
  /**
   * The tint color of the particle. Can be set using hex numbers or CSS color strings.
   * The tint is multiplied with the texture color to create the final particle color.
   * @example
   * ```ts
   * // Create a red particle
   * const particle = new Particle({
   *     texture: Texture.from('particle.png'),
   *     tint: 0xff0000
   * });
   *
   * // Use CSS color strings
   * particle.tint = '#00ff00';  // Green
   * particle.tint = 'blue';     // Blue
   *
   * // Animate tint color
   * app.ticker.add(() => {
   *     const time = performance.now() / 1000;
   *
   *     // Cycle through hues
   *     const hue = (time * 50) % 360;
   *     particle.tint = `hsl(${hue}, 100%, 50%)`;
   * });
   *
   * // Reset to white (no tint)
   * particle.tint = 0xffffff;
   * ```
   * @type {ColorSource} Hex number or CSS color string
   * @default 0xffffff
   * @see {@link Particle#alpha} For controlling transparency
   * @see {@link Particle#color} For the combined color and alpha value
   * @see {@link Color} For supported color formats
   */
  get tint() {
    return bgr2rgb(this._tint);
  }
  set tint(value) {
    this._tint = Color.shared.setValue(value ?? 16777215).toBgrNumber();
    this._updateColor();
  }
  _updateColor() {
    this.color = this._tint + ((this._alpha * 255 | 0) << 24);
  }
};
_Particle.defaultOptions = {
  anchorX: 0,
  anchorY: 0,
  x: 0,
  y: 0,
  scaleX: 1,
  scaleY: 1,
  rotation: 0,
  tint: 16777215,
  alpha: 1
};
var Particle = _Particle;

// node_modules/pixi.js/lib/scene/particle-container/shared/particleData.mjs
var particleData = {
  vertex: {
    attributeName: "aVertex",
    format: "float32x2",
    code: `
            const texture = p.texture;
            const sx = p.scaleX;
            const sy = p.scaleY;
            const ax = p.anchorX;
            const ay = p.anchorY;
            const trim = texture.trim;
            const orig = texture.orig;

            if (trim)
            {
                w1 = trim.x - (ax * orig.width);
                w0 = w1 + trim.width;

                h1 = trim.y - (ay * orig.height);
                h0 = h1 + trim.height;
            }
            else
            {
                w1 = -ax * (orig.width);
                w0 = w1 + orig.width;

                h1 = -ay * (orig.height);
                h0 = h1 + orig.height;
            }

            f32v[offset] = w1 * sx;
            f32v[offset + 1] = h1 * sy;

            f32v[offset + stride] = w0 * sx;
            f32v[offset + stride + 1] = h1 * sy;

            f32v[offset + (stride * 2)] = w0 * sx;
            f32v[offset + (stride * 2) + 1] = h0 * sy;

            f32v[offset + (stride * 3)] = w1 * sx;
            f32v[offset + (stride * 3) + 1] = h0 * sy;
        `,
    dynamic: false
  },
  // positionData
  position: {
    attributeName: "aPosition",
    format: "float32x2",
    code: `
            var x = p.x;
            var y = p.y;

            f32v[offset] = x;
            f32v[offset + 1] = y;

            f32v[offset + stride] = x;
            f32v[offset + stride + 1] = y;

            f32v[offset + (stride * 2)] = x;
            f32v[offset + (stride * 2) + 1] = y;

            f32v[offset + (stride * 3)] = x;
            f32v[offset + (stride * 3) + 1] = y;
        `,
    dynamic: true
  },
  // rotationData
  rotation: {
    attributeName: "aRotation",
    format: "float32",
    code: `
            var rotation = p.rotation;

            f32v[offset] = rotation;
            f32v[offset + stride] = rotation;
            f32v[offset + (stride * 2)] = rotation;
            f32v[offset + (stride * 3)] = rotation;
        `,
    dynamic: false
  },
  // uvsData
  uvs: {
    attributeName: "aUV",
    format: "float32x2",
    code: `
            var uvs = p.texture.uvs;

            f32v[offset] = uvs.x0;
            f32v[offset + 1] = uvs.y0;

            f32v[offset + stride] = uvs.x1;
            f32v[offset + stride + 1] = uvs.y1;

            f32v[offset + (stride * 2)] = uvs.x2;
            f32v[offset + (stride * 2) + 1] = uvs.y2;

            f32v[offset + (stride * 3)] = uvs.x3;
            f32v[offset + (stride * 3) + 1] = uvs.y3;
        `,
    dynamic: false
  },
  // tintData
  color: {
    attributeName: "aColor",
    format: "unorm8x4",
    code: `
            const c = p.color;

            u32v[offset] = c;
            u32v[offset + stride] = c;
            u32v[offset + (stride * 2)] = c;
            u32v[offset + (stride * 3)] = c;
        `,
    dynamic: false
  }
};

// node_modules/pixi.js/lib/scene/particle-container/init.mjs
extensions.add(GlParticleContainerPipe);
extensions.add(GpuParticleContainerPipe);
extensions.add(CanvasParticleContainerPipe);

// node_modules/pixi.js/lib/scene/particle-container/shared/ParticleContainer.mjs
var emptyBounds = new Bounds(0, 0, 0, 0);
var _ParticleContainer = class _ParticleContainer2 extends ViewContainer {
  /**
   * @param options - The options for creating the sprite.
   */
  constructor(options = {}) {
    options = __spreadProps(__spreadValues(__spreadValues({}, _ParticleContainer2.defaultOptions), options), {
      dynamicProperties: __spreadValues(__spreadValues({}, _ParticleContainer2.defaultOptions.dynamicProperties), options?.dynamicProperties)
    });
    const _a = options, { dynamicProperties, shader, roundPixels, texture, particles } = _a, rest = __objRest(_a, ["dynamicProperties", "shader", "roundPixels", "texture", "particles"]);
    super(__spreadValues({
      label: "ParticleContainer"
    }, rest));
    this.renderPipeId = "particle";
    this.batched = false;
    this._childrenDirty = false;
    this.texture = texture || null;
    this.shader = shader;
    this._properties = {};
    for (const key in particleData) {
      const property = particleData[key];
      const dynamic = dynamicProperties[key];
      this._properties[key] = __spreadProps(__spreadValues({}, property), {
        dynamic
      });
    }
    this.allowChildren = true;
    this.roundPixels = roundPixels ?? false;
    this.particleChildren = particles ?? [];
  }
  /**
   * Adds one or more particles to the container. The particles will be rendered using the container's shared texture
   * and properties. When adding multiple particles, they must all share the same base texture.
   * @example
   * ```ts
   * const container = new ParticleContainer();
   *
   * // Add a single particle
   * const particle = new Particle(Assets.get('particleTexture'));
   * container.addParticle(particle);
   *
   * // Add multiple particles at once
   * const particles = [
   *     new Particle(Assets.get('particleTexture')),
   *     new Particle(Assets.get('particleTexture')),
   *     new Particle(Assets.get('particleTexture'))
   * ];
   *
   * container.addParticle(...particles);
   * ```
   * @param children - The Particle(s) to add to the container
   * @returns The first particle that was added, for method chaining
   * @see {@link ParticleContainer#texture} For setting the shared texture
   * @see {@link ParticleContainer#update} For updating after modifications
   */
  addParticle(...children) {
    for (let i = 0; i < children.length; i++) {
      this.particleChildren.push(children[i]);
    }
    this.onViewUpdate();
    return children[0];
  }
  /**
   * Removes one or more particles from the container. The particles must already be children
   * of this container to be removed.
   * @example
   * ```ts
   * // Remove a single particle
   * container.removeParticle(particle1);
   *
   * // Remove multiple particles at once
   * container.removeParticle(particle2, particle3);
   * ```
   * @param children - The Particle(s) to remove from the container
   * @returns The first particle that was removed, for method chaining
   * @see {@link ParticleContainer#particleChildren} For accessing all particles
   * @see {@link ParticleContainer#removeParticles} For removing particles by index
   * @see {@link ParticleContainer#removeParticleAt} For removing a particle at a specific index
   */
  removeParticle(...children) {
    let didRemove = false;
    for (let i = 0; i < children.length; i++) {
      const index = this.particleChildren.indexOf(children[i]);
      if (index > -1) {
        this.particleChildren.splice(index, 1);
        didRemove = true;
      }
    }
    if (didRemove) this.onViewUpdate();
    return children[0];
  }
  /**
   * Updates the particle container's internal state. Call this method after manually modifying
   * the particleChildren array or when changing static properties of particles.
   * @example
   * ```ts
   * // Batch modify particles
   * container.particleChildren.push(...particles);
   * container.update(); // Required after direct array modification
   *
   * // Update static properties
   * container.particleChildren.forEach(particle => {
   *     particle.position.set(
   *         Math.random() * 800,
   *         Math.random() * 600
   *     );
   * });
   * container.update(); // Required after changing static positions
   * ```
   * @see {@link ParticleProperties} For configuring dynamic vs static properties
   * @see {@link ParticleContainer#particleChildren} For direct array access
   */
  update() {
    this._childrenDirty = true;
  }
  onViewUpdate() {
    this._childrenDirty = true;
    super.onViewUpdate();
  }
  /**
   * Returns a static empty bounds object since ParticleContainer does not calculate bounds automatically
   * for performance reasons. Use the `boundsArea` property to manually set container bounds.
   * @example
   * ```ts
   * const container = new ParticleContainer({
   *     texture: Texture.from('particle.png')
   * });
   *
   * // Default bounds are empty
   * console.log(container.bounds); // Bounds(0, 0, 0, 0)
   *
   * // Set manual bounds for the particle area
   * container.boundsArea = {
   *     minX: 0,
   *     minY: 0,
   *     maxX: 800,
   *     maxY: 600
   * };
   * ```
   * @readonly
   * @returns {Bounds} An empty bounds object (0,0,0,0)
   * @see {@link Container#boundsArea} For manually setting container bounds
   * @see {@link Bounds} For bounds object structure
   */
  get bounds() {
    return emptyBounds;
  }
  /** @private */
  updateBounds() {
  }
  /**
   * Destroys this sprite renderable and optionally its texture.
   * @param options - Options parameter. A boolean will act as if all options
   *  have been set to that value
   * @example
   * particleContainer.destroy();
   * particleContainer.destroy(true);
   * particleContainer.destroy({ texture: true, textureSource: true, children: true });
   */
  destroy(options = false) {
    super.destroy(options);
    const destroyTexture = typeof options === "boolean" ? options : options?.texture;
    if (destroyTexture) {
      const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
      const texture = this.texture ?? this.particleChildren[0]?.texture;
      if (texture) {
        texture.destroy(destroyTextureSource);
      }
    }
    this.texture = null;
    this.shader?.destroy();
  }
  /**
   * Removes all particles from this container that are within the begin and end indexes.
   * @param beginIndex - The beginning position.
   * @param endIndex - The ending position. Default value is size of the container.
   * @returns - List of removed particles
   */
  removeParticles(beginIndex, endIndex) {
    beginIndex ?? (beginIndex = 0);
    endIndex ?? (endIndex = this.particleChildren.length);
    const children = this.particleChildren.splice(
      beginIndex,
      endIndex - beginIndex
    );
    this.onViewUpdate();
    return children;
  }
  /**
   * Removes a particle from the specified index position.
   * @param index - The index to get the particle from
   * @returns The particle that was removed.
   */
  removeParticleAt(index) {
    const child = this.particleChildren.splice(index, 1);
    this.onViewUpdate();
    return child[0];
  }
  /**
   * Adds a particle to the container at a specified index. If the index is out of bounds an error will be thrown.
   * If the particle is already in this container, it will be moved to the specified index.
   * @param {Container} child - The particle to add.
   * @param {number} index - The absolute index where the particle will be positioned at the end of the operation.
   * @returns {Container} The particle that was added.
   */
  addParticleAt(child, index) {
    this.particleChildren.splice(index, 0, child);
    this.onViewUpdate();
    return child;
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.addParticle()` instead.
   * @param {...any} _children
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  addChild(..._children) {
    throw new Error(
      "ParticleContainer.addChild() is not available. Please use ParticleContainer.addParticle()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   * Calling this method will throw an error. Please use `ParticleContainer.removeParticle()` instead.
   * @param {...any} _children
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  removeChild(..._children) {
    throw new Error(
      "ParticleContainer.removeChild() is not available. Please use ParticleContainer.removeParticle()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.removeParticles()` instead.
   * @param {number} [_beginIndex]
   * @param {number} [_endIndex]
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  removeChildren(_beginIndex, _endIndex) {
    throw new Error(
      "ParticleContainer.removeChildren() is not available. Please use ParticleContainer.removeParticles()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.removeParticleAt()` instead.
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  removeChildAt(_index) {
    throw new Error(
      "ParticleContainer.removeChildAt() is not available. Please use ParticleContainer.removeParticleAt()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.getParticleAt()` instead.
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  getChildAt(_index) {
    throw new Error(
      "ParticleContainer.getChildAt() is not available. Please use ParticleContainer.getParticleAt()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.setParticleIndex()` instead.
   * @param {ContainerChild} _child
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  setChildIndex(_child, _index) {
    throw new Error(
      "ParticleContainer.setChildIndex() is not available. Please use ParticleContainer.setParticleIndex()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.getParticleIndex()` instead.
   * @param {ContainerChild} _child
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  getChildIndex(_child) {
    throw new Error(
      "ParticleContainer.getChildIndex() is not available. Please use ParticleContainer.getParticleIndex()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.addParticleAt()` instead.
   * @param {ContainerChild} _child
   * @param {number} _index
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  addChildAt(_child, _index) {
    throw new Error(
      "ParticleContainer.addChildAt() is not available. Please use ParticleContainer.addParticleAt()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error. Please use `ParticleContainer.swapParticles()` instead.
   * @param {ContainerChild} _child
   * @param {ContainerChild} _child2
   * @ignore
   */
  swapChildren(_child, _child2) {
    throw new Error(
      "ParticleContainer.swapChildren() is not available. Please use ParticleContainer.swapParticles()"
    );
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error.
   * @param _child - The child to reparent
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  reparentChild(..._child) {
    throw new Error("ParticleContainer.reparentChild() is not available with the particle container");
  }
  /**
   * This method is not available in ParticleContainer.
   *
   * Calling this method will throw an error.
   * @param _child - The child to reparent
   * @param _index - The index to reparent the child to
   * @throws {Error} Always throws an error as this method is not available.
   * @ignore
   */
  reparentChildAt(_child, _index) {
    throw new Error("ParticleContainer.reparentChildAt() is not available with the particle container");
  }
};
_ParticleContainer.defaultOptions = {
  /** Specifies which properties are dynamic. */
  dynamicProperties: {
    /** Indicates if vertex positions are dynamic. */
    vertex: false,
    /** Indicates if particle positions are dynamic. */
    position: true,
    /** Indicates if particle rotations are dynamic. */
    rotation: false,
    /** Indicates if UV coordinates are dynamic. */
    uvs: false,
    /** Indicates if particle colors are dynamic. */
    color: false
  },
  /** Indicates if pixels should be rounded for rendering. */
  roundPixels: false
};
var ParticleContainer = _ParticleContainer;

// node_modules/pixi.js/lib/scene/sprite-nine-slice/canvas/CanvasNineSliceSpritePipe.mjs
var colsSrc = [[0, 0], [0, 0], [0, 0]];
var rowsSrc = [[0, 0], [0, 0], [0, 0]];
var colsDst = [[0, 0], [0, 0], [0, 0]];
var rowsDst = [[0, 0], [0, 0], [0, 0]];
function setSpans(spans, s0, n0, s1, n1, s2, n2) {
  spans[0][0] = s0;
  spans[0][1] = n0;
  spans[1][0] = s1;
  spans[1][1] = n1;
  spans[2][0] = s2;
  spans[2][1] = n2;
}
var CanvasNineSliceSpritePipe = class {
  constructor(renderer) {
    this._renderer = renderer;
  }
  validateRenderable(_sprite) {
    return false;
  }
  addRenderable(sprite, instructionSet) {
    this._renderer.renderPipes.batch.break(instructionSet);
    instructionSet.add(sprite);
  }
  updateRenderable(_sprite) {
  }
  execute(sprite) {
    const renderer = this._renderer;
    const contextSystem = renderer.canvasContext;
    const context = contextSystem.activeContext;
    context.save();
    const transform2 = sprite.groupTransform;
    const roundPixels = renderer._roundPixels | sprite._roundPixels;
    contextSystem.setContextTransform(transform2, roundPixels === 1);
    contextSystem.setBlendMode(sprite.groupBlendMode);
    const globalColor = renderer.globalUniforms.globalUniformData?.worldColor ?? 4294967295;
    const groupColorAlpha = sprite.groupColorAlpha;
    const globalAlpha = (globalColor >>> 24 & 255) / 255;
    const groupAlphaValue = (groupColorAlpha >>> 24 & 255) / 255;
    const filterAlpha = renderer.filter?.alphaMultiplier ?? 1;
    const alpha = globalAlpha * groupAlphaValue * filterAlpha;
    if (alpha <= 0) {
      context.restore();
      return;
    }
    context.globalAlpha = alpha;
    const globalTint = globalColor & 16777215;
    const groupTintBGR = groupColorAlpha & 16777215;
    const tint = bgr2rgb(multiplyHexColors(groupTintBGR, globalTint));
    const texture = sprite.texture;
    const drawSource = canvasUtils.getCanvasSource(texture);
    if (!drawSource) {
      context.restore();
      return;
    }
    const smoothProperty = contextSystem.smoothProperty;
    const shouldSmooth = texture.source.style.scaleMode !== "nearest";
    if (context[smoothProperty] !== shouldSmooth) {
      context[smoothProperty] = shouldSmooth;
    }
    const needsProcessing = tint !== 16777215 || texture.rotate !== 0;
    const finalSource = needsProcessing ? canvasUtils.getTintedCanvas({ texture }, tint) : drawSource;
    const {
      leftWidth,
      topHeight,
      rightWidth,
      bottomHeight,
      width,
      height
    } = sprite;
    const totalBorderWidth = leftWidth + rightWidth;
    const totalBorderHeight = topHeight + bottomHeight;
    const scale = Math.min(
      totalBorderWidth > width ? width / totalBorderWidth : 1,
      totalBorderHeight > height ? height / totalBorderHeight : 1,
      1
    );
    const destLeftWidth = leftWidth * scale;
    const destRightWidth = rightWidth * scale;
    const destTopHeight = topHeight * scale;
    const destBottomHeight = bottomHeight * scale;
    const destCenterWidth = Math.max(0, width - destLeftWidth - destRightWidth);
    const destCenterHeight = Math.max(0, height - destTopHeight - destBottomHeight);
    const anchor = sprite.anchor;
    const resolution = texture.source._resolution ?? texture.source.resolution ?? 1;
    let sx = texture.frame.x * resolution;
    let sy = texture.frame.y * resolution;
    const dx = -anchor.x * width;
    const dy = -anchor.y * height;
    const lw = leftWidth * resolution;
    const tw = topHeight * resolution;
    const rw = rightWidth * resolution;
    const bw = bottomHeight * resolution;
    let sw = texture.frame.width * resolution;
    let sh = texture.frame.height * resolution;
    if (needsProcessing) {
      sx = 0;
      sy = 0;
      sw = finalSource.width;
      sh = finalSource.height;
    }
    const centerSrcW = sw - lw - rw;
    const centerSrcH = sh - tw - bw;
    const centerSx = centerSrcW > 0 ? sx + lw : Math.max(sx, Math.min(sx + lw, sx + sw - 1));
    const centerSw = centerSrcW > 0 ? centerSrcW : 1;
    const centerSy = centerSrcH > 0 ? sy + tw : Math.max(sy, Math.min(sy + tw, sy + sh - 1));
    const centerSh = centerSrcH > 0 ? centerSrcH : 1;
    setSpans(colsSrc, sx, lw, centerSx, centerSw, sx + sw - rw, rw);
    setSpans(rowsSrc, sy, tw, centerSy, centerSh, sy + sh - bw, bw);
    setSpans(
      colsDst,
      dx,
      destLeftWidth,
      dx + destLeftWidth,
      destCenterWidth,
      dx + width - destRightWidth,
      destRightWidth
    );
    setSpans(
      rowsDst,
      dy,
      destTopHeight,
      dy + destTopHeight,
      destCenterHeight,
      dy + height - destBottomHeight,
      destBottomHeight
    );
    for (let col = 0; col < 3; col++) {
      const dww = colsDst[col][1];
      if (dww <= 0) continue;
      const sxx = colsSrc[col][0];
      const sww = colsSrc[col][1];
      const dxx = colsDst[col][0];
      for (let row = 0; row < 3; row++) {
        const dhh = rowsDst[row][1];
        if (dhh <= 0) continue;
        context.drawImage(
          finalSource,
          sxx,
          rowsSrc[row][0],
          sww,
          rowsSrc[row][1],
          dxx,
          rowsDst[row][0],
          dww,
          dhh
        );
      }
    }
    context.restore();
  }
  destroy() {
    this._renderer = null;
  }
};
CanvasNineSliceSpritePipe.extension = {
  type: [
    ExtensionType.CanvasPipes
  ],
  name: "nineSliceSprite"
};

// node_modules/pixi.js/lib/scene/sprite-nine-slice/NineSliceGeometry.mjs
var _NineSliceGeometry = class _NineSliceGeometry2 extends PlaneGeometry {
  constructor(options = {}) {
    options = __spreadValues(__spreadValues({}, _NineSliceGeometry2.defaultOptions), options);
    super({
      width: options.width,
      height: options.height,
      verticesX: 4,
      verticesY: 4
    });
    this._trimX = 0;
    this._trimY = 0;
    this._trimWidth = options.originalWidth ?? _NineSliceGeometry2.defaultOptions.originalWidth;
    this._trimHeight = options.originalHeight ?? _NineSliceGeometry2.defaultOptions.originalHeight;
    this.update(options);
  }
  /**
   * Updates the NineSliceGeometry with the options.
   * @param options - The options of the NineSliceGeometry.
   */
  update(options) {
    this.width = options.width ?? this.width;
    this.height = options.height ?? this.height;
    this._originalWidth = options.originalWidth ?? this._originalWidth;
    this._originalHeight = options.originalHeight ?? this._originalHeight;
    this._leftWidth = options.leftWidth ?? this._leftWidth;
    this._rightWidth = options.rightWidth ?? this._rightWidth;
    this._topHeight = options.topHeight ?? this._topHeight;
    this._bottomHeight = options.bottomHeight ?? this._bottomHeight;
    this._anchorX = options.anchor?.x;
    this._anchorY = options.anchor?.y;
    if (options.trim !== void 0) {
      this._trimX = options.trim?.x ?? 0;
      this._trimY = options.trim?.y ?? 0;
      this._trimWidth = options.trim?.width ?? this._originalWidth;
      this._trimHeight = options.trim?.height ?? this._originalHeight;
    } else {
      this._trimWidth = this._originalWidth;
      this._trimHeight = this._originalHeight;
    }
    this.updateUvs();
    this.updatePositions();
  }
  /** Updates the positions of the vertices. */
  updatePositions() {
    const p = this.positions;
    const {
      width,
      height,
      _leftWidth,
      _rightWidth,
      _topHeight,
      _bottomHeight,
      _anchorX,
      _anchorY
    } = this;
    const w = _leftWidth + _rightWidth;
    const scaleW = width > w ? 1 : width / w;
    const h = _topHeight + _bottomHeight;
    const scaleH = height > h ? 1 : height / h;
    const scale = Math.min(scaleW, scaleH);
    const anchorOffsetX = _anchorX * width;
    const anchorOffsetY = _anchorY * height;
    p[0] = p[8] = p[16] = p[24] = -anchorOffsetX;
    p[2] = p[10] = p[18] = p[26] = _leftWidth * scale - anchorOffsetX;
    p[4] = p[12] = p[20] = p[28] = width - _rightWidth * scale - anchorOffsetX;
    p[6] = p[14] = p[22] = p[30] = width - anchorOffsetX;
    p[1] = p[3] = p[5] = p[7] = -anchorOffsetY;
    p[9] = p[11] = p[13] = p[15] = _topHeight * scale - anchorOffsetY;
    p[17] = p[19] = p[21] = p[23] = height - _bottomHeight * scale - anchorOffsetY;
    p[25] = p[27] = p[29] = p[31] = height - anchorOffsetY;
    this.getBuffer("aPosition").update();
  }
  /** Updates the UVs of the vertices. */
  updateUvs() {
    const uvs = this.uvs;
    const origW = this._originalWidth;
    const origH = this._originalHeight;
    const u0 = this._trimX / origW;
    const v0 = this._trimY / origH;
    const u1 = (this._trimX + this._trimWidth) / origW;
    const v1 = (this._trimY + this._trimHeight) / origH;
    uvs[0] = uvs[8] = uvs[16] = uvs[24] = u0;
    uvs[1] = uvs[3] = uvs[5] = uvs[7] = v0;
    uvs[6] = uvs[14] = uvs[22] = uvs[30] = u1;
    uvs[25] = uvs[27] = uvs[29] = uvs[31] = v1;
    const _uvw = 1 / origW;
    const _uvh = 1 / origH;
    uvs[2] = uvs[10] = uvs[18] = uvs[26] = u0 + _uvw * this._leftWidth;
    uvs[9] = uvs[11] = uvs[13] = uvs[15] = v0 + _uvh * this._topHeight;
    uvs[4] = uvs[12] = uvs[20] = uvs[28] = u1 - _uvw * this._rightWidth;
    uvs[17] = uvs[19] = uvs[21] = uvs[23] = v1 - _uvh * this._bottomHeight;
    this.getBuffer("aUV").update();
  }
};
_NineSliceGeometry.defaultOptions = {
  /** The width of the NineSlicePlane, setting this will actually modify the vertices and UV's of this plane. */
  width: 100,
  /** The height of the NineSlicePlane, setting this will actually modify the vertices and UV's of this plane. */
  height: 100,
  /** The width of the left column. */
  leftWidth: 10,
  /** The height of the top row. */
  topHeight: 10,
  /** The width of the right column. */
  rightWidth: 10,
  /** The height of the bottom row. */
  bottomHeight: 10,
  /** The original width of the texture */
  originalWidth: 100,
  /** The original height of the texture */
  originalHeight: 100
};
var NineSliceGeometry = _NineSliceGeometry;

// node_modules/pixi.js/lib/scene/sprite-nine-slice/NineSliceSpritePipe.mjs
var NineSliceSpriteGpuData = class extends BatchableMesh {
  constructor() {
    super();
    this.geometry = new NineSliceGeometry();
  }
  destroy() {
    this.geometry.destroy();
  }
};
var NineSliceSpritePipe = class {
  constructor(renderer) {
    this._renderer = renderer;
    this._managedSprites = new GCManagedHash({ renderer, type: "renderable", name: "nineSliceSprite" });
  }
  addRenderable(sprite, instructionSet) {
    const gpuSprite = this._getGpuSprite(sprite);
    if (sprite.didViewUpdate) this._updateBatchableSprite(sprite, gpuSprite);
    this._renderer.renderPipes.batch.addToBatch(gpuSprite, instructionSet);
  }
  updateRenderable(sprite) {
    const gpuSprite = this._getGpuSprite(sprite);
    if (sprite.didViewUpdate) this._updateBatchableSprite(sprite, gpuSprite);
    gpuSprite._batcher.updateElement(gpuSprite);
  }
  validateRenderable(sprite) {
    const gpuSprite = this._getGpuSprite(sprite);
    return !gpuSprite._batcher.checkAndUpdateTexture(
      gpuSprite,
      sprite._texture
    );
  }
  _updateBatchableSprite(sprite, batchableSprite) {
    batchableSprite.geometry.update(sprite);
    batchableSprite.setTexture(sprite._texture);
  }
  _getGpuSprite(sprite) {
    return sprite._gpuData[this._renderer.uid] || this._initGPUSprite(sprite);
  }
  _initGPUSprite(sprite) {
    const gpuData = sprite._gpuData[this._renderer.uid] = new NineSliceSpriteGpuData();
    const batchableMesh = gpuData;
    batchableMesh.renderable = sprite;
    batchableMesh.transform = sprite.groupTransform;
    batchableMesh.texture = sprite._texture;
    batchableMesh.roundPixels = this._renderer._roundPixels | sprite._roundPixels;
    this._managedSprites.add(sprite);
    if (!sprite.didViewUpdate) {
      this._updateBatchableSprite(sprite, batchableMesh);
    }
    return gpuData;
  }
  destroy() {
    this._managedSprites.destroy();
    this._renderer = null;
  }
};
NineSliceSpritePipe.extension = {
  type: [
    ExtensionType.WebGLPipes,
    ExtensionType.WebGPUPipes
  ],
  name: "nineSliceSprite"
};

// node_modules/pixi.js/lib/scene/sprite-nine-slice/init.mjs
extensions.add(CanvasNineSliceSpritePipe);
extensions.add(NineSliceSpritePipe);

// node_modules/pixi.js/lib/scene/sprite-nine-slice/NineSliceSprite.mjs
var _NineSliceSprite = class _NineSliceSprite2 extends ViewContainer {
  constructor(options) {
    if (options instanceof Texture) {
      options = { texture: options };
    }
    const _a = options, {
      width,
      height,
      anchor,
      leftWidth,
      rightWidth,
      topHeight,
      bottomHeight,
      texture,
      roundPixels
    } = _a, rest = __objRest(_a, [
      "width",
      "height",
      "anchor",
      "leftWidth",
      "rightWidth",
      "topHeight",
      "bottomHeight",
      "texture",
      "roundPixels"
    ]);
    super(__spreadValues({
      label: "NineSliceSprite"
    }, rest));
    this.renderPipeId = "nineSliceSprite";
    this.batched = true;
    this._leftWidth = leftWidth ?? texture?.defaultBorders?.left ?? NineSliceGeometry.defaultOptions.leftWidth;
    this._topHeight = topHeight ?? texture?.defaultBorders?.top ?? NineSliceGeometry.defaultOptions.topHeight;
    this._rightWidth = rightWidth ?? texture?.defaultBorders?.right ?? NineSliceGeometry.defaultOptions.rightWidth;
    this._bottomHeight = bottomHeight ?? texture?.defaultBorders?.bottom ?? NineSliceGeometry.defaultOptions.bottomHeight;
    this._width = width ?? texture.width ?? NineSliceGeometry.defaultOptions.width;
    this._height = height ?? texture.height ?? NineSliceGeometry.defaultOptions.height;
    this.allowChildren = false;
    this.texture = texture ?? _NineSliceSprite2.defaultOptions.texture;
    this.roundPixels = roundPixels ?? false;
    this._anchor = new ObservablePoint(
      {
        _onUpdate: () => {
          this.onViewUpdate();
        }
      }
    );
    if (anchor) {
      this.anchor = anchor;
    } else if (this.texture.defaultAnchor) {
      this.anchor = this.texture.defaultAnchor;
    }
  }
  /**
   * The anchor sets the origin point of the sprite. The default value is taken from the {@link Texture}
   * and passed to the constructor.
   *
   * - The default is `(0,0)`, this means the sprite's origin is the top left.
   * - Setting the anchor to `(0.5,0.5)` means the sprite's origin is centered.
   * - Setting the anchor to `(1,1)` would mean the sprite's origin point will be the bottom right corner.
   *
   * If you pass only single parameter, it will set both x and y to the same value as shown in the example below.
   * @example
   * ```ts
   * // Center the anchor point
   * sprite.anchor = 0.5; // Sets both x and y to 0.5
   * sprite.position.set(400, 300); // Sprite will be centered at this position
   *
   * // Set specific x/y anchor points
   * sprite.anchor = {
   *     x: 1, // Right edge
   *     y: 0  // Top edge
   * };
   *
   * // Using individual coordinates
   * sprite.anchor.set(0.5, 1); // Center-bottom
   *
   * // For rotation around center
   * sprite.anchor.set(0.5);
   * sprite.rotation = Math.PI / 4; // 45 degrees around center
   *
   * // For scaling from center
   * sprite.anchor.set(0.5);
   * sprite.scale.set(2); // Scales from center point
   * ```
   */
  get anchor() {
    return this._anchor;
  }
  set anchor(value) {
    typeof value === "number" ? this._anchor.set(value) : this._anchor.copyFrom(value);
  }
  /**
   * The width of the NineSliceSprite, setting this will actually modify the vertices and UV's of this plane.
   * The width affects how the middle sections are scaled.
   * @example
   * ```ts
   * // Create a nine-slice sprite with fixed width
   * const panel = new NineSliceSprite({
   *     texture: Texture.from('panel.png'),
   *     width: 200  // Sets initial width
   * });
   *
   * // Adjust width dynamically
   * panel.width = 300;  // Stretches middle sections
   * ```
   * @see {@link NineSliceSprite#setSize} For setting both width and height efficiently
   * @see {@link NineSliceSprite#height} For setting height
   */
  get width() {
    return this._width;
  }
  set width(value) {
    this._width = value;
    this.onViewUpdate();
  }
  /**
   * The height of the NineSliceSprite, setting this will actually modify the vertices and UV's of this plane.
   * The height affects how the middle sections are scaled.
   * @example
   * ```ts
   * // Create a nine-slice sprite with fixed height
   * const panel = new NineSliceSprite({
   *     texture: Texture.from('panel.png'),
   *     height: 150  // Sets initial height
   * });
   *
   * // Adjust height dynamically
   * panel.height = 200;  // Stretches middle sections
   *
   * // Create responsive UI element
   * const dialog = new NineSliceSprite({
   *     texture: Texture.from('dialog.png'),
   *     topHeight: 30,
   *     bottomHeight: 30,
   *     height: parent.height * 0.5  // 50% of parent height
   * });
   * ```
   * @see {@link NineSliceSprite#setSize} For setting both width and height efficiently
   * @see {@link NineSliceSprite#width} For setting width
   */
  get height() {
    return this._height;
  }
  set height(value) {
    this._height = value;
    this.onViewUpdate();
  }
  /**
   * Sets the size of the NineSliceSprite to the specified width and height.
   * This method directly modifies the vertices and UV coordinates of the sprite.
   *
   * Using this is more efficient than setting width and height separately as it only triggers one update.
   * @example
   * ```ts
   * // Set to specific dimensions
   * panel.setSize(300, 200); // Width: 300, Height: 200
   *
   * // Set uniform size
   * panel.setSize(200); // Makes a square 200x200
   *
   * // Set size using object
   * panel.setSize({
   *     width: 400,
   *     height: 300
   * });
   * ```
   * @param value - This can be either a number or a Size object with width/height properties
   * @param height - The height to set. Defaults to the value of `width` if not provided
   * @see {@link NineSliceSprite#width} For setting width only
   * @see {@link NineSliceSprite#height} For setting height only
   */
  setSize(value, height) {
    if (typeof value === "object") {
      height = value.height ?? value.width;
      value = value.width;
    }
    this._width = value;
    this._height = height ?? value;
    this.onViewUpdate();
  }
  /**
   * Retrieves the size of the NineSliceSprite as a [Size]{@link Size} object.
   * This method is more efficient than getting width and height separately.
   * @example
   * ```ts
   * // Get basic size
   * const size = panel.getSize();
   * console.log(`Size: ${size.width}x${size.height}`);
   *
   * // Reuse existing size object
   * const reuseSize = { width: 0, height: 0 };
   * panel.getSize(reuseSize);
   * ```
   * @param out - Optional object to store the size in, to avoid allocating a new object
   * @returns The size of the NineSliceSprite
   * @see {@link NineSliceSprite#width} For getting just the width
   * @see {@link NineSliceSprite#height} For getting just the height
   * @see {@link NineSliceSprite#setSize} For setting both width and height efficiently
   */
  getSize(out) {
    out || (out = {});
    out.width = this._width;
    out.height = this._height;
    return out;
  }
  /**
   * Width of the left vertical bar (A).
   * Controls the size of the left edge that remains unscaled
   * @example
   * ```ts
   * const sprite = new NineSliceSprite({ ..., leftWidth: 20 });
   * sprite.leftWidth = 20; // Set left border width
   * ```
   * @default 10
   */
  get leftWidth() {
    return this._leftWidth;
  }
  set leftWidth(value) {
    this._leftWidth = value;
    this.onViewUpdate();
  }
  /**
   * Height of the top horizontal bar (C).
   * Controls the size of the top edge that remains unscaled
   * @example
   * ```ts
   * const sprite = new NineSliceSprite({ ..., topHeight: 20 });
   * sprite.topHeight = 20; // Set top border height
   * ```
   * @default 10
   */
  get topHeight() {
    return this._topHeight;
  }
  set topHeight(value) {
    this._topHeight = value;
    this.onViewUpdate();
  }
  /**
   * Width of the right vertical bar (B).
   * Controls the size of the right edge that remains unscaled
   * @example
   * ```ts
   * const sprite = new NineSliceSprite({ ..., rightWidth: 20 });
   * sprite.rightWidth = 20; // Set right border width
   * ```
   * @default 10
   */
  get rightWidth() {
    return this._rightWidth;
  }
  set rightWidth(value) {
    this._rightWidth = value;
    this.onViewUpdate();
  }
  /**
   * Height of the bottom horizontal bar (D).
   * Controls the size of the bottom edge that remains unscaled
   * @example
   * ```ts
   * const sprite = new NineSliceSprite({ ..., bottomHeight: 20 });
   * sprite.bottomHeight = 20; // Set bottom border height
   * ```
   * @default 10
   */
  get bottomHeight() {
    return this._bottomHeight;
  }
  set bottomHeight(value) {
    this._bottomHeight = value;
    this.onViewUpdate();
  }
  /**
   * The texture to use on the NineSliceSprite.
   * ```ts
   * // Create a sprite with a texture
   * const sprite = new NineSliceSprite({
   *     texture: Texture.from('path/to/image.png')
   * });
   * // Update the texture later
   * sprite.texture = Texture.from('path/to/another-image.png');
   * ```
   * @default Texture.EMPTY
   */
  get texture() {
    return this._texture;
  }
  set texture(value) {
    value || (value = Texture.EMPTY);
    const currentTexture = this._texture;
    if (currentTexture === value) return;
    if (currentTexture && currentTexture.dynamic) currentTexture.off("update", this.onViewUpdate, this);
    if (value.dynamic) value.on("update", this.onViewUpdate, this);
    this._texture = value;
    this.onViewUpdate();
  }
  /**
   * The original width of the texture before any nine-slice scaling.
   * This is the width of the source texture used to create the nine-slice sprite.
   * @example
   * ```ts
   * // Get original dimensions
   * console.log(`Original size: ${sprite.originalWidth}x${sprite.originalHeight}`);
   *
   * // Use for relative scaling
   * sprite.width = sprite.originalWidth * 2; // Double the original width
   *
   * // Reset to original size
   * sprite.setSize(sprite.originalWidth, sprite.originalHeight);
   * ```
   * @readonly
   * @see {@link NineSliceSprite#width} For the current displayed width
   * @see {@link Texture#width} For direct texture width access
   * @returns The original width of the texture
   */
  get originalWidth() {
    return this._texture.width;
  }
  /**
   * The original height of the texture before any nine-slice scaling.
   * This is the height of the source texture used to create the nine-slice sprite.
   * @example
   * ```ts
   * // Get original dimensions
   * console.log(`Original size: ${sprite.originalWidth}x${sprite.originalHeight}`);
   *
   * // Use for relative scaling
   * sprite.height = sprite.originalHeight * 2; // Double the original height
   *
   * // Reset to original size
   * sprite.setSize(sprite.originalWidth, sprite.originalHeight);
   * ```
   * @readonly
   * @see {@link NineSliceSprite#height} For the current displayed height
   * @see {@link Texture#height} For direct texture height access
   * @returns The original height of the texture
   */
  get originalHeight() {
    return this._texture.height;
  }
  /**
   * The trim rectangle of the underlying texture, or `null` if the texture is not trimmed.
   * This is forwarded to the {@link NineSliceGeometry} so that UV coordinates are clamped
   * to the visible pixel region, preventing transparent atlas padding from bleeding into
   * the rendered sprite corners.
   * @readonly
   * @internal
   */
  get trim() {
    return this._texture.trim ?? null;
  }
  /**
   * Destroys this sprite renderable and optionally its texture.
   * @param options - Options parameter. A boolean will act as if all options
   *  have been set to that value
   * @example
   * nineSliceSprite.destroy();
   * nineSliceSprite.destroy(true);
   * nineSliceSprite.destroy({ texture: true, textureSource: true });
   */
  destroy(options) {
    super.destroy(options);
    const destroyTexture = typeof options === "boolean" ? options : options?.texture;
    if (destroyTexture) {
      const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
      this._texture.destroy(destroyTextureSource);
    }
    this._texture = null;
  }
  /** @private */
  updateBounds() {
    const bounds = this._bounds;
    const anchor = this._anchor;
    const width = this._width;
    const height = this._height;
    bounds.minX = -anchor._x * width;
    bounds.maxX = bounds.minX + width;
    bounds.minY = -anchor._y * height;
    bounds.maxY = bounds.minY + height;
  }
};
_NineSliceSprite.defaultOptions = {
  /** @default Texture.EMPTY */
  texture: Texture.EMPTY
};
var NineSliceSprite = _NineSliceSprite;
var NineSlicePlane = class extends NineSliceSprite {
  constructor(...args) {
    let options = args[0];
    if (options instanceof Texture) {
      deprecation(v8_0_0, "NineSlicePlane now uses the options object {texture, leftWidth, rightWidth, topHeight, bottomHeight}");
      options = {
        texture: options,
        leftWidth: args[1],
        topHeight: args[2],
        rightWidth: args[3],
        bottomHeight: args[4]
      };
    }
    deprecation(v8_0_0, "NineSlicePlane is deprecated. Use NineSliceSprite instead.");
    super(options);
  }
};

// node_modules/pixi.js/lib/scene/text-bitmap/utils/bitmapTextSplit.mjs
function bitmapTextSplit(options) {
  const { text, style, chars: existingChars } = options;
  const textStyle = style;
  const font = BitmapFontManager.getFont(text, textStyle);
  const segments = CanvasTextMetrics.graphemeSegmenter(text);
  const layout = getBitmapTextLayout(segments, textStyle, font, true);
  const scale = layout.scale;
  const chars = [];
  const words = [];
  const lines = [];
  const lineHeight = style.lineHeight ? style.lineHeight : font.lineHeight * scale;
  let yOffset = 0;
  for (const line of layout.lines) {
    if (line.chars.length === 0) continue;
    const lineContainer = new Container({ label: "line" });
    lineContainer.y = yOffset;
    lines.push(lineContainer);
    let currentWordContainer = new Container({ label: "word" });
    let currentWordStartIndex = 0;
    for (let i = 0; i < line.chars.length; i++) {
      const char = line.chars[i];
      if (!char) continue;
      const charData = font.chars[char];
      if (!charData) continue;
      const isSpace = char === " ";
      const isLastChar = i === line.chars.length - 1;
      let charInstance;
      if (existingChars.length > 0) {
        charInstance = existingChars.shift();
        charInstance.text = char;
        charInstance.style = textStyle;
        charInstance.label = `char-${char}`;
        charInstance.x = line.charPositions[i] * scale - line.charPositions[currentWordStartIndex] * scale;
      } else {
        charInstance = new BitmapText({
          text: char,
          style: textStyle,
          label: `char-${char}`,
          x: line.charPositions[i] * scale - line.charPositions[currentWordStartIndex] * scale
        });
      }
      if (!isSpace) {
        chars.push(charInstance);
        currentWordContainer.addChild(charInstance);
      }
      if (isSpace || isLastChar) {
        if (currentWordContainer.children.length > 0) {
          currentWordContainer.x = line.charPositions[currentWordStartIndex] * scale;
          words.push(currentWordContainer);
          lineContainer.addChild(currentWordContainer);
          currentWordContainer = new Container({ label: "word" });
          currentWordStartIndex = i + 1;
        }
      }
    }
    yOffset += lineHeight;
  }
  return { chars, lines, words };
}

// node_modules/pixi.js/lib/scene/text-split/AbstractSplitText.mjs
var AbstractSplitText = class extends Container {
  constructor(config) {
    const _a = config, {
      text,
      style,
      autoSplit,
      lineAnchor,
      wordAnchor,
      charAnchor
    } = _a, options = __objRest(_a, [
      "text",
      "style",
      "autoSplit",
      "lineAnchor",
      "wordAnchor",
      "charAnchor"
    ]);
    super(options);
    this._dirty = false;
    this._canReuseChars = false;
    this.chars = [];
    this.words = [];
    this.lines = [];
    this._originalText = text;
    this._autoSplit = autoSplit;
    this._lineAnchor = lineAnchor;
    this._wordAnchor = wordAnchor;
    this._charAnchor = charAnchor;
    this.style = style;
  }
  /**
   * Splits the text into lines, words, and characters.
   * Call this manually when autoSplit is false.
   * @example Manual Splitting
   * ```ts
   * const text = new SplitText({
   *   text: 'Manual Update',
   *   autoSplit: false
   * });
   *
   * text.text = 'New Content';
   * text.style = { fontSize: 32 };
   * text.split(); // Apply changes
   * ```
   */
  split() {
    const res = this.splitFn();
    this.chars = res.chars;
    this.words = res.words;
    this.lines = res.lines;
    this.addChild(...this.lines);
    this.charAnchor = this._charAnchor;
    this.wordAnchor = this._wordAnchor;
    this.lineAnchor = this._lineAnchor;
    this._dirty = false;
    this._canReuseChars = true;
  }
  get text() {
    return this._originalText;
  }
  /**
   * Gets or sets the text content.
   * Setting new text triggers splitting if autoSplit is true.
   * > [!NOTE] Setting this frequently can have a performance impact, especially with large texts and canvas text.
   * @example Dynamic Text Updates
   * ```ts
   * const text = new SplitText({
   *   text: 'Original',
   *   autoSplit: true
   * });
   *
   * // Auto-splits on change
   * text.text = 'Updated Content';
   *
   * // Manual update
   * text.autoSplit = false;
   * text.text = 'Manual Update';
   * text.split();
   * ```
   */
  set text(value) {
    this._originalText = value;
    this.lines.forEach((line) => line.destroy({ children: true }));
    this.lines.length = 0;
    this.words.length = 0;
    this.chars.length = 0;
    this._canReuseChars = false;
    this.onTextUpdate();
  }
  _setOrigin(value, elements, property) {
    let originPoint;
    if (typeof value === "number") {
      originPoint = { x: value, y: value };
    } else {
      originPoint = { x: value.x, y: value.y };
    }
    elements.forEach((element) => {
      const localBounds = element.getLocalBounds();
      const originX = localBounds.minX + localBounds.width * originPoint.x;
      const originY = localBounds.minY + localBounds.height * originPoint.y;
      element.origin.set(originX, originY);
    });
    this[property] = value;
  }
  /**
   * Gets or sets the transform anchor for line segments.
   * The anchor point determines the center of rotation and scaling for each line.
   * @example Setting Line Anchors
   * ```ts
   * // Center rotation/scaling
   * text.lineAnchor = 0.5;
   *
   * // Rotate/scale from top-right corner
   * text.lineAnchor = { x: 1, y: 0 };
   *
   * // Custom anchor point
   * text.lineAnchor = {
   *   x: 0.2, // 20% from left
   *   y: 0.8  // 80% from top
   * };
   * ```
   */
  get lineAnchor() {
    return this._lineAnchor;
  }
  set lineAnchor(value) {
    this._setOrigin(value, this.lines, "_lineAnchor");
  }
  /**
   * Gets or sets the transform anchor for word segments.
   * The anchor point determines the center of rotation and scaling for each word.
   * @example
   * ```ts
   * // Center each word
   * text.wordAnchor = 0.5;
   *
   * // Scale from bottom-left
   * text.wordAnchor = { x: 0, y: 1 };
   *
   * // Rotate around custom point
   * text.wordAnchor = {
   *   x: 0.75,  // 75% from left
   *   y: 0.5    // Middle vertically
   * };
   * ```
   */
  get wordAnchor() {
    return this._wordAnchor;
  }
  set wordAnchor(value) {
    this._setOrigin(value, this.words, "_wordAnchor");
  }
  /**
   * Gets or sets the transform anchor for character segments.
   * The anchor point determines the center of rotation and scaling for each character.
   * @example Setting Character Anchors
   * ```ts
   * // Center each character
   * text.charAnchor = 0.5;
   *
   * // Rotate from top-center
   * text.charAnchor = { x: 0.5, y: 0 };
   *
   * // Scale from bottom-right
   * text.charAnchor = { x: 1, y: 1 };
   * ```
   * @example Animation with Anchors
   * ```ts
   * // Rotate characters around their centers
   * text.charAnchor = 0.5;
   * text.chars.forEach((char, i) => {
   *   gsap.to(char, {
   *     rotation: Math.PI * 2,
   *     duration: 1,
   *     delay: i * 0.1,
   *     repeat: -1
   *   });
   * });
   * ```
   */
  get charAnchor() {
    return this._charAnchor;
  }
  set charAnchor(value) {
    this._setOrigin(value, this.chars, "_charAnchor");
  }
  get style() {
    return this._style;
  }
  /**
   * The style configuration for the text.
   * Can be a TextStyle instance or a configuration object.
   * @example
   * ```ts
   * const text = new Text({
   *     text: 'Styled Text',
   *     style: {
   *         fontSize: 24,
   *         fill: 0xff1010, // Red color
   *         fontFamily: 'Arial',
   *         align: 'center', // Center alignment
   *         stroke: { color: '#4a1850', width: 5 }, // Purple stroke
   *         dropShadow: {
   *             color: '#000000', // Black shadow
   *             blur: 4, // Shadow blur
   *             distance: 6 // Shadow distance
   *         }
   *     }
   * });
   * // Update style dynamically
   * text.style = {
   *     fontSize: 30, // Change font size
   *     fill: 0x00ff00, // Change color to green
   *     align: 'right', // Change alignment to right
   *     stroke: { color: '#000000', width: 2 }, // Add black stroke
   * }
   */
  set style(style) {
    style || (style = {});
    this._style = new TextStyle(style);
    this.styleChanged();
  }
  /**
   * Used to notify the text that the style has changed.
   * This will re-split the text and re-apply the style.
   * @example
   * ```ts
   * text.style.fontSize = 32;
   * text.styleChanged();
   * ```
   */
  styleChanged() {
    this.words.forEach((word) => word.destroy());
    this.words.length = 0;
    this.lines.forEach((line) => line.destroy());
    this.lines.length = 0;
    this._canReuseChars = true;
    this.onTextUpdate();
  }
  onTextUpdate() {
    this._dirty = true;
    if (this._autoSplit) {
      this.split();
    }
  }
  /**
   * Destroys the SplitText instance and all its resources.
   * Cleans up all segment arrays, event listeners, and optionally the text style.
   * @param options - Destroy configuration options
   * @example
   * ```ts
   * // Clean up everything
   * text.destroy({ children: true, texture: true, style: true });
   *
   * // Remove from parent but keep style
   * text.destroy({ children: true, style: false });
   * ```
   */
  destroy(options) {
    super.destroy(options);
    this.chars = [];
    this.words = [];
    this.lines = [];
    if (typeof options === "boolean" ? options : options?.style) {
      this._style.destroy(options);
    }
    this._style = null;
    this._originalText = "";
  }
};

// node_modules/pixi.js/lib/scene/text-split/SplitBitmapText.mjs
var _SplitBitmapText = class _SplitBitmapText2 extends AbstractSplitText {
  constructor(config) {
    var _a;
    const completeOptions = __spreadValues(__spreadValues({}, _SplitBitmapText2.defaultOptions), config);
    completeOptions.style ?? (completeOptions.style = {});
    (_a = completeOptions.style).fill ?? (_a.fill = 16777215);
    super(completeOptions);
  }
  /**
   * Creates a SplitBitmapText instance from an existing text object.
   * Useful for converting standard Text or BitmapText objects into segmented versions.
   * @param text - The source text object to convert
   * @param options - Additional splitting options
   * @returns A new SplitBitmapText instance
   * @example
   * ```ts
   * const bitmapText = new BitmapText({
   *   text: 'Bitmap Text',
   *   style: { fontFamily: 'Arial' }
   * });
   *
   * const segmented = SplitBitmapText.from(bitmapText);
   *
   * // with additional options
   * const segmentedWithOptions = SplitBitmapText.from(bitmapText, {
   *   autoSplit: false,
   *   lineAnchor: 0.5,
   *   wordAnchor: { x: 0, y: 0.5 },
   * })
   * ```
   */
  static from(text, options) {
    const completeOptions = __spreadProps(__spreadValues(__spreadValues({}, _SplitBitmapText2.defaultOptions), options), {
      text: text.text,
      style: new TextStyle(text.style)
    });
    if (text.style.tagStyles) {
      warn("[SplitBitmapText] Tag styles are not supported for SplitBitmapText. They will be ignored.");
      text.style._tagStyles = void 0;
    }
    const splitText = new _SplitBitmapText2(__spreadValues({}, completeOptions));
    const anchor = text.anchor;
    if (anchor.x !== 0 || anchor.y !== 0) {
      splitText.pivot.set(
        splitText.width * anchor.x,
        splitText.height * anchor.y
      );
    }
    return splitText;
  }
  splitFn() {
    return bitmapTextSplit({
      text: this._originalText,
      style: this._style,
      chars: this._canReuseChars ? this.chars : []
    });
  }
};
_SplitBitmapText.defaultOptions = {
  autoSplit: true,
  // Auto-update on text/style changes
  lineAnchor: 0,
  // Top-left alignment
  wordAnchor: 0,
  // Top-left alignment
  charAnchor: 0
  // Top-left alignment
};
var SplitBitmapText = _SplitBitmapText;

// node_modules/pixi.js/lib/scene/text/utils/canvasTextSplit.mjs
function getAlignmentOffset(alignment, lineWidth, largestLine) {
  switch (alignment) {
    case "center":
      return (largestLine - lineWidth) / 2;
    case "right":
      return largestLine - lineWidth;
    case "left":
    default:
      return 0;
  }
}
function isNewlineCharacter(char) {
  return char === "\r" || char === "\n" || char === "\r\n";
}
var whitespaceRegex = /^\s*$/;
function groupTextSegments(segments, measuredText) {
  const groupedSegments = [];
  let currentLine = measuredText.lines[0];
  let matchedLine = "";
  let chars = [];
  let lineCount = 0;
  segments.forEach((segment) => {
    const isWhitespace = whitespaceRegex.test(segment);
    const isNewline2 = isNewlineCharacter(segment);
    const isSpaceAtStart = matchedLine.length === 0 && isWhitespace;
    if (isWhitespace && !isNewline2 && isSpaceAtStart && (!currentLine || !currentLine.startsWith(segment))) {
      return;
    }
    if (!isNewline2) matchedLine += segment;
    chars.push(segment);
    if (matchedLine.length >= currentLine.length) {
      groupedSegments.push({
        line: matchedLine,
        chars
      });
      chars = [];
      matchedLine = "";
      lineCount++;
      currentLine = measuredText.lines[lineCount];
    }
  });
  return groupedSegments;
}
function canvasTextSplit(options) {
  const { text, style, chars: existingChars } = options;
  const textStyle = style;
  const measuredText = CanvasTextMetrics.measureText(text, textStyle);
  if (measuredText.runsByLine && measuredText.runsByLine.length > 0) {
    return canvasTaggedTextSplitFromRuns(measuredText, textStyle, existingChars, text);
  }
  const segments = CanvasTextMetrics.graphemeSegmenter(text);
  const groupedSegments = groupTextSegments(segments, measuredText);
  const alignment = textStyle.align;
  const maxLineWidth = measuredText.lineWidths.reduce((max, line) => Math.max(max, line), 0);
  const fillGradient = textStyle._fill?.fill;
  const strokeGradient = textStyle._stroke?.fill;
  const hasFillGradient = fillGradient instanceof FillGradient;
  const hasStrokeGradient = strokeGradient instanceof FillGradient;
  const hasGradient = hasFillGradient || hasStrokeGradient;
  const hasLocalGradient = hasFillGradient && fillGradient.textureSpace === "local" || hasStrokeGradient && strokeGradient.textureSpace === "local";
  const fullTextWidth = measuredText.width;
  const fullTextHeight = measuredText.height;
  const baseCharStyle = textStyle.clone();
  baseCharStyle.align = "left";
  let trimOffsetX = 0;
  let trimOffsetY = 0;
  if (baseCharStyle.trim) {
    const { frame, canvasAndContext } = CanvasTextGenerator.getCanvasAndContext({
      text,
      style: textStyle,
      resolution: 1
    });
    CanvasTextGenerator.returnCanvasAndContext(canvasAndContext);
    trimOffsetX = -frame.x;
    trimOffsetY = -frame.y;
    baseCharStyle.trim = false;
  }
  const chars = [];
  const lineContainers = [];
  const wordContainers = [];
  let yOffset = 0;
  let existingCharIndex = 0;
  const gradientBounds = hasLocalGradient ? { width: fullTextWidth, height: fullTextHeight } : null;
  groupedSegments.forEach((group, lineIndex) => {
    const lineContainer = new Container({ label: `line-${lineIndex}` });
    lineContainer.y = yOffset + trimOffsetY;
    lineContainers.push(lineContainer);
    const lineWidth = measuredText.lineWidths[lineIndex];
    let xOffset = getAlignmentOffset(alignment, lineWidth, maxLineWidth);
    let currentWordContainer = new Container({ label: "word" });
    currentWordContainer.x = xOffset + trimOffsetX;
    const context = CanvasTextMetrics._context;
    context.font = baseCharStyle._fontString;
    if (CanvasTextMetrics.experimentalLetterSpacingSupported) {
      context.letterSpacing = "0px";
      context.textLetterSpacing = "0px";
    }
    let remainingLineText = group.line;
    let previousRemainingWidth = context.measureText(remainingLineText).width;
    group.chars.forEach((segment) => {
      if (isNewlineCharacter(segment)) {
        return;
      }
      remainingLineText = remainingLineText.slice(segment.length);
      const currentRemainingWidth = remainingLineText.length > 0 ? context.measureText(remainingLineText).width : 0;
      const charAdvance = previousRemainingWidth - currentRemainingWidth;
      previousRemainingWidth = currentRemainingWidth;
      if (charAdvance === 0) return;
      if (segment === " ") {
        if (currentWordContainer.children.length > 0) {
          wordContainers.push(currentWordContainer);
          lineContainer.addChild(currentWordContainer);
        }
        xOffset += charAdvance + textStyle.letterSpacing;
        currentWordContainer = new Container({ label: "word" });
        currentWordContainer.x = xOffset + trimOffsetX;
      } else {
        let charStyle = baseCharStyle;
        if (hasGradient) {
          charStyle = baseCharStyle.clone();
          charStyle._gradientOffset = { x: -xOffset, y: -yOffset };
          if (gradientBounds) {
            charStyle._gradientBounds = gradientBounds;
          }
        }
        let char;
        if (existingCharIndex < existingChars.length) {
          char = existingChars[existingCharIndex++];
          char.text = segment;
          char.style = charStyle;
          char.setFromMatrix(Matrix.IDENTITY);
          char.x = xOffset - currentWordContainer.x + trimOffsetX;
        } else {
          char = new Text({
            text: segment,
            style: charStyle,
            x: xOffset - currentWordContainer.x + trimOffsetX
          });
        }
        chars.push(char);
        currentWordContainer.addChild(char);
        xOffset += charAdvance + textStyle.letterSpacing;
      }
    });
    if (currentWordContainer.children.length > 0) {
      wordContainers.push(currentWordContainer);
      lineContainer.addChild(currentWordContainer);
    }
    if (alignment === "justify" && textStyle.wordWrap && lineIndex < groupedSegments.length - 1) {
      const lineWords = lineContainer.children;
      const wordGaps = lineWords.length - 1;
      if (wordGaps > 0) {
        const extraPerGap = (maxLineWidth - lineWidth) / wordGaps;
        for (let i = 1; i < lineWords.length; i++) {
          lineWords[i].x += i * extraPerGap;
        }
      }
    }
    yOffset += measuredText.lineHeight;
  });
  return { chars, lines: lineContainers, words: wordContainers };
}
function canvasTaggedTextSplitFromRuns(measuredText, textStyle, existingChars, text) {
  const { runsByLine } = measuredText;
  const alignment = textStyle.align;
  const maxLineWidth = measuredText.lineWidths.reduce((max, line) => Math.max(max, line), 0);
  let trimOffsetX = 0;
  let trimOffsetY = 0;
  if (textStyle.trim) {
    const { frame, canvasAndContext } = CanvasTextGenerator.getCanvasAndContext({
      text,
      style: textStyle,
      resolution: 1
    });
    CanvasTextGenerator.returnCanvasAndContext(canvasAndContext);
    trimOffsetX = -frame.x;
    trimOffsetY = -frame.y;
  }
  const chars = [];
  const lineContainers = [];
  const wordContainers = [];
  let yOffset = 0;
  let existingCharIndex = 0;
  runsByLine.forEach((lineRuns, lineIndex) => {
    const lineContainer = new Container({ label: `line-${lineIndex}` });
    lineContainer.y = yOffset + trimOffsetY;
    lineContainers.push(lineContainer);
    const lineWidth = measuredText.lineWidths[lineIndex];
    let xOffset = getAlignmentOffset(alignment, lineWidth, maxLineWidth);
    let currentWordContainer = new Container({ label: "word" });
    currentWordContainer.x = xOffset + trimOffsetX;
    for (const run of lineRuns) {
      const runStyle = run.style;
      const fillGradient = runStyle._fill?.fill;
      const strokeGradient = runStyle._stroke?.fill;
      const hasFillGradient = fillGradient instanceof FillGradient;
      const hasStrokeGradient = strokeGradient instanceof FillGradient;
      const hasGradient = hasFillGradient || hasStrokeGradient;
      const hasLocalGradient = hasFillGradient && fillGradient.textureSpace === "local" || hasStrokeGradient && strokeGradient.textureSpace === "local";
      const graphemes = CanvasTextMetrics.graphemeSegmenter(run.text);
      const baseRunStyle = runStyle.clone();
      baseRunStyle.align = "left";
      baseRunStyle.wordWrap = false;
      if (baseRunStyle.trim) baseRunStyle.trim = false;
      baseRunStyle.tagStyles = void 0;
      baseRunStyle["_lineHeight"] = 0;
      const context = CanvasTextMetrics._context;
      context.font = baseRunStyle._fontString;
      if (CanvasTextMetrics.experimentalLetterSpacingSupported) {
        context.letterSpacing = "0px";
        context.textLetterSpacing = "0px";
      }
      let remainingText = run.text;
      let previousRemainingWidth = context.measureText(remainingText).width;
      const runStartX = xOffset;
      const runTextWidth = previousRemainingWidth;
      const runFontProps = CanvasTextMetrics.measureFont(baseRunStyle._fontString);
      const runHeight = runStyle.lineHeight || runFontProps.fontSize;
      const runGradientBounds = hasLocalGradient ? { width: runTextWidth, height: runHeight } : null;
      for (const grapheme of graphemes) {
        remainingText = remainingText.slice(grapheme.length);
        const currentRemainingWidth = remainingText.length > 0 ? context.measureText(remainingText).width : 0;
        const charAdvance = previousRemainingWidth - currentRemainingWidth;
        previousRemainingWidth = currentRemainingWidth;
        if (isNewlineCharacter(grapheme)) continue;
        if (charAdvance === 0) continue;
        if (grapheme === " ") {
          if (currentWordContainer.children.length > 0) {
            wordContainers.push(currentWordContainer);
            lineContainer.addChild(currentWordContainer);
          }
          xOffset += charAdvance + runStyle.letterSpacing;
          currentWordContainer = new Container({ label: "word" });
          currentWordContainer.x = xOffset + trimOffsetX;
        } else {
          let charStyle = baseRunStyle;
          if (hasGradient) {
            charStyle = baseRunStyle.clone();
            if (hasLocalGradient) {
              charStyle._gradientOffset = { x: -(xOffset - runStartX), y: 0 };
              charStyle._gradientBounds = runGradientBounds;
            } else {
              charStyle._gradientOffset = { x: -(xOffset - runStartX), y: 0 };
            }
          }
          let char;
          if (existingCharIndex < existingChars.length) {
            char = existingChars[existingCharIndex++];
            char.text = grapheme;
            char.style = charStyle;
            char.setFromMatrix(Matrix.IDENTITY);
            char.x = xOffset - currentWordContainer.x + trimOffsetX;
          } else {
            char = new Text({
              text: grapheme,
              style: charStyle,
              x: xOffset - currentWordContainer.x + trimOffsetX
            });
          }
          chars.push(char);
          currentWordContainer.addChild(char);
          xOffset += charAdvance + runStyle.letterSpacing;
        }
      }
    }
    if (currentWordContainer.children.length > 0) {
      wordContainers.push(currentWordContainer);
      lineContainer.addChild(currentWordContainer);
    }
    if (alignment === "justify" && textStyle.wordWrap && lineIndex < runsByLine.length - 1) {
      const lineWords = lineContainer.children;
      const wordGaps = lineWords.length - 1;
      if (wordGaps > 0) {
        const extraPerGap = (maxLineWidth - lineWidth) / wordGaps;
        for (let i = 1; i < lineWords.length; i++) {
          lineWords[i].x += i * extraPerGap;
        }
      }
    }
    const lineHeight = measuredText.lineHeights?.[lineIndex] ?? measuredText.lineHeight;
    yOffset += lineHeight;
  });
  return { chars, lines: lineContainers, words: wordContainers };
}

// node_modules/pixi.js/lib/scene/text-split/SplitText.mjs
var _SplitText = class _SplitText2 extends AbstractSplitText {
  constructor(config) {
    const completeOptions = __spreadValues(__spreadValues({}, _SplitText2.defaultOptions), config);
    super(completeOptions);
  }
  /**
   * Creates a SplitText instance from an existing text object.
   * Useful for converting standard Text or Text objects into segmented versions.
   * @param text - The source text object to convert
   * @param options - Additional splitting options
   * @returns A new SplitText instance
   * @example
   * ```ts
   * const text = new Text({
   *   text: 'Bitmap Text',
   *   style: { fontFamily: 'Arial' }
   * });
   *
   * const segmented = SplitText.from(text);
   *
   * // with additional options
   * const segmentedWithOptions = SplitText.from(text, {
   *   autoSplit: false,
   *   lineAnchor: 0.5,
   *   wordAnchor: { x: 0, y: 0.5 },
   * })
   * ```
   */
  static from(text, options) {
    const completeOptions = __spreadProps(__spreadValues(__spreadValues({}, _SplitText2.defaultOptions), options), {
      text: text.text,
      style: new TextStyle(text.style)
    });
    const splitText = new _SplitText2(__spreadValues({}, completeOptions));
    const anchor = text.anchor;
    if (anchor.x !== 0 || anchor.y !== 0) {
      splitText.pivot.set(
        splitText.width * anchor.x,
        splitText.height * anchor.y
      );
    }
    return splitText;
  }
  splitFn() {
    return canvasTextSplit({
      text: this._originalText,
      style: this._style,
      chars: this._canReuseChars ? this.chars : []
    });
  }
};
_SplitText.defaultOptions = {
  autoSplit: true,
  // Auto-update on text/style changes
  lineAnchor: 0,
  // Top-left alignment
  wordAnchor: 0,
  // Top-left alignment
  charAnchor: 0
  // Top-left alignment
};
var SplitText = _SplitText;

// node_modules/pixi.js/lib/scene/text/utils/generateTextStyleKey.mjs
var valuesToIterateForKeys = [
  "align",
  "breakWords",
  "cssOverrides",
  "fontVariant",
  "fontWeight",
  "leading",
  "letterSpacing",
  "lineHeight",
  "padding",
  "textBaseline",
  "trim",
  "whiteSpace",
  "wordWrap",
  "wordWrapWidth",
  "fontFamily",
  "fontStyle",
  "fontSize"
];
function generateTextStyleKey(style) {
  const key = [];
  let index = 0;
  for (let i = 0; i < valuesToIterateForKeys.length; i++) {
    const prop = `_${valuesToIterateForKeys[i]}`;
    key[index++] = style[prop];
  }
  index = addFillStyleKey(style._fill, key, index);
  index = addStokeStyleKey(style._stroke, key, index);
  index = addDropShadowKey(style.dropShadow, key, index);
  index = addFiltersKey(style.filters, key, index);
  return key.join("-");
}
function addFiltersKey(filters, key, index) {
  if (!filters) return index;
  for (const filter of filters) {
    key[index++] = filter.uid;
  }
  return index;
}
function addFillStyleKey(fillStyle, key, index) {
  if (!fillStyle) return index;
  key[index++] = fillStyle.color;
  key[index++] = fillStyle.alpha;
  key[index++] = fillStyle.fill?.styleKey;
  return index;
}
function addStokeStyleKey(strokeStyle, key, index) {
  if (!strokeStyle) return index;
  index = addFillStyleKey(strokeStyle, key, index);
  key[index++] = strokeStyle.width;
  key[index++] = strokeStyle.alignment;
  key[index++] = strokeStyle.cap;
  key[index++] = strokeStyle.join;
  key[index++] = strokeStyle.miterLimit;
  return index;
}
function addDropShadowKey(dropShadow, key, index) {
  if (!dropShadow) return index;
  key[index++] = dropShadow.alpha;
  key[index++] = dropShadow.angle;
  key[index++] = dropShadow.blur;
  key[index++] = dropShadow.distance;
  key[index++] = Color.shared.setValue(dropShadow.color).toNumber();
  return index;
}

// node_modules/pixi.js/lib/utils/logging/logDebugTexture.mjs
function logDebugTexture(texture, renderer, size = 200) {
  return __async(this, null, function* () {
    const base64 = yield renderer.extract.base64(texture);
    if (renderer.type !== RendererType.CANVAS) {
      yield renderer.encoder.commandFinished;
    }
    const width = size;
    console.log(`logging texture ${texture.source.width}px ${texture.source.height}px`);
    const style = [
      "font-size: 1px;",
      `padding: ${width}px ${300}px;`,
      `background: url(${base64}) no-repeat;`,
      "background-size: contain;"
    ].join(" ");
    console.log("%c ", style);
  });
}

// node_modules/pixi.js/lib/utils/logging/logScene.mjs
var colors = [
  "#000080",
  // Navy Blue
  "#228B22",
  // Forest Green
  "#8B0000",
  // Dark Red
  "#4169E1",
  // Royal Blue
  "#008080",
  // Teal
  "#800000",
  // Maroon
  "#9400D3",
  // Dark Violet
  "#FF8C00",
  // Dark Orange
  "#556B2F",
  // Olive Green
  "#8B008B"
  // Dark Magenta
];
var colorTick = 0;
function logScene(container, depth = 0, data = { color: "#000000" }) {
  if (container.renderGroup) {
    data.color = colors[colorTick++];
  }
  let spaces = "";
  for (let i = 0; i < depth; i++) {
    spaces += "    ";
  }
  let label = container.label;
  if (!label && container instanceof Sprite) {
    label = `sprite:${container.texture.label}`;
  }
  let output = `%c ${spaces}|- ${label} (worldX:${container.worldTransform.tx}, relativeRenderX:${container.relativeGroupTransform.tx}, renderX:${container.groupTransform.tx}, localX:${container.x})`;
  if (container.renderGroup) {
    output += " (RenderGroup)";
  }
  if (container.filters) {
    output += "(*filters)";
  }
  console.log(output, `color:${data.color}; font-weight:bold;`);
  depth++;
  for (let i = 0; i < container.children.length; i++) {
    const child = container.children[i];
    logScene(child, depth, __spreadValues({}, data));
  }
}
function logRenderGroupScene(renderGroup, depth = 0, data = { index: 0, color: "#000000" }) {
  let spaces = "";
  for (let i = 0; i < depth; i++) {
    spaces += "    ";
  }
  const output = `%c ${spaces}- ${data.index}: ${renderGroup.root.label} worldX:${renderGroup.worldTransform.tx}`;
  console.log(output, `color:${data.color}; font-weight:bold;`);
  depth++;
  for (let i = 0; i < renderGroup.renderGroupChildren.length; i++) {
    const child = renderGroup.renderGroupChildren[i];
    logRenderGroupScene(child, depth, __spreadProps(__spreadValues({}, data), { index: i }));
  }
}

// node_modules/pixi.js/lib/index.mjs
extensions.add(browserExt, webworkerExt);
export {
  AbstractBitmapFont,
  AbstractBitmapTextPipe,
  AbstractRenderer,
  AbstractSplitText,
  AbstractText,
  AbstractTextSystem,
  AccessibilitySystem,
  AlphaFilter,
  AlphaMask,
  AlphaMaskPipe,
  AnimatedSprite,
  Application,
  ApplicationInitHook,
  Assets,
  AssetsClass,
  BLEND_TO_NPM,
  BREAKING_SPACES,
  BREAKING_SPACES_SET,
  BREAK_AFTER_CHARS,
  BREAK_AFTER_CHARS_SET,
  BUFFER_TYPE,
  BackgroundLoader,
  BackgroundSystem,
  Batch,
  BatchGeometry,
  BatchTextureArray,
  BatchableGraphics,
  BatchableHTMLText,
  BatchableMesh,
  BatchableSprite,
  BatchableText,
  Batcher,
  BatcherPipe,
  BigPool,
  BindGroup,
  BindGroupSystem,
  BitmapFont,
  BitmapFontManager,
  BitmapText,
  BitmapTextGraphics,
  BitmapTextPipe,
  BlendModeFilter,
  BlendModePipe,
  BlurFilter,
  BlurFilterPass,
  Bounds,
  BrowserAdapter,
  Buffer,
  BufferImageSource,
  BufferResource,
  BufferUsage,
  CLEAR,
  COLLAPSIBLE_SPACES,
  COLLAPSIBLE_SPACES_SET,
  Cache,
  CanvasBatchAdaptor,
  CanvasBitmapTextPipe,
  CanvasColorMaskPipe,
  CanvasContextSystem,
  CanvasFilterSystem,
  CanvasGraphicsAdaptor,
  CanvasGraphicsContextSystem,
  CanvasGraphicsPipe,
  CanvasLimitsSystem,
  CanvasNineSliceSpritePipe,
  CanvasObserver,
  CanvasParticleContainerAdaptor,
  CanvasParticleContainerPipe,
  CanvasPool,
  CanvasPoolClass,
  CanvasRenderTargetAdaptor,
  CanvasRenderTargetSystem,
  CanvasRenderer,
  CanvasRendererTextSystem,
  CanvasSource,
  CanvasStencilMaskPipe,
  CanvasTextGenerator,
  CanvasTextMetrics,
  CanvasTextPipe,
  CanvasTextSystem,
  CanvasTextureSystem,
  CanvasTilingSpritePipe,
  Circle,
  Color,
  ColorBlend,
  ColorBurnBlend,
  ColorDodgeBlend,
  ColorMask,
  ColorMaskPipe,
  ColorMatrixFilter,
  CompressedSource,
  Container,
  CubeTexture,
  CubeTextureSource,
  Culler,
  CullerPlugin,
  CustomRenderPipe,
  D3D10_RESOURCE_DIMENSION,
  D3DFMT,
  DATA_URI,
  DDS,
  DEG_TO_RAD,
  DEPRECATED_SCALE_MODES,
  DEPRECATED_WRAP_MODES,
  DOMAdapter,
  DOMContainer,
  DOMPipe,
  DRAW_MODES,
  DXGI_FORMAT,
  DXGI_TO_TEXTURE_FORMAT,
  DarkenBlend,
  DefaultBatcher,
  DefaultShader,
  DifferenceBlend,
  DisplacementFilter,
  DivideBlend,
  DynamicBitmapFont,
  Ellipse,
  EventBoundary,
  eventemitter3_default as EventEmitter,
  EventSystem,
  EventsTicker,
  ExclusionBlend,
  ExtensionType,
  ExternalSource,
  ExtractSystem,
  FOURCC_TO_TEXTURE_FORMAT,
  FederatedContainer,
  FederatedEvent,
  FederatedMouseEvent,
  FederatedPointerEvent,
  FederatedWheelEvent,
  FillGradient,
  FillPattern,
  Filter,
  FilterEffect,
  FilterPipe,
  FilterSystem,
  FontStylePromiseCache,
  GAUSSIAN_VALUES,
  GCManagedHash,
  GCSystem,
  GL_FORMATS,
  GL_INTERNAL_FORMAT,
  GL_TARGETS,
  GL_TYPES,
  GL_WRAP_MODES,
  GPUTextureGpuData,
  GenerateTextureSystem,
  Geometry,
  GlBackBufferSystem,
  GlBatchAdaptor,
  GlBuffer,
  GlBufferSystem,
  GlColorMaskSystem,
  GlContextSystem,
  GlEncoderSystem,
  GlGeometryGpuData,
  GlGeometrySystem,
  GlGraphicsAdaptor,
  GlLimitsSystem,
  GlMeshAdaptor,
  GlParticleContainerAdaptor,
  GlParticleContainerPipe,
  GlProgram,
  GlProgramData,
  GlRenderTarget,
  GlRenderTargetAdaptor,
  GlRenderTargetSystem,
  GlShaderSystem,
  GlStateSystem,
  GlStencilSystem,
  GlTexture,
  GlTextureSystem,
  GlUboSystem,
  GlUniformGroupSystem,
  GlobalResourceRegistry,
  GlobalUniformSystem,
  Gpu3dMipmapGenerator,
  GpuBatchAdaptor,
  GpuBlendModesToPixi,
  GpuBufferData,
  GpuBufferSystem,
  GpuColorMaskSystem,
  GpuDeviceSystem,
  GpuEncoderSystem,
  GpuGraphicsAdaptor,
  GpuGraphicsContext,
  GpuLimitsSystem,
  GpuMeshAdapter,
  GpuMipmapGenerator,
  GpuMsaaRestore,
  GpuParticleContainerAdaptor,
  GpuParticleContainerPipe,
  GpuProgram,
  GpuRenderTarget,
  GpuRenderTargetAdaptor,
  GpuRenderTargetSystem,
  GpuShaderSystem,
  GpuStateSystem,
  GpuStencilModesToPixi,
  GpuStencilSystem,
  GpuTextureSystem,
  GpuUboSystem,
  GpuUniformBatchPipe,
  Graphics,
  GraphicsContext,
  GraphicsContextRenderData,
  GraphicsContextSystem,
  GraphicsGpuData,
  GraphicsPath,
  GraphicsPipe,
  HTMLText,
  HTMLTextPipe,
  HTMLTextRenderData,
  HTMLTextStyle,
  HTMLTextSystem,
  HardLightBlend,
  HardMixBlend,
  HelloSystem,
  IGLUniformData,
  ImageSource,
  InstructionSet,
  KTX,
  LightenBlend,
  LinearBurnBlend,
  LinearDodgeBlend,
  LinearLightBlend,
  Loader,
  LoaderParserPriority,
  LuminosityBlend,
  MaskEffectManager,
  MaskEffectManagerClass,
  MaskFilter,
  Matrix,
  Mesh,
  MeshGeometry,
  MeshGpuData,
  MeshPipe,
  MeshPlane,
  MeshRope,
  MeshSimple,
  NEWLINES,
  NEWLINES_SET,
  NEWLINE_MATCH_REGEX,
  NEWLINE_SPLIT_REGEX,
  NOOP,
  NegationBlend,
  NineSliceGeometry,
  NineSlicePlane,
  NineSliceSprite,
  NineSliceSpriteGpuData,
  NineSliceSpritePipe,
  NoiseFilter,
  ObservablePoint,
  OverlayBlend,
  PI_2,
  Particle,
  ParticleBuffer,
  ParticleContainer,
  ParticleContainerPipe,
  ParticleShader,
  PassthroughFilter,
  PerspectiveMesh,
  PerspectivePlaneGeometry,
  PinLightBlend,
  PipelineSystem,
  PlaneGeometry,
  Point,
  Polygon,
  Pool,
  PoolGroupClass,
  PrepareBase,
  PrepareQueue,
  PrepareSystem,
  PrepareUpload,
  QuadGeometry,
  RAD_TO_DEG,
  Rectangle,
  RenderBundle,
  RenderContainer,
  RenderGroup,
  RenderGroupPipe,
  RenderGroupSystem,
  RenderLayer,
  RenderTarget,
  RenderTargetSystem,
  RenderTexture,
  RenderableGCSystem,
  RendererInitHook,
  RendererType,
  ResizePlugin,
  Resolver,
  RopeGeometry,
  RoundedRectangle,
  SCALE_MODES,
  STATE_BITS,
  STENCIL_MODES,
  SVGDefsCollector,
  SVGParser,
  SaturationBlend,
  SchedulerSystem,
  ScissorMask,
  ScreenSizeRegistry,
  SdfShader,
  Shader,
  ShaderOverrides,
  ShaderStage,
  ShapePath,
  SharedRenderPipes,
  SharedSystems,
  SoftLightBlend,
  SplitBitmapText,
  SplitText,
  Sprite,
  SpritePipe,
  Spritesheet,
  State,
  StencilMask,
  StencilMaskPipe,
  SubtractBlend,
  SystemRunner,
  TEXTURE_FORMAT_BLOCK_SIZE,
  Text,
  TextStyle,
  Texture,
  TextureGCSystem,
  TextureMatrix,
  TexturePool,
  TexturePoolClass,
  TextureSource,
  TextureStyle,
  TextureUvs,
  TextureView,
  Ticker,
  TickerListener,
  TickerPlugin,
  TilingSprite,
  TilingSpriteGpuData,
  TilingSpritePipe,
  TilingSpriteShader,
  Transform,
  Triangle,
  UNIFORM_TO_ARRAY_SETTERS,
  UNIFORM_TO_SINGLE_SETTERS,
  UNIFORM_TYPES_MAP,
  UNIFORM_TYPES_VALUES,
  UPDATE_BLEND,
  UPDATE_COLOR,
  UPDATE_PRIORITY,
  UPDATE_TRANSFORM,
  UPDATE_VISIBLE,
  UboBatch,
  UboSystem,
  UniformGroup,
  VERSION,
  VideoSource,
  ViewContainer,
  ViewSystem,
  ViewableBuffer,
  VividLightBlend,
  WGSL_ALIGN_SIZE_DATA,
  WGSL_TO_STD40_SIZE,
  WRAP_MODES,
  WebGLRenderer,
  WebGPURenderer,
  WebWorkerAdapter,
  WorkerManager,
  accessibilityTarget,
  addBits,
  addMaskBounds,
  addMaskLocalBounds,
  addProgramDefines,
  fragment3 as alphaFrag,
  source3 as alphaWgsl,
  appendSVGPath,
  applyMatrix,
  applyProjectiveTransformationToPlane,
  applyStyleParams,
  assertMipmap3dTexture,
  assignWithIgnore,
  autoDetectEnvironment,
  autoDetectRenderer,
  autoDetectSource,
  bakeOverridesIntoSource,
  basisTranscoderUrls,
  bgr2rgb,
  bitmapFontCachePlugin,
  bitmapFontTextParser,
  bitmapFontXMLParser,
  bitmapFontXMLStringParser,
  bitmapTextSplit,
  blendTemplateFrag,
  blendTemplateVert,
  blendTemplate as blendTemplateWgsl,
  blockDataMap,
  source4 as blurTemplateWgsl,
  boundsPool,
  browserExt,
  buildAdaptiveBezier,
  buildAdaptiveQuadratic,
  buildArc,
  buildArcTo,
  buildArcToSvg,
  buildCircle,
  buildContextBatches,
  buildEllipse,
  buildGeometryFromPath,
  buildLine,
  buildPixelLine,
  buildPolygon,
  buildRectangle,
  buildRoundedRectangle,
  buildSVGFillAttributes,
  buildSVGPath,
  buildSVGStrokeAttributes,
  buildSimpleUvs,
  buildTriangle,
  buildUvs,
  cacheAsTextureMixin,
  cacheTextureArray,
  calculatePathArea,
  calculateProjection,
  canUseNewCanvasBlendModes,
  canvasTextSplit,
  canvasUtils,
  checkChildrenDidChange,
  checkDataUrl,
  checkExtension,
  checkForNestedPattern,
  checkMaxIfStatementsInShader,
  childrenHelperMixin,
  cleanArray,
  cleanHash,
  clearList,
  closePointEps,
  collapseNewlines,
  collapseSpaces,
  collectAllRenderables,
  collectRenderablesMixin,
  color32BitToUniform,
  colorBit,
  colorBitGl,
  fragment4 as colorMatrixFilterFrag,
  source5 as colorMatrixFilterWgsl,
  colorToUniform,
  compareModeToGlCompare,
  compileBufferSync,
  compileHighShader,
  compileHighShaderGl,
  compileHighShaderGlProgram,
  compileHighShaderGpuProgram,
  compileHooks,
  compileInputs,
  compileOutputs,
  compileShader,
  compute2DProjection,
  convertFormatIfRequired,
  convertToList,
  copySearchParams,
  createGlUploadCubeTextureResource,
  createGpuUploadCubeTextureResource,
  createIdFromString,
  createIndicesForQuads,
  createLevelBuffers,
  createLevelBuffersFromKTX,
  createStringVariations,
  createTexture,
  createUboElementsSTD40,
  createUboElementsWGSL,
  createUboSyncFunctionSTD40,
  createUboSyncFunctionWGSL,
  crossOrigin,
  cullingMixin,
  curveEps,
  vertex as defaultFilterVert,
  defaultValue,
  definedProps,
  deprecation,
  detectAvif,
  detectBasis,
  detectCompressed,
  detectDefaults,
  detectMp4,
  detectOgv,
  detectVideoAlphaMode,
  detectWebm,
  detectWebp,
  determineCrossOrigin,
  fragment5 as displacementFrag,
  vertex3 as displacementVert,
  source6 as displacementWgsl,
  earcut,
  effectsMixin,
  ensureAttributes,
  ensureIsBuffer,
  ensurePrecision,
  ensureTextOptions,
  executeInstructions,
  extensions,
  extractAttributesFromGlProgram,
  extractAttributesFromGpuProgram,
  extractFontFamilies,
  extractStructAndGroups,
  extractSubpaths,
  extractSvgUrlId,
  fastCopy,
  findMixin,
  fontStringFromTextStyle,
  formatShader,
  fragmentGPUTemplate,
  fragmentGlTemplate,
  generateArraySyncSTD40,
  generateArraySyncWGSL,
  generateBlurFragSource,
  generateBlurGlProgram,
  generateBlurProgram,
  generateBlurVertSource,
  generateGPULayout,
  generateGpuLayoutGroups,
  generateLayout,
  generateLayoutHash,
  generateParticleUpdateFunction,
  generateProgram,
  generateShaderSyncCode,
  generateTextStyleKey,
  generateTextureBatchBit,
  generateTextureBatchBitGl,
  generateTextureMatrix,
  generateUniformsSync,
  getAdjustedBlendModeBlend,
  getAttributeInfoFromFormat,
  getBatchSamplersUniformGroup,
  getBitmapTextLayout,
  getCanvasBoundingBox,
  getCanvasFillStyle,
  getCanvasTexture,
  getCharacterGroups,
  getDefaultUniformValue,
  getFastGlobalBounds,
  getFastGlobalBoundsMixin,
  getFillInstructionData,
  getFontCss,
  getFontFamilyName,
  getGeometryBounds,
  getGlTypeFromFormat,
  getGlobalBounds,
  getGlobalMixin,
  getGlobalRenderableBounds,
  getLocalBounds,
  getMaxFragmentPrecision,
  getMaxMiterRatio,
  getMaxTexturesPerBatch,
  getOrientationOfPoints,
  getPlainText,
  getPo2TextureFromSource,
  getResolutionOfUrl,
  getSVGUrl,
  getSupportedCompressedTextureFormats,
  getSupportedGPUCompressedTextureFormats,
  getSupportedGlCompressedTextureFormats,
  getSupportedTextureFormats,
  getTemporaryCanvasFromImage,
  getTestContext,
  getTexelRangeRects,
  getTextureBatchBindGroup,
  getTextureDefaultMatrix,
  getTextureFormatFromKTXTexture,
  getUboData,
  getUniformData,
  getUrlExtension,
  glFormatToGPUFormat,
  glUploadBufferImageResource,
  glUploadCompressedTextureResource,
  glUploadImageResource,
  glUploadVideoResource,
  globalUniformsBit,
  globalUniformsBitGl,
  globalUniformsUBOBitGl,
  gpuFormatToBasisTranscoderFormat,
  gpuFormatToKTXBasisTranscoderFormat,
  gpuUploadBufferImageResource,
  gpuUploadCompressedTextureResource,
  gpuUploadImageResource,
  gpuUploadVideoResource,
  graphicsContextToSvg,
  groupD8,
  hasCachedCanvasTexture,
  hasTagMarkup,
  hasTagStyles,
  hsl as hslWgsl,
  hslgl,
  hslgpu,
  injectBits,
  insertVersion,
  isBreakAfterChar,
  isBreakingSpace,
  isCanvasFilterCapable,
  isCollapsibleSpace,
  isIntegerFormat,
  isMobile,
  isNewline,
  isPow2,
  isRenderingToScreen,
  isSafari,
  isSingleItem,
  isWebGLSupported,
  isWebGPUSupported,
  ktxTranscoderUrls,
  loadBasis,
  loadBasisOnWorker,
  loadBitmapFont,
  loadDDS,
  loadEnvironmentExtensions,
  loadFontAsBase64,
  loadFontCSS,
  loadImageBitmap,
  loadJson,
  loadKTX,
  loadKTX2,
  loadKTX2onWorker,
  loadSVGImage,
  loadSvg,
  loadTextures,
  loadTxt,
  loadVideoTextures,
  loadWebFont,
  localUniformBit,
  localUniformBitGl,
  localUniformBitGroup2,
  localUniformMSDFBit,
  localUniformMSDFBitGl,
  log2,
  logDebugTexture,
  logProgramError,
  logRenderGroupScene,
  logScene,
  mSDFBit,
  mSDFBitGl,
  mapCanvasBlendModesToPixi,
  mapFormatToGlFormat,
  mapFormatToGlInternalFormat,
  mapFormatToGlType,
  mapGlToVertexFormat,
  mapSize,
  mapType,
  mapViewDimensionToGlTarget,
  mapWebGLBlendModesToPixi,
  fragment2 as maskFrag,
  vertex2 as maskVert,
  source2 as maskWgsl,
  matrixPool,
  measureHtmlText,
  measureMixin,
  measureTaggedText,
  migrateFragmentFromV7toV8,
  mipmapScaleModeToGlFilter,
  multiplyColors,
  multiplyHexColors,
  nextPow2,
  fragment6 as noiseFrag,
  source7 as noiseWgsl,
  nonCompressedFormats,
  normalizeExtensionPriority,
  onRenderMixin,
  parseDDS,
  parseFunctionBody,
  parseKTX,
  parseSVGDefinitions,
  parseSVGFloatAttribute,
  parseSVGPath,
  parseSVGStyle,
  parseTaggedText,
  particleData,
  fragment7 as particlesFrag,
  vertex4 as particlesVert,
  wgsl as particlesWgsl,
  fragment as passthroughFrag,
  source as passthroughWgsl,
  path,
  pointInTriangle,
  preloadVideo,
  removeItems,
  removeStructAndGroupDuplicates,
  resetUids,
  resolveCharacters,
  resolveCompressedTextureUrl,
  resolveJsonUrl,
  resolveTextureUrl,
  resourceToTexture,
  roundPixelsBit,
  roundPixelsBitGl,
  roundedShapeArc,
  roundedShapeQuadraticCurve,
  sayHello,
  scaleModeToGlFilter,
  setBasisTranscoderPath,
  setKTXTranscoderPath,
  setPositions,
  setProgramName,
  setUvs,
  shapeBuilders,
  sortMixin,
  spritesheetAsset,
  squaredDistanceToLineSegment,
  stripVersion,
  styleAttributes,
  testImageFormat,
  testVideoFormat,
  textStyleToCSS,
  textureBit,
  textureBitGl,
  textureFrom,
  tilingBit,
  tilingBitGl,
  toFillStyle,
  toLocalGlobalMixin,
  toStrokeStyle,
  tokenize,
  tokenizeTaggedRuns,
  transformVertices,
  triangulateWithHoles,
  trimRight,
  uboSyncFunctionsSTD40,
  uboSyncFunctionsWGSL,
  uid,
  uniformParsers,
  unpremultiplyAlpha,
  unsafeEvalSupported,
  updateLocalTransform,
  updateQuadBounds,
  updateRenderGroupTransform,
  updateRenderGroupTransforms,
  updateTextBounds,
  updateTransformAndChildren,
  updateTransformBackwards,
  updateWorldTransform,
  v8_0_0,
  v8_21_0,
  v8_22_0,
  v8_3_4,
  validFormats,
  validateRenderables,
  vertexGPUTemplate,
  vertexGlTemplate,
  vkFormatToGPUFormat,
  warn,
  warnIgnoredTextureStyle,
  webworkerExt,
  wordWrap,
  wordWrapTaggedLines,
  wrapModeToGlAddress
};
//# sourceMappingURL=pixi__js.js.map
