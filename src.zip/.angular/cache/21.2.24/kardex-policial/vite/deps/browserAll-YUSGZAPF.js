import {
  AccessibilitySystem,
  DOMPipe,
  EventSystem,
  FederatedContainer,
  accessibilityTarget
} from "./chunk-EYAHMOIP.js";
import "./chunk-EADIHTGU.js";
import "./chunk-2TIJWRQZ.js";
import {
  Container
} from "./chunk-RSU6N5IH.js";
import "./chunk-A5DJO54Z.js";
import "./chunk-DBITZEUE.js";
import {
  extensions
} from "./chunk-YC5XMVVP.js";
import "./chunk-I6DCS273.js";

// node_modules/pixi.js/lib/accessibility/init.mjs
extensions.add(AccessibilitySystem);
extensions.mixin(Container, accessibilityTarget);

// node_modules/pixi.js/lib/dom/init.mjs
extensions.add(DOMPipe);

// node_modules/pixi.js/lib/events/init.mjs
extensions.add(EventSystem);
extensions.mixin(Container, FederatedContainer);
//# sourceMappingURL=browserAll-YUSGZAPF.js.map
